/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.windows;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.client.api.Operation;
/*    */ import com.pnfsoftware.jeb.rcpclient.handlers.OperationHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WindowOpenNewView
/*    */   extends OperationHandler
/*    */ {
/*    */   public WindowOpenNewView()
/*    */   {
/* 22 */     super(Operation.VIEW_NEW, null, S.s(530), null, null);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\windows\WindowOpenNewView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */