/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionConvertHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionConvertHandler()
/*    */   {
/* 21 */     super(5, "convert", S.s(469), "Apply a conversion operation (eg, change the base of a number)", "eclipse/loop_obj.png", 66);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionConvertHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */