/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionRenameHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionRenameHandler()
/*    */   {
/* 21 */     super(2, "rename", S.s(547), null, "eclipse/write_obj.png", 78);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionRenameHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */