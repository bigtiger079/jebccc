/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionXrefHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionXrefHandler()
/*    */   {
/* 21 */     super(4, "queryXrefs", S.s(583), "View the cross-references of an item", "eclipse/search_ref_obj.png", 88);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionXrefHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */