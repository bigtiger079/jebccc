/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionOverridesHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionOverridesHandler()
/*    */   {
/* 22 */     super(13, "queryOverrides", S.s(534), "", "eclipse/super_co.png", 79);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionOverridesHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */