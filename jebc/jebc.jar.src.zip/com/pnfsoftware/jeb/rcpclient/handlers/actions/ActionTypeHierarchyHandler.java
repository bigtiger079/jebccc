/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionTypeHierarchyHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionTypeHierarchyHandler()
/*    */   {
/* 21 */     super(12, "queryTypeHierarchy", S.s(579), "", "eclipse/types.png", 72);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionTypeHierarchyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */