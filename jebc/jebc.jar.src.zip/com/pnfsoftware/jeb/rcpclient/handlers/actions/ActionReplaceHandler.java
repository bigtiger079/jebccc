/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionReplaceHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionReplaceHandler()
/*    */   {
/* 22 */     super(6, "replace", "Replace...", null, "eclipse/correction_cast.png", SWT.MOD1 | 0x4E);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionReplaceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */