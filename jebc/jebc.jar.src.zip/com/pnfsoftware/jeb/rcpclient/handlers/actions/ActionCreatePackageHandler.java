/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionCreatePackageHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionCreatePackageHandler()
/*    */   {
/* 21 */     super(10, "createPackage", S.s(471), "", "eclipse/package_obj.png", 75);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionCreatePackageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */