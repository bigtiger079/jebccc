/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionDeleteHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionDeleteHandler()
/*    */   {
/* 23 */     super(1, "delete", S.s(482), "Delete an item and cascade changes to connected items", "eclipse/delete_obj.png", 127);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionDeleteHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */