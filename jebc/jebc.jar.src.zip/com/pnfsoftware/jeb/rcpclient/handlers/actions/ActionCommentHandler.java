/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionCommentHandler
/*    */   extends ActionGenericHandler
/*    */ {
/*    */   public ActionCommentHandler()
/*    */   {
/* 21 */     super(3, "comment", S.s(468), "", "eclipse/comment_edit.png", 47);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\actions\ActionCommentHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */