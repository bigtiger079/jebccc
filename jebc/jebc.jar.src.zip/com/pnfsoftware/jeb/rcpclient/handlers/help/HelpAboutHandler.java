/*    */ package com.pnfsoftware.jeb.rcpclient.handlers.help;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.AboutDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.handlers.JebBaseHandler;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelpAboutHandler
/*    */   extends JebBaseHandler
/*    */ {
/* 23 */   private static final ILogger logger = GlobalLog.getLogger(HelpAboutHandler.class);
/*    */   
/*    */   public HelpAboutHandler() {
/* 26 */     super(null, S.s(458), null, "jeb1/icon-jeb.png");
/*    */   }
/*    */   
/*    */   public boolean canExecute()
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void execute()
/*    */   {
/* 36 */     new AboutDialog(this.shell, this.context).open();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\handlers\help\HelpAboutHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */