/*     */ package com.pnfsoftware.jeb.rcpclient.actions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.client.api.IUnitFragment;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionCommentData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionContext;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionConvertData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionCreatePackageData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionDeleteData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionMoveToPackageData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionOverridesData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionRenameData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionReplaceData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionTypeHierarchyData;
/*     */ import com.pnfsoftware.jeb.core.actions.ActionXrefsData;
/*     */ import com.pnfsoftware.jeb.core.output.text.ICoordinates;
/*     */ import com.pnfsoftware.jeb.core.units.IInteractiveUnit;
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.ICodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.ISourceUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.CodeConstant;
/*     */ import com.pnfsoftware.jeb.core.util.DecompilerHelper;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.CodeHierarchyDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.CommentDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.CreatePackageDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.MoveToPackageDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.ReferencesDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.RenameItemDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.nativecode.NamedConstantsChooserDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.handlers.nativeactions.NativeActionUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.PartManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.UnitPartManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.IRcpUnitFragment;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.InteractiveTextView;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicalActionExecutor
/*     */ {
/*  62 */   private static final ILogger logger = GlobalLog.getLogger(GraphicalActionExecutor.class);
/*     */   
/*     */ 
/*     */   private Shell shell;
/*     */   
/*     */ 
/*     */   private RcpClientContext context;
/*     */   
/*     */ 
/*     */ 
/*     */   public GraphicalActionExecutor(Shell shell, RcpClientContext context)
/*     */   {
/*  74 */     this.shell = shell;
/*  75 */     this.context = context;
/*     */   }
/*     */   
/*     */   public boolean execute(ActionUIContext uictx) {
/*  79 */     return execute(uictx, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean execute(ActionUIContext uictx, Object value)
/*     */   {
/*  91 */     logger.i("Executing: %s", new Object[] { uictx });
/*  92 */     ActionContext info = uictx.getActionContext();
/*     */     
/*  94 */     switch (info.getActionId()) {
/*     */     case 2: 
/*  96 */       ActionRenameData data = new ActionRenameData();
/*  97 */       if (info.getUnit().prepareExecution(info, data)) {
/*  98 */         String newName = null;
/*  99 */         if (value == null)
/*     */         {
/* 101 */           RenameItemDialog dlg = new RenameItemDialog(this.shell, RcpClientContext.getStandardRenamingHistory(this.context));
/* 102 */           dlg.setDescription(data.getDescription());
/* 103 */           dlg.setInitialValue(data.getCurrentName());
/* 104 */           dlg.setOriginalValue(data.getOriginalName());
/* 105 */           newName = dlg.open();
/*     */         }
/*     */         else {
/* 108 */           newName = value.toString();
/*     */         }
/* 110 */         if (newName != null) {
/* 111 */           data.setNewName(newName);
/* 112 */           return info.getUnit().executeAction(info, data);
/*     */         } }
/* 114 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/* 118 */       ActionCommentData data = new ActionCommentData();
/* 119 */       if (info.getUnit().prepareExecution(info, data)) {
/* 120 */         String address = info.getAddress();
/* 121 */         if (address != null) {
/* 122 */           String newComment = null;
/* 123 */           if (value == null) {
/* 124 */             CommentDialog dlg = new CommentDialog(this.shell, address);
/* 125 */             dlg.setDescription(data.getDescription());
/* 126 */             dlg.setInitialComment(data.getComment());
/* 127 */             newComment = dlg.open();
/*     */           }
/*     */           else {
/* 130 */             newComment = value.toString();
/*     */           }
/* 132 */           if (newComment != null) {
/* 133 */             data.setNewComment(newComment);
/* 134 */             return info.getUnit().executeAction(info, data);
/*     */           }
/*     */         } }
/* 137 */       break;
/*     */     
/*     */ 
/*     */     case 10: 
/* 141 */       ActionCreatePackageData data = new ActionCreatePackageData();
/* 142 */       if (info.getUnit().prepareExecution(info, data)) {
/* 143 */         String fqname = null;
/* 144 */         if (value == null)
/*     */         {
/* 146 */           CreatePackageDialog dlg = new CreatePackageDialog(this.shell, RcpClientContext.getStandardRenamingHistory(this.context));
/* 147 */           dlg.setDescription(data.getDescription());
/* 148 */           dlg.setInitialValue(data.getCurrentPackageFqname());
/* 149 */           fqname = dlg.open();
/*     */         }
/*     */         else {
/* 152 */           fqname = value.toString();
/*     */         }
/* 154 */         if (fqname != null) {
/* 155 */           data.setFqname(fqname);
/* 156 */           return info.getUnit().executeAction(info, data);
/*     */         } }
/* 158 */       break;
/*     */     
/*     */ 
/*     */     case 11: 
/* 162 */       ActionMoveToPackageData data = new ActionMoveToPackageData();
/* 163 */       if (info.getUnit().prepareExecution(info, data)) {
/* 164 */         String fqname = null;
/* 165 */         if (value == null)
/*     */         {
/* 167 */           MoveToPackageDialog dlg = new MoveToPackageDialog(this.shell, RcpClientContext.getStandardRenamingHistory(this.context));
/* 168 */           dlg.setDescription(data.getDescription());
/* 169 */           dlg.setInitialValue(data.getCurrentPackageFqname());
/* 170 */           fqname = dlg.open();
/*     */         }
/*     */         else {
/* 173 */           fqname = value.toString();
/*     */         }
/* 175 */         if (fqname != null) {
/* 176 */           data.setDstPackageFqname(fqname);
/* 177 */           return info.getUnit().executeAction(info, data);
/*     */         } }
/* 179 */       break;
/*     */     
/*     */ 
/*     */     case 4: 
/* 183 */       ActionXrefsData data = new ActionXrefsData();
/* 184 */       if (info.getUnit().prepareExecution(info, data)) {
/* 185 */         String caption = S.s(45);
/* 186 */         if (data.getTarget() != null) {
/* 187 */           caption = caption + " to " + data.getTarget();
/*     */         }
/* 189 */         ReferencesDialog dlg = new ReferencesDialog(this.shell, caption, data.getAddresses(), data.getDetails(), info.getUnit());
/* 190 */         int index = dlg.open().intValue();
/* 191 */         if (index >= 0) {
/* 192 */           String address = (String)data.getAddresses().get(index);
/* 193 */           gotoAddress(this.context, info.getUnit(), address);
/*     */         }
/* 195 */         return info.getUnit().executeAction(info, data);
/*     */       }
/*     */       
/*     */ 
/* 199 */       IUnitFragment fragment = uictx.getFragment();
/* 200 */       if ((fragment instanceof InteractiveTextView)) {
/* 201 */         long itemId = info.getItemId();
/* 202 */         List<ICoordinates> coords = ((InteractiveTextView)fragment).collectItemCoordinates(itemId);
/* 203 */         if (!coords.isEmpty()) {
/* 204 */           List<String> addresses = new ArrayList();
/* 205 */           for (ICoordinates coord : coords) {
/* 206 */             addresses.add(String.format("Text @ %d:%d", new Object[] { Integer.valueOf(1 + coord.getLineDelta()), Integer.valueOf(1 + coord.getColumnOffset()) }));
/*     */           }
/* 208 */           ReferencesDialog dlg = new ReferencesDialog(this.shell, S.s(47), addresses, null, info.getUnit());
/* 209 */           int index = dlg.open().intValue();
/* 210 */           if (index >= 0) {
/* 211 */             ICoordinates coord = (ICoordinates)coords.get(index);
/* 212 */             ((InteractiveTextView)fragment).setCaretCoordinates(coord);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 217 */       break;
/*     */     
/*     */     case 12: 
/* 220 */       ActionTypeHierarchyData data = new ActionTypeHierarchyData();
/* 221 */       if (info.getUnit().prepareExecution(info, data))
/*     */       {
/* 223 */         ICodeUnit codeUnit = null;
/* 224 */         IUnit unit = info.getUnit();
/* 225 */         if ((unit instanceof ICodeUnit)) {
/* 226 */           codeUnit = (ICodeUnit)unit;
/*     */         }
/* 228 */         if ((unit instanceof ISourceUnit)) {
/* 229 */           codeUnit = DecompilerHelper.getRelatedCodeUnit(unit);
/*     */         }
/* 231 */         if (codeUnit != null)
/*     */         {
/* 233 */           CodeHierarchyDialog dlg = new CodeHierarchyDialog(this.shell, codeUnit, data.getBaseNode(), data.getBaseNodeForAscendingHierarchy(), this.context);
/* 234 */           String selectedAddress = dlg.open();
/*     */           
/* 236 */           gotoAddress(this.context, info.getUnit(), selectedAddress);
/* 237 */           return info.getUnit().executeAction(info, data);
/*     */         } }
/* 239 */       break;
/*     */     
/*     */ 
/*     */     case 13: 
/* 243 */       ActionOverridesData data = new ActionOverridesData();
/* 244 */       if (info.getUnit().prepareExecution(info, data))
/*     */       {
/* 246 */         ReferencesDialog dlg = new ReferencesDialog(this.shell, S.s(534), data.getAddresses(), null, info.getUnit());
/* 247 */         int index = dlg.open().intValue();
/* 248 */         if (index >= 0) {
/* 249 */           String address = (String)data.getAddresses().get(index);
/*     */           
/* 251 */           gotoAddress(this.context, info.getUnit(), address);
/*     */         }
/* 253 */         return info.getUnit().executeAction(info, data);
/*     */       }
/*     */       
/*     */       break;
/*     */     case 1: 
/* 258 */       ActionDeleteData data = new ActionDeleteData();
/* 259 */       if (info.getUnit().prepareExecution(info, data)) {
/* 260 */         return info.getUnit().executeAction(info, data);
/*     */       }
/*     */       
/*     */       break;
/*     */     case 5: 
/* 265 */       ActionConvertData data = new ActionConvertData();
/* 266 */       if (info.getUnit().prepareExecution(info, data)) {
/* 267 */         return info.getUnit().executeAction(info, data);
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     case 6: 
/* 273 */       INativeCodeUnit<?> pbcu = NativeActionUtil.getRelatedNativeCodeUnit(info.getUnit());
/* 274 */       if (pbcu == null) {
/* 275 */         return false;
/*     */       }
/*     */       
/* 278 */       ActionReplaceData data = new ActionReplaceData();
/* 279 */       if (info.getUnit().prepareExecution(info, data)) {
/* 280 */         Object o = data.getTargetObject();
/* 281 */         if (o == null) {
/* 282 */           return false;
/*     */         }
/* 284 */         NamedConstantsChooserDialog dlg = new NamedConstantsChooserDialog(this.shell, pbcu, o);
/* 285 */         CodeConstant cst = dlg.open();
/* 286 */         if (cst == null) {
/* 287 */           return false;
/*     */         }
/* 289 */         data.setWantedReplacement(cst);
/* 290 */         return info.getUnit().executeAction(info, data);
/*     */       }
/*     */       break;
/*     */     case 7: case 8: 
/*     */     case 9: default: 
/* 295 */       logger.debug("The action (%d) is not supported by this client", new Object[] { Integer.valueOf(info.getActionId()) });
/*     */     }
/* 297 */     return false;
/*     */   }
/*     */   
/*     */   public static int gotoAddress(RcpClientContext context, IUnit unit, String selectedAddress) {
/* 301 */     PartManager pman = context.getPartManager();
/*     */     
/* 303 */     if ((pman == null) || (unit == null)) {
/* 304 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 307 */     if (selectedAddress == null) {
/* 308 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 316 */     int cnt = 0;
/* 317 */     List<UnitPartManager> objects = pman.getPartManagersForUnit(unit);
/*     */     
/*     */ 
/* 320 */     if ((objects.isEmpty()) && (unit.isProcessed())) {
/* 321 */       pman.create(unit, true);
/* 322 */       objects = pman.getPartManagersForUnit(unit);
/*     */     }
/*     */     
/* 325 */     for (Iterator localIterator1 = objects.iterator(); localIterator1.hasNext();) { object = (UnitPartManager)localIterator1.next();
/* 326 */       activeFragment = object.getActiveFragment();
/* 327 */       if ((activeFragment != null) && 
/* 328 */         (activeFragment.setActiveAddress(selectedAddress, null, true))) {
/* 329 */         cnt++;
/* 330 */         break;
/*     */       }
/*     */       
/*     */ 
/* 334 */       for (IRcpUnitFragment fragment : object.getPreviouslyActiveFragments())
/* 335 */         if (fragment != activeFragment)
/*     */         {
/*     */ 
/* 338 */           if (fragment.setActiveAddress(selectedAddress, null, true)) {
/* 339 */             object.setActiveFragment(fragment);
/* 340 */             cnt++;
/* 341 */             break;
/*     */           } }
/*     */     }
/*     */     UnitPartManager object;
/*     */     IRcpUnitFragment activeFragment;
/* 346 */     return cnt;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\actions\GraphicalActionExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */