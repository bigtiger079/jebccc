/*    */ package com.pnfsoftware.jeb.rcpclient.actions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.api.IUnitFragment;
/*    */ import com.pnfsoftware.jeb.core.actions.ActionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionUIContext
/*    */ {
/*    */   private ActionContext actionContext;
/*    */   private IUnitFragment fragment;
/*    */   
/*    */   public ActionUIContext(ActionContext actionContext, IUnitFragment fragment)
/*    */   {
/* 23 */     this.actionContext = actionContext;
/* 24 */     this.fragment = fragment;
/*    */   }
/*    */   
/*    */   public ActionContext getActionContext() {
/* 28 */     return this.actionContext;
/*    */   }
/*    */   
/*    */   public IUnitFragment getFragment() {
/* 32 */     return this.fragment;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 37 */     return String.format("%s{%s}", new Object[] { getActionContext(), getFragment() });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\actions\ActionUIContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */