package com.pnfsoftware.jeb.rcpclient.iviewers.text;

public abstract interface INavigableViewer
{
  public abstract boolean updateDocument(long paramLong, int paramInt1, int paramInt2);
  
  public abstract void updateAnnotationBar();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\iviewers\text\INavigableViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */