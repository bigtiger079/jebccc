/*    */ package com.pnfsoftware.jeb.rcpclient.iviewers.text;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.output.text.ITextItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemEvent
/*    */ {
/*    */   public static final int CaretOut = 0;
/*    */   public static final int CaretIn = 1;
/*    */   public static final int DblClick = 2;
/*    */   public ITextItem item;
/*    */   public int type;
/*    */   
/*    */   public ItemEvent(ITextItem item, int type)
/*    */   {
/* 33 */     this.item = item;
/* 34 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\iviewers\text\ItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */