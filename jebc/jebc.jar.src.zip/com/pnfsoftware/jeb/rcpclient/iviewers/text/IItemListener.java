package com.pnfsoftware.jeb.rcpclient.iviewers.text;

public abstract interface IItemListener
{
  public abstract void notifyItemEvent(ITextDocumentViewer paramITextDocumentViewer, ItemEvent paramItemEvent);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\iviewers\text\IItemListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */