/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.core.units.IAddressableUnit;
/*    */ import com.pnfsoftware.jeb.core.units.IUnit;
/*    */ import com.pnfsoftware.jeb.core.units.IUnitNotification;
/*    */ import com.pnfsoftware.jeb.core.units.UnitUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*    */ import com.pnfsoftware.jeb.util.base.Couple;
/*    */ import java.util.List;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllNotificationsDialog
/*    */   extends DataFrameDialog
/*    */ {
/*    */   private static AllNotificationsDialog instance;
/*    */   
/*    */   public static AllNotificationsDialog getInstance()
/*    */   {
/* 33 */     return instance;
/*    */   }
/*    */   
/*    */   public AllNotificationsDialog(Shell parent, List<Couple<IUnit, IUnitNotification>> elements) {
/* 37 */     super(parent, S.s(602), false, "allNotificationsDialog");
/*    */     
/* 39 */     DataFrame df = new DataFrame(new String[] { S.s(785), S.s(779), S.s(268), S.s(52), S.s(424) });
/* 40 */     for (Couple<IUnit, IUnitNotification> elt : elements) {
/* 41 */       IUnit unit = (IUnit)elt.getFirst();
/* 42 */       IUnitNotification not = (IUnitNotification)elt.getSecond();
/* 43 */       String path = UnitUtil.buildFullyQualifiedUnitPath(unit);
/* 44 */       String addr = not.getAddress();
/* 45 */       if ((unit instanceof IAddressableUnit)) {
/* 46 */         df.addRow(new Object[] { path, not.getType(), not.getDescription(), addr, addr == null ? "" : ((IAddressableUnit)unit).getAddressLabel(addr) });
/*    */       }
/*    */       else {
/* 49 */         df.addRow(new Object[] { path, not.getType(), not.getDescription(), addr, "" });
/*    */       }
/*    */     }
/*    */     
/* 53 */     setDataFrame(df);
/* 54 */     setDisplayIndex(false);
/*    */   }
/*    */   
/*    */   public Integer open()
/*    */   {
/* 59 */     instance = this;
/* 60 */     Integer r = super.open();
/* 61 */     instance = null;
/* 62 */     return r;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\AllNotificationsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */