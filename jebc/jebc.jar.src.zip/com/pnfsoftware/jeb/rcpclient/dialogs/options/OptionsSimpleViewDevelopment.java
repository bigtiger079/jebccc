/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsSimpleViewDevelopment
/*     */   extends Composite
/*     */ {
/*     */   protected static final String CLIENT = "Client";
/*     */   protected static final String ENGINES = "Engines";
/*     */   protected static final String PROJECT_SPECIFIC = "Project-specific";
/*     */   private static final String PROPERTY_CLASSPATH = "DevPluginClasspath";
/*     */   private static final String PROPERTY_CLASSNAMES = "DevPluginClassnames";
/*  43 */   private Map<String, OptionsSimpleListener> listeners = new HashMap();
/*     */   private final OptionsChanges optionsChanges;
/*     */   
/*     */   public OptionsSimpleViewDevelopment(Composite parent, OptionsChanges optionsChanges) {
/*  47 */     super(parent, 0);
/*  48 */     setLayout(new FillLayout());
/*     */     
/*  50 */     Composite ph = new Composite(this, 0);
/*  51 */     ph.setLayout(new GridLayout(1, false));
/*     */     
/*  53 */     this.optionsChanges = optionsChanges;
/*     */     
/*  55 */     initSimpleViewElementListener("Client");
/*  56 */     initSimpleViewElementListener("Engines");
/*     */     
/*     */ 
/*  59 */     Group dev = createGroup(ph, S.s(271));
/*  60 */     createBooleanOption(dev, S.s(272), S.s(816), "Client", "DevelopmentMode");
/*  61 */     EditableList cp = createClasspathOption(dev, S.s(646), "Engines", 
/*  62 */       Licensing.canUseCoreAPI() ? "DevPluginClasspath" : null, "\\" + File.pathSeparator);
/*  63 */     EditableList cn = createClassnameOption(dev, S.s(645), "Engines", 
/*  64 */       Licensing.canUseCoreAPI() ? "DevPluginClassnames" : null, ",", 
/*  65 */       Licensing.canUseCoreAPI() ? "DevPluginClasspath" : null, "\\" + File.pathSeparator);
/*  66 */     if (!Licensing.canUseCoreAPI()) {
/*  67 */       cp.setEnabled(false);
/*  68 */       cn.setEnabled(false);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initSimpleViewElementListener(String propertyManagerKey) {
/*  73 */     OptionsSimpleListener listener = new OptionsSimpleListener();
/*  74 */     this.listeners.put(propertyManagerKey, listener);
/*  75 */     OptionsChanges.Changes c = this.optionsChanges.get(propertyManagerKey);
/*  76 */     if (c != null) {
/*  77 */       c.listeners.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   private Group createGroup(Composite parent, String label) {
/*  82 */     Group g = UIUtil.createGroup(parent, label);
/*  83 */     g.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  84 */     return g;
/*     */   }
/*     */   
/*     */   private EditableList createClasspathOption(Composite parent, String label, String propertyManagerKey, String propertyKey, String separator)
/*     */   {
/*  89 */     return 
/*  90 */       new OptionsSimpleViewClasspath(this.optionsChanges.get(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey, separator).create(parent, label);
/*     */   }
/*     */   
/*     */   private EditableList createClassnameOption(Composite parent, String label, String propertyManagerKey, String propertyKey, String separator, String classPathProperty, String classPathSeparator)
/*     */   {
/*  95 */     return 
/*     */     
/*  97 */       new OptionsSimpleViewClassname(this.optionsChanges.get(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey, separator, classPathProperty, classPathSeparator).create(parent, label);
/*     */   }
/*     */   
/*     */   private Button createBooleanOption(Composite parent, String label, String toolTip, String propertyManagerKey, String propertyKey)
/*     */   {
/* 102 */     return 
/* 103 */       new OptionsBooleanViewer(this.optionsChanges.get(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey).create(parent, label, toolTip);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewDevelopment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */