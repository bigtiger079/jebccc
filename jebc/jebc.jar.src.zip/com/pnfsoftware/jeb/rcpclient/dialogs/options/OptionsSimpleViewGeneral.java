/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DirectorySelectorView;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsSimpleViewGeneral
/*     */   extends Composite
/*     */ {
/*     */   protected static final String CLIENT = "Client";
/*     */   protected static final String ENGINES = "Engines";
/*     */   protected static final String PROJECT_SPECIFIC = "Project-specific";
/*  49 */   private Map<String, OptionsSimpleListener> listeners = new HashMap();
/*     */   private final OptionsChanges optionsChanges;
/*  51 */   private List<Control> proxySubEntries = new ArrayList();
/*     */   
/*     */   public OptionsSimpleViewGeneral(Composite parent, OptionsChanges optionsChanges) {
/*  54 */     super(parent, 0);
/*  55 */     setLayout(new FillLayout());
/*     */     
/*  57 */     Composite ph = new Composite(this, 0);
/*  58 */     ph.setLayout(new GridLayout(1, false));
/*     */     
/*  60 */     this.optionsChanges = optionsChanges;
/*     */     
/*  62 */     initSimpleViewElementListener("Client");
/*  63 */     initSimpleViewElementListener("Engines");
/*  64 */     initSimpleViewElementListener("Project-specific");
/*     */     
/*     */ 
/*  67 */     if (optionsChanges.get("Engines") != null) {
/*  68 */       Group plugin = createGroup(ph, S.s(639));
/*  69 */       DirectorySelectorView plug = createDirectoryOption(plugin, S.s(647), null, "Engines", 
/*  70 */         Licensing.canUseCoreAPI() ? "PluginsFolder" : null);
/*  71 */       if (!Licensing.canUseCoreAPI()) {
/*  72 */         plug.setEnabled(false);
/*     */       }
/*     */     }
/*     */     
/*  76 */     Group update = createGroup(ph, S.s(796));
/*  77 */     createBooleanOption(update, S.s(798), null, "Client", "CheckUpdates");
/*     */     
/*  79 */     Group proxy = createGroup(update, S.s(668));
/*  80 */     Button proxyButton = createProxyOption(proxy, S.s(669), null, "Client", "NetworkProxy");
/*  81 */     this.proxySubEntries.add(createComboBox(proxy, S.s(672), null, "Client", "NetworkProxy", 0, new String[] { "http", "socks" }));
/*     */     
/*  83 */     this.proxySubEntries.add(createTextOption(proxy, S.s(670), null, "Client", "NetworkProxy", 1));
/*  84 */     Text portText = createTextOption(proxy, S.s(671), null, "Client", "NetworkProxy", 2);
/*  85 */     this.proxySubEntries.add(portText);
/*     */     
/*  87 */     Group proxyAuth = createGroup(proxy, "Authentication");
/*  88 */     proxyAuth.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  89 */     Text userText = createTextOption(proxyAuth, S.s(811), null, "Client", "NetworkProxy", 3);
/*  90 */     this.proxySubEntries.add(userText);
/*  91 */     Text passwordText = createTextOption(proxyAuth, S.s(631), null, "Client", "NetworkProxy", 4);
/*  92 */     this.proxySubEntries.add(passwordText);
/*     */     
/*  94 */     addVerifyListenerIntOnly(portText);
/*  95 */     ((OptionsSimpleListener)this.listeners.get("Client")).addEnabledOnCheckbox(proxyButton, this.proxySubEntries);
/*  96 */     initProxyOptions("Client", "NetworkProxy");
/*     */   }
/*     */   
/*     */   private Group createGroup(Composite parent, String label) {
/* 100 */     Group g = UIUtil.createGroup(parent, label);
/* 101 */     g.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 102 */     return g;
/*     */   }
/*     */   
/*     */   private void initSimpleViewElementListener(String propertyManagerKey) {
/* 106 */     OptionsSimpleListener listener = new OptionsSimpleListener();
/* 107 */     this.listeners.put(propertyManagerKey, listener);
/* 108 */     OptionsChanges.Changes c = getChanges(propertyManagerKey);
/* 109 */     if (c != null) {
/* 110 */       c.listeners.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   private DirectorySelectorView createDirectoryOption(Composite parent, String label, String toolTip, String propertyManagerKey, String propertyKey)
/*     */   {
/* 116 */     return 
/* 117 */       new OptionsSimpleViewText(getChanges(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey).createDirectory(parent, label, toolTip);
/*     */   }
/*     */   
/*     */   private Text createTextOption(Composite parent, String label, String toolTip, String propertyManagerKey, String propertyKey, int tokenPosition)
/*     */   {
/* 122 */     return 
/* 123 */       new OptionsSimpleViewText(getChanges(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey).create(parent, label, toolTip, tokenPosition);
/*     */   }
/*     */   
/*     */   private void initProxyOptions(String propertyManagerKey, String propertyKey) {
/* 127 */     OptionsChanges.Changes c = getChanges(propertyManagerKey);
/* 128 */     boolean initialValue = !Strings.isBlank((String)AbstractOptionsSimpleWidget.getProperty(c, propertyKey, true));
/* 129 */     for (Control child : this.proxySubEntries) {
/* 130 */       child.setEnabled(initialValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private Button createProxyOption(Composite parent, String label, String toolTip, final String propertyManagerKey, final String propertyKey)
/*     */   {
/* 136 */     Button b = UIUtil.createCheckbox(parent, label, new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 139 */         OptionsChanges.Changes c = OptionsSimpleViewGeneral.this.getChanges(propertyManagerKey);
/* 140 */         boolean newValue = ((Button)e.getSource()).getSelection();
/* 141 */         Object newValueObj = Boolean.valueOf(newValue);
/* 142 */         Composite parentButton = ((Button)e.getSource()).getParent();
/* 143 */         if (newValue)
/*     */         {
/* 145 */           newValueObj = parentButton.getData("PREVIOUS_DATA");
/* 146 */           if (newValueObj == null)
/*     */           {
/*     */ 
/* 149 */             newValueObj = AbstractOptionsSimpleWidget.getProperty(c, propertyKey, true);
/*     */           }
/* 151 */           if ((newValueObj == null) || (StringUtils.isEmpty(newValueObj.toString()))) {
/* 152 */             newValueObj = "||";
/*     */           }
/* 154 */           parentButton.setData("PREVIOUS_DATA", null);
/*     */         }
/*     */         else
/*     */         {
/* 158 */           previousData = c.changeList.get(propertyKey);
/* 159 */           if (previousData == null) {
/* 160 */             previousData = c.pm.getValue(propertyKey);
/*     */           }
/* 162 */           if ((previousData != null) && (StringUtils.isEmpty(previousData.toString()))) {
/* 163 */             previousData = null;
/*     */           }
/* 165 */           parentButton.setData("PREVIOUS_DATA", previousData);
/* 166 */           newValueObj = "";
/*     */         }
/* 168 */         for (Object previousData = OptionsSimpleViewGeneral.this.proxySubEntries.iterator(); ((Iterator)previousData).hasNext();) { Control child = (Control)((Iterator)previousData).next();
/* 169 */           child.setEnabled(newValue);
/*     */         }
/* 171 */         c.addChange(propertyKey, newValueObj);
/*     */       }
/* 173 */     });
/* 174 */     OptionsChanges.Changes c = getChanges(propertyManagerKey);
/* 175 */     b.setSelection(StringUtils.isNotEmpty(c.pm.getString(propertyKey)));
/* 176 */     if (toolTip != null) {
/* 177 */       b.setToolTipText(toolTip);
/*     */     }
/* 179 */     b.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/* 180 */     AbstractOptionsSimpleWidget.addSimpleViewElements((OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey, b);
/* 181 */     return b;
/*     */   }
/*     */   
/*     */   private OptionsChanges.Changes getChanges(String propertyManagerKey) {
/* 185 */     return this.optionsChanges.get(propertyManagerKey);
/*     */   }
/*     */   
/*     */   private Control createComboBox(Composite parent, String label, String toolTip, String propertyManagerKey, String propertyKey, int tokenPosition, String[] options)
/*     */   {
/* 190 */     return 
/* 191 */       new OptionsSimpleViewCombo(getChanges(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey).createComboBox(parent, label, toolTip, tokenPosition, options);
/*     */   }
/*     */   
/*     */   private Button createBooleanOption(Composite parent, String label, String toolTip, String propertyManagerKey, String propertyKey)
/*     */   {
/* 196 */     return 
/* 197 */       new OptionsBooleanViewer(getChanges(propertyManagerKey), (OptionsSimpleListener)this.listeners.get(propertyManagerKey), propertyKey).create(parent, label, toolTip);
/*     */   }
/*     */   
/*     */   private void addVerifyListenerIntOnly(Text text) {
/* 201 */     text.addListener(25, new Listener()
/*     */     {
/*     */       public void handleEvent(Event e) {
/* 204 */         String string = e.text;
/* 205 */         char[] chars = new char[string.length()];
/* 206 */         string.getChars(0, chars.length, chars, 0);
/* 207 */         for (int i = 0; i < chars.length; i++) {
/* 208 */           if (('0' > chars[i]) || (chars[i] > '9')) {
/* 209 */             e.doit = false;
/* 210 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewGeneral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */