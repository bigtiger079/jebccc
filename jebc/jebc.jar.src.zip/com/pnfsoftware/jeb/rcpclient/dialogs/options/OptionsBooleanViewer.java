/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import org.apache.commons.lang3.BooleanUtils;
/*    */ import org.eclipse.swt.events.SelectionAdapter;
/*    */ import org.eclipse.swt.events.SelectionEvent;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsBooleanViewer
/*    */   extends AbstractOptionsSimpleWidget
/*    */ {
/*    */   public OptionsBooleanViewer(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey)
/*    */   {
/* 27 */     super(changes, listener, propertyKey);
/*    */   }
/*    */   
/*    */   public Button create(Composite parent, String label, String toolTip) {
/* 31 */     Button b = UIUtil.createCheckbox(parent, label, new SelectionAdapter()
/*    */     {
/*    */       public void widgetSelected(SelectionEvent e) {
/* 34 */         boolean newValue = ((Button)e.getSource()).getSelection();
/* 35 */         OptionsBooleanViewer.this.changes.addChange(OptionsBooleanViewer.this.propertyKey, Boolean.valueOf(newValue));
/*    */       }
/* 37 */     });
/* 38 */     b.setSelection(BooleanUtils.toBoolean(this.changes.getBoolean(this.propertyKey)));
/* 39 */     if (toolTip != null) {
/* 40 */       b.setToolTipText(toolTip);
/*    */     }
/* 42 */     b.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/* 43 */     addSimpleViewElements(this.listener, this.propertyKey, b);
/* 44 */     return b;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsBooleanViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */