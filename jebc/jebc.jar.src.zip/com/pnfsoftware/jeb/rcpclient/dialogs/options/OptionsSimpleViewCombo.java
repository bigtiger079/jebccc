/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import org.eclipse.swt.events.SelectionAdapter;
/*    */ import org.eclipse.swt.events.SelectionEvent;
/*    */ import org.eclipse.swt.widgets.Combo;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsSimpleViewCombo
/*    */   extends AbstractOptionsSimpleWidget
/*    */ {
/*    */   public OptionsSimpleViewCombo(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey)
/*    */   {
/* 29 */     super(changes, listener, propertyKey);
/*    */   }
/*    */   
/*    */   public Combo createComboBox(Composite parent, String label, String toolTip, final int tokenPosition, String[] options)
/*    */   {
/* 34 */     Combo combo = buildComboBox(parent, label, getToken(tokenPosition), toolTip, options);
/* 35 */     combo.setData("TOKENIZE_NUMBER", Integer.valueOf(tokenPosition));
/* 36 */     combo.addSelectionListener(new SelectionAdapter()
/*    */     {
/*    */       public void widgetSelected(SelectionEvent e) {
/* 39 */         Combo source = (Combo)e.getSource();
/* 40 */         int newIndex = source.getSelectionIndex();
/* 41 */         String newValue = source.getItem(newIndex);
/* 42 */         if (tokenPosition >= 0) {
/* 43 */           String previousValue = Strings.safe(OptionsSimpleViewCombo.this.changes.getString(OptionsSimpleViewCombo.this.propertyKey));
/* 44 */           newValue = OptionsSimpleViewCombo.this.getNewValue(newValue, previousValue, tokenPosition);
/*    */         }
/* 46 */         OptionsSimpleViewCombo.this.changes.addChange(OptionsSimpleViewCombo.this.propertyKey, newValue);
/*    */       }
/* 48 */     });
/* 49 */     addSimpleViewElements(combo);
/* 50 */     return combo;
/*    */   }
/*    */   
/*    */   private Combo buildComboBox(Composite parent, String label, String value, String toolTip, String[] items) {
/* 54 */     Label l = UIUtil.createLabel(parent, label);
/* 55 */     if (toolTip != null) {
/* 56 */       l.setToolTipText(toolTip);
/*    */     }
/* 58 */     Combo combo = new Combo(parent, 2056);
/* 59 */     combo.setItems(items);
/* 60 */     selectComboValue(combo, value);
/* 61 */     if (toolTip != null) {
/* 62 */       combo.setToolTipText(toolTip);
/*    */     }
/* 64 */     combo.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 65 */     return combo;
/*    */   }
/*    */   
/*    */   protected static int selectComboValue(Combo combo, String value) {
/* 69 */     String[] comboItems = combo.getItems();
/* 70 */     for (int i = 0; i < comboItems.length; i++) {
/* 71 */       if (comboItems[i].equalsIgnoreCase(value)) {
/* 72 */         combo.select(i);
/* 73 */         return i;
/*    */       }
/*    */     }
/* 76 */     combo.deselectAll();
/* 77 */     combo.setText("");
/* 78 */     return -1;
/*    */   }
/*    */   
/*    */   protected static void refresh(Combo t, Object[] data) {
/* 82 */     Object tokenPositionObj = t.getData("TOKENIZE_NUMBER");
/* 83 */     String newValue = data[1].toString();
/* 84 */     if (tokenPositionObj != null) {
/* 85 */       int tokenPosition = ((Integer)tokenPositionObj).intValue();
/* 86 */       newValue = getToken(newValue, tokenPosition);
/*    */     }
/* 88 */     selectComboValue(t, newValue);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewCombo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */