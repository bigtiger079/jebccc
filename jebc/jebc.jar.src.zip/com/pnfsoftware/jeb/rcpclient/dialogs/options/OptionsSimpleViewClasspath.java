/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DirectorySelectionListener;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FileSelectionListener;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.eclipse.jface.dialogs.InputDialog;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsSimpleViewClasspath
/*     */   extends OptionsSimpleViewList
/*     */ {
/*     */   public OptionsSimpleViewClasspath(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey, String separator)
/*     */   {
/*  34 */     super(changes, listener, propertyKey, separator);
/*     */   }
/*     */   
/*     */   protected EditableList build(Composite parent, String label, String value)
/*     */   {
/*  39 */     final EditableList list = super.build(parent, label, value);
/*  40 */     list.addButton(S.s(50) + "...", new DirectorySelectionListener(parent.getShell(), null)
/*     */     {
/*     */       public String getDefaultText() {
/*  43 */         return "";
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  48 */       public void setText(String dirname) { OptionsSimpleViewClasspath.this.addToClasspath(dirname); } }, false);
/*     */     
/*     */ 
/*  51 */     list.addButton(S.s(51) + "...", new FileSelectionListener(parent.getShell(), null, new String[] { "*.jar" })
/*     */     {
/*     */       public String getDefaultText() {
/*  54 */         return "";
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  59 */       public void setText(String file) { OptionsSimpleViewClasspath.this.addToClasspath(file); } }, false);
/*     */     
/*     */ 
/*     */ 
/*  63 */     list.addButton(S.s(284) + "...", new SelectionAdapter()
/*     */     {
/*     */ 
/*  66 */       public void widgetSelected(SelectionEvent e) { OptionsSimpleViewClasspath.this.onEdit(list); } }, true);
/*     */     
/*     */ 
/*     */ 
/*  70 */     addRemoveButton(list);
/*     */     
/*     */ 
/*  73 */     list.getTable().addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseDoubleClick(MouseEvent e) {
/*  76 */         OptionsSimpleViewClasspath.this.onEdit(list);
/*     */       }
/*  78 */     });
/*  79 */     return list;
/*     */   }
/*     */   
/*     */   private void onEdit(EditableList list) {
/*  83 */     TableItem[] indices = list.getSelection();
/*  84 */     if ((indices == null) || (indices.length == 0) || (indices.length > 1))
/*     */     {
/*  86 */       return;
/*     */     }
/*  88 */     String intialValue = indices[0].getText();
/*  89 */     InputDialog id = new InputDialog(list.getShell(), "Classpath", "Edit the classpath:", intialValue, null);
/*  90 */     int result = id.open();
/*  91 */     if (result == 0) {
/*  92 */       updateClasspath(list.getSelectionIndices()[0], id.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addToClasspath(String dirname) {
/*  97 */     StringBuilder newProperty = new StringBuilder();
/*  98 */     Object previousValue = getProperty();
/*  99 */     if ((previousValue != null) && (!((String)previousValue).isEmpty())) {
/* 100 */       newProperty.append(previousValue.toString());
/* 101 */       newProperty.append(this.separator.replace("\\", ""));
/*     */     }
/* 103 */     newProperty.append(dirname);
/* 104 */     String newPropertyStr = newProperty.toString();
/* 105 */     this.changes.addChange(this.propertyKey, newPropertyStr);
/*     */   }
/*     */   
/*     */   private void updateClasspath(int position, String value) {
/* 109 */     String[] values = getItems((String)getProperty());
/* 110 */     values[position] = value;
/* 111 */     this.changes.addChange(this.propertyKey, StringUtils.join(values, this.separator.replace("\\", "")));
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewClasspath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */