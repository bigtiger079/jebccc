/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractOptionsSimpleWidget
/*     */ {
/*     */   private static final String DEFAULT_TOKENIZER = "\\|";
/*     */   private static final String DEFAULT_RETOKENIZER = "|";
/*     */   protected OptionsChanges.Changes changes;
/*     */   protected OptionsSimpleListener listener;
/*     */   protected String propertyKey;
/*     */   
/*     */   public AbstractOptionsSimpleWidget(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey)
/*     */   {
/*  36 */     this.changes = changes;
/*  37 */     this.listener = listener;
/*  38 */     this.propertyKey = propertyKey;
/*     */   }
/*     */   
/*     */   public String getToken(int tokenPosition) {
/*  42 */     return getToken(getValue(), tokenPosition);
/*     */   }
/*     */   
/*     */   public static String getToken(String property, int tokenPosition) {
/*  46 */     if (property == null) {
/*  47 */       return "";
/*     */     }
/*  49 */     String[] tokens = property.split("\\|", -1);
/*  50 */     if (tokenPosition >= tokens.length) {
/*  51 */       return "";
/*     */     }
/*  53 */     return tokens[tokenPosition];
/*     */   }
/*     */   
/*     */   protected String getNewValue(String newText, String previousValue, int tokenPosition) {
/*  57 */     String currentValue = null;
/*  58 */     if (this.changes.getChange(this.propertyKey) != null) {
/*  59 */       currentValue = this.changes.getChange(this.propertyKey).toString();
/*     */     }
/*     */     else {
/*  62 */       currentValue = previousValue;
/*     */     }
/*  64 */     if (currentValue == null) {
/*  65 */       currentValue = "";
/*     */     }
/*  67 */     String[] tokens = currentValue.split("\\|", -1);
/*     */     String[] newTokens;
/*  69 */     String[] newTokens; if (tokenPosition >= tokens.length) {
/*  70 */       newTokens = new String[tokenPosition + 1];
/*     */     }
/*     */     else {
/*  73 */       newTokens = new String[tokens.length];
/*     */     }
/*  75 */     System.arraycopy(tokens, 0, newTokens, 0, tokens.length);
/*  76 */     newTokens[tokenPosition] = newText;
/*  77 */     return StringUtils.join(newTokens, "|");
/*     */   }
/*     */   
/*     */   protected void addSimpleViewElements(Control c) {
/*  81 */     addSimpleViewElements(this.listener, this.propertyKey, c);
/*     */   }
/*     */   
/*     */   public static void addSimpleViewElements(OptionsSimpleListener listener, String propertyKey, Control c) {
/*  85 */     listener.addElement(propertyKey, c);
/*     */   }
/*     */   
/*     */   protected Object getProperty() {
/*  89 */     return getProperty(this.changes, this.propertyKey, false);
/*     */   }
/*     */   
/*     */   public static Object getProperty(OptionsChanges.Changes c, String propertyKey, boolean retrieveOldDataIfEmpty) {
/*  93 */     Object previousData = c.getChange(propertyKey);
/*  94 */     if ((previousData == null) || ((retrieveOldDataIfEmpty) && (Strings.isBlank(previousData.toString())))) {
/*  95 */       previousData = c.getValue(propertyKey);
/*     */     }
/*  97 */     return previousData;
/*     */   }
/*     */   
/*     */   protected String getValue() {
/* 101 */     if ((this.changes == null) || (this.propertyKey == null)) {
/* 102 */       return "";
/*     */     }
/* 104 */     return this.changes.getString(this.propertyKey);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\AbstractOptionsSimpleWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */