/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.commons.lang3.BooleanUtils;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Combo;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Control;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.Listener;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsSimpleListener
/*    */   implements Listener
/*    */ {
/* 35 */   private Map<String, List<Control>> elements = new HashMap();
/*    */   
/* 37 */   private Map<Control, List<Control>> enabledOnCheckBoxItems = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleEvent(Event event)
/*    */   {
/* 44 */     Object[] data = (Object[])event.data;
/* 45 */     for (Map.Entry<String, List<Control>> ent : this.elements.entrySet()) {
/* 46 */       if (data[0].equals(ent.getKey())) {
/* 47 */         for (Control c : (List)ent.getValue())
/* 48 */           if (data[1] != null)
/*    */           {
/*    */ 
/* 51 */             if ((c instanceof Text)) {
/* 52 */               OptionsSimpleViewText.refresh((Text)c, data);
/*    */             }
/* 54 */             else if ((c instanceof Button)) {
/* 55 */               Boolean selected = null;
/* 56 */               if ((data[1] instanceof Boolean)) {
/* 57 */                 selected = Boolean.valueOf(BooleanUtils.toBoolean((Boolean)data[1]));
/*    */               }
/* 59 */               else if (data[1] != null) {
/* 60 */                 selected = Boolean.valueOf(!Strings.isBlank(data[1].toString()));
/*    */               }
/* 62 */               List<Control> subEntries = (List)this.enabledOnCheckBoxItems.get(c);
/* 63 */               if ((subEntries != null) && (!subEntries.isEmpty())) {
/* 64 */                 for (Control child : subEntries) {
/* 65 */                   child.setEnabled(BooleanUtils.toBoolean(selected));
/*    */                 }
/*    */               }
/* 68 */               if (selected != null) {
/* 69 */                 ((Button)c).setSelection(selected.booleanValue());
/*    */               }
/*    */             }
/* 72 */             else if ((c instanceof Combo)) {
/* 73 */               OptionsSimpleViewCombo.refresh((Combo)c, data);
/*    */             }
/* 75 */             else if ((c instanceof EditableList)) {
/* 76 */               OptionsSimpleViewList.refresh((EditableList)c, data);
/*    */             }
/* 78 */             c.getParent().update();
/*    */           }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void addEnabledOnCheckbox(Control c, List<Control> children) {
/* 85 */     this.enabledOnCheckBoxItems.put(c, children);
/*    */   }
/*    */   
/*    */   protected void addElement(String propertyKey, Control c) {
/* 89 */     List<Control> controls = (List)this.elements.get(propertyKey);
/* 90 */     if (controls == null) {
/* 91 */       controls = new ArrayList();
/* 92 */       this.elements.put(propertyKey, controls);
/*    */     }
/* 94 */     controls.add(c);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */