/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList.ICheckable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsSimpleViewList
/*     */   extends AbstractOptionsSimpleWidget
/*     */ {
/*     */   protected String separator;
/*     */   
/*     */   public OptionsSimpleViewList(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey, String separator)
/*     */   {
/*  33 */     super(changes, listener, propertyKey);
/*  34 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public EditableList create(Composite parent, String label) {
/*  38 */     EditableList widget = build(parent, label, getValue());
/*  39 */     addSimpleViewElements(widget);
/*  40 */     return widget;
/*     */   }
/*     */   
/*     */   protected EditableList build(Composite parent, String label, String value) {
/*  44 */     EditableList list = new EditableList(parent, getTableStyle(), label, getItems(this.separator, value));
/*  45 */     list.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  46 */     list.setData("SEPARATOR", this.separator);
/*  47 */     return list;
/*     */   }
/*     */   
/*     */   protected int getTableStyle() {
/*  51 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addRemoveButton(final EditableList list)
/*     */   {
/*  60 */     list.addButton(S.s(677), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  63 */         int[] toRemove = list.getSelectionIndices();
/*  64 */         if ((toRemove == null) || (toRemove.length == 0)) {
/*  65 */           return;
/*     */         }
/*  67 */         Object previousValue = OptionsSimpleViewList.this.getProperty();
/*  68 */         if (previousValue == null) {
/*  69 */           return;
/*     */         }
/*  71 */         String[] items = OptionsSimpleViewList.getItems(OptionsSimpleViewList.this.separator, previousValue.toString());
/*  72 */         String[] newItems = OptionsSimpleViewList.this.removeElements(items, toRemove);
/*  73 */         OptionsSimpleViewList.this.changes.addChange(OptionsSimpleViewList.this.propertyKey, StringUtils.join(newItems, OptionsSimpleViewList.this.separator.replace("\\", ""))); } }, true);
/*     */   }
/*     */   
/*     */ 
/*     */   protected String[] getItems(String value)
/*     */   {
/*  79 */     return getItems(this.separator, value);
/*     */   }
/*     */   
/*     */   protected static String[] getItems(EditableList table, String value) {
/*  83 */     return getItems((String)table.getData("SEPARATOR"), value);
/*     */   }
/*     */   
/*     */   protected static String[] getItems(String separator, String value) {
/*  87 */     if ((value == null) || (value.isEmpty())) {
/*  88 */       return new String[0];
/*     */     }
/*  90 */     return value.split(separator);
/*     */   }
/*     */   
/*     */   protected String[] removeElements(String[] items, int[] toRemoveArray) {
/*  94 */     if ((toRemoveArray == null) || (toRemoveArray.length == 0)) {
/*  95 */       return items;
/*     */     }
/*  97 */     List<String> result = new ArrayList();
/*  98 */     List<Integer> toRemove = asList(toRemoveArray);
/*  99 */     for (int sourceIndex = 0; sourceIndex < items.length; sourceIndex++) {
/* 100 */       if (!toRemove.contains(Integer.valueOf(sourceIndex))) {
/* 101 */         result.add(items[sourceIndex]);
/*     */       }
/*     */     }
/* 104 */     return (String[])result.toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */   private List<Integer> asList(int[] array)
/*     */   {
/* 109 */     List<Integer> result = new ArrayList();
/* 110 */     for (int v : array) {
/* 111 */       result.add(Integer.valueOf(v));
/*     */     }
/* 113 */     return result;
/*     */   }
/*     */   
/*     */   public static void refresh(EditableList table, Object[] data) {
/* 117 */     Object checkable = table.getData("CHECKABLE");
/* 118 */     if (checkable != null) {
/* 119 */       table.resetItems(((ICheckableProvider)checkable).getCheckableList(table, (String)data[1]));
/*     */     }
/*     */     else {
/* 122 */       table.resetItems(getItems(table, (String)data[1]));
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface ICheckableProvider
/*     */   {
/*     */     public abstract List<EditableList.ICheckable> getCheckableList(EditableList paramEditableList, String paramString);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */