/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.core.properties.impl.CoreProperties;
/*     */ import com.pnfsoftware.jeb.core.properties.impl.DevPluginClassname;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.EditableList.ICheckable;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.dialogs.InputDialog;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsSimpleViewClassname
/*     */   extends OptionsSimpleViewList
/*     */ {
/*  47 */   private static final ILogger logger = GlobalLog.getLogger(OptionsSimpleViewClassname.class);
/*     */   
/*     */   private static final String MESSAGE_TITLE = "Classname";
/*     */   
/*     */   private static final String MESSAGE_VERIFY_TITLE = "Verify classname";
/*     */   
/*     */   private String classPathProperty;
/*     */   private String classPathSeparator;
/*     */   
/*     */   public OptionsSimpleViewClassname(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey, String separator, String classPathProperty, String classPathSeparator)
/*     */   {
/*  58 */     super(changes, listener, propertyKey, separator);
/*  59 */     this.classPathProperty = classPathProperty;
/*  60 */     this.classPathSeparator = classPathSeparator;
/*     */   }
/*     */   
/*     */   protected EditableList build(Composite parent, String label, String value)
/*     */   {
/*  65 */     final EditableList list = super.build(parent, label, value);
/*  66 */     boolean readOnly = this.changes == null;
/*  67 */     final CoreProperties cp = new CoreProperties(readOnly ? null : this.changes.getPropertyManager());
/*  68 */     if (!readOnly) {
/*  69 */       CheckableClassnameProvider provider = new CheckableClassnameProvider(cp);
/*  70 */       list.setData("CHECKABLE", provider);
/*  71 */       list.resetItems(provider.getCheckableList(list, value));
/*  72 */       list.getTable().addListener(13, new Listener()
/*     */       {
/*     */         public void handleEvent(Event event) {
/*  75 */           boolean checked = event.detail == 32;
/*  76 */           if (!checked) {
/*  77 */             return;
/*     */           }
/*     */           
/*  80 */           Table table = (Table)event.widget;
/*     */           
/*  82 */           for (int selected = 0; selected < table.getItemCount(); selected++) {
/*  83 */             if (table.getItem(selected) == event.item) {
/*     */               break;
/*     */             }
/*     */           }
/*     */           
/*  88 */           List<DevPluginClassname> classnames = cp.parseDevPluginClassnames((String)OptionsSimpleViewClassname.this.getProperty());
/*     */           
/*  90 */           if ((selected < 0) || (selected >= table.getItemCount())) {
/*  91 */             OptionsSimpleViewClassname.logger.error("The change was not recorded!", new Object[0]);
/*  92 */             return;
/*     */           }
/*     */           
/*  95 */           DevPluginClassname classname = (DevPluginClassname)classnames.get(selected);
/*     */           
/*  97 */           DevPluginClassname newClassname = new DevPluginClassname(classname.getClassname(), !classname.isEnabled());
/*  98 */           classnames.remove(selected);
/*  99 */           classnames.add(selected, newClassname);
/* 100 */           OptionsSimpleViewClassname.this.changes.addChange(OptionsSimpleViewClassname.this.propertyKey, cp.buildDevPluginClassnames(classnames));
/*     */         }
/*     */       });
/*     */     }
/* 104 */     list.addButton("Add...", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 107 */         InputDialog id = new InputDialog(list.getShell(), "Classname", "Enter the classname:", "", null);
/* 108 */         int result = id.open();
/* 109 */         if ((result == 0) && (!Strings.isBlank(id.getValue()))) {
/* 110 */           OptionsSimpleViewClassname.this.addClassname(cp, id.getValue());
/* 111 */           OptionsSimpleViewClassname.this.displayVerifyClassname(id.getValue(), list.getShell()); } } }, false);
/*     */     
/*     */ 
/*     */ 
/* 115 */     list.addButton("Edit...", new SelectionAdapter()
/*     */     {
/*     */ 
/* 118 */       public void widgetSelected(SelectionEvent e) { OptionsSimpleViewClassname.this.onEdit(list, cp); } }, true);
/*     */     
/*     */ 
/*     */ 
/* 122 */     addRemoveButton(list);
/* 123 */     list.addButton("Verify", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent se) {
/* 126 */         TableItem[] indices = list.getSelection();
/* 127 */         if ((indices == null) || (indices.length == 0) || (indices.length > 1))
/*     */         {
/* 129 */           return;
/*     */         }
/* 131 */         String cname = indices[0].getText();
/* 132 */         OptionsSimpleViewClassname.this.displayVerifyClassname(cname, list.getShell()); } }, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     list.getTable().addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseDoubleClick(MouseEvent e) {
/* 141 */         OptionsSimpleViewClassname.this.onEdit(list, cp);
/*     */       }
/*     */       
/* 144 */     });
/* 145 */     return list;
/*     */   }
/*     */   
/*     */   private void onEdit(EditableList list, CoreProperties cp) {
/* 149 */     TableItem[] indices = list.getSelection();
/* 150 */     if ((indices == null) || (indices.length == 0) || (indices.length > 1))
/*     */     {
/* 152 */       return;
/*     */     }
/* 154 */     String intialValue = indices[0].getText();
/* 155 */     InputDialog id = new InputDialog(list.getShell(), "Classname", "Edit the classname:", intialValue, null);
/* 156 */     int result = id.open();
/* 157 */     if ((result == 0) && (!Strings.isBlank(id.getValue()))) {
/* 158 */       updateClassname(cp, list.getSelectionIndices()[0], id.getValue());
/* 159 */       displayVerifyClassname(id.getValue(), list.getShell());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addClassname(CoreProperties cp, String classname) {
/* 164 */     List<DevPluginClassname> classnames = cp.parseDevPluginClassnames((String)getProperty());
/* 165 */     DevPluginClassname classnameObj = new DevPluginClassname(classname, true);
/* 166 */     classnames.add(classnameObj);
/* 167 */     this.changes.addChange(this.propertyKey, cp.buildDevPluginClassnames(classnames));
/*     */   }
/*     */   
/*     */   private void updateClassname(CoreProperties cp, int position, String value)
/*     */   {
/* 172 */     List<DevPluginClassname> classnames = cp.parseDevPluginClassnames((String)getProperty());
/* 173 */     DevPluginClassname old = (DevPluginClassname)classnames.remove(position);
/* 174 */     classnames.add(position, new DevPluginClassname(value, old.isEnabled()));
/* 175 */     this.changes.addChange(this.propertyKey, cp.buildDevPluginClassnames(classnames));
/*     */   }
/*     */   
/*     */   private void displayVerifyClassname(String classname, Shell shell) {
/* 179 */     if (verifyClassname(classname)) {
/* 180 */       MessageDialog.openInformation(shell, "Verify classname", "Classname was found in specified classpath");
/*     */     }
/*     */     else {
/* 183 */       MessageDialog.openError(shell, "Verify classname", "Classname can not be found in specified classpath");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean verifyClassname(String classname) {
/* 188 */     String[] values = getItems(this.classPathSeparator, (String)getProperty(this.changes, this.classPathProperty, false));
/*     */     try {
/* 190 */       buildClassLoader(values).loadClass(classname);
/* 191 */       return true;
/*     */     }
/*     */     catch (ClassNotFoundException e) {}
/* 194 */     return false;
/*     */   }
/*     */   
/*     */   private URLClassLoader buildClassLoader(String[] paths)
/*     */   {
/* 199 */     List<URL> urls = new ArrayList();
/* 200 */     for (String pathelt : paths) {
/*     */       try {
/* 202 */         urls.add(new File(pathelt.trim()).toURI().toURL());
/*     */       }
/*     */       catch (MalformedURLException e) {}
/*     */     }
/*     */     
/*     */ 
/* 208 */     return new URLClassLoader((URL[])urls.toArray(new URL[urls.size()]), getClass().getClassLoader());
/*     */   }
/*     */   
/*     */   protected int getTableStyle()
/*     */   {
/* 213 */     return 32;
/*     */   }
/*     */   
/*     */   private static class CheckableClassnameProvider implements OptionsSimpleViewList.ICheckableProvider {
/*     */     CoreProperties cp;
/*     */     
/*     */     public CheckableClassnameProvider(CoreProperties cp) {
/* 220 */       this.cp = cp;
/*     */     }
/*     */     
/*     */     public List<EditableList.ICheckable> getCheckableList(EditableList table, String value)
/*     */     {
/* 225 */       List<EditableList.ICheckable> result = new ArrayList();
/* 226 */       List<DevPluginClassname> classnames = this.cp.parseDevPluginClassnames(value);
/* 227 */       for (DevPluginClassname cl : classnames) {
/* 228 */         result.add(new OptionsSimpleViewClassname.CheckableDevPluginClassname(cl));
/*     */       }
/* 230 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CheckableDevPluginClassname implements EditableList.ICheckable {
/*     */     DevPluginClassname classname;
/*     */     
/*     */     public CheckableDevPluginClassname(DevPluginClassname classname) {
/* 238 */       this.classname = classname;
/*     */     }
/*     */     
/*     */     public String getText()
/*     */     {
/* 243 */       return this.classname.getClassname();
/*     */     }
/*     */     
/*     */     public boolean isChecked()
/*     */     {
/* 248 */       return this.classname.isEnabled();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewClassname.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */