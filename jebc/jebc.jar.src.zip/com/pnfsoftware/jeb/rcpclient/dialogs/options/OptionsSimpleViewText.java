/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DirectorySelectorView;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.LongInputField;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import org.eclipse.swt.events.FocusAdapter;
/*    */ import org.eclipse.swt.events.FocusEvent;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsSimpleViewText
/*    */   extends AbstractOptionsSimpleWidget
/*    */ {
/*    */   public OptionsSimpleViewText(OptionsChanges.Changes changes, OptionsSimpleListener listener, String propertyKey)
/*    */   {
/* 29 */     super(changes, listener, propertyKey);
/*    */   }
/*    */   
/*    */   public Text create(Composite parent, String label, String toolTip, int tokenPosition) {
/* 33 */     Text text = buildText(parent, label, getToken(tokenPosition), toolTip);
/* 34 */     text.setData("TOKENIZE_NUMBER", Integer.valueOf(tokenPosition));
/* 35 */     syncText(text, tokenPosition);
/* 36 */     return text;
/*    */   }
/*    */   
/*    */   public Text create(Composite parent, String label, String toolTip) {
/* 40 */     Text text = buildText(parent, label, getValue(), toolTip);
/* 41 */     syncText(text);
/* 42 */     return text;
/*    */   }
/*    */   
/*    */   public DirectorySelectorView createDirectory(Composite parent, String label, String toolTip) {
/* 46 */     DirectorySelectorView dsv = new DirectorySelectorView(parent, label, getValue());
/* 47 */     dsv.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/* 48 */     Text text = dsv.getTextbox();
/*    */     
/* 50 */     if (toolTip != null) {
/* 51 */       text.setToolTipText(toolTip);
/*    */     }
/* 53 */     syncText(text);
/* 54 */     return dsv;
/*    */   }
/*    */   
/*    */   private Text buildText(Composite parent, String label, String value, String toolTip) {
/* 58 */     Text text = LongInputField.create(parent, label, value, false);
/* 59 */     if (toolTip != null) {
/* 60 */       text.setToolTipText(toolTip);
/*    */     }
/* 62 */     return text;
/*    */   }
/*    */   
/*    */   private void syncText(Text text) {
/* 66 */     syncText(text, -1);
/*    */   }
/*    */   
/*    */   private void syncText(final Text text, final int tokenPosition) {
/* 70 */     text.addFocusListener(new FocusAdapter()
/*    */     {
/*    */       public void focusLost(FocusEvent e) {
/* 73 */         String newValue = text.getText();
/* 74 */         if (tokenPosition >= 0) {
/* 75 */           String previousValue = Strings.safe(OptionsSimpleViewText.this.getValue());
/* 76 */           newValue = OptionsSimpleViewText.this.getNewValue(newValue, previousValue, tokenPosition);
/*    */         }
/* 78 */         OptionsSimpleViewText.this.changes.addChange(OptionsSimpleViewText.this.propertyKey, newValue);
/*    */       }
/*    */       
/* 81 */     });
/* 82 */     addSimpleViewElements(text);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected static void refresh(Text t, Object[] data)
/*    */   {
/* 89 */     Object tokenPositionObj = t.getData("TOKENIZE_NUMBER");
/* 90 */     String newValue = data[1].toString();
/* 91 */     if (tokenPositionObj != null) {
/* 92 */       int tokenPosition = ((Integer)tokenPositionObj).intValue();
/* 93 */       newValue = getToken(newValue, tokenPosition);
/*    */     }
/* 95 */     t.setText(newValue);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsSimpleViewText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */