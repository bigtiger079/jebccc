/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.telemetry.ITelemetryDatabase;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsChanges
/*     */ {
/*  31 */   private Map<String, Changes> changes = new HashMap();
/*     */   
/*     */ 
/*     */   public static class Changes
/*     */   {
/*     */     IPropertyManager pm;
/*     */     
/*  38 */     Map<String, Object> changeList = new HashMap();
/*  39 */     List<Listener> listeners = new ArrayList();
/*     */     
/*     */     public Changes(IPropertyManager pm) {
/*  42 */       this.pm = pm;
/*     */     }
/*     */     
/*     */     public boolean hasChanges() {
/*  46 */       return !this.changeList.isEmpty();
/*     */     }
/*     */     
/*     */     public void addChange(String property, Object value) {
/*  50 */       if (property.startsWith(".")) {
/*  51 */         property = property.substring(1);
/*     */       }
/*  53 */       if (Objects.equals(this.pm.getValue(property), value))
/*     */       {
/*  55 */         removeChange(property, value);
/*     */       }
/*     */       else {
/*  58 */         this.changeList.put(property, value);
/*  59 */         if (!this.listeners.isEmpty()) {
/*  60 */           for (Listener l : this.listeners) {
/*  61 */             Event e = new Event();
/*  62 */             e.data = new Object[] { property, value };
/*  63 */             l.handleEvent(e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void removeChange(String property, Object value) {
/*  70 */       if (property.startsWith(".")) {
/*  71 */         property = property.substring(1);
/*     */       }
/*  73 */       this.changeList.remove(property);
/*  74 */       if (!this.listeners.isEmpty()) {
/*  75 */         for (Listener l : this.listeners) {
/*  76 */           Event e = new Event();
/*  77 */           e.data = new Object[] { property, value };
/*  78 */           l.handleEvent(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void applyChanges() {
/*  84 */       for (Map.Entry<String, Object> e : this.changeList.entrySet()) {
/*  85 */         this.pm.setValue((String)e.getKey(), e.getValue(), false);
/*     */       }
/*     */     }
/*     */     
/*     */     public Boolean getBoolean(String name) {
/*  90 */       return Boolean.valueOf(this.pm.getBoolean(name));
/*     */     }
/*     */     
/*     */     public String getString(String name) {
/*  94 */       return this.pm.getString(name);
/*     */     }
/*     */     
/*     */     public Object getValue(String name) {
/*  98 */       return this.pm.getValue(name);
/*     */     }
/*     */     
/*     */     public Object getChange(Object key) {
/* 102 */       return this.changeList.get(key);
/*     */     }
/*     */     
/*     */     public Map<String, Object> getChanges() {
/* 106 */       return this.changeList;
/*     */     }
/*     */     
/*     */     public IPropertyManager getPropertyManager() {
/* 110 */       return this.pm;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addPropertyManager(String name, IPropertyManager pm)
/*     */   {
/* 116 */     this.changes.put(name, new Changes(pm));
/*     */   }
/*     */   
/*     */   public void addChange(String propertyManagerName, String key, Object value) {
/* 120 */     Changes c = (Changes)this.changes.get(propertyManagerName);
/* 121 */     if (c != null) {
/* 122 */       c.addChange(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeChange(String propertyManagerKey, String key, Object value) {
/* 127 */     Changes c = (Changes)this.changes.get(propertyManagerKey);
/* 128 */     if (c != null) {
/* 129 */       c.removeChange(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveAllChanges(ITelemetryDatabase tele) {
/* 134 */     for (Changes c : this.changes.values()) {
/* 135 */       if (c.hasChanges()) {
/* 136 */         c.applyChanges();
/*     */         
/*     */ 
/* 139 */         if (tele != null) {
/* 140 */           for (Map.Entry<String, Object> e : c.getChanges().entrySet()) {
/* 141 */             String key = (String)e.getKey();
/* 142 */             Object value = e.getValue();
/* 143 */             if ((key != null) && (value != null)) {
/* 144 */               tele.record("optionChange", "name", key, "value", Strings.toString(value));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Changes get(String key) {
/* 153 */     return (Changes)this.changes.get(key);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsChanges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */