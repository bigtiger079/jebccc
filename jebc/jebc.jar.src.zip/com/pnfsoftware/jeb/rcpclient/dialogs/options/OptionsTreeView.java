/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.options;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyDefinition;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyDefinitionManager;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyType;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyTypeBoolean;
/*     */ import com.pnfsoftware.jeb.core.properties.impl.PropertyDefinitionManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ContextMenuFilter;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.PatternTreeView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTreeViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.IFilteredTreeContentProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.IPatternMatcher;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.IValueProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.SimplePatternMatcher;
/*     */ import com.pnfsoftware.jeb.util.collect.ArrayUtil;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.jface.viewers.CellEditor;
/*     */ import org.eclipse.jface.viewers.CheckboxCellEditor;
/*     */ import org.eclipse.jface.viewers.ColumnViewer;
/*     */ import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
/*     */ import org.eclipse.jface.viewers.EditingSupport;
/*     */ import org.eclipse.jface.viewers.StyledCellLabelProvider;
/*     */ import org.eclipse.jface.viewers.TextCellEditor;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.jface.viewers.TreeViewerColumn;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerCell;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsTreeView
/*     */   extends PatternTreeView
/*     */ {
/*  59 */   private static final ILogger logger = GlobalLog.getLogger(OptionsTreeView.class);
/*     */   
/*  61 */   private static final String[] titleColumns = { S.s(667), S.s(779), S.s(247), S.s(815) };
/*     */   private final OptionsChanges.Changes changes;
/*     */   
/*     */   public static OptionsTreeView build(Composite parent, IPropertyManager pm, OptionsChanges.Changes changes, boolean expandAfterFilter) {
/*  65 */     LabelProvider labelProvider = new LabelProvider();
/*  66 */     IPatternMatcher patternMatcher = new SimplePatternMatcher(labelProvider);
/*  67 */     return new OptionsTreeView(parent, pm, changes, labelProvider, patternMatcher, expandAfterFilter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private OptionsTreeView(Composite parent, IPropertyManager pm, OptionsChanges.Changes changes, LabelProvider labelProvider, IPatternMatcher patternMatcher, boolean expandAfterFilter)
/*     */   {
/*  75 */     super(parent, 65664, titleColumns, null, patternMatcher, expandAfterFilter);
/*  76 */     this.changes = changes;
/*     */     
/*     */ 
/*     */ 
/*  80 */     final FilteredTreeViewer viewer = getTreeViewer();
/*  81 */     ContextMenuFilter.addContextMenu(viewer.getViewer(), getFilterText(), labelProvider, new String[] {
/*  82 */       S.s(667), S.s(779) }, new Boolean[] { Boolean.FALSE, Boolean.TRUE });
/*     */     
/*  84 */     final TreeContentProvider contentProvider = new TreeContentProvider();
/*     */     
/*  86 */     EditingSupport editingSupport = new ValueEditingSupport(viewer.getViewer());
/*  87 */     ColumnViewerToolTipSupport.enableFor(viewer.getViewer());
/*  88 */     changes.listeners.add(new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/*  91 */         Object[] data = (Object[])event.data;
/*  92 */         for (OptionsTreeView.PropertyLine prop : contentProvider.propertyLines) {
/*  93 */           if (prop.fqname.substring(1).equals(data[0])) {
/*  94 */             prop.value = data[1];
/*  95 */             prop.display = Objects.toString(data[1]);
/*  96 */             ((TreeViewer)viewer.getViewer()).update(prop, null);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/* 102 */     });
/* 103 */     Tree tree = getTree();
/* 104 */     tree.setHeaderVisible(true);
/* 105 */     tree.setLinesVisible(true);
/* 106 */     TreeColumn[] cols = tree.getColumns();
/* 107 */     TreeViewerColumn tcv = new TreeViewerColumn((TreeViewer)viewer.getViewer(), cols[3]);
/* 108 */     tcv.setEditingSupport(editingSupport);
/*     */     
/*     */ 
/* 111 */     viewer.setContentProvider(contentProvider);
/* 112 */     viewer.setLabelProvider(labelProvider);
/* 113 */     viewer.setInput(pm);
/*     */     
/*     */ 
/* 116 */     viewer.expandAll();
/* 117 */     for (TreeColumn col : cols) {
/* 118 */       col.pack();
/*     */     }
/* 120 */     cols[0].setWidth(cols[0].getWidth() + 20);
/* 121 */     if (cols[2].getWidth() > 200) {
/* 122 */       cols[2].setWidth(200);
/*     */     }
/* 124 */     if (cols[3].getWidth() < 200) {
/* 125 */       cols[3].setWidth(200);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TreeContentProvider implements IFilteredTreeContentProvider {
/*     */     IPropertyManager pm;
/* 131 */     List<OptionsTreeView.PropertyLine> propertyLines = new ArrayList();
/*     */     
/*     */ 
/*     */     public void dispose() {}
/*     */     
/*     */ 
/*     */     public void inputChanged(Viewer viewer, Object oldInput, Object newInput)
/*     */     {
/* 139 */       this.pm = ((IPropertyManager)newInput);
/*     */     }
/*     */     
/*     */     public Object[] getElements(Object inputElement)
/*     */     {
/* 144 */       IPropertyManager pm = (IPropertyManager)inputElement;
/* 145 */       IPropertyDefinitionManager pdm = pm.getPropertyDefinitionManager();
/* 146 */       if (pdm == null) {
/* 147 */         return ArrayUtil.NO_OBJECT;
/*     */       }
/* 149 */       return new Object[] { pdm };
/*     */     }
/*     */     
/*     */     public Object getParent(Object element)
/*     */     {
/* 154 */       return null;
/*     */     }
/*     */     
/*     */     public boolean hasChildren(Object element)
/*     */     {
/* 159 */       return getChildren(element) != null;
/*     */     }
/*     */     
/*     */     public Object[] getChildren(Object parentElement)
/*     */     {
/* 164 */       if ((parentElement instanceof IPropertyDefinitionManager)) {
/* 165 */         IPropertyDefinitionManager pdm = (IPropertyDefinitionManager)parentElement;
/* 166 */         return enumerate(this.pm, pdm);
/*     */       }
/*     */       
/* 169 */       return ArrayUtil.NO_OBJECT;
/*     */     }
/*     */     
/*     */     private Object[] enumerate(IPropertyManager pm, IPropertyDefinitionManager pdm)
/*     */     {
/* 174 */       List<Object> r = new ArrayList();
/*     */       
/*     */ 
/* 177 */       for (IPropertyDefinition definition : pdm.getDefinitions())
/* 178 */         if (!definition.isInternal())
/*     */         {
/*     */ 
/* 181 */           OptionsTreeView.PropertyLine line = new OptionsTreeView.PropertyLine();
/* 182 */           line.fqname = (pdm.getNamespace() + "." + definition.getName());
/* 183 */           line.definition = definition;
/* 184 */           line.value = pm.getValue(line.fqname, 0, true);
/* 185 */           if (line.value != null) {
/* 186 */             line.display = line.value.toString();
/*     */           }
/*     */           else {
/* 189 */             line.value = pm.getValue(line.fqname, 1, true);
/* 190 */             if (line.value != null) {
/* 191 */               line.display = "<master>";
/*     */             }
/*     */             else {
/* 194 */               line.value = pm.getValue(line.fqname, 3, true);
/* 195 */               if (line.value != null) {
/* 196 */                 line.display = "<default>";
/*     */               }
/*     */               else {
/* 199 */                 line.display = "<error>";
/*     */               }
/*     */             }
/*     */           }
/* 203 */           r.add(line);
/* 204 */           this.propertyLines.add(line);
/*     */         }
/* 206 */       Collections.sort(r, new Comparator()
/*     */       {
/*     */         public int compare(Object o1, Object o2) {
/* 209 */           return ((OptionsTreeView.PropertyLine)o1).definition.getName().compareTo(((OptionsTreeView.PropertyLine)o2).definition.getName());
/*     */         }
/*     */       });
/*     */       
/*     */ 
/* 214 */       for (IPropertyDefinitionManager pdmNext : pdm.getChildren()) {
/* 215 */         r.add(pdmNext);
/*     */       }
/*     */       
/*     */ 
/* 219 */       return r.toArray();
/*     */     }
/*     */     
/*     */     public String getString(Object element) {
/* 223 */       if ((element instanceof OptionsTreeView.PropertyLine)) {
/* 224 */         return ((OptionsTreeView.PropertyLine)element).fqname.substring(1);
/*     */       }
/* 226 */       if ((element instanceof PropertyDefinitionManager)) {
/* 227 */         return ((PropertyDefinitionManager)element).getRegion();
/*     */       }
/* 229 */       if (element != null) {
/* 230 */         return element.toString();
/*     */       }
/* 232 */       return null;
/*     */     }
/*     */     
/*     */     public Object[] getRowElements(Object row)
/*     */     {
/* 237 */       return new Object[] { getString(row) };
/*     */     }
/*     */   }
/*     */   
/*     */   static class LabelProvider extends StyledCellLabelProvider implements IValueProvider
/*     */   {
/*     */     public void update(ViewerCell cell) {
/* 244 */       String text = "";
/* 245 */       Object elt = cell.getElement();
/* 246 */       int index = cell.getColumnIndex();
/*     */       
/* 248 */       if (((elt instanceof IPropertyDefinitionManager)) && 
/* 249 */         (index == 0)) {
/* 250 */         text = ((IPropertyDefinitionManager)elt).getRegion();
/* 251 */         if (text.isEmpty()) {
/* 252 */           text = "<root>";
/*     */         }
/*     */       }
/*     */       
/* 256 */       if ((elt instanceof OptionsTreeView.PropertyLine)) {
/* 257 */         if (index == 0) {
/* 258 */           text = ((OptionsTreeView.PropertyLine)elt).definition.getName();
/*     */         }
/* 260 */         else if (index == 1) {
/* 261 */           text = ((OptionsTreeView.PropertyLine)elt).definition.getType().toString();
/*     */         }
/* 263 */         else if (index == 2) {
/* 264 */           text = ((OptionsTreeView.PropertyLine)elt).definition.getType().getDefault().toString();
/*     */         }
/* 266 */         else if (index == 3) {
/* 267 */           text = ((OptionsTreeView.PropertyLine)elt).display;
/*     */         }
/*     */       }
/*     */       
/* 271 */       cell.setText(text);
/* 272 */       super.update(cell);
/*     */     }
/*     */     
/*     */     public String getStringAt(Object element, int key)
/*     */     {
/* 277 */       if ((element instanceof OptionsTreeView.PropertyLine)) {
/* 278 */         if (key == 0) {
/* 279 */           return ((OptionsTreeView.PropertyLine)element).fqname.substring(1);
/*     */         }
/* 281 */         if (key == 1) {
/* 282 */           return ((OptionsTreeView.PropertyLine)element).definition.getType().toString();
/*     */         }
/*     */       }
/* 285 */       else if (((element instanceof PropertyDefinitionManager)) && 
/* 286 */         (key == 0)) {
/* 287 */         return ((PropertyDefinitionManager)element).getRegion();
/*     */       }
/*     */       
/* 290 */       if (element != null) {
/* 291 */         return element.toString();
/*     */       }
/* 293 */       return null;
/*     */     }
/*     */     
/*     */     public String getString(Object element)
/*     */     {
/* 298 */       return getStringAt(element, 0);
/*     */     }
/*     */   }
/*     */   
/*     */   class ValueEditingSupport extends EditingSupport {
/*     */     ColumnViewer viewer;
/*     */     TextCellEditor editor;
/*     */     CheckboxCellEditor booleanEditor;
/*     */     
/*     */     public ValueEditingSupport(ColumnViewer viewer) {
/* 308 */       super();
/* 309 */       this.viewer = viewer;
/*     */       
/* 311 */       Composite parent = (Composite)viewer.getControl();
/* 312 */       this.editor = new TextCellEditor(parent);
/* 313 */       this.booleanEditor = new CheckboxCellEditor(parent);
/*     */     }
/*     */     
/*     */     protected CellEditor getCellEditor(Object element)
/*     */     {
/* 318 */       if (!(element instanceof OptionsTreeView.PropertyLine)) {
/* 319 */         return null;
/*     */       }
/*     */       
/* 322 */       OptionsTreeView.PropertyLine line = (OptionsTreeView.PropertyLine)element;
/* 323 */       if ((line.definition.getType() instanceof IPropertyTypeBoolean)) {
/* 324 */         return this.booleanEditor;
/*     */       }
/*     */       
/* 327 */       return this.editor;
/*     */     }
/*     */     
/*     */     protected boolean canEdit(Object element)
/*     */     {
/* 332 */       return true;
/*     */     }
/*     */     
/*     */     protected Object getValue(Object element)
/*     */     {
/* 337 */       OptionsTreeView.PropertyLine line = (OptionsTreeView.PropertyLine)element;
/* 338 */       if ((line.definition.getType() instanceof IPropertyTypeBoolean)) {
/* 339 */         return Boolean.valueOf(line.value.toString());
/*     */       }
/*     */       
/* 342 */       Object value = ((OptionsTreeView.PropertyLine)element).value;
/* 343 */       if (value == null) {
/* 344 */         return "";
/*     */       }
/* 346 */       return value.toString();
/*     */     }
/*     */     
/*     */     protected void setValue(Object element, Object value)
/*     */     {
/* 351 */       OptionsTreeView.PropertyLine line = (OptionsTreeView.PropertyLine)element;
/* 352 */       if (!line.definition.getType().validate(value)) {
/* 353 */         OptionsTreeView.logger.i("Illegal value for property", new Object[0]);
/* 354 */         return;
/*     */       }
/*     */       
/* 357 */       OptionsTreeView.logger.i("Property %s is being updated", new Object[] { line.fqname });
/* 358 */       line.value = value;
/* 359 */       line.display = value.toString();
/*     */       
/* 361 */       this.viewer.update(element, null);
/*     */       
/* 363 */       OptionsTreeView.this.changes.addChange(line.fqname, value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class PropertyLine
/*     */   {
/*     */     public String fqname;
/*     */     public IPropertyDefinition definition;
/*     */     public Object value;
/*     */     public String display;
/*     */     public boolean dirty;
/*     */     
/*     */     public String toString() {
/* 376 */       return this.fqname + ": " + this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\options\OptionsTreeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */