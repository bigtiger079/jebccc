/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.BrowserUtil;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Link;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LicenseKeyDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private String licdata;
/*     */   private String lickey;
/*     */   
/*     */   public LicenseKeyDialog(Shell parent, String licdata)
/*     */   {
/*  40 */     super(parent, "JEB", true, true);
/*     */     
/*     */ 
/*  43 */     setVisualBounds(-1, 50, -1, -1);
/*     */     
/*  45 */     this.licdata = licdata;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/*  50 */     super.open();
/*  51 */     return this.lickey;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  56 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  58 */     String url = "https://www.pnfsoftware.com/genlk";
/*  59 */     String message = String.format(S.s(736), new Object[] { Licensing.user_name, "https://www.pnfsoftware.com/genlk" });
/*  60 */     message = message.replace('\n', ' ').trim();
/*  61 */     String clickableUrl = String.format("<a href=\"%s\">%s</a>", new Object[] { "https://www.pnfsoftware.com/genlk", "https://www.pnfsoftware.com/genlk" });
/*  62 */     message = message.replace("https://www.pnfsoftware.com/genlk", clickableUrl);
/*     */     
/*  64 */     Link t0 = new Link(parent, 64);
/*  65 */     t0.setText(message);
/*  66 */     t0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  67 */     ((GridData)t0.getLayoutData()).minimumWidth = 100;
/*  68 */     t0.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  71 */         String url2 = String.format("%s?licdata=%s", new Object[] { "https://www.pnfsoftware.com/genlk", LicenseKeyDialog.this.licdata });
/*  72 */         BrowserUtil.openInBrowser(url2);
/*     */       }
/*     */       
/*     */ 
/*  76 */     });
/*  77 */     new Label(parent, 0).setText("\n" + S.s(433) + ": ");
/*  78 */     Text text0 = new Text(parent, 2060);
/*  79 */     text0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  80 */     text0.setText(this.licdata);
/*  81 */     text0.selectAll();
/*  82 */     text0.setFocus();
/*     */     
/*     */ 
/*  85 */     new Label(parent, 0).setText(S.s(436) + ": ");
/*  86 */     final Text text1 = new Text(parent, 2052);
/*  87 */     text1.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*     */ 
/*  90 */     Composite c4 = new Composite(parent, 0);
/*  91 */     c4.setLayout(new RowLayout(256));
/*     */     
/*     */ 
/*  94 */     final Button btnOk = UIUtil.createPushbox(c4, S.s(605), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/*  97 */         LicenseKeyDialog.this.lickey = text1.getText();
/*  98 */         LicenseKeyDialog.this.shell.close();
/*     */       }
/* 100 */     });
/* 101 */     btnOk.setEnabled(false);
/*     */     
/*     */ 
/* 104 */     this.shell.setDefaultButton(btnOk);
/*     */     
/*     */ 
/* 107 */     text1.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 110 */         String str = text1.getText().trim();
/* 111 */         btnOk.setEnabled(LicenseKeyAutoDialog.looksLikeLicenseKey(str));
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\LicenseKeyDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */