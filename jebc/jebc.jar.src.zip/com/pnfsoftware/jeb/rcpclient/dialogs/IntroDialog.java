/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import org.eclipse.swt.browser.Browser;
/*    */ import org.eclipse.swt.browser.TitleEvent;
/*    */ import org.eclipse.swt.browser.TitleListener;
/*    */ import org.eclipse.swt.layout.FillLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntroDialog
/*    */   extends JebDialog
/*    */ {
/*    */   public IntroDialog(Shell parent)
/*    */   {
/* 31 */     super(parent, "An introduction to JEB", true, true);
/* 32 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.NONE;
/*    */   }
/*    */   
/*    */   protected void createContents(Composite parent)
/*    */   {
/* 37 */     parent.setLayout(new FillLayout());
/*    */     
/* 39 */     Browser browser = new Browser(parent, 0);
/* 40 */     browser.addTitleListener(new TitleListener()
/*    */     {
/*    */       public void changed(TitleEvent event) {
/* 43 */         IntroDialog.this.shell.setText(event.title);
/*    */       }
/*    */       
/* 46 */     });
/* 47 */     browser.setBounds(0, 0, 580, 340);
/*    */     
/*    */ 
/* 50 */     browser.setUrl("https://www.pnfsoftware.com/jeb/intro.html");
/*    */     
/*    */ 
/* 53 */     browser.setText("<a href=\"http://www.google.com\">test</a>");
/*    */     
/*    */ 
/*    */ 
/* 57 */     String s = browser.getText();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\IntroDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */