/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IEnginesPlugin;
/*     */ import com.pnfsoftware.jeb.core.IOptionDefinition;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsForEnginesPluginDialog
/*     */   extends JebDialog
/*     */ {
/*  37 */   private static final ILogger logger = GlobalLog.getLogger(OptionsForEnginesPluginDialog.class);
/*     */   
/*     */   private IEnginesPlugin plugin;
/*  40 */   private List<Text> widgetDatas = new ArrayList();
/*     */   private Map<String, String> options;
/*     */   
/*     */   public OptionsForEnginesPluginDialog(Shell parent, IEnginesPlugin plugin) {
/*  44 */     super(parent, S.s(317), true, true);
/*  45 */     this.scrolledContainer = true;
/*  46 */     this.plugin = plugin;
/*     */   }
/*     */   
/*     */   public Map<String, String> open()
/*     */   {
/*  51 */     super.open();
/*  52 */     return this.options;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  57 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  59 */     new Label(parent, 0).setText(S.s(651));
/*     */     
/*  61 */     Group g = new Group(parent, 0);
/*  62 */     g.setText("Options");
/*  63 */     g.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  64 */     g.setLayout(new GridLayout(2, false));
/*     */     
/*  66 */     List<? extends IOptionDefinition> deflist = this.plugin.getExecutionOptionDefinitions();
/*  67 */     if (deflist != null) {
/*  68 */       for (IOptionDefinition opt : deflist) {
/*  69 */         String name = opt.getName();
/*  70 */         String desc = Strings.safe(opt.getDescription());
/*  71 */         String defaultValue = opt.getDefaultValue();
/*     */         
/*  73 */         if (name == null) {
/*  74 */           Label label = new Label(g, 0);
/*  75 */           label.setText(desc);
/*  76 */           label.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*     */ 
/*     */         }
/*  79 */         else if (name.isEmpty()) {
/*  80 */           logger.warn("Invalid property definition (empty)", new Object[0]);
/*     */         }
/*     */         else
/*     */         {
/*  84 */           new Label(g, 0).setText(desc);
/*     */           
/*  86 */           Text widgetData = new Text(g, 2052);
/*  87 */           widgetData.setLayoutData(UIUtil.createGridDataForText(widgetData, 30));
/*     */           
/*     */ 
/*  90 */           widgetData.setData("optionName", name);
/*  91 */           widgetData.setText(Strings.safe(defaultValue));
/*  92 */           this.widgetDatas.add(widgetData);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 102 */     this.options = new HashMap();
/* 103 */     for (Text widgetData : this.widgetDatas) {
/* 104 */       this.options.put((String)widgetData.getData("optionName"), widgetData.getText());
/*     */     }
/* 106 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\OptionsForEnginesPluginDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */