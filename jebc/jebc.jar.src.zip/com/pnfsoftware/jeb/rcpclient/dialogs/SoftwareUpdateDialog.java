/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.base.RunnableWithProgressCallback;
/*     */ import com.pnfsoftware.jeb.util.io.IO;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoftwareUpdateDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private RcpClientContext context;
/*     */   private boolean expiredLicense;
/*     */   
/*     */   public SoftwareUpdateDialog(Shell parent, RcpClientContext context, boolean expiredLicense)
/*     */   {
/*  44 */     super(parent, S.s(744), true, true);
/*     */     
/*     */ 
/*     */ 
/*  48 */     this.context = context;
/*  49 */     this.expiredLicense = expiredLicense;
/*     */     
/*  51 */     setVisualBounds(20, 60, 20, 80);
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  56 */     super.open();
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  62 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  64 */     Group g0 = new Group(parent, 0);
/*  65 */     g0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  66 */     g0.setLayout(new GridLayout(1, false));
/*  67 */     g0.setText(S.s(395));
/*     */     
/*  69 */     Label t0 = new Label(g0, 64);
/*  70 */     t0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  71 */     t0.setText("If your machine is connected to the Internet, press the button below to perform an update check.");
/*     */     
/*  73 */     Button btn = UIUtil.createPushbox(g0, S.s(194), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/*  76 */         SoftwareUpdateDialog.this.context.executeTask("Checking for update", new RunnableWithProgressCallback()
/*     */         {
/*     */           public void run() {
/*  79 */             SoftwareUpdateDialog.this.context.checkUpdate(true, SoftwareUpdateDialog.this.expiredLicense, this.callback);
/*     */           }
/*  81 */         });
/*  82 */         SoftwareUpdateDialog.this.shell.close();
/*     */       }
/*  84 */     });
/*  85 */     btn.setEnabled(this.context != null);
/*     */     
/*  87 */     Group g1 = new Group(parent, 0);
/*  88 */     g1.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  89 */     g1.setLayout(new GridLayout(1, false));
/*  90 */     g1.setText("Manual update");
/*     */     
/*  92 */     Label t1 = new Label(g1, 64);
/*  93 */     t1.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  94 */     t1.setText("Users in SCIF have the option to perform a manual update. Refer to your most recent update email from PNF Software for details.");
/*     */     
/*     */ 
/*  97 */     UIUtil.createPushbox(g1, S.s(635) + "...", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 100 */         ManualSoftwareUpdateDialog d = new ManualSoftwareUpdateDialog(SoftwareUpdateDialog.this.shell);
/* 101 */         String[] r = d.open();
/* 102 */         if (r == null) {
/* 103 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 107 */           byte[] data = IO.readFile(r[0]);
/* 108 */           SoftwareUpdateDialog.this.context.dumpUpdateToDisk(data, r[1]);
/*     */         }
/*     */         catch (IOException e) {
/* 111 */           return;
/*     */         }
/*     */         
/* 114 */         SoftwareUpdateDialog.this.context.installUpdate(SoftwareUpdateDialog.this.shell, null);
/* 115 */         SoftwareUpdateDialog.this.shell.close();
/*     */       }
/* 117 */     });
/* 118 */     btn.setEnabled(this.context != null);
/*     */     
/* 120 */     Label t3 = new Label(parent, 64);
/* 121 */     t3.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 122 */     t3.setText("If you cannot or do not have access to the registered email address, send us an email at support@pnfsoftware.com - Thank you.");
/*     */     
/*     */ 
/* 125 */     Composite buttons = new Composite(parent, 0);
/* 126 */     buttons.setLayout(new GridLayout(2, false));
/* 127 */     buttons.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*     */     
/* 129 */     createOkayButton(parent);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\SoftwareUpdateDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */