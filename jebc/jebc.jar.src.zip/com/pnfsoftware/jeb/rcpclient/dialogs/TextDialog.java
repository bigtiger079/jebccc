/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontMetrics;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private Text text;
/*     */   private String textLabel;
/*     */   private String input;
/*     */   private Font font;
/*     */   private int linecount;
/*     */   private int colcount;
/*     */   private boolean editable;
/*     */   private boolean selected;
/*     */   private String initialText;
/*     */   private Integer labelOk;
/*     */   private Integer labelCancel;
/*     */   protected Button btnOk;
/*     */   protected Button btnCancel;
/*     */   
/*     */   public TextDialog(Shell parent, String caption, String initialText, String widgetName)
/*     */   {
/*  51 */     super(parent, caption, true, true, widgetName);
/*     */     
/*     */ 
/*     */ 
/*  55 */     this.linecount = 1;
/*  56 */     this.colcount = 20;
/*  57 */     this.editable = true;
/*  58 */     this.selected = false;
/*  59 */     this.initialText = initialText;
/*  60 */     this.labelOk = Integer.valueOf(605);
/*  61 */     this.labelCancel = Integer.valueOf(105);
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/*  65 */     this.font = font;
/*     */   }
/*     */   
/*     */   public void setInitialText(String text) {
/*  69 */     this.initialText = text;
/*     */   }
/*     */   
/*     */   public void setTextLabel(String label) {
/*  73 */     this.textLabel = label;
/*     */   }
/*     */   
/*     */   public void setLineCount(int linecount) {
/*  77 */     this.linecount = linecount;
/*     */   }
/*     */   
/*     */   public void setColumnCount(int colcount) {
/*  81 */     this.colcount = colcount;
/*     */   }
/*     */   
/*     */   public void setEditable(boolean editable) {
/*  85 */     this.editable = editable;
/*     */   }
/*     */   
/*     */   public void setSelected(boolean selected) {
/*  89 */     this.selected = selected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOkLabelId(Integer labelId)
/*     */   {
/*  99 */     this.labelOk = labelId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCancelLabelId(Integer labelId)
/*     */   {
/* 109 */     this.labelCancel = labelId;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/* 114 */     super.open();
/* 115 */     return this.input;
/*     */   }
/*     */   
/*     */   public String getInputText() {
/* 119 */     return this.input;
/*     */   }
/*     */   
/*     */   public final void createContents(Composite parent)
/*     */   {
/* 124 */     UIUtil.setStandardLayout(parent);
/*     */     
/* 126 */     createBeforeText(parent);
/*     */     
/* 128 */     createText(parent);
/*     */     
/* 130 */     createAfterText(parent);
/*     */     
/* 132 */     createButtons(parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createBeforeText(Composite parent) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createAfterText(Composite parent) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createText(Composite parent)
/*     */   {
/* 152 */     if (this.textLabel != null) {
/* 153 */       new Label(parent, 0).setText(this.textLabel + ": ");
/*     */     }
/* 155 */     GridData data = new GridData();
/* 156 */     if (this.linecount >= 2) {
/* 157 */       this.text = new Text(parent, 2626);
/*     */     }
/*     */     else {
/* 160 */       this.text = new Text(parent, 2052);
/*     */     }
/* 162 */     this.text.setFont(this.font);
/* 163 */     GC gc = new GC(this.text);
/*     */     try {
/* 165 */       gc.setFont(this.text.getFont());
/* 166 */       FontMetrics fm = gc.getFontMetrics();
/* 167 */       data = new GridData(this.colcount * fm.getAverageCharWidth(), this.linecount * fm.getHeight());
/*     */     }
/*     */     finally {
/* 170 */       gc.dispose();
/*     */     }
/* 172 */     data.grabExcessHorizontalSpace = true;
/* 173 */     data.horizontalAlignment = 4;
/* 174 */     data.grabExcessVerticalSpace = true;
/* 175 */     data.verticalAlignment = 4;
/* 176 */     this.text.setLayoutData(data);
/*     */     
/* 178 */     this.text.setEditable(this.editable);
/*     */     
/* 180 */     if (this.initialText != null) {
/* 181 */       this.text.setText(this.initialText);
/* 182 */       if (this.selected) {
/* 183 */         this.text.selectAll();
/*     */       }
/*     */     }
/*     */     
/* 187 */     UIUtil.disableTabOutput(this.text);
/*     */   }
/*     */   
/*     */   protected void createButtons(Composite parent)
/*     */   {
/* 192 */     List<int[]> avails = new ArrayList();
/* 193 */     if (this.labelOk != null) {
/* 194 */       avails.add(new int[] { 32, this.labelOk.intValue() == -1 ? 'ɝ' : this.labelOk.intValue() });
/*     */     }
/* 196 */     if (this.labelCancel != null) {
/* 197 */       avails.add(new int[] { 256, this.labelCancel.intValue() == -1 ? 105 : this.labelCancel.intValue() });
/*     */     }
/* 199 */     createButtons(parent, 0, (int[][])avails.toArray(new int[avails.size()][]), 32);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 204 */     this.input = this.text.getText();
/* 205 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\TextDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */