/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.core.units.IInteractiveUnit;
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.IUnit;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReferencesDialog
/*    */   extends DataFrameDialog
/*    */ {
/* 30 */   private static final ILogger logger = GlobalLog.getLogger(ReferencesDialog.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReferencesDialog(Shell parent, String caption, List<String> addresses, List<String> details, IUnit unit)
/*    */   {
/* 43 */     super(parent, caption, true, "referencesDialog");
/*    */     
/* 45 */     if (addresses == null) {
/* 46 */       logger.i("The list of addresses is null", new Object[0]);
/* 47 */       addresses = new ArrayList();
/*    */     }
/* 49 */     if ((details != null) && (details.size() != addresses.size()))
/* 50 */       throw new IllegalArgumentException();
/*    */     IInteractiveUnit iunit;
/*    */     DataFrame df;
/*    */     int i;
/* 54 */     DataFrame df; if ((unit instanceof IInteractiveUnit)) {
/* 55 */       iunit = (IInteractiveUnit)unit;
/* 56 */       df = new DataFrame(new String[] { S.s(52), S.s(424), details != null ? S.s(270) : S.s(203) });
/* 57 */       df.setRenderedBaseForNumberObjects(16);
/* 58 */       i = 0;
/* 59 */       for (String address : addresses) {
/* 60 */         Object label = iunit.getAddressLabel(address);
/* 61 */         if ((label == null) && ((unit instanceof INativeCodeUnit)))
/*    */         {
/* 63 */           label = Long.valueOf(((INativeCodeUnit)iunit).getCanonicalMemoryAddress(address));
/*    */         }
/*    */         String extra;
/*    */         String extra;
/* 67 */         if ((details == null) || (details.get(i) == null)) {
/* 68 */           extra = iunit.getComment(address);
/*    */         }
/*    */         else {
/* 71 */           extra = (String)details.get(i);
/*    */         }
/*    */         
/* 74 */         df.addRow(new Object[] { address, label, extra });
/* 75 */         i++;
/*    */       }
/*    */     }
/*    */     else {
/* 79 */       df = new DataFrame(new String[] { S.s(52) });
/* 80 */       for (String address : addresses) {
/* 81 */         df.addRow(new Object[] { address });
/*    */       }
/*    */     }
/*    */     
/* 85 */     setDataFrame(df);
/* 86 */     setDisplayIndex(true);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ReferencesDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */