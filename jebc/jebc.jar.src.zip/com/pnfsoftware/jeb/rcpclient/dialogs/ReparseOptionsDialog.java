/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyDefinition;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyDefinitionManager;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReparseOptionsDialog
/*     */   extends JebDialog
/*     */ {
/*  44 */   private static final ILogger logger = GlobalLog.getLogger(ReparseOptionsDialog.class);
/*     */   
/*     */   private IUnit unit;
/*  47 */   private List<Text> widgetDatas = new ArrayList();
/*     */   private Map<String, Object> options;
/*     */   
/*     */   public ReparseOptionsDialog(Shell parent, IUnit unit) {
/*  51 */     super(parent, "Processing options", true, true);
/*  52 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public Map<String, Object> open()
/*     */   {
/*  57 */     super.open();
/*  58 */     return this.options;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  63 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*     */ 
/*     */ 
/*  67 */     Group g = new Group(parent, 0);
/*  68 */     g.setText("Options");
/*  69 */     g.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*  70 */     g.setLayout(new GridLayout(2, false));
/*     */     
/*  72 */     IPropertyDefinitionManager pdm = this.unit.getPropertyDefinitionManager();
/*  73 */     IPropertyManager pm = this.unit.getPropertyManager();
/*  74 */     for (IPropertyDefinition def : pdm.getDefinitions()) {
/*  75 */       String name = def.getName();
/*  76 */       Object value = pm.getValue(name);
/*     */       
/*  78 */       new Label(g, 0).setText(name);
/*     */       
/*  80 */       Text widgetData = new Text(g, 2052);
/*  81 */       widgetData.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  82 */       widgetData.setData("optionName", name);
/*  83 */       this.widgetDatas.add(widgetData);
/*     */       
/*  85 */       widgetData.setText(Strings.safe(value));
/*     */     }
/*     */     
/*  88 */     Composite buttons = new Composite(parent, 0);
/*  89 */     buttons.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*  90 */     buttons.setLayout(new RowLayout(256));
/*     */     
/*  92 */     Button btn_ok = UIUtil.createPushbox(buttons, S.s(605), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/*  95 */         ReparseOptionsDialog.this.options = new HashMap();
/*  96 */         for (Text widgetData : ReparseOptionsDialog.this.widgetDatas) {
/*  97 */           ReparseOptionsDialog.this.options.put((String)widgetData.getData("optionName"), widgetData.getText());
/*     */         }
/*  99 */         ReparseOptionsDialog.this.shell.close();
/*     */       }
/* 101 */     });
/* 102 */     UIUtil.createPushbox(buttons, S.s(105), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 105 */         ReparseOptionsDialog.this.options = null;
/* 106 */         ReparseOptionsDialog.this.shell.close();
/*     */       }
/* 108 */     });
/* 109 */     this.shell.setDefaultButton(btn_ok);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ReparseOptionsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */