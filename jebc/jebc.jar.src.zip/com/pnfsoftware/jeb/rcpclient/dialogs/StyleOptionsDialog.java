/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.output.ItemClassIdentifiers;
/*     */ import com.pnfsoftware.jeb.rcpclient.FontManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.themes.ThemeManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.Style;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.StyleManager;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.custom.CCombo;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.FontDialog;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyleOptionsDialog
/*     */   extends JebDialog
/*     */ {
/*  45 */   private static final ILogger logger = GlobalLog.getLogger(StyleOptionsDialog.class);
/*     */   
/*  47 */   private Boolean modified = Boolean.FALSE;
/*     */   
/*     */   private ThemeManager themeManager;
/*     */   
/*     */   private FontManager fontman;
/*     */   
/*     */   private FontManager fontman0;
/*     */   
/*     */   private StyleManager styleman;
/*     */   
/*     */   private StyleManager styleman0;
/*     */   
/*     */   private Label labelFontName;
/*     */   
/*     */   private Button btnDarkTheme;
/*     */   
/*     */   private CCombo colors;
/*     */   
/*     */ 
/*     */   public StyleOptionsDialog(Shell parent, ThemeManager themeManager, StyleManager styleManager, FontManager fontManager)
/*     */   {
/*  68 */     super(parent, S.s(755), true, true);
/*  69 */     this.scrolledContainer = true;
/*  70 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */     
/*  72 */     this.themeManager = themeManager;
/*     */     
/*  74 */     if (styleManager == null) {
/*  75 */       throw new NullPointerException();
/*     */     }
/*  77 */     this.styleman = styleManager;
/*     */     
/*  79 */     this.fontman = fontManager;
/*     */   }
/*     */   
/*     */   public Boolean open()
/*     */   {
/*  84 */     super.open();
/*  85 */     return this.modified;
/*     */   }
/*     */   
/*     */   protected void createContents(final Composite parent)
/*     */   {
/*  90 */     UIUtil.setStandardLayout(parent);
/*     */     
/*     */ 
/*  93 */     if (this.fontman != null) {
/*  94 */       this.fontman0 = this.fontman.clone();
/*     */       
/*  96 */       Group grpFont = new Group(parent, 0);
/*  97 */       grpFont.setLayout(new GridLayout(2, false));
/*  98 */       grpFont.setText(S.s(202));
/*  99 */       grpFont.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */       
/* 101 */       UIUtil.createPushbox(grpFont, S.s(722) + "...", new SelectionAdapter()
/*     */       {
/*     */         public void widgetSelected(SelectionEvent event) {
/* 104 */           FontDialog dlgFontSelect = new FontDialog(StyleOptionsDialog.this.shell);
/* 105 */           Font codefont = StyleOptionsDialog.this.fontman.getCodeFont();
/* 106 */           dlgFontSelect.setFontList(codefont.getFontData());
/* 107 */           FontData fd = dlgFontSelect.open();
/* 108 */           if (fd != null) {
/* 109 */             codefont = new Font(parent.getDisplay(), dlgFontSelect.getFontList());
/* 110 */             StyleOptionsDialog.this.fontman.setCodeFont(codefont);
/* 111 */             StyleOptionsDialog.this.refreshWidgets();
/*     */           }
/*     */           
/*     */         }
/* 115 */       });
/* 116 */       this.labelFontName = new Label(grpFont, 2048);
/* 117 */       this.labelFontName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     }
/*     */     
/*     */ 
/* 121 */     this.styleman0 = this.styleman.clone();
/*     */     
/*     */ 
/* 124 */     Group grpTheme = new Group(parent, 0);
/* 125 */     grpTheme.setLayout(new GridLayout(2, false));
/* 126 */     grpTheme.setText(S.s(771));
/* 127 */     grpTheme.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 129 */     this.btnDarkTheme = UIUtil.createCheckbox(grpTheme, S.s(810), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 132 */         boolean selected = StyleOptionsDialog.this.btnDarkTheme.getSelection();
/* 133 */         boolean restart = StyleOptionsDialog.this.themeManager.setActiveTheme(selected ? "theme.dark" : "theme.standard");
/* 134 */         if (restart) {}
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 141 */     });
/* 142 */     createColorPickerForClassIds(parent);
/*     */     
/* 144 */     Composite buttons = new Composite(parent, 0);
/* 145 */     buttons.setLayout(new GridLayout(3, false));
/* 146 */     buttons.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*     */     
/* 148 */     UIUtil.createPushbox(buttons, S.s(605), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 151 */         StyleOptionsDialog.this.modified = Boolean.TRUE;
/* 152 */         StyleOptionsDialog.this.shell.close();
/*     */       }
/*     */       
/* 155 */     });
/* 156 */     UIUtil.createPushbox(buttons, S.s(105), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 159 */         if (StyleOptionsDialog.this.fontman != null) {
/* 160 */           StyleOptionsDialog.this.fontman.restore(StyleOptionsDialog.this.fontman0, true);
/*     */         }
/* 162 */         StyleOptionsDialog.this.styleman.restore(StyleOptionsDialog.this.styleman0, true);
/* 163 */         StyleOptionsDialog.this.shell.close();
/*     */       }
/*     */       
/* 166 */     });
/* 167 */     UIUtil.createPushbox(buttons, S.s(681), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 170 */         if (StyleOptionsDialog.this.fontman != null) {
/* 171 */           StyleOptionsDialog.this.fontman.resetDefaults(true, true);
/*     */         }
/* 173 */         StyleOptionsDialog.this.styleman.resetDefaults(true);
/* 174 */         StyleOptionsDialog.this.refreshWidgets();
/*     */       }
/*     */       
/* 177 */     });
/* 178 */     refreshWidgets();
/*     */   }
/*     */   
/*     */   private void refreshWidgets()
/*     */   {
/* 183 */     if (this.fontman != null) {
/* 184 */       Font codefont = this.fontman.getCodeFont();
/* 185 */       if ((codefont != null) && (codefont.getFontData().length >= 1)) {
/* 186 */         FontData fd = codefont.getFontData()[0];
/* 187 */         String text = String.format("%s %dpt", new Object[] { fd.getName(), Integer.valueOf(fd.getHeight()) });
/* 188 */         if ((fd.getStyle() & 0x1) != 0) {
/* 189 */           text = text + " " + S.s(99);
/*     */         }
/* 191 */         if ((fd.getStyle() & 0x2) != 0) {
/* 192 */           text = text + " " + S.s(407);
/*     */         }
/* 194 */         this.labelFontName.setText(text);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 199 */     if (this.themeManager == null) {
/* 200 */       this.btnDarkTheme.setEnabled(false);
/*     */     }
/*     */     else {
/* 203 */       this.btnDarkTheme.setSelection(this.themeManager.isDarkTheme());
/*     */     }
/*     */     
/*     */ 
/* 207 */     this.colors.select(0);
/* 208 */     this.colors.notifyListeners(13, new Event());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void createColorPickerForClassIds(Composite parent)
/*     */   {
/* 215 */     Group c0 = new Group(parent, 0);
/* 216 */     c0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 217 */     c0.setLayout(new RowLayout(512));
/* 218 */     c0.setText(S.s(196));
/*     */     
/* 220 */     Composite c1 = new Composite(c0, 0);
/* 221 */     c1.setLayout(new RowLayout(256));
/*     */     
/* 223 */     Label lbl_sc = new Label(c1, 0);
/* 224 */     lbl_sc.setText(S.s(779) + ":  ");
/* 225 */     this.colors = new CCombo(c1, 8390664);
/*     */     
/* 227 */     final ItemClassIdentifiers[] style_types = ItemClassIdentifiers.values();
/* 228 */     for (ItemClassIdentifiers classId : style_types) {
/* 229 */       this.colors.add(classId.toString());
/*     */     }
/*     */     
/* 232 */     Group c2 = new Group(c0, 0);
/* 233 */     c2.setLayout(new RowLayout(256));
/* 234 */     c2.setText(S.s(597));
/*     */     
/* 236 */     final ColorPickerView normal_fgcolor = new ColorPickerView(c2, S.s(355));
/* 237 */     final ColorPickerView normal_bgcolor = new ColorPickerView(c2, S.s(96));
/* 238 */     final Button normal_bold = UIUtil.createCheckbox(c2, S.s(99), null);
/* 239 */     final Button normal_italic = UIUtil.createCheckbox(c2, S.s(407), null);
/*     */     
/* 241 */     Group c3 = new Group(c0, 0);
/* 242 */     c3.setLayout(new RowLayout(256));
/* 243 */     c3.setText(S.s(49));
/*     */     
/* 245 */     final ColorPickerView active_fgcolor = new ColorPickerView(c3, S.s(355));
/* 246 */     final ColorPickerView active_bgcolor = new ColorPickerView(c3, S.s(96));
/* 247 */     final Button active_bold = UIUtil.createCheckbox(c3, S.s(99), null);
/* 248 */     final Button active_italic = UIUtil.createCheckbox(c3, S.s(407), null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */     this.colors.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 257 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/*     */         
/*     */ 
/* 260 */         Style style = StyleOptionsDialog.this.styleman.getNormalStyle(style_types[index]);
/* 261 */         normal_fgcolor.setColor(style.getColor());
/* 262 */         normal_bgcolor.setColor(style.getBackgroungColor());
/* 263 */         normal_bold.setSelection(style.isBold());
/* 264 */         normal_italic.setSelection(style.isItalic());
/*     */         
/*     */ 
/* 267 */         style = StyleOptionsDialog.this.styleman.getActiveStyle(style_types[index]);
/* 268 */         active_fgcolor.setColor(style.getColor());
/* 269 */         active_bgcolor.setColor(style.getBackgroungColor());
/* 270 */         active_bold.setSelection(style.isBold());
/* 271 */         active_italic.setSelection(style.isItalic());
/*     */       }
/*     */       
/* 274 */     });
/* 275 */     SelectionAdapter listener_normal_fgcolor = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 278 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 279 */         StyleOptionsDialog.this.styleman.getNormalStyle(style_types[index]).setColor(((ColorPickerView)e.widget).getColor());
/*     */       }
/* 281 */     };
/* 282 */     normal_fgcolor.addSelectionListener(listener_normal_fgcolor);
/*     */     
/* 284 */     SelectionAdapter listener_normal_bgcolor = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 287 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 288 */         StyleOptionsDialog.this.styleman.getNormalStyle(style_types[index]).setBackgroundColor(((ColorPickerView)e.widget).getColor());
/*     */       }
/* 290 */     };
/* 291 */     normal_bgcolor.addSelectionListener(listener_normal_bgcolor);
/*     */     
/* 293 */     normal_bold.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 296 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 297 */         StyleOptionsDialog.this.styleman.getNormalStyle(style_types[index]).setBold(((Button)e.widget).getSelection());
/*     */       }
/*     */       
/* 300 */     });
/* 301 */     normal_italic.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 304 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 305 */         StyleOptionsDialog.this.styleman.getNormalStyle(style_types[index]).setItalic(((Button)e.widget).getSelection());
/*     */       }
/*     */       
/* 308 */     });
/* 309 */     SelectionAdapter listener_active_fgcolor = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 312 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 313 */         StyleOptionsDialog.this.styleman.getActiveStyle(style_types[index]).setColor(((ColorPickerView)e.widget).getColor());
/*     */       }
/* 315 */     };
/* 316 */     active_fgcolor.addSelectionListener(listener_active_fgcolor);
/*     */     
/* 318 */     SelectionAdapter listener_active_bgcolor = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 321 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 322 */         StyleOptionsDialog.this.styleman.getActiveStyle(style_types[index]).setBackgroundColor(((ColorPickerView)e.widget).getColor());
/*     */       }
/* 324 */     };
/* 325 */     active_bgcolor.addSelectionListener(listener_active_bgcolor);
/*     */     
/* 327 */     active_bold.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 330 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 331 */         StyleOptionsDialog.this.styleman.getActiveStyle(style_types[index]).setBold(((Button)e.widget).getSelection());
/*     */       }
/*     */       
/* 334 */     });
/* 335 */     active_italic.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 338 */         int index = StyleOptionsDialog.this.colors.getSelectionIndex();
/* 339 */         StyleOptionsDialog.this.styleman.getActiveStyle(style_types[index]).setItalic(((Button)e.widget).getSelection());
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\StyleOptionsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */