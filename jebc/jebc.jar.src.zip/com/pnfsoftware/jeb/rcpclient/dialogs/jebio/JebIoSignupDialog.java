/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.jebio;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.jebio.JebIoApiHelper;
/*     */ import com.pnfsoftware.jeb.client.jebio.JebIoObjectUser;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.format.Validator;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.eclipse.jface.dialogs.TitleAreaDialog;
/*     */ import org.eclipse.swt.events.HelpEvent;
/*     */ import org.eclipse.swt.events.HelpListener;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JebIoSignupDialog
/*     */   extends TitleAreaDialog
/*     */ {
/*  43 */   private static final ILogger logger = GlobalLog.getLogger(JebIoSignupDialog.class);
/*     */   
/*     */   RcpClientContext context;
/*     */   
/*     */   String emailHint;
/*     */   Text txtEmail;
/*     */   Text txtPassword;
/*     */   Text txtPassword2;
/*     */   Button btnSignup;
/*     */   String email;
/*     */   String password;
/*     */   String apikey;
/*     */   
/*     */   public JebIoSignupDialog(Shell shell, RcpClientContext context, String emailHint)
/*     */   {
/*  58 */     super(shell);
/*  59 */     this.context = context;
/*  60 */     this.emailHint = emailHint;
/*     */   }
/*     */   
/*     */   protected boolean isResizable()
/*     */   {
/*  65 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isHelpAvailable()
/*     */   {
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public void create()
/*     */   {
/*  75 */     super.create();
/*     */     
/*     */ 
/*  78 */     getShell().addHelpListener(new HelpListener()
/*     */     {
/*     */       public void helpRequested(HelpEvent e)
/*     */       {
/*  82 */         new JebIoHelpDialog(JebIoSignupDialog.this.getShell()).open();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected Control createDialogArea(Composite parent)
/*     */   {
/*  89 */     getShell().setText("Sign up");
/*  90 */     setTitle("JEB Malware Sharing Network");
/*  91 */     setMessage("Fill out the following form to create a new account", 1);
/*     */     
/*  93 */     Composite area = (Composite)super.createDialogArea(parent);
/*  94 */     Composite container = new Composite(area, 0);
/*  95 */     container.setLayoutData(new GridData(4, 4, true, true));
/*  96 */     GridLayout layout = new GridLayout(2, false);
/*  97 */     container.setLayout(layout);
/*     */     
/*  99 */     createEmailField(container, this.emailHint);
/* 100 */     createPasswordField(container, null);
/* 101 */     createPasswordConfirmationField(container, null);
/*     */     
/* 103 */     this.txtEmail.setFocus();
/* 104 */     this.txtEmail.selectAll();
/* 105 */     return area;
/*     */   }
/*     */   
/*     */   private void createEmailField(Composite container, String defValue) {
/* 109 */     Label lbtFirstName = new Label(container, 0);
/* 110 */     lbtFirstName.setText("Email Address:");
/* 111 */     GridData data = new GridData();
/* 112 */     data.grabExcessHorizontalSpace = true;
/* 113 */     data.horizontalAlignment = 4;
/* 114 */     this.txtEmail = new Text(container, 2048);
/* 115 */     this.txtEmail.setLayoutData(data);
/* 116 */     this.txtEmail.setText(Strings.safe(defValue));
/*     */   }
/*     */   
/*     */   private void createPasswordField(Composite container, String defValue) {
/* 120 */     Label lbtLastName = new Label(container, 0);
/* 121 */     lbtLastName.setText("Password:");
/* 122 */     GridData data = new GridData();
/* 123 */     data.grabExcessHorizontalSpace = true;
/* 124 */     data.horizontalAlignment = 4;
/* 125 */     this.txtPassword = new Text(container, 4196352);
/* 126 */     this.txtPassword.setLayoutData(data);
/* 127 */     this.txtPassword.setText(Strings.safe(defValue));
/*     */   }
/*     */   
/*     */   private void createPasswordConfirmationField(Composite container, String defValue) {
/* 131 */     Label lbtLastName = new Label(container, 0);
/* 132 */     lbtLastName.setText("Confirm your Password:");
/* 133 */     GridData data = new GridData();
/* 134 */     data.grabExcessHorizontalSpace = true;
/* 135 */     data.horizontalAlignment = 4;
/* 136 */     this.txtPassword2 = new Text(container, 4196352);
/* 137 */     this.txtPassword2.setLayoutData(data);
/* 138 */     this.txtPassword2.setText(Strings.safe(defValue));
/*     */   }
/*     */   
/*     */   protected void okPressed()
/*     */   {
/* 143 */     this.email = this.txtEmail.getText();
/* 144 */     if (!Validator.isLegalEmail(this.email)) {
/* 145 */       UI.warn("The provided email is illegal");
/* 146 */       this.txtEmail.setFocus();
/* 147 */       return;
/*     */     }
/*     */     
/* 150 */     this.password = this.txtPassword.getText();
/* 151 */     if (Strings.isBlank(this.password)) {
/* 152 */       UI.warn("The password field is empty");
/* 153 */       this.txtPassword.setFocus();
/* 154 */       return;
/*     */     }
/*     */     
/* 157 */     if (!this.password.equals(this.txtPassword2.getText())) {
/* 158 */       UI.warn("The password does not match the confirmation password");
/* 159 */       this.txtPassword2.setFocus();
/* 160 */       return;
/*     */     }
/*     */     
/* 163 */     final JebIoApiHelper helper = new JebIoApiHelper(this.context.getNetworkUtility(), null);
/* 164 */     JebIoObjectUser user = (JebIoObjectUser)this.context.executeNetworkTask(new Callable()
/*     */     {
/*     */       public JebIoObjectUser call() throws Exception {
/*     */         try {
/* 168 */           return helper.createUser(JebIoSignupDialog.this.email, JebIoSignupDialog.this.password);
/*     */         }
/*     */         catch (IOException e) {
/* 171 */           UI.error("An error occurred.\n\nException: " + e.getMessage()); }
/* 172 */         return null;
/*     */       }
/*     */     });
/*     */     
/* 176 */     if (user == null) {
/* 177 */       return;
/*     */     }
/*     */     
/* 180 */     if (user.getCode() != 0L) {
/* 181 */       UI.error("The account was not created.\n\nResponse code: " + user.getCode());
/* 182 */       return;
/*     */     }
/*     */     
/* 185 */     this.apikey = user.getApikey();
/* 186 */     String msg = String.format("Your account was created.\n\nA confirmation email was sent to %s", new Object[] { this.email });
/* 187 */     UI.info(getShell(), "Congratulations!", msg);
/*     */     
/* 189 */     setReturnCode(0);
/* 190 */     close();
/*     */   }
/*     */   
/*     */   public String getEmail() {
/* 194 */     return this.email;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 198 */     return this.password;
/*     */   }
/*     */   
/*     */   public String getApiKey() {
/* 202 */     return this.apikey;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\jebio\JebIoSignupDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */