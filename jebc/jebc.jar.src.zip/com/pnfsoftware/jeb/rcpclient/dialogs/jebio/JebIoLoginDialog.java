/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.jebio;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.jebio.JebIoApiHelper;
/*     */ import com.pnfsoftware.jeb.client.jebio.JebIoObjectUser;
/*     */ import com.pnfsoftware.jeb.client.jebio.JebIoUtil;
/*     */ import com.pnfsoftware.jeb.client.jebio.UserCredentials;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.util.format.PluralFormatter;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.format.Validator;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.jface.dialogs.TitleAreaDialog;
/*     */ import org.eclipse.jface.resource.JFaceResources;
/*     */ import org.eclipse.swt.events.HelpEvent;
/*     */ import org.eclipse.swt.events.HelpListener;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JebIoLoginDialog
/*     */   extends TitleAreaDialog
/*     */ {
/*  54 */   private static final ILogger logger = GlobalLog.getLogger(JebIoLoginDialog.class);
/*     */   
/*     */   private static final int SIGNUP_ID = 1025;
/*     */   RcpClientContext context;
/*     */   UserCredentials previousCredentials;
/*     */   Text txtEmail;
/*     */   Text txtPassword;
/*     */   Text textApikey;
/*     */   Button btnVerify;
/*     */   Button btnSignup;
/*     */   boolean verified;
/*     */   
/*     */   public JebIoLoginDialog(Shell shell, RcpClientContext context)
/*     */   {
/*  68 */     super(shell);
/*  69 */     this.context = context;
/*     */   }
/*     */   
/*     */   protected boolean isResizable()
/*     */   {
/*  74 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isHelpAvailable()
/*     */   {
/*  79 */     return true;
/*     */   }
/*     */   
/*     */   public void create()
/*     */   {
/*  84 */     super.create();
/*     */     
/*     */ 
/*  87 */     getShell().addHelpListener(new HelpListener()
/*     */     {
/*     */       public void helpRequested(HelpEvent e) {
/*  90 */         new JebIoHelpDialog(JebIoLoginDialog.this.getShell()).open();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected Control createDialogArea(Composite parent)
/*     */   {
/*  97 */     getShell().setText("Login");
/*  98 */     setTitle("JEB Malware Sharing Network");
/*  99 */     if (!JebIoUtil.retrieveCredentials(this.context).lookValid()) {
/* 100 */       setMessage("Click the \"Create an Account\" button to get started, or log in using your credentials.", 2);
/*     */     }
/*     */     else {
/* 103 */       setMessage("Your account on the JEB Malware Sharing Network", 1);
/*     */     }
/*     */     
/* 106 */     Composite area = (Composite)super.createDialogArea(parent);
/*     */     
/* 108 */     Composite container = new Composite(area, 0);
/* 109 */     container.setLayoutData(new GridData(4, 4, true, true));
/* 110 */     GridLayout layout = new GridLayout(1, false);
/* 111 */     container.setLayout(layout);
/*     */     
/* 113 */     Group container2 = new Group(container, 0);
/* 114 */     container2.setText("Log in");
/* 115 */     container2.setLayoutData(new GridData(4, 4, true, true));
/* 116 */     container2.setLayout(new GridLayout(2, false));
/*     */     
/* 118 */     this.previousCredentials = JebIoUtil.retrieveCredentials(this.context);
/* 119 */     createEmailField(container2, this.previousCredentials.getEmail());
/* 120 */     createPasswordField(container2, this.previousCredentials.getPassword());
/* 121 */     createApiKeyField(container2, this.previousCredentials.getApikey());
/* 122 */     createVerifyButton(container2);
/*     */     
/* 124 */     this.txtEmail.setFocus();
/* 125 */     this.txtEmail.selectAll();
/* 126 */     return area;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void createButtonsForButtonBar(Composite parent)
/*     */   {
/* 132 */     parent.setLayoutData(new GridData(4, 16777216, true, false));
/*     */     
/* 134 */     createButton(parent, 1025, "Create an Account", false)
/* 135 */       .addSelectionListener(new SelectionAdapter()
/*     */       {
/*     */         public void widgetSelected(SelectionEvent e)
/*     */         {
/* 138 */           if ((JebIoLoginDialog.this.previousCredentials.lookValid()) && 
/* 139 */             (!MessageDialog.openQuestion(JebIoLoginDialog.this.getShell(), "Proceed", "It looks like you have an account already.\n\nWould you like to sign up for another account?")))
/*     */           {
/* 141 */             return;
/*     */           }
/*     */           
/* 144 */           JebIoSignupDialog dlg = new JebIoSignupDialog(JebIoLoginDialog.this.getShell(), JebIoLoginDialog.this.context, JebIoLoginDialog.this.txtEmail.getText());
/* 145 */           int retcode = dlg.open();
/* 146 */           if (retcode == 0) {
/* 147 */             JebIoLoginDialog.this.txtEmail.setText(dlg.getEmail());
/* 148 */             JebIoLoginDialog.this.txtPassword.setText(dlg.getPassword());
/* 149 */             JebIoLoginDialog.this.textApikey.setText(dlg.getApiKey());
/*     */           }
/*     */           
/*     */         }
/*     */         
/* 154 */       });
/* 155 */     Label spacer = new Label(parent, 0);
/* 156 */     spacer.setLayoutData(new GridData(4, 16777216, true, false));
/*     */     
/*     */ 
/* 159 */     GridLayout layout = (GridLayout)parent.getLayout();
/* 160 */     layout.numColumns += 1;
/* 161 */     layout.makeColumnsEqualWidth = false;
/*     */     
/* 163 */     createButton(parent, 0, "OK", true);
/* 164 */     createButton(parent, 1, "Cancel", false);
/*     */   }
/*     */   
/*     */   private void createEmailField(Composite container, String defValue) {
/* 168 */     Label lbtFirstName = new Label(container, 0);
/* 169 */     lbtFirstName.setText("Email Address:");
/*     */     
/* 171 */     GridData data = new GridData();
/* 172 */     data.grabExcessHorizontalSpace = true;
/* 173 */     data.horizontalAlignment = 4;
/*     */     
/* 175 */     this.txtEmail = new Text(container, 2048);
/* 176 */     this.txtEmail.setLayoutData(data);
/* 177 */     this.txtEmail.setText(Strings.safe(defValue));
/* 178 */     this.txtEmail.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 181 */         JebIoLoginDialog.this.verified = false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void createPasswordField(Composite container, String defValue) {
/* 187 */     Label lbtLastName = new Label(container, 0);
/* 188 */     lbtLastName.setText("Password:");
/*     */     
/* 190 */     GridData data = new GridData();
/* 191 */     data.grabExcessHorizontalSpace = true;
/* 192 */     data.horizontalAlignment = 4;
/* 193 */     this.txtPassword = new Text(container, 4196352);
/* 194 */     this.txtPassword.setLayoutData(data);
/* 195 */     this.txtPassword.setText(Strings.safe(defValue));
/* 196 */     this.txtPassword.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 199 */         JebIoLoginDialog.this.verified = false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void createApiKeyField(Composite container, String defValue) {
/* 205 */     Label lbtLastName = new Label(container, 0);
/* 206 */     lbtLastName.setText("API Key:");
/*     */     
/* 208 */     GridData data = new GridData();
/* 209 */     data.grabExcessHorizontalSpace = true;
/* 210 */     data.horizontalAlignment = 4;
/* 211 */     this.textApikey = new Text(container, 2056);
/* 212 */     this.textApikey.setLayoutData(data);
/* 213 */     this.textApikey.setText(Strings.safe(defValue));
/*     */   }
/*     */   
/*     */   private void createVerifyButton(Composite container) {
/* 217 */     Label lbtLastName = new Label(container, 0);
/* 218 */     lbtLastName.setText("");
/*     */     
/* 220 */     GridData data = new GridData();
/* 221 */     data.grabExcessHorizontalSpace = false;
/* 222 */     data.horizontalAlignment = 1;
/* 223 */     this.btnVerify = new Button(container, 8);
/* 224 */     this.btnVerify.setFont(JFaceResources.getDialogFont());
/* 225 */     this.btnVerify.setLayoutData(data);
/* 226 */     this.btnVerify.setText("View my Profile");
/*     */     
/* 228 */     this.btnVerify.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 231 */         JebIoObjectUser user = JebIoLoginDialog.this.getUser(JebIoLoginDialog.this.txtEmail.getText(), JebIoLoginDialog.this.txtPassword.getText());
/* 232 */         if (user != null) {
/* 233 */           StringBuilder sb = new StringBuilder();
/* 234 */           int level = 30;
/*     */           
/* 236 */           if (!user.isConfirmed()) {
/* 237 */             sb.append("[[ Your account has not been confirmed yet. Check for an email from PNF Software to confirm it. ]]\n\n");
/* 238 */             level = 40;
/*     */           }
/*     */           
/* 241 */           int score = user.getScore();
/* 242 */           int sharecount = user.getSharecount();
/* 243 */           String lastsharets = user.getLastsharets();
/* 244 */           int receivecount = user.getReceivecount();
/*     */           
/*     */ 
/* 247 */           sb.append(String.format("Your score: %s\n\n", new Object[] { score == 0 ? "N/A" : Integer.toString(score) }));
/*     */           
/* 249 */           if (sharecount == 0) {
/* 250 */             sb.append("You haven't shared any sample yet!\n\n");
/*     */           }
/*     */           else {
/* 253 */             sb.append(String.format("You have shared a total of %d %s.\nYour last contribution was made on %s.\n\n", new Object[] { Integer.valueOf(sharecount), 
/* 254 */               PluralFormatter.countS(Integer.valueOf(sharecount), "sample"), lastsharets }));
/*     */           }
/*     */           
/* 257 */           if (receivecount == 0) {
/* 258 */             if (sharecount == 0) {
/* 259 */               sb.append("You haven't received samples yet.");
/*     */             }
/*     */             else {
/* 262 */               sb.append("You haven't received samples yet.");
/*     */             }
/*     */           }
/*     */           else {
/* 266 */             sb.append(String.format("You have received a total of %d %s in exchange for your contribution.", new Object[] {
/* 267 */               Integer.valueOf(receivecount), PluralFormatter.countS(Integer.valueOf(receivecount), "sample") }));
/*     */           }
/*     */           
/* 270 */           UI.log(level, JebIoLoginDialog.this.getShell(), "My Profile", sb.toString());
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   boolean verify(String email, String password, boolean silentOnSuccess)
/*     */   {
/* 278 */     if (!Validator.isLegalEmail(email)) {
/* 279 */       UI.warn("The provided email is illegal");
/* 280 */       return false;
/*     */     }
/* 282 */     if (password.isEmpty()) {
/* 283 */       UI.warn("The password is blank");
/* 284 */       return false;
/*     */     }
/*     */     
/* 287 */     JebIoObjectUser user = getUser(email, password);
/* 288 */     if (user == null) {
/* 289 */       return false;
/*     */     }
/*     */     
/* 292 */     String apikey = user.getApikey();
/* 293 */     this.textApikey.setText(apikey);
/* 294 */     if (!silentOnSuccess) {
/* 295 */       UI.info("Log in was successful.");
/*     */     }
/* 297 */     JebIoUtil.saveCredentials(this.context, new UserCredentials(email, password, apikey));
/*     */     
/* 299 */     this.verified = true;
/* 300 */     return true;
/*     */   }
/*     */   
/*     */   JebIoObjectUser getUser(String email, String password) {
/* 304 */     final JebIoApiHelper helper = new JebIoApiHelper(this.context.getNetworkUtility(), new UserCredentials(email, password, ""));
/* 305 */     JebIoObjectUser user = (JebIoObjectUser)this.context.executeNetworkTask(new Callable()
/*     */     {
/*     */       public JebIoObjectUser call() throws Exception {
/*     */         try {
/* 309 */           return helper.getUser();
/*     */         }
/*     */         catch (IOException e) {
/* 312 */           UI.error("An error occurred.\n\nException: " + e.getMessage()); }
/* 313 */         return null;
/*     */       }
/*     */     });
/*     */     
/* 317 */     if (user == null) {
/* 318 */       UI.error("Login failed.");
/* 319 */       return null;
/*     */     }
/* 321 */     if (user.getCode() != 0L) {
/* 322 */       UI.error("Login failed.\n\nResponse code: " + user.getCode());
/* 323 */       return null;
/*     */     }
/* 325 */     return user;
/*     */   }
/*     */   
/*     */   protected void okPressed()
/*     */   {
/* 330 */     String email = this.txtEmail.getText();
/* 331 */     String password = this.txtPassword.getText();
/* 332 */     if ((!this.verified) && (!verify(email, password, this.previousCredentials.lookValid()))) {
/* 333 */       this.txtEmail.setFocus();
/* 334 */       return;
/*     */     }
/* 336 */     super.okPressed();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\jebio\JebIoLoginDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */