/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.jebio;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.util.BrowserUtil;
/*    */ import org.eclipse.jface.dialogs.MessageDialog;
/*    */ import org.eclipse.swt.graphics.Image;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JebIoHelpDialog
/*    */   extends MessageDialog
/*    */ {
/*    */   public JebIoHelpDialog(Shell shell)
/*    */   {
/* 25 */     super(shell, "Help", (Image)null, "Participants in the JEB Malware Sharing Network receive some samples that other users have been sharing. The samples you receive are determined algorithmically based on the quantity and quality of your contributions.\n\nIn order to share a file currently opened in JEB, click the \"Share\" button in the toolbar, or use the \"File, Share\" menu entry.\n\nThis service is entirely optional. Your contributions are anonymous.", 2, new String[] { "OK", "More Help Online" }, 0);
/*    */   }
/*    */   
/*    */   protected boolean isResizable()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   protected void buttonPressed(int buttonId)
/*    */   {
/* 35 */     if (buttonId == 1) {
/* 36 */       BrowserUtil.openInBrowser("https://www.pnfsoftware.com/jeb/msninfo");
/* 37 */       return;
/*    */     }
/* 39 */     super.buttonPressed(buttonId);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\jebio\JebIoHelpDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */