package com.pnfsoftware.jeb.rcpclient.dialogs.jebio;

public class JebIoMessages
{
  public static final String MsnName = "JEB Malware Sharing Network";
  public static final String msgIntro = "The JEB Malware Sharing Network is an optional service available to all JEB users.\n\nCreate your account to have the opportunity to anonymously share malware samples and files, at your own discretion.\n\nParticipants will receive samples that other users have been sharing. The samples you will receive are determined algorithmically based on the quantity and quality of your contributions.\n\nContinue to log in or sign up. (This service is optional and disabled by default.)";
  public static final String msgNagProjectOpened = "Would you like to share this sample on the JEB Malware Sharing Network?\nReverse engineers who contribute will receive additional samples in return.\n\nYou may share at any time by pressing the 'Share' button in the toolbar.\nPress 'Yes' to learn more.\n";
  public static final String msgHelp = "Participants in the JEB Malware Sharing Network receive some samples that other users have been sharing. The samples you receive are determined algorithmically based on the quantity and quality of your contributions.\n\nIn order to share a file currently opened in JEB, click the \"Share\" button in the toolbar, or use the \"File, Share\" menu entry.\n\nThis service is entirely optional. Your contributions are anonymous.";
  public static final String msgHelp2 = "The JEB Malware Sharing Network is an optional service available to all JEB users.\n\nCreate your account to have the opportunity to anonymously share malware samples and files, at your own discretion.\n\nParticipants will receive samples that other users have been sharing. The samples you will receive are determined algorithmically based on the quantity and quality of your contributions.\n\nThis service is optional and disabled by default. Press OK to log in or sign up.";
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\jebio\JebIoMessages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */