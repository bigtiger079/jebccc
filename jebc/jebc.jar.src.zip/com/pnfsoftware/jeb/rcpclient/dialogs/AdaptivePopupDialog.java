/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdaptivePopupDialog
/*     */   extends JebDialog
/*     */ {
/*     */   public static final int TYPE_INFORMATION = 1;
/*     */   public static final int TYPE_QUESTION = 2;
/*     */   private int type;
/*     */   private String message;
/*     */   private Button btnDoNotShow;
/*     */   private int retval;
/*  36 */   boolean doNotShow = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AdaptivePopupDialog(Shell parent, int type, String caption, String message, String widgetName)
/*     */   {
/*  49 */     super(parent, caption, true, true, widgetName);
/*  50 */     this.scrolledContainer = true;
/*  51 */     setMessage(message);
/*  52 */     setVisualBounds(30, -1, 15, -1);
/*     */     
/*  54 */     if ((type != 1) && (type != 2)) {
/*  55 */       throw new IllegalArgumentException("Invalid dialog type");
/*     */     }
/*  57 */     this.type = type;
/*     */   }
/*     */   
/*     */   public void setMessage(String message) {
/*  61 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer open()
/*     */   {
/*  69 */     super.open();
/*  70 */     return Integer.valueOf(this.retval);
/*     */   }
/*     */   
/*     */   private void setPreferredShellIcon() {
/*  74 */     Image icon = null;
/*  75 */     if (this.type == 1) {
/*  76 */       icon = Display.getCurrent().getSystemImage(2);
/*     */     }
/*  78 */     else if (this.type == 2) {
/*  79 */       icon = Display.getCurrent().getSystemImage(4);
/*     */     }
/*  81 */     if (icon != null) {
/*  82 */       this.shell.setImage(icon);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  88 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  90 */     setPreferredShellIcon();
/*     */     
/*  92 */     Label label = new Label(parent, 64);
/*  93 */     label.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  94 */     label.setText(Strings.safe(this.message, "< " + S.s(287) + " >"));
/*     */     
/*     */ 
/*  97 */     new Label(parent, 64).setText("");
/*     */     
/*  99 */     this.btnDoNotShow = UIUtil.createCheckbox(parent, S.s(281), null);
/* 100 */     if ((getWidgetManager() != null) && (getWidgetName() != null)) {
/* 101 */       this.btnDoNotShow.setSelection(!getWidgetManager().getShouldShowDialog(getWidgetName()));
/*     */     }
/*     */     else {
/* 104 */       this.btnDoNotShow.setEnabled(false);
/*     */     }
/*     */     
/* 107 */     if (this.type == 1) {
/* 108 */       createButtons(parent, 32, 32);
/*     */     }
/* 110 */     else if (this.type == 2) {
/* 111 */       createButtons(parent, 192, 64);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 117 */     record();
/* 118 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   protected void onButtonNo()
/*     */   {
/* 123 */     record();
/* 124 */     super.onButtonNo();
/*     */   }
/*     */   
/*     */   protected void onButtonYes()
/*     */   {
/* 129 */     this.retval = 1;
/* 130 */     record();
/* 131 */     super.onButtonYes();
/*     */   }
/*     */   
/*     */   public boolean isDoNotShow() {
/* 135 */     return this.doNotShow;
/*     */   }
/*     */   
/*     */   private void record() {
/* 139 */     this.doNotShow = this.btnDoNotShow.getSelection();
/* 140 */     if ((getWidgetManager() != null) && (getWidgetName() != null)) {
/* 141 */       getWidgetManager().setShouldShowDialog(getWidgetName(), !this.doNotShow);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\AdaptivePopupDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */