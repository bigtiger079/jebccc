/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IRuntimeProject;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.eclipse.jface.resource.JFaceResources;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectPropertiesDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private IRuntimeProject project;
/*     */   private Text widgetName;
/*     */   private StyledText widgetNotes;
/*     */   
/*     */   public ProjectPropertiesDialog(Shell parent, IRuntimeProject project)
/*     */   {
/*  39 */     super(parent, S.s(658), true, true);
/*  40 */     this.scrolledContainer = true;
/*     */     
/*  42 */     if (project == null) {
/*  43 */       throw new NullPointerException();
/*     */     }
/*  45 */     this.project = project;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  50 */     super.open();
/*     */     
/*  52 */     return null;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  57 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  59 */     new Label(parent, 0).setText(S.s(657) + ": ");
/*  60 */     this.widgetName = new Text(parent, 2052);
/*  61 */     this.widgetName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  62 */     this.widgetName.setText(this.project.getName());
/*  63 */     this.widgetName.selectAll();
/*  64 */     this.widgetName.setFocus();
/*     */     
/*  66 */     new Label(parent, 0).setText(S.s(214) + ": ");
/*  67 */     Text widgetCtime = new Text(parent, 2060);
/*  68 */     widgetCtime.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  69 */     DateFormat df = DateFormat.getDateTimeInstance();
/*  70 */     String str_ctime = df.format(new Date(this.project.getCreationTimestamp()));
/*  71 */     String str_tz = df.getTimeZone().getDisplayName(false, 0);
/*  72 */     widgetCtime.setText(str_ctime + " " + str_tz);
/*  73 */     widgetCtime.selectAll();
/*     */     
/*  75 */     new Label(parent, 0).setText(S.s(428) + ": ");
/*  76 */     Text widgetMtime = new Text(parent, 2060);
/*  77 */     widgetMtime.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  78 */     long ts = this.project.getRecordedTimestamp();
/*  79 */     if (ts == 0L) {
/*  80 */       widgetMtime.setText("N/A");
/*     */     }
/*     */     else {
/*  83 */       String str_mtime = df.format(new Date(ts));
/*  84 */       widgetMtime.setText(str_mtime + " " + str_tz);
/*     */     }
/*  86 */     widgetMtime.selectAll();
/*     */     
/*  88 */     new Label(parent, 0).setText(S.s(422) + ": ");
/*  89 */     Text widgetKey = new Text(parent, 2060);
/*  90 */     widgetKey.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  91 */     widgetKey.setText(this.project.getKey());
/*  92 */     widgetKey.selectAll();
/*     */     
/*  94 */     new Label(parent, 0).setText(S.s(78) + ": ");
/*  95 */     new Label(parent, 0).setText("" + this.project.getLiveArtifacts().size());
/*     */     
/*  97 */     new Label(parent, 0).setText(S.s(599) + ": ");
/*  98 */     new Label(parent, 0).setText("");
/*  99 */     this.widgetNotes = new StyledText(parent, 2818);
/* 100 */     this.widgetNotes.setAlwaysShowScrollBars(false);
/* 101 */     this.widgetNotes.setText(this.project.getNotes());
/* 102 */     this.widgetNotes.setFont(JFaceResources.getTextFont());
/* 103 */     GridData griddata = UIUtil.createGridDataForText(this.widgetNotes, 50, 3, false);
/* 104 */     griddata.horizontalSpan = 2;
/* 105 */     griddata.grabExcessHorizontalSpace = true;
/* 106 */     griddata.horizontalAlignment = 4;
/* 107 */     griddata.grabExcessVerticalSpace = true;
/* 108 */     griddata.verticalAlignment = 4;
/* 109 */     this.widgetNotes.setLayoutData(griddata);
/* 110 */     UIUtil.disableTabOutput(this.widgetNotes);
/*     */     
/* 112 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 117 */     this.project.setName(this.widgetName.getText());
/* 118 */     this.project.setNotes(this.widgetNotes.getText());
/* 119 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ProjectPropertiesDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */