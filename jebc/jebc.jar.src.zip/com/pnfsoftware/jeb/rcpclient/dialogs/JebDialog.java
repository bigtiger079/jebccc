/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilterText;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.SwtUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.custom.ScrolledComposite;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Dialog;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JebDialog
/*     */   extends Dialog
/*     */ {
/*     */   private static IWidgetManager standardWidgetManager;
/*     */   private IWidgetManager widgetManager;
/*     */   private String widgetName;
/*     */   private int widthMinRatio;
/*     */   private int widthMaxRatio;
/*     */   private int heightMinRatio;
/*     */   private int heightMaxRatio;
/*     */   protected Shell shell;
/*     */   protected boolean doNotOpenShell;
/*     */   protected boolean doNotDispatchEvents;
/*     */   
/*     */   public static void setStandardWidgetManager(IWidgetManager widgetManager)
/*     */   {
/*  49 */     standardWidgetManager = widgetManager;
/*     */   }
/*     */   
/*     */   public static IWidgetManager getStandardWidgetManager() {
/*  53 */     return standardWidgetManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   protected ShellWrapper.BoundsRestorationType boundsRestorationType = ShellWrapper.BoundsRestorationType.POSITION;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean scrolledContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JebDialog(Shell parent, String caption, boolean resizable, boolean modal)
/*     */   {
/* 105 */     this(parent, caption, resizable, modal, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JebDialog(Shell parent, String caption, boolean resizable, boolean modal, String widgetName)
/*     */   {
/* 119 */     this(parent == null ? Display.getCurrent().getActiveShell() : parent, 0x860 | (resizable ? 16 : 0) | (modal ? 65536 : 0), caption, widgetName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JebDialog(Shell parent, int style, String caption, String widgetName)
/*     */   {
/* 135 */     super(parent, style);
/*     */     
/* 137 */     if (caption != null) {
/* 138 */       setText(caption);
/*     */     }
/*     */     
/* 141 */     this.widgetManager = (this.widgetManager != null ? this.widgetManager : standardWidgetManager);
/* 142 */     this.widgetName = ((widgetName != null) && (!widgetName.isEmpty()) ? widgetName : getClass().getName());
/*     */     
/* 144 */     setVisualBounds(20, 80, 20, 80);
/*     */   }
/*     */   
/*     */   public void setText(String text)
/*     */   {
/* 149 */     super.setText(text);
/* 150 */     if (this.shell != null) {
/* 151 */       this.shell.setText(super.getText());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setVisualBounds(int widthMinRatio, int widthMaxRatio, int heightMinRatio, int heightMaxRatio) {
/* 156 */     if ((widthMinRatio >= 0) && (widthMinRatio <= 100)) {
/* 157 */       this.widthMinRatio = widthMinRatio;
/* 158 */       if (this.widthMaxRatio < this.widthMinRatio) {
/* 159 */         this.widthMaxRatio = this.widthMinRatio;
/*     */       }
/*     */     }
/* 162 */     if ((widthMaxRatio >= 0) && (widthMaxRatio <= 100)) {
/* 163 */       this.widthMaxRatio = widthMaxRatio;
/* 164 */       if (this.widthMaxRatio < this.widthMinRatio) {
/* 165 */         this.widthMinRatio = this.widthMaxRatio;
/*     */       }
/*     */     }
/* 168 */     if ((heightMinRatio >= 0) && (heightMinRatio <= 100)) {
/* 169 */       this.heightMinRatio = heightMinRatio;
/* 170 */       if (this.heightMaxRatio < this.heightMinRatio) {
/* 171 */         this.heightMaxRatio = this.heightMinRatio;
/*     */       }
/*     */     }
/* 174 */     if ((heightMaxRatio >= 0) && (heightMaxRatio <= 100)) {
/* 175 */       this.heightMaxRatio = heightMaxRatio;
/* 176 */       if (this.heightMaxRatio < this.heightMinRatio) {
/* 177 */         this.heightMinRatio = this.heightMaxRatio;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getWidgetName() {
/* 183 */     return this.widgetName;
/*     */   }
/*     */   
/*     */   public IWidgetManager getWidgetManager() {
/* 187 */     return this.widgetManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object open()
/*     */   {
/* 199 */     Shell parent = getParent();
/*     */     
/*     */ 
/* 202 */     Rectangle parentBounds = parent.getBounds();
/* 203 */     int wmax = this.widthMaxRatio * parentBounds.width / 100;
/* 204 */     int wmin = this.widthMinRatio * parentBounds.width / 100;
/* 205 */     int hmax = this.heightMaxRatio * parentBounds.height / 100;
/* 206 */     int hmin = this.heightMinRatio * parentBounds.height / 100;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */     this.shell = new Shell(parent, getStyle());
/* 213 */     this.shell.setText(getText());
/* 214 */     UIUtil.setWidgetName(this.shell, this.widgetName);
/* 215 */     ShellWrapper shellWrapper = ShellWrapper.wrap(this.shell, this.widgetManager);
/*     */     
/* 217 */     boolean hasRecordedBounds = (shellWrapper != null) && (shellWrapper.hasRecordedBounds());
/* 218 */     if ((this.boundsRestorationType != ShellWrapper.BoundsRestorationType.NONE) && (!hasRecordedBounds)) {
/* 219 */       this.shell.setSize(wmax, hmax);
/*     */     }
/*     */     
/*     */ 
/* 223 */     ScrolledComposite sctl = null;
/* 224 */     Composite ctl = null;
/* 225 */     this.shell.setLayout(new FillLayout());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     if (this.scrolledContainer) {
/* 233 */       sctl = new ScrolledComposite(this.shell, 768);
/* 234 */       sctl.setExpandHorizontal(true);
/* 235 */       sctl.setExpandVertical(true);
/* 236 */       ctl = new Composite(sctl, 0);
/* 237 */       sctl.setContent(ctl);
/*     */     }
/*     */     else {
/* 240 */       ctl = new Composite(this.shell, 0);
/*     */     }
/* 242 */     createContents(ctl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 247 */     if (this.scrolledContainer) {
/* 248 */       sctl.setMinSize(ctl.computeSize(-1, -1));
/*     */     }
/*     */     
/* 251 */     this.shell.pack();
/*     */     
/*     */ 
/* 254 */     if (this.boundsRestorationType != ShellWrapper.BoundsRestorationType.NONE)
/*     */     {
/*     */ 
/* 257 */       if (hasRecordedBounds) {
/* 258 */         switch (this.boundsRestorationType) {
/*     */         case POSITION: 
/* 260 */           this.shell.setLocation(shellWrapper.getRecordedPosition());
/* 261 */           break;
/*     */         case SIZE: 
/* 263 */           this.shell.setSize(shellWrapper.getRecordedSize());
/* 264 */           break;
/*     */         case SIZE_AND_POSITION: 
/* 266 */           this.shell.setBounds(shellWrapper.getRecordedBounds());
/* 267 */           break;
/*     */         
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 276 */         boolean smallerWidth = false;
/* 277 */         boolean smallerHeight = false;
/*     */         
/* 279 */         Point dlgsize = this.shell.getSize();
/* 280 */         if (dlgsize.x > wmax) {
/* 281 */           dlgsize.x = wmax;
/* 282 */           smallerWidth = true;
/*     */         }
/* 284 */         else if (dlgsize.x < wmin) {
/* 285 */           dlgsize.x = wmin;
/*     */         }
/* 287 */         if (dlgsize.y > hmax) {
/* 288 */           dlgsize.y = hmax;
/* 289 */           smallerHeight = true;
/*     */         }
/* 291 */         else if (dlgsize.y < hmin) {
/* 292 */           dlgsize.y = hmin;
/*     */         }
/*     */         
/* 295 */         if ((smallerWidth) && (!smallerHeight)) {
/* 296 */           int y = this.shell.computeSize(dlgsize.x, -1).y;
/* 297 */           if ((y >= hmin) && (y <= hmax)) {
/* 298 */             dlgsize.y = y;
/*     */           }
/*     */         }
/* 301 */         if ((!smallerWidth) && (smallerHeight)) {
/* 302 */           int x = this.shell.computeSize(-1, dlgsize.y).x;
/* 303 */           if ((x >= wmin) && (x <= wmax)) {
/* 304 */             dlgsize.x = x;
/*     */           }
/*     */         }
/*     */         
/* 308 */         this.shell.setSize(dlgsize);
/*     */         
/*     */ 
/* 311 */         dlgsize = this.shell.getSize();
/* 312 */         this.shell.setLocation(parentBounds.x + (parentBounds.width - dlgsize.x) / 2, parentBounds.y + (parentBounds.height - dlgsize.y) / 2);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 317 */     this.shell.addListener(31, new Listener()
/*     */     {
/*     */       public void handleEvent(Event e)
/*     */       {
/* 321 */         if (e.detail == 4) {
/* 322 */           e.doit = JebDialog.this.allowKeyboardEnterExecution(e);
/*     */         }
/*     */       }
/*     */     });
/*     */     
/*     */ 
/* 328 */     if (!this.doNotOpenShell) {
/* 329 */       this.shell.open();
/*     */     }
/*     */     
/* 332 */     if (!this.doNotDispatchEvents) {
/* 333 */       Display display = parent.getDisplay();
/* 334 */       while (!this.shell.isDisposed()) {
/* 335 */         if (!display.readAndDispatch()) {
/* 336 */           SwtUtil.sleep(display);
/*     */         }
/*     */       }
/*     */     }
/* 340 */     return null;
/*     */   }
/*     */   
/*     */   public Shell getShell() {
/* 344 */     return this.shell;
/*     */   }
/*     */   
/*     */   public void setFocus() {
/* 348 */     this.shell.setFocus();
/*     */   }
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 352 */     this.shell.setVisible(visible);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */   private static final int[][] defaultAvailableButtons = { { 32, 605 }, { 256, 105 }, { 64, 828 }, { 128, 594 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void createContents(Composite paramComposite);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 375 */   private Map<Integer, Button> buttons = new HashMap();
/*     */   
/*     */   protected Button getButtonByStyle(int style) {
/* 378 */     return (Button)this.buttons.get(Integer.valueOf(style)); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Composite createOkayButton(Composite parent)
/*     */   {
/* 387 */     return createButtons(parent, 32, 32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Composite createOkayCancelButtons(Composite parent)
/*     */   {
/* 398 */     return createButtons(parent, 288, 32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Composite createButtons(Composite parent, int buttonStyles, int defaultButton)
/*     */   {
/* 412 */     List<int[]> avails = new ArrayList();
/* 413 */     for (int[] button : defaultAvailableButtons) {
/* 414 */       int buttonMask = button[0];
/* 415 */       if ((buttonStyles & buttonMask) != 0) {
/* 416 */         avails.add(button);
/*     */       }
/*     */     }
/* 419 */     return createButtons(parent, 0, (int[][])avails.toArray(new int[avails.size()][]), defaultButton);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Composite createButtons(Composite parent, int style, int[][] availableButtons, int defaultButtonId)
/*     */   {
/* 437 */     Composite buttonsPanel = new Composite(parent, style);
/* 438 */     int cols; if ((parent.getLayout() instanceof GridLayout)) {
/* 439 */       cols = availableButtons.length;
/* 440 */       buttonsPanel.setLayoutData(UIUtil.createGridDataSpanHorizontally(cols));
/*     */     }
/* 442 */     buttonsPanel.setLayout(new RowLayout(256));
/*     */     
/* 444 */     for (int[] button : availableButtons) {
/* 445 */       final int buttonId = button[0];
/* 446 */       Button btn = UIUtil.createPushbox(buttonsPanel, S.s(button[1]), new SelectionAdapter()
/*     */       {
/*     */         public void widgetSelected(SelectionEvent event) {
/* 449 */           JebDialog.this.onButtonClick(buttonId);
/*     */         }
/* 451 */       });
/* 452 */       this.buttons.put(Integer.valueOf(button[0]), btn);
/* 453 */       if (buttonId == defaultButtonId) {
/* 454 */         this.shell.setDefaultButton(btn);
/*     */       }
/*     */     }
/* 457 */     return buttonsPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onButtonClick(int style)
/*     */   {
/* 468 */     if (style == 32) {
/* 469 */       onConfirm();
/*     */     }
/* 471 */     else if (style == 256) {
/* 472 */       onCancel();
/*     */     }
/* 474 */     else if (style == 64) {
/* 475 */       onButtonYes();
/*     */     }
/* 477 */     else if (style == 128) {
/* 478 */       onButtonNo();
/*     */     }
/*     */     else {
/* 481 */       this.shell.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onConfirm()
/*     */   {
/* 489 */     this.shell.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onCancel()
/*     */   {
/* 496 */     this.shell.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onButtonYes()
/*     */   {
/* 503 */     this.shell.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onButtonNo()
/*     */   {
/* 510 */     this.shell.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean allowKeyboardEnterExecution(Event e)
/*     */   {
/* 519 */     return !FilterText.isSelected();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\JebDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */