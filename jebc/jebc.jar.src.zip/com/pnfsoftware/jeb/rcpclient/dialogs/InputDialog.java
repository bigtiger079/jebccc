/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private Text text;
/*     */   private String message;
/*     */   private boolean confirmed;
/*     */   private String value;
/*     */   private boolean multiline;
/*     */   private int minColumnCount;
/*     */   private int minLineCount;
/*     */   
/*     */   public InputDialog(Shell parent, String caption, String initialValue)
/*     */   {
/*  35 */     this(parent, caption, initialValue, false, 0, 0);
/*     */   }
/*     */   
/*     */   public InputDialog(Shell parent, String caption, String initialValue, boolean multiline, int minColumnCount, int minLineCount) {
/*  39 */     super(parent, caption, true, true);
/*  40 */     this.scrolledContainer = true;
/*     */     
/*  42 */     this.value = Strings.safe(initialValue);
/*  43 */     this.multiline = multiline;
/*  44 */     this.minColumnCount = minColumnCount;
/*  45 */     this.minLineCount = minLineCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(String message)
/*     */   {
/*  54 */     this.message = message;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  58 */     return this.value;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/*  63 */     super.open();
/*  64 */     return this.confirmed ? this.value : null;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  69 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  71 */     Label label = new Label(parent, 0);
/*  72 */     label.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, false));
/*  73 */     if (this.message != null) {
/*  74 */       label.setText(this.message);
/*     */     }
/*     */     
/*     */ 
/*  78 */     if (this.minColumnCount <= 0) {
/*  79 */       if (this.value != null) {
/*  80 */         this.minColumnCount = this.value.length();
/*     */       }
/*     */       else {
/*  83 */         this.minColumnCount = 40;
/*     */       }
/*     */     }
/*     */     
/*  87 */     this.minColumnCount = Math.max(30, Math.min(this.minColumnCount, 60));
/*  88 */     this.minLineCount = Math.max(1, Math.min(this.minLineCount, 10));
/*     */     
/*  90 */     if ((this.multiline) && (this.minLineCount >= 1)) {
/*  91 */       this.text = UIUtil.createTextboxInGrid(parent, 2626, this.minColumnCount, this.minLineCount);
/*     */     }
/*     */     else {
/*  94 */       this.text = UIUtil.createTextboxInGrid(parent, 2048, this.minColumnCount, 1);
/*     */     }
/*  96 */     if (this.value != null) {
/*  97 */       this.text.setText(this.value);
/*  98 */       this.text.selectAll();
/*  99 */       this.value = null;
/*     */     }
/*     */     
/* 102 */     UIUtil.disableTabOutput(this.text);
/*     */     
/* 104 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 109 */     this.confirmed = true;
/* 110 */     this.value = this.text.getText();
/* 111 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\InputDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */