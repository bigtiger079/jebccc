/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.core.units.IUnitNotification;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*    */ import java.util.List;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationsDialog
/*    */   extends DataFrameDialog
/*    */ {
/*    */   public NotificationsDialog(Shell parent, List<? extends IUnitNotification> anomalies)
/*    */   {
/* 27 */     super(parent, S.s(602), true, "notificationsDialog");
/*    */     
/* 29 */     DataFrame df = new DataFrame(new String[] { S.s(779), S.s(268), S.s(52) });
/* 30 */     for (IUnitNotification a : anomalies) {
/* 31 */       df.addRow(new Object[] { a.getType(), a.getDescription(), a.getAddress() });
/*    */     }
/*    */     
/* 34 */     setDataFrame(df);
/* 35 */     setDisplayIndex(true);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\NotificationsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */