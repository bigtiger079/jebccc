/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IEnginesContext;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.IDebuggerMachineInformation;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.IDebuggerProcessInformation;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.IDebuggerTargetEnumerator;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.IDebuggerUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.IDebuggerUnitIdentifier;
/*     */ import com.pnfsoftware.jeb.core.units.code.debug.impl.DebuggerSetupInformation;
/*     */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DataFrameView;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame.Row;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.jface.viewers.ColumnViewer;
/*     */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*     */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*     */ import org.eclipse.swt.custom.BusyIndicator;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DbgAttachDialog
/*     */   extends JebDialog
/*     */ {
/*  54 */   private static final ILogger logger = GlobalLog.getLogger(DbgAttachDialog.class);
/*     */   private IGraphicalTaskExecutor taskExecutor;
/*     */   private IDebuggerUnit dbg;
/*     */   private IUnit target;
/*     */   
/*     */   public static class DbgAttachInfo { public DebuggerSetupInformation info;
/*     */     
/*  61 */     DbgAttachInfo(DebuggerSetupInformation info, IDebuggerUnitIdentifier ident) { this.info = info;
/*  62 */       this.ident = ident;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  67 */       return String.format("info=%s,ident=%s", new Object[] { this.info, this.ident });
/*     */     }
/*     */     
/*     */ 
/*     */     public IDebuggerUnitIdentifier ident;
/*     */   }
/*     */   
/*  74 */   private List<IDebuggerUnitIdentifier> idents = new ArrayList();
/*     */   
/*  76 */   private List<IDebuggerUnitIdentifier> identifiers = new ArrayList();
/*  77 */   private List<IDebuggerMachineInformation> machines = new ArrayList();
/*     */   private DataFrame dfMachines;
/*     */   private DataFrameView dfvMachines;
/*  80 */   private List<? extends IDebuggerProcessInformation> processes = new ArrayList();
/*     */   
/*     */   private DataFrame dfProcesses;
/*     */   
/*     */   private DataFrameView dfvProcesses;
/*     */   private Button btnRemoteTarget;
/*     */   private Text widgetHostname;
/*     */   private Text widgetPort;
/*     */   private Button btnSuspendThreads;
/*     */   private Button btnUseChildren;
/*     */   private Button btnRefresh;
/*     */   private DbgAttachInfo result;
/*     */   
/*     */   public DbgAttachDialog(Shell parent, RcpClientContext context, IDebuggerUnit optionalDebuggerUnit, IUnit optionalTargetUnit)
/*     */   {
/*  95 */     super(parent, S.s(234), true, true);
/*  96 */     this.scrolledContainer = true;
/*  97 */     setVisualBounds(30, -1, -1, 70);
/*     */     
/*  99 */     this.taskExecutor = context;
/*     */     
/* 101 */     this.dbg = optionalDebuggerUnit;
/*     */     
/* 103 */     if ((this.dbg == null) && (context != null))
/*     */     {
/* 105 */       this.idents = context.getEnginesContext().getDebuggerUnitIdentifiers();
/*     */     }
/*     */     
/* 108 */     this.target = optionalTargetUnit;
/*     */   }
/*     */   
/*     */   void updateMachinesList() {
/* 112 */     Runnable r = new Runnable()
/*     */     {
/*     */       public void run() {
/* 115 */         DbgAttachDialog.this.identifiers.clear();
/* 116 */         DbgAttachDialog.this.machines.clear();
/* 117 */         IDebuggerTargetEnumerator ta; if (DbgAttachDialog.this.dbg != null) {
/* 118 */           ta = DbgAttachDialog.this.dbg.getTargetEnumerator();
/* 119 */           if (ta != null) {
/* 120 */             for (IDebuggerMachineInformation machine : ta.listMachines()) {
/* 121 */               DbgAttachDialog.this.identifiers.add(null);
/* 122 */               DbgAttachDialog.this.machines.add(machine);
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 127 */           for (ta = DbgAttachDialog.this.idents.iterator(); ta.hasNext();) { ident = (IDebuggerUnitIdentifier)ta.next();
/* 128 */             IDebuggerTargetEnumerator ta = ident.getTargetEnumerator();
/* 129 */             if (ta != null)
/* 130 */               for (IDebuggerMachineInformation machine : ta.listMachines()) {
/* 131 */                 DbgAttachDialog.this.identifiers.add(ident);
/* 132 */                 DbgAttachDialog.this.machines.add(machine);
/*     */               }
/*     */           }
/*     */         }
/*     */         IDebuggerUnitIdentifier ident;
/*     */       }
/*     */     };
/* 139 */     if (this.taskExecutor != null) {
/* 140 */       this.taskExecutor.executeTaskWithPopupDelay(500, "Please wait while debugger information is being gathered...", false, r);
/*     */     }
/*     */     else {
/* 143 */       BusyIndicator.showWhile(this.shell.getDisplay(), r);
/*     */     }
/*     */   }
/*     */   
/*     */   void updateProcessesList(final IDebuggerMachineInformation machine) {
/* 148 */     Runnable r = new Runnable()
/*     */     {
/*     */       public void run() {
/* 151 */         DbgAttachDialog.this.processes = machine.getProcesses();
/*     */       }
/*     */     };
/* 154 */     if (this.taskExecutor != null) {
/* 155 */       this.taskExecutor.executeTaskWithPopupDelay(500, "Please wait while processes information is being gathered...", false, r);
/*     */     }
/*     */     else {
/* 158 */       BusyIndicator.showWhile(this.shell.getDisplay(), r);
/*     */     }
/*     */   }
/*     */   
/*     */   void prepareMachineList() {
/* 163 */     if (this.dfMachines == null) {
/* 164 */       this.dfMachines = new DataFrame(new String[] { S.s(591), S.s(447), S.s(351), S.s(387) });
/*     */     }
/*     */     else {
/* 167 */       this.dfMachines.clear();
/*     */     }
/*     */     
/* 170 */     updateMachinesList();
/*     */     
/* 172 */     for (IDebuggerMachineInformation machine : this.machines) {
/* 173 */       int flags = machine.getFlags();
/* 174 */       String ff = "";
/* 175 */       if ((flags & 0x1) != 0) {
/* 176 */         ff = ff + "Online";
/*     */       }
/*     */       else {
/* 179 */         ff = ff + "Offline";
/*     */       }
/* 181 */       this.dfMachines.addRow(new Object[] { machine.getName(), machine.getLocation(), ff, machine.getInformation() });
/*     */     }
/*     */   }
/*     */   
/*     */   String prepareProcessList(IDebuggerMachineInformation machine) {
/* 186 */     if (this.dfProcesses == null) {
/* 187 */       this.dfProcesses = new DataFrame(new String[] { S.s(376), S.s(591), S.s(351) });
/*     */     }
/*     */     else {
/* 190 */       this.dfProcesses.clear();
/*     */     }
/*     */     
/* 193 */     StringBuilder suggestedFilter = new StringBuilder();
/* 194 */     if (machine != null) {
/* 195 */       updateProcessesList(machine);
/*     */       
/* 197 */       for (IDebuggerProcessInformation process : this.processes) {
/* 198 */         int flags = process.getFlags();
/* 199 */         String ff = "";
/* 200 */         if ((flags & 0x1) != 0) {
/* 201 */           ff = ff + "D";
/*     */         }
/* 203 */         this.dfProcesses.addRow(new Object[] { Long.valueOf(process.getId()), process.getName(), ff });
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 208 */     IUnit unit = this.target;
/* 209 */     while (unit != null) {
/* 210 */       if (!Strings.isBlank(unit.getName())) {
/* 211 */         if (suggestedFilter.length() > 0) {
/* 212 */           suggestedFilter.append("|");
/*     */         }
/* 214 */         suggestedFilter.append(unit.getName());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 223 */       if (!(unit.getParent() instanceof IUnit)) {
/*     */         break;
/*     */       }
/* 226 */       unit = (IUnit)unit.getParent();
/*     */     }
/* 228 */     return suggestedFilter.toString();
/*     */   }
/*     */   
/*     */   void refreshMachineList() {
/* 232 */     int index = this.dfvMachines.getSelectedRow();
/* 233 */     prepareMachineList();
/* 234 */     this.dfvMachines.refresh();
/* 235 */     if ((index < this.dfvMachines.getItemCount()) && (index >= 0)) {
/* 236 */       this.dfvMachines.setSelection(index);
/*     */     }
/* 238 */     else if (this.dfvMachines.getItemCount() > 0) {
/* 239 */       this.dfvMachines.setSelection(0);
/*     */     }
/*     */   }
/*     */   
/*     */   void refreshProcessList() {
/* 244 */     int index = this.dfvMachines.getSelectedRow();
/* 245 */     String suggFilter = prepareProcessList((index < 0) || (index >= this.machines.size()) ? null : (IDebuggerMachineInformation)this.machines.get(index));
/* 246 */     this.dfvProcesses.refresh();
/*     */     
/* 248 */     tryAutoSelectProcess(suggFilter);
/*     */   }
/*     */   
/*     */   public DbgAttachInfo open()
/*     */   {
/* 253 */     super.open();
/* 254 */     return this.result;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/* 259 */     this.shell.setMinimumSize(600, 450);
/* 260 */     int autoInitDone = 0;
/*     */     
/* 262 */     UIUtil.setStandardLayout(parent, 3);
/*     */     
/* 264 */     Composite c = new Composite(parent, 0);
/* 265 */     c.setLayoutData(UIUtil.createGridDataSpanHorizontally(3, true, true));
/* 266 */     c.setLayout(new GridLayout(1, false));
/*     */     
/* 268 */     prepareMachineList();
/* 269 */     IDebuggerMachineInformation machine = this.machines.isEmpty() ? null : (IDebuggerMachineInformation)this.machines.get(0);
/* 270 */     String suggestedFilter = prepareProcessList(machine);
/*     */     
/* 272 */     Group g0 = new Group(c, 0);
/* 273 */     g0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 274 */     g0.setLayout(new GridLayout(1, false));
/* 275 */     g0.setText(String.format("%s / %s", new Object[] { S.s(449), S.s(273) }));
/*     */     
/* 277 */     this.dfvMachines = new DataFrameView(g0, this.dfMachines, true);
/* 278 */     this.dfvMachines.addExtraEntriesToContextMenu();
/* 279 */     this.dfvMachines.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 280 */     if (machine != null) {
/* 281 */       this.dfvMachines.setSelection(0);
/* 282 */       autoInitDone++;
/*     */     }
/*     */     
/*     */ 
/* 286 */     Group g1 = new Group(c, 0);
/* 287 */     g1.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*     */     
/* 289 */     g1.setLayout(new GridLayout(1, false));
/* 290 */     g1.setText(S.s(663));
/*     */     
/* 292 */     this.dfvProcesses = new DataFrameView(g1, this.dfProcesses, true);
/* 293 */     this.dfvProcesses.addExtraEntriesToContextMenu();
/* 294 */     if (tryAutoSelectProcess(suggestedFilter)) {
/* 295 */       autoInitDone++;
/*     */     }
/* 297 */     this.dfvProcesses.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/* 298 */     this.dfvProcesses.refresh();
/*     */     
/*     */ 
/* 301 */     this.dfvMachines.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 304 */         int index = DbgAttachDialog.this.dfvMachines.getSelectedRow();
/* 305 */         DbgAttachDialog.logger.i("Selected: %d", new Object[] { Integer.valueOf(index) });
/* 306 */         DbgAttachDialog.this.refreshProcessList();
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 314 */     });
/* 315 */     this.dfvProcesses.getTableViewer().addDoubleClickListener(new IDoubleClickListener()
/*     */     {
/*     */       public void doubleClick(DoubleClickEvent event) {
/* 318 */         if (DbgAttachDialog.this.tryAttach()) {
/* 319 */           DbgAttachDialog.this.shell.close();
/*     */         }
/*     */         
/*     */       }
/* 323 */     });
/* 324 */     Group g2 = new Group(parent, 0);
/* 325 */     g2.setLayoutData(UIUtil.createGridDataSpanHorizontally(3, true, false));
/* 326 */     g2.setLayout(new GridLayout(2, false));
/* 327 */     g2.setText("Remote Debugging");
/*     */     
/* 329 */     this.btnRemoteTarget = UIUtil.createCheckbox(g2, "Debug a remote target", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 332 */         boolean isRemote = DbgAttachDialog.this.btnRemoteTarget.getSelection();
/* 333 */         DbgAttachDialog.this.dfvMachines.setEnabled(!isRemote);
/* 334 */         DbgAttachDialog.this.dfvProcesses.setEnabled(!isRemote);
/* 335 */         DbgAttachDialog.this.widgetHostname.setEnabled(isRemote);
/* 336 */         DbgAttachDialog.this.widgetPort.setEnabled(isRemote);
/* 337 */         DbgAttachDialog.this.btnRefresh.setEnabled(!isRemote);
/*     */       }
/* 339 */     });
/* 340 */     this.btnRemoteTarget.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*     */     
/* 342 */     new Label(g2, 0).setText(S.s(670) + ": ");
/* 343 */     this.widgetHostname = new Text(g2, 2052);
/* 344 */     this.widgetHostname.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 345 */     this.widgetHostname.setEnabled(false);
/*     */     
/* 347 */     new Label(g2, 0).setText(S.s(671) + ": ");
/* 348 */     this.widgetPort = new Text(g2, 2052);
/* 349 */     this.widgetPort.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 350 */     this.widgetPort.setEnabled(false);
/*     */     
/* 352 */     Group g3 = new Group(parent, 0);
/* 353 */     g3.setLayoutData(UIUtil.createGridDataSpanHorizontally(3, true, false));
/* 354 */     g3.setLayout(new GridLayout(1, false));
/* 355 */     g3.setText("Options");
/*     */     
/* 357 */     this.btnSuspendThreads = UIUtil.createCheckbox(g3, S.s(760), null);
/* 358 */     this.btnSuspendThreads.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, false));
/*     */     
/* 360 */     this.btnUseChildren = UIUtil.createCheckbox(g3, "Allow children debuggers (for Android apps, provide Native debugging)", null);
/* 361 */     this.btnUseChildren.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, false));
/* 362 */     this.btnUseChildren.setToolTipText("Example: when debugging an Android app with native code, the native code debugger will be a child of the bytecode debugger");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 367 */     Button btnAttach = UIUtil.createPushbox(parent, S.s(83), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 370 */         if (DbgAttachDialog.this.tryAttach()) {
/* 371 */           DbgAttachDialog.this.shell.close();
/*     */         }
/*     */       }
/* 374 */     });
/* 375 */     UIUtil.createPushbox(parent, S.s(201), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 378 */         DbgAttachDialog.this.shell.close();
/*     */       }
/*     */       
/* 381 */     });
/* 382 */     this.btnRefresh = UIUtil.createPushbox(parent, "Refresh Machines List", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 385 */         DbgAttachDialog.this.refreshMachineList();
/* 386 */         DbgAttachDialog.this.refreshProcessList();
/*     */       }
/*     */     });
/*     */     
/* 390 */     if (autoInitDone == 2)
/*     */     {
/* 392 */       btnAttach.setFocus();
/*     */     }
/*     */     
/* 395 */     this.shell.setDefaultButton(btnAttach);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean tryAutoSelectProcess(String suggestedFilter)
/*     */   {
/* 416 */     if (!Strings.isBlank(suggestedFilter)) {
/* 417 */       this.dfvProcesses.forceFilter(suggestedFilter);
/*     */       
/* 419 */       int candidate = 0;
/* 420 */       TableItem[] items = this.dfvProcesses.getTable().getItems();
/* 421 */       for (int i = 0; i < items.length; i++) {
/* 422 */         DataFrame.Row df = (DataFrame.Row)items[i].getData();
/* 423 */         boolean debuggable = ((String)df.elements.get(2)).contains("D");
/* 424 */         if (debuggable) {
/* 425 */           if (candidate == 0) {
/* 426 */             this.dfvProcesses.setSelection(i);
/*     */           }
/* 428 */           candidate++;
/*     */         }
/*     */       }
/* 431 */       if (candidate == 1) {
/* 432 */         return true;
/*     */       }
/*     */     }
/* 435 */     return false;
/*     */   }
/*     */   
/*     */   private boolean tryAttach() {
/* 439 */     this.result = null;
/*     */     
/* 441 */     boolean isRemote = this.btnRemoteTarget.getSelection();
/* 442 */     if (!isRemote) {
/* 443 */       int index = this.dfvMachines.getSelectedRow();
/* 444 */       if ((index >= 0) && (index < this.machines.size())) {
/* 445 */         IDebuggerMachineInformation machine = (IDebuggerMachineInformation)this.machines.get(index);
/* 446 */         IDebuggerUnitIdentifier ident = (IDebuggerUnitIdentifier)this.identifiers.get(index);
/* 447 */         index = this.dfvProcesses.getSelectedRow();
/* 448 */         if ((index >= 0) && (index < this.processes.size())) {
/* 449 */           IDebuggerProcessInformation process = (IDebuggerProcessInformation)this.processes.get(index);
/* 450 */           this.result = new DbgAttachInfo(DebuggerSetupInformation.create(machine, process), ident);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 455 */       String hostname = this.widgetHostname.getText();
/* 456 */       if (hostname.isEmpty()) {
/* 457 */         hostname = "localhost";
/* 458 */         this.widgetHostname.setText(hostname);
/*     */       }
/* 460 */       int port = Conversion.stringToInt(this.widgetPort.getText());
/* 461 */       if (port != 0) {
/* 462 */         this.result = new DbgAttachInfo(DebuggerSetupInformation.create(hostname, port), null);
/*     */       }
/*     */     }
/*     */     
/* 466 */     if (this.result == null) {
/* 467 */       MessageDialog.openWarning(this.shell, S.s(405), S.s(406));
/* 468 */       return false;
/*     */     }
/*     */     
/* 471 */     this.result.info.setSuspendThreads(this.btnSuspendThreads.getSelection());
/* 472 */     this.result.info.setUseChildrenDebuggers(this.btnUseChildren.getSelection());
/* 473 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\DbgAttachDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */