/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.TypeLibraryEntry;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.TypeLibraryMetadata;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.TypeLibraryService;
/*     */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilteredTableView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ITableEventListener;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCellLabelProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCheckStateProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.IFilteredTableContentProvider;
/*     */ import com.pnfsoftware.jeb.util.collect.ArrayUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListTypelibsDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private IGraphicalTaskExecutor executor;
/*     */   private TypeLibraryService tls;
/*     */   private FilteredTableViewer ftv;
/*     */   
/*     */   public ListTypelibsDialog(Shell parent, IGraphicalTaskExecutor executor)
/*     */   {
/*  47 */     super(parent, "Type libraries", true, true, "typelibsDialog");
/*  48 */     setVisualBounds(-1, 90, -1, -1);
/*  49 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */     
/*  51 */     this.executor = executor;
/*     */   }
/*     */   
/*     */   public void setInput(TypeLibraryService tls) {
/*  55 */     this.tls = tls;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  60 */     return super.open();
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  65 */     UIUtil.setStandardLayout(parent);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     FilteredTableView ft = new FilteredTableView(parent, 32, new String[] { "Loaded", "Targets", "Group", S.s(591), S.s(268), S.s(86), S.s(341) });
/*     */     
/*  76 */     GridData data = UIUtil.createGridDataFill(true, true);
/*  77 */     data.minimumHeight = 200;
/*  78 */     ft.setLayoutData(data);
/*     */     
/*  80 */     this.ftv = new FilteredTableViewer(ft);
/*  81 */     ContentProviderListener p = new ContentProviderListener();
/*  82 */     this.ftv.setContentProvider(p);
/*  83 */     this.ftv.setCheckStateProvider(new DefaultCheckStateProvider(p));
/*  84 */     this.ftv.setLabelProvider(new DefaultCellLabelProvider(p));
/*  85 */     ft.addTableEventListener(p);
/*  86 */     this.ftv.setInput(this.tls);
/*     */     
/*  88 */     createOkayButton(parent);
/*     */     
/*  90 */     if (getStandardWidgetManager() != null)
/*  91 */       getStandardWidgetManager().wrapWidget(ft, "listTypelibs");
/*     */   }
/*     */   
/*     */   class ContentProviderListener implements ITableEventListener, IFilteredTableContentProvider {
/*     */     private TypeLibraryService tls0;
/*     */     
/*     */     ContentProviderListener() {}
/*     */     
/*     */     public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
/* 100 */       this.tls0 = ((TypeLibraryService)newInput);
/*     */     }
/*     */     
/*     */ 
/*     */     public void dispose() {}
/*     */     
/*     */ 
/*     */     public Object[] getElements(Object inputElement)
/*     */     {
/* 109 */       List<TypeLibraryEntry> r = this.tls0.getAvailables();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */       TypeLibraryEntry[] a = (TypeLibraryEntry[])r.toArray(new TypeLibraryEntry[r.size()]);
/* 117 */       Arrays.sort(a);
/* 118 */       return a;
/*     */     }
/*     */     
/*     */     public Object[] getRowElements(Object row)
/*     */     {
/* 123 */       if ((row instanceof TypeLibraryEntry)) {
/* 124 */         TypeLibraryEntry e = (TypeLibraryEntry)row;
/*     */         
/* 126 */         String loaded = e.getTypelib() != null ? S.s(828) : S.s(594);
/*     */         
/* 128 */         TypeLibraryMetadata hdr = e.getMetadataHeader();
/* 129 */         int groupId = hdr.getGroupId();
/* 130 */         String proctypes = Strings.join(", ", hdr.getProcessorTypes());
/*     */         
/* 132 */         String groupName = TypeLibraryService.groupIdToName(groupId);
/* 133 */         String name = hdr.getName();
/* 134 */         String description = hdr.getDescription();
/* 135 */         String author = hdr.getAuthor();
/*     */         
/* 137 */         String filepath = e.getFile().getPath();
/*     */         
/* 139 */         return new Object[] { loaded, proctypes, groupName, name, description, author, filepath };
/*     */       }
/* 141 */       return ArrayUtil.NO_OBJECT;
/*     */     }
/*     */     
/*     */     public boolean isChecked(Object row)
/*     */     {
/* 146 */       if ((row instanceof TypeLibraryEntry)) {
/* 147 */         TypeLibraryEntry e = (TypeLibraryEntry)row;
/* 148 */         return e.getTypelib() != null;
/*     */       }
/* 150 */       return false;
/*     */     }
/*     */     
/*     */     public void onTableEvent(Object row, boolean isSelected, boolean isChecked)
/*     */     {
/* 155 */       if ((row instanceof TypeLibraryEntry)) {
/* 156 */         final TypeLibraryEntry e = (TypeLibraryEntry)row;
/* 157 */         boolean isLoaded = e.getTypelib() != null;
/* 158 */         if ((isChecked) && (!isLoaded)) {
/* 159 */           if (ListTypelibsDialog.this.executor == null) {
/* 160 */             this.tls0.load(e);
/*     */           }
/*     */           else {
/* 163 */             ListTypelibsDialog.this.executor.executeTask("Loading type library...", new Runnable()
/*     */             {
/*     */               public void run() {
/* 166 */                 ListTypelibsDialog.ContentProviderListener.this.tls0.load(e);
/*     */               }
/*     */             });
/*     */           }
/*     */         }
/* 171 */         else if ((!isChecked) && (isLoaded)) {
/* 172 */           UI.error("Type libraries cannot be unloaded.");
/*     */         }
/* 174 */         ListTypelibsDialog.this.ftv.refresh();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ListTypelibsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */