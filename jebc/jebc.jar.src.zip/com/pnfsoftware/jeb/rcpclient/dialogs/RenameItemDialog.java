/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.HistoryAssistedTextField;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*     */ import com.pnfsoftware.jeb.util.base.OSType;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenameItemDialog
/*     */   extends JebDialog
/*     */ {
/*  32 */   private static final ILogger logger = GlobalLog.getLogger(RenameItemDialog.class);
/*     */   private TextHistory textHistory;
/*     */   private HistoryAssistedTextField text;
/*     */   private String input;
/*     */   private String description;
/*     */   private String initialValue;
/*     */   private String originalValue;
/*     */   
/*     */   public RenameItemDialog(Shell parent, TextHistory textHistory)
/*     */   {
/*  42 */     super(parent, S.s(678), true, true);
/*  43 */     this.scrolledContainer = true;
/*     */     
/*  45 */     this.textHistory = textHistory;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/*  49 */     this.description = description;
/*     */   }
/*     */   
/*     */   public void setInitialValue(String initialValue) {
/*  53 */     this.initialValue = initialValue;
/*     */   }
/*     */   
/*     */   public void setOriginalValue(String originalValue) {
/*  57 */     this.originalValue = originalValue;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/*  62 */     super.open();
/*  63 */     return this.input;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  68 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  70 */     Label hint = new Label(parent, 64);
/*  71 */     hint.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  72 */     hint.setText(this.description != null ? this.description : "Rename the selected item. Leave empty to reset to original value.");
/*     */     
/*  74 */     if (this.originalValue != null)
/*     */     {
/*     */ 
/*  77 */       HistoryAssistedTextField text0 = new HistoryAssistedTextField(parent, "Original:\t", null, false);
/*  78 */       text0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  79 */       text0.setText(this.originalValue);
/*  80 */       text0.getWidget().setEditable(false);
/*     */     }
/*     */     
/*  83 */     this.text = new HistoryAssistedTextField(parent, S.s(591) + ":\t", this.textHistory, true);
/*  84 */     this.text.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*     */ 
/*  87 */     if (this.initialValue != null) {
/*  88 */       this.text.getWidget().setText(this.initialValue);
/*  89 */       this.text.getWidget().forceFocus();
/*     */       
/*  91 */       if (!OSType.determine().isWindows()) {
/*  92 */         this.text.getWidget().selectAll();
/*     */       }
/*     */       else
/*     */       {
/*  96 */         parent.getDisplay().timerExec(5, new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 100 */               RenameItemDialog.this.text.selectAll();
/*     */             }
/*     */             catch (Exception localException) {}
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 109 */     UIUtil.disableTabOutput(this.text);
/*     */     
/*     */ 
/* 112 */     Composite c1 = new Composite(parent, 0);
/* 113 */     c1.setLayout(new RowLayout(256));
/*     */     
/*     */ 
/* 116 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 121 */     this.text.confirm();
/* 122 */     this.input = this.text.getText();
/* 123 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\RenameItemDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */