/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DirectorySelectorView;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportDecompiledCodeDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private Text text;
/*     */   private ExportStatus exportStatus;
/*     */   
/*     */   public static enum State
/*     */   {
/*  37 */     ALL, 
/*  38 */     FILTER, 
/*  39 */     DECOMPILED, 
/*  40 */     CURRENT;
/*     */     
/*     */     private State() {}
/*     */   }
/*     */   
/*  45 */   private State exportState = State.ALL;
/*     */   private String initialFilter;
/*     */   private String initialDirectory;
/*     */   private DirectorySelectorView folderText;
/*     */   private String outputDirectory;
/*     */   private Button mergeAll;
/*     */   private boolean merge;
/*     */   private Text fileText;
/*     */   private String outputFile;
/*     */   
/*     */   public static class ExportStatus {
/*     */     private ExportDecompiledCodeDialog.State state;
/*     */     private String filter;
/*     */     
/*     */     public ExportStatus(ExportDecompiledCodeDialog.State state, String filter) {
/*  60 */       this.state = state;
/*  61 */       this.filter = filter;
/*     */     }
/*     */     
/*     */     public ExportDecompiledCodeDialog.State getState() {
/*  65 */       return this.state;
/*     */     }
/*     */     
/*     */     public String getFilter() {
/*  69 */       return this.filter;
/*     */     }
/*     */   }
/*     */   
/*     */   public ExportDecompiledCodeDialog(Shell parent)
/*     */   {
/*  75 */     super(parent, S.s(327), true, true);
/*  76 */     this.scrolledContainer = true;
/*     */   }
/*     */   
/*     */   public void setInitialState(State state) {
/*  80 */     this.exportState = state;
/*     */   }
/*     */   
/*     */   public void setInitialState(ExportStatus state) {
/*  84 */     setInitialState(state.state);
/*  85 */     setInitialFilter(state.filter);
/*     */   }
/*     */   
/*     */   public State getState() {
/*  89 */     return this.exportState;
/*     */   }
/*     */   
/*     */   public void setInitialFilter(String initialFilter) {
/*  93 */     this.initialFilter = initialFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setInitialDirectory(String initialDirectory)
/*     */   {
/* 100 */     this.initialDirectory = initialDirectory;
/*     */   }
/*     */   
/*     */   public String getOutputDirectory() {
/* 104 */     return this.outputDirectory;
/*     */   }
/*     */   
/*     */   public boolean isMergeFiles() {
/* 108 */     return this.merge;
/*     */   }
/*     */   
/*     */   public String getOutputFile() {
/* 112 */     return this.outputFile;
/*     */   }
/*     */   
/*     */   public ExportStatus open()
/*     */   {
/* 117 */     super.open();
/* 118 */     return this.exportStatus;
/*     */   }
/*     */   
/*     */   private class ExportSelectionListener implements SelectionListener
/*     */   {
/*     */     private ExportDecompiledCodeDialog.State state;
/*     */     
/*     */     public ExportSelectionListener(ExportDecompiledCodeDialog.State state) {
/* 126 */       this.state = state;
/*     */     }
/*     */     
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/* 131 */       switch (ExportDecompiledCodeDialog.2.$SwitchMap$com$pnfsoftware$jeb$rcpclient$dialogs$ExportDecompiledCodeDialog$State[this.state.ordinal()]) {
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 3: 
/* 135 */         ExportDecompiledCodeDialog.this.text.setEnabled(false);
/* 136 */         break;
/*     */       case 4: 
/* 138 */         ExportDecompiledCodeDialog.this.text.setEnabled(true);
/* 139 */         break;
/*     */       }
/*     */       
/*     */       
/* 143 */       ExportDecompiledCodeDialog.this.exportState = this.state;
/*     */     }
/*     */     
/*     */     public void widgetDefaultSelected(SelectionEvent e)
/*     */     {
/* 148 */       widgetSelected(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void createContents(Composite parent)
/*     */   {
/* 155 */     UIUtil.setStandardLayout(parent, 1);
/*     */     
/*     */ 
/* 158 */     Group c0 = new Group(parent, 0);
/* 159 */     c0.setText(S.s(324));
/* 160 */     GridData exportGridData = UIUtil.createGridDataFillHorizontally();
/* 161 */     exportGridData.horizontalSpan = 2;
/* 162 */     c0.setLayoutData(exportGridData);
/* 163 */     c0.setLayout(new GridLayout(1, false));
/*     */     
/* 165 */     Button all = new Button(c0, 16);
/* 166 */     all.setText(S.s(54));
/* 167 */     all.addSelectionListener(new ExportSelectionListener(State.ALL));
/*     */     
/* 169 */     Button filter = new Button(c0, 16);
/* 170 */     filter.setText(S.s(343));
/* 171 */     filter.addSelectionListener(new ExportSelectionListener(State.FILTER));
/*     */     
/* 173 */     this.text = new Text(c0, 2048);
/* 174 */     this.text.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 175 */     this.text.setMessage(S.s(343));
/*     */     
/* 177 */     Button decomp = new Button(c0, 16);
/* 178 */     decomp.setText(S.s(607));
/* 179 */     decomp.addSelectionListener(new ExportSelectionListener(State.DECOMPILED));
/*     */     
/* 181 */     Button current = new Button(c0, 16);
/* 182 */     current.setText(S.s(228));
/* 183 */     current.addSelectionListener(new ExportSelectionListener(State.CURRENT));
/* 184 */     Text currentUnitText = new Text(c0, 2048);
/* 185 */     currentUnitText.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 186 */     currentUnitText.setEnabled(false);
/*     */     
/*     */ 
/* 189 */     switch (this.exportState) {
/*     */     case ALL: 
/* 191 */       all.setSelection(true);
/* 192 */       all.setFocus();
/* 193 */       this.text.setEnabled(false);
/* 194 */       current.setEnabled(false);
/* 195 */       break;
/*     */     case FILTER: 
/* 197 */       filter.setSelection(true);
/* 198 */       filter.setFocus();
/* 199 */       current.setEnabled(false);
/* 200 */       break;
/*     */     case DECOMPILED: 
/* 202 */       decomp.setSelection(true);
/* 203 */       decomp.setFocus();
/* 204 */       this.text.setEnabled(false);
/* 205 */       current.setEnabled(false);
/* 206 */       break;
/*     */     case CURRENT: 
/* 208 */       current.setSelection(true);
/* 209 */       current.setFocus();
/* 210 */       this.text.setEnabled(false);
/* 211 */       if (this.initialFilter != null) {
/* 212 */         currentUnitText.setText(this.initialFilter);
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 220 */     Group c1 = new Group(parent, 0);
/* 221 */     c1.setText("Destination");
/* 222 */     c1.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/* 223 */     c1.setLayout(new GridLayout(1, false));
/*     */     
/* 225 */     this.folderText = new DirectorySelectorView(c1, S.s(269) + ": ", this.initialDirectory);
/* 226 */     this.folderText.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 227 */     GridData gd = new GridData();
/* 228 */     gd.horizontalSpan = 2;
/* 229 */     this.folderText.setLayoutData(gd);
/*     */     
/* 231 */     this.mergeAll = new Button(this.folderText, 32);
/* 232 */     this.mergeAll.setText("Merge to one file: ");
/* 233 */     this.mergeAll.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 236 */         if (ExportDecompiledCodeDialog.this.mergeAll.getSelection()) {
/* 237 */           ExportDecompiledCodeDialog.this.fileText.setEnabled(true);
/*     */         }
/*     */         else {
/* 240 */           ExportDecompiledCodeDialog.this.fileText.setEnabled(false);
/*     */         }
/*     */         
/*     */       }
/* 244 */     });
/* 245 */     this.fileText = new Text(this.folderText, 2048);
/* 246 */     this.fileText.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 247 */     this.fileText.setMessage("File name");
/* 248 */     this.fileText.setEnabled(false);
/*     */     
/* 250 */     if (this.initialFilter != null) {
/* 251 */       this.text.setText(this.initialFilter);
/*     */     }
/*     */     
/*     */ 
/* 255 */     Composite buttons = createButtons(parent, 288, 32);
/* 256 */     GridData gdButtons = new GridData();
/* 257 */     gdButtons.verticalIndent = 20;
/* 258 */     buttons.setLayoutData(gdButtons);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 263 */     if (Strings.isBlank(this.folderText.getText())) {
/* 264 */       MessageDialog.openError(this.shell, "Empty directory", "Destination directory can not be empty. Please select one.");
/*     */ 
/*     */     }
/* 267 */     else if ((this.mergeAll.getSelection()) && (Strings.isBlank(this.fileText.getText()))) {
/* 268 */       MessageDialog.openError(this.shell, "Empty file name", "File name can not be empty. Please enter one.");
/*     */     }
/*     */     else {
/* 271 */       this.exportStatus = new ExportStatus(this.exportState, this.text.getText());
/* 272 */       this.outputDirectory = this.folderText.getText();
/* 273 */       this.merge = this.mergeAll.getSelection();
/* 274 */       this.outputFile = this.fileText.getText();
/* 275 */       super.onConfirm();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void onCancel()
/*     */   {
/* 281 */     this.exportStatus = null;
/* 282 */     super.onCancel();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ExportDecompiledCodeDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */