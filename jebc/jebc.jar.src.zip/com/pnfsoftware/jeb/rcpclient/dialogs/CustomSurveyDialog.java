/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import com.pnfsoftware.jeb.util.net.Net;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.eclipse.jface.dialogs.TitleAreaDialog;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomSurveyDialog
/*     */   extends TitleAreaDialog
/*     */ {
/*  41 */   private static final ILogger logger = GlobalLog.getLogger(CustomSurveyDialog.class);
/*     */   RcpClientContext context;
/*     */   Text txtSuggestion;
/*     */   
/*     */   public CustomSurveyDialog(Shell shell, RcpClientContext context)
/*     */   {
/*  47 */     super(shell);
/*  48 */     this.context = context;
/*     */   }
/*     */   
/*     */   protected Control createDialogArea(Composite parent)
/*     */   {
/*  53 */     getShell().setText("Feedback");
/*  54 */     setTitle("What would you like to have in JEB");
/*  55 */     setMessage("This is an optional, single-question survey we ask our regular users.", 1);
/*     */     
/*     */ 
/*  58 */     Composite area = (Composite)super.createDialogArea(parent);
/*  59 */     Composite container = new Composite(area, 0);
/*  60 */     container.setLayoutData(new GridData(4, 4, true, true));
/*  61 */     GridLayout layout = new GridLayout(1, false);
/*  62 */     container.setLayout(layout);
/*     */     
/*     */ 
/*     */ 
/*  66 */     Label label = new Label(container, 0);
/*  67 */     label.setText("What is the most important feature you would like to have in JEB next?\nFeel free to be as brief or as elaborate as you want.");
/*     */     
/*     */ 
/*  70 */     GridData data = new GridData();
/*  71 */     data.grabExcessHorizontalSpace = true;
/*  72 */     data.horizontalAlignment = 4;
/*  73 */     data.grabExcessVerticalSpace = true;
/*  74 */     data.verticalAlignment = 4;
/*  75 */     this.txtSuggestion = new Text(container, 2050);
/*  76 */     this.txtSuggestion.setLayoutData(data);
/*  77 */     return area;
/*     */   }
/*     */   
/*     */   protected void createButtonsForButtonBar(Composite parent)
/*     */   {
/*  82 */     createButton(parent, 0, "Submit", true);
/*  83 */     createButton(parent, 1, "Dismiss", false);
/*     */   }
/*     */   
/*     */   protected void okPressed()
/*     */   {
/*  88 */     final String suggestion = this.txtSuggestion.getText();
/*  89 */     if (Strings.countNonBlankCharacters(suggestion) < 3) {
/*  90 */       UI.error("Cannot submit a blank answer!");
/*  91 */       this.txtSuggestion.setFocus();
/*  92 */       return;
/*     */     }
/*     */     
/*  95 */     String r = (String)this.context.executeNetworkTask(new Callable()
/*     */     {
/*     */       public String call() throws Exception {
/*     */         try {
/*  99 */           String url = "https://www.pnfsoftware.com/submitsurvey?survey=productSurvey1&licenseid=" + Licensing.license_id;
/* 100 */           Map<String, String> params = new HashMap();
/* 101 */           params.put("suggestion", suggestion);
/* 102 */           return CustomSurveyDialog.this.context.getNetworkUtility().post(url, null, params);
/*     */         }
/*     */         catch (IOException e) {
/* 105 */           UI.error("An error occurred.\n\nException: " + e.getMessage()); }
/* 106 */         return null;
/*     */       }
/*     */       
/* 109 */     });
/* 110 */     logger.i("Server response: %s", new Object[] { r });
/*     */     
/* 112 */     UI.info("Thank you!");
/*     */     
/* 114 */     setReturnCode(0);
/* 115 */     close();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\CustomSurveyDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */