/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.DataFrameView;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.jface.viewers.ColumnViewer;
/*    */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*    */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataFrameDialog
/*    */   extends JebDialog
/*    */ {
/* 29 */   private static final ILogger logger = GlobalLog.getLogger(DataFrameDialog.class);
/*    */   
/*    */   private String msg;
/* 32 */   private boolean displayIndex = false;
/*    */   private DataFrame df;
/*    */   private DataFrameView dfv;
/* 35 */   private int selectedIndex = -1;
/*    */   
/*    */   public DataFrameDialog(Shell parent, String caption, boolean modal, String widgetName) {
/* 38 */     super(parent, caption, true, modal, widgetName);
/*    */     
/*    */ 
/* 41 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*    */   }
/*    */   
/*    */   public void setDisplayIndex(boolean displayIndex) {
/* 45 */     this.displayIndex = displayIndex;
/*    */   }
/*    */   
/*    */   public void setDataFrame(DataFrame df) {
/* 49 */     this.df = df;
/*    */   }
/*    */   
/*    */   public void setMessage(String msg) {
/* 53 */     this.msg = msg;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Integer open()
/*    */   {
/* 61 */     if (this.df == null) {
/* 62 */       throw new IllegalStateException("The dataframe model was not set");
/*    */     }
/*    */     
/* 65 */     super.open();
/* 66 */     return Integer.valueOf(this.selectedIndex);
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 71 */     UIUtil.setStandardLayout(parent);
/*    */     
/* 73 */     if (this.msg != null) {
/* 74 */       UIUtil.createWrappedLabelInGridLayout(parent, 0, this.msg, 1);
/*    */     }
/*    */     
/* 77 */     this.dfv = new DataFrameView(parent, this.df, this.displayIndex);
/* 78 */     this.dfv.addExtraEntriesToContextMenu();
/* 79 */     this.dfv.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*    */     
/*    */ 
/* 82 */     this.dfv.getTableViewer().addDoubleClickListener(new IDoubleClickListener()
/*    */     {
/*    */       public void doubleClick(DoubleClickEvent e) {
/* 85 */         DataFrameDialog.this.onConfirm();
/*    */       }
/*    */       
/* 88 */     });
/* 89 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 94 */     this.selectedIndex = this.dfv.getSelectedRow();
/* 95 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\DataFrameDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */