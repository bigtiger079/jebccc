/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IPluginInformation;
/*     */ import com.pnfsoftware.jeb.core.IRuntimeProject;
/*     */ import com.pnfsoftware.jeb.core.RuntimeProjectUtil;
/*     */ import com.pnfsoftware.jeb.core.input.IInput;
/*     */ import com.pnfsoftware.jeb.core.units.IBinaryUnit;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.core.units.IUnitIdentifier;
/*     */ import com.pnfsoftware.jeb.core.units.IUnitProcessor;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.events.FocusAdapter;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReparseDialog
/*     */   extends JebDialog
/*     */ {
/*     */   public static class Information
/*     */   {
/*     */     private IUnit unit;
/*     */     private String subUnitName;
/*     */     private String wantedType;
/*     */     private long offset;
/*     */     private long size;
/*     */     
/*     */     public Information(IUnit unit, String subUnitName, String wantedType, long offset, long size)
/*     */     {
/*  64 */       this.unit = unit;
/*  65 */       this.subUnitName = subUnitName;
/*  66 */       this.wantedType = wantedType;
/*  67 */       this.offset = offset;
/*  68 */       this.size = size;
/*     */     }
/*     */     
/*     */     public IUnit getUnit() {
/*  72 */       return this.unit;
/*     */     }
/*     */     
/*     */     public String getSubUnitName() {
/*  76 */       return this.subUnitName;
/*     */     }
/*     */     
/*     */     public String getWantedType() {
/*  80 */       return this.wantedType;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public long getOffset()
/*     */     {
/*  89 */       return this.offset;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public long getSize()
/*     */     {
/*  98 */       return this.size;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 103 */   private static final ILogger logger = GlobalLog.getLogger(ReparseDialog.class);
/*     */   
/*     */   private IUnit unit;
/*     */   
/*     */   private List<IUnitIdentifier> unitIdentifiers;
/*     */   private long maxsize;
/*     */   private Information reparseInfo;
/*     */   private Text widgetSubUnitName;
/*     */   private Combo widgetParsers;
/*     */   private Text widgetOffset;
/*     */   private Text widgetSize;
/*     */   private Text widgetEnd;
/*     */   private Button widgetNullInput;
/*     */   
/*     */   public ReparseDialog(Shell parent, IUnit unit)
/*     */   {
/* 119 */     super(parent, S.s(626), true, true);
/* 120 */     this.scrolledContainer = true;
/*     */     
/* 122 */     if (unit == null) {
/* 123 */       throw new NullPointerException();
/*     */     }
/* 125 */     this.unit = unit;
/*     */     
/* 127 */     this.unitIdentifiers = new ArrayList(RuntimeProjectUtil.findProject(unit).getProcessor().getUnitIdentifiers());
/* 128 */     Collections.sort(this.unitIdentifiers, new Comparator()
/*     */     {
/*     */       public int compare(IUnitIdentifier o1, IUnitIdentifier o2) {
/* 131 */         return o1.getFormatType().compareTo(o2.getFormatType());
/*     */       }
/*     */       
/* 134 */     });
/* 135 */     this.maxsize = 0L;
/* 136 */     if ((unit instanceof IBinaryUnit)) {
/* 137 */       IInput input = ((IBinaryUnit)unit).getInput();
/* 138 */       this.maxsize = input.getCurrentSize();
/*     */     }
/*     */   }
/*     */   
/*     */   public Information open()
/*     */   {
/* 144 */     super.open();
/* 145 */     return this.reparseInfo;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 149 */     return this.widgetSubUnitName.getText();
/*     */   }
/*     */   
/*     */   public String getWantedType() {
/* 153 */     int index = this.widgetParsers.getSelectionIndex();
/* 154 */     if ((index < 0) || (index >= this.unitIdentifiers.size())) {
/* 155 */       return null;
/*     */     }
/*     */     
/* 158 */     return ((IUnitIdentifier)this.unitIdentifiers.get(index)).getFormatType();
/*     */   }
/*     */   
/*     */   private boolean isNullInput() {
/* 162 */     return this.widgetNullInput.getSelection();
/*     */   }
/*     */   
/*     */   private void setOffset(long offset) {
/* 166 */     this.widgetOffset.setText(String.format("%d", new Object[] { Long.valueOf(offset) }));
/*     */   }
/*     */   
/*     */   private long getOffset() {
/* 170 */     if ((this.maxsize < 0L) || (isNullInput())) {
/* 171 */       return -1L;
/*     */     }
/*     */     
/* 174 */     return Conversion.stringToLong(this.widgetOffset.getText(), 0L);
/*     */   }
/*     */   
/*     */   private void setSize(long size) {
/* 178 */     this.widgetSize.setText(String.format("%d", new Object[] { Long.valueOf(size) }));
/*     */   }
/*     */   
/*     */   public long getSize() {
/* 182 */     if ((this.maxsize < 0L) || (isNullInput())) {
/* 183 */       return -1L;
/*     */     }
/*     */     
/* 186 */     return Conversion.stringToLong(this.widgetSize.getText(), 0L);
/*     */   }
/*     */   
/*     */   private void updateEnd() {
/* 190 */     long end = getOffset() + getSize();
/* 191 */     this.widgetEnd.setText(String.format("%d", new Object[] { Long.valueOf(end) }));
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/* 196 */     GridLayout layout = new GridLayout(2, false);
/* 197 */     layout.marginLeft = (layout.marginRight = layout.marginTop = layout.marginBottom = 6);
/* 198 */     parent.setLayout(layout);
/*     */     
/* 200 */     new Label(parent, 0).setText(S.s(591) + ": ");
/*     */     
/* 202 */     this.widgetSubUnitName = new Text(parent, 2052);
/* 203 */     this.widgetSubUnitName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 204 */     this.widgetSubUnitName.setText("sub-unit");
/* 205 */     this.widgetSubUnitName.selectAll();
/* 206 */     this.widgetSubUnitName.setFocus();
/*     */     
/* 208 */     new Label(parent, 0).setText(S.s(627) + ": ");
/*     */     
/* 210 */     this.widgetParsers = new Combo(parent, 12);
/* 211 */     GridData layoutData = UIUtil.createGridDataFillHorizontally();
/* 212 */     layoutData.widthHint = UIUtil.determineTextWidth(this.widgetParsers, 40);
/* 213 */     this.widgetParsers.setLayoutData(layoutData);
/* 214 */     for (IUnitIdentifier id : this.unitIdentifiers)
/*     */     {
/* 216 */       this.widgetParsers.add(id.getFormatType());
/*     */     }
/*     */     
/* 219 */     new Label(parent, 0).setText(S.s(270) + ": ");
/*     */     
/* 221 */     final Text widgetPinfo = new Text(parent, 2060);
/* 222 */     widgetPinfo.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 223 */     widgetPinfo.setText("N/A");
/*     */     
/* 225 */     new Label(parent, 0).setText(S.s(388) + ": ");
/* 226 */     this.widgetNullInput = new Button(parent, 32);
/* 227 */     this.widgetNullInput.setText("null (parent unit only)");
/* 228 */     this.widgetNullInput.setEnabled(this.maxsize >= 0L);
/*     */     
/* 230 */     new Label(parent, 0).setText(S.s(604) + ": ");
/* 231 */     this.widgetOffset = new Text(parent, 2052);
/* 232 */     this.widgetOffset.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 233 */     this.widgetOffset.setText("0");
/*     */     
/* 235 */     new Label(parent, 0).setText(S.s(741) + ": ");
/* 236 */     this.widgetSize = new Text(parent, 2052);
/* 237 */     this.widgetSize.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 238 */     this.widgetSize.setText(String.format("%d", new Object[] { Long.valueOf(this.maxsize) }));
/*     */     
/* 240 */     new Label(parent, 0).setText(String.format("(%s: )", new Object[] { S.s(289) }));
/* 241 */     this.widgetEnd = new Text(parent, 2052);
/* 242 */     this.widgetEnd.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 243 */     this.widgetEnd.setText(String.format("%d", new Object[] { Long.valueOf(this.maxsize) }));
/*     */     
/* 245 */     createOkayCancelButtons(parent);
/* 246 */     final Button widgetOk = getButtonByStyle(32);
/* 247 */     widgetOk.setEnabled(false);
/*     */     
/*     */ 
/*     */ 
/* 251 */     this.widgetOffset.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/* 254 */         long offset = ReparseDialog.this.getOffset();
/* 255 */         if (offset < 0L) {
/* 256 */           offset = 0L;
/* 257 */           ReparseDialog.this.setOffset(0L);
/*     */         }
/*     */         
/* 260 */         if (offset > ReparseDialog.this.maxsize) {
/* 261 */           ReparseDialog.this.setOffset(ReparseDialog.this.maxsize);
/* 262 */           ReparseDialog.this.setSize(0L);
/*     */         }
/*     */         else {
/* 265 */           long size = ReparseDialog.this.getSize();
/* 266 */           if (offset + size >= ReparseDialog.this.maxsize) {
/* 267 */             size = ReparseDialog.this.maxsize - offset;
/* 268 */             ReparseDialog.this.setSize(size);
/*     */           }
/*     */         }
/*     */         
/* 272 */         ReparseDialog.this.updateEnd();
/*     */       }
/*     */       
/* 275 */     });
/* 276 */     this.widgetSize.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/* 279 */         long size = ReparseDialog.this.getSize();
/* 280 */         long offset = ReparseDialog.this.getOffset();
/* 281 */         if (offset + size > ReparseDialog.this.maxsize) {
/* 282 */           ReparseDialog.this.setOffset(ReparseDialog.this.maxsize);
/* 283 */           ReparseDialog.this.setSize(0L);
/*     */         }
/* 285 */         ReparseDialog.this.updateEnd();
/*     */       }
/*     */       
/* 288 */     });
/* 289 */     this.widgetParsers.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 292 */         int index = ReparseDialog.this.widgetParsers.getSelectionIndex();
/* 293 */         if ((index < 0) || (index >= ReparseDialog.this.unitIdentifiers.size())) {
/* 294 */           return;
/*     */         }
/*     */         
/* 297 */         IPluginInformation pi = ((IUnitIdentifier)ReparseDialog.this.unitIdentifiers.get(index)).getPluginInformation();
/* 298 */         if (pi == null) {
/* 299 */           return;
/*     */         }
/*     */         
/* 302 */         if (!widgetOk.isEnabled()) {
/* 303 */           widgetOk.setEnabled(true);
/* 304 */           ReparseDialog.this.shell.setDefaultButton(widgetOk);
/*     */         }
/*     */         
/* 307 */         String s = String.format("%s (v%s)", new Object[] { Strings.safe2(pi.getDescription(), String.format("(%s)", new Object[] { S.s(595) })), 
/* 308 */           Strings.safe2(pi.getVersion(), "?") });
/* 309 */         widgetPinfo.setText(s);
/*     */       }
/*     */       
/* 312 */     });
/* 313 */     this.widgetNullInput.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 316 */         boolean enabled = !ReparseDialog.this.isNullInput();
/* 317 */         ReparseDialog.this.widgetOffset.setEnabled(enabled);
/* 318 */         ReparseDialog.this.widgetSize.setEnabled(enabled);
/* 319 */         ReparseDialog.this.widgetEnd.setEnabled(enabled);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 326 */     this.reparseInfo = new Information(this.unit, getName(), getWantedType(), getOffset(), getSize());
/* 327 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ReparseDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */