/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.HistoryAssistedTextField;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.FindTextOptions;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.GraphicalTextFinder;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.IFindTextImpl;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*     */ import com.pnfsoftware.jeb.util.collect.WeakIdentityHashMap;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FindTextDialog
/*     */   extends JebDialog
/*     */ {
/*  50 */   private static final ILogger logger = GlobalLog.getLogger(FindTextDialog.class);
/*     */   
/*  52 */   private static WeakIdentityHashMap<Object, FindTextDialog> usermap = new WeakIdentityHashMap();
/*     */   private GraphicalTextFinder<?> finder;
/*     */   
/*  55 */   public static FindTextDialog getInstance(Object owner) { return (FindTextDialog)usermap.get(owner); }
/*     */   
/*     */ 
/*     */   private IFindTextImpl<?> findimpl;
/*     */   
/*     */   private TextHistory textHistory;
/*     */   
/*     */   private HistoryAssistedTextField searchField;
/*     */   
/*     */   private Button btn_case_sensitive;
/*     */   
/*     */   private Button btn_regex;
/*     */   
/*     */   private Button btn_reverse;
/*     */   
/*     */   private Button btn_wraparound;
/*     */   
/*     */   private boolean validRegex;
/*     */   
/*     */   private boolean wantsRegex;
/*     */   public FindTextDialog(Shell parent, GraphicalTextFinder<?> finder, TextHistory textHistory)
/*     */   {
/*  77 */     this(parent, finder, textHistory, true, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FindTextDialog(Shell parent, GraphicalTextFinder<?> finder, TextHistory textHistory, boolean modal, Control owner, String ownerName)
/*     */   {
/*  90 */     super(parent, generateTitle(modal, ownerName), true, modal);
/*  91 */     this.scrolledContainer = true;
/*     */     
/*  93 */     if (finder == null) {
/*  94 */       throw new NullPointerException();
/*     */     }
/*  96 */     this.finder = finder;
/*  97 */     this.findimpl = finder.getFindTextImpl();
/*     */     
/*  99 */     this.textHistory = textHistory;
/*     */     
/*     */ 
/* 102 */     if ((!modal) && (owner != null)) {
/* 103 */       owner.addDisposeListener(new DisposeListener()
/*     */       {
/*     */         public void widgetDisposed(DisposeEvent e) {
/* 106 */           if (!FindTextDialog.this.shell.isDisposed()) {
/* 107 */             FindTextDialog.this.shell.dispose();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */   private static String generateTitle(boolean modal, String ownerName) {
/* 115 */     String title = S.s(345);
/* 116 */     if ((!modal) && (ownerName != null)) {
/* 117 */       title = title + " (" + Strings.truncateWithSuffix(ownerName, 24, "...") + ")";
/*     */     }
/* 119 */     return title;
/*     */   }
/*     */   
/*     */   private void setOwnerObject(Object owner) {
/* 123 */     usermap.put(owner, this);
/*     */   }
/*     */   
/*     */   private void unsetOwnerObject(Object owner) {
/* 127 */     usermap.remove(owner);
/*     */   }
/*     */   
/*     */   private Object getOwnerObject() {
/* 131 */     for (Object o : usermap.keySet()) {
/* 132 */       if (usermap.get(o) == this) {
/* 133 */         return o;
/*     */       }
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public Object open(Object owner) {
/*     */     try {
/* 141 */       setOwnerObject(owner);
/* 142 */       return open();
/*     */     }
/*     */     finally {
/* 145 */       unsetOwnerObject(owner);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/* 151 */     super.open();
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/* 157 */     UIUtil.setStandardLayout(parent);
/*     */     
/* 159 */     Group areaSearch = new Group(parent, 0);
/* 160 */     areaSearch.setText("Search string");
/* 161 */     areaSearch.setLayoutData(new GridData(4, 128, true, false));
/* 162 */     areaSearch.setLayout(new GridLayout(1, false));
/*     */     
/* 164 */     Group areaOptions = new Group(parent, 0);
/* 165 */     areaOptions.setText(S.s(616));
/* 166 */     areaOptions.setLayoutData(new GridData(4, 128, true, false));
/* 167 */     areaOptions.setLayout(new GridLayout(2, false));
/*     */     
/* 169 */     Composite areaAction = new Composite(parent, 0);
/* 170 */     areaAction.setLayout(new RowLayout(256));
/*     */     
/* 172 */     FindTextOptions opt = this.findimpl.getFindTextOptions(true);
/*     */     
/*     */ 
/* 175 */     this.searchField = new HistoryAssistedTextField(areaSearch, S.s(345) + ":", this.textHistory, true);
/* 176 */     GridData data = new GridData();
/* 177 */     data.horizontalAlignment = 4;
/* 178 */     data.grabExcessHorizontalSpace = true;
/* 179 */     this.searchField.setLayoutData(data);
/* 180 */     this.searchField.setText(opt.getSearchString());
/* 181 */     this.searchField.selectAll();
/*     */     
/*     */ 
/* 184 */     this.btn_case_sensitive = new Button(areaOptions, 32);
/* 185 */     this.btn_case_sensitive.setText(S.s(109));
/* 186 */     this.btn_case_sensitive.setSelection(opt.isCaseSensitive());
/*     */     
/* 188 */     this.btn_regex = new Button(areaOptions, 32);
/* 189 */     this.btn_regex.setText(S.s(676));
/* 190 */     this.btn_regex.setSelection(opt.isRegularExpression());
/*     */     
/* 192 */     this.btn_wraparound = new Button(areaOptions, 32);
/* 193 */     this.btn_wraparound.setText(S.s(826));
/* 194 */     this.btn_wraparound.setSelection(opt.isWrapAround());
/*     */     
/* 196 */     this.btn_reverse = new Button(areaOptions, 32);
/* 197 */     this.btn_reverse.setText(S.s(684));
/* 198 */     this.btn_reverse.setSelection(opt.isReverseSearch());
/* 199 */     this.btn_reverse.setEnabled(this.findimpl.supportReverseSearch());
/*     */     
/*     */ 
/* 202 */     UIUtil.createPushbox(areaAction, S.s(345), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 205 */         FindTextDialog.this.search();
/*     */       }
/*     */       
/* 208 */     });
/* 209 */     UIUtil.createPushbox(areaAction, S.s(201), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 212 */         FindTextDialog.this.shell.close();
/*     */       }
/*     */       
/* 215 */     });
/* 216 */     this.btn_regex.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 219 */         FindTextDialog.this.wantsRegex = FindTextDialog.this.btn_regex.getSelection();
/*     */       }
/*     */       
/* 222 */     });
/* 223 */     this.searchField.getWidget().addKeyListener(this.kl);
/*     */     
/* 225 */     this.btn_case_sensitive.addKeyListener(this.kl);
/* 226 */     this.btn_regex.addKeyListener(this.kl);
/* 227 */     this.btn_reverse.addKeyListener(this.kl);
/* 228 */     this.btn_wraparound.addKeyListener(this.kl);
/*     */     
/* 230 */     this.searchField.getWidget().addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 233 */         FindTextDialog.this.validateRegex();
/*     */       }
/*     */       
/* 236 */     });
/* 237 */     validateRegex();
/*     */   }
/*     */   
/* 240 */   private KeyAdapter kl = new KeyAdapter()
/*     */   {
/*     */     public void keyPressed(KeyEvent e)
/*     */     {
/* 244 */       if (e.character == '\r') {
/* 245 */         FindTextDialog.this.search();
/*     */ 
/*     */       }
/* 248 */       else if ((e.stateMask == SWT.MOD1) && (e.keyCode == 102)) {
/* 249 */         Object o = FindTextDialog.this.getOwnerObject();
/* 250 */         if ((o instanceof Control)) {
/* 251 */           ((Control)o).setFocus();
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   private void search() {
/* 258 */     String value = this.searchField.getText();
/* 259 */     if (value.length() <= 0) {
/* 260 */       return;
/*     */     }
/* 262 */     this.searchField.confirm();
/*     */     
/* 264 */     FindTextOptions opt = this.findimpl.getFindTextOptions(true);
/* 265 */     opt.setSearchString(value);
/* 266 */     opt.setCaseSensitive(this.btn_case_sensitive.getSelection());
/* 267 */     opt.setRegularExpression(this.btn_regex.getSelection());
/* 268 */     opt.setWrapAround(this.btn_wraparound.getSelection());
/* 269 */     opt.setReverseSearch(this.btn_reverse.getSelection());
/*     */     
/* 271 */     this.finder.search(opt);
/*     */     
/*     */ 
/*     */ 
/* 275 */     getShell().setFocus();
/*     */   }
/*     */   
/*     */   private void validateRegex() {
/*     */     try {
/* 280 */       Pattern.compile(this.searchField.getText());
/* 281 */       this.validRegex = true;
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 284 */       this.validRegex = false;
/*     */     }
/*     */     
/* 287 */     if (!this.validRegex) {
/* 288 */       this.btn_regex.setSelection(false);
/* 289 */       this.btn_regex.setEnabled(false);
/*     */     }
/*     */     else {
/* 292 */       this.btn_regex.setEnabled(true);
/* 293 */       this.btn_regex.setSelection(this.wantsRegex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\FindTextDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */