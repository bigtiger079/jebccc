/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import com.pnfsoftware.jeb.util.net.Net;
/*     */ import com.pnfsoftware.jeb.util.net.NetProxyInfo;
/*     */ import java.io.IOException;
/*     */ import java.net.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.swt.custom.BusyIndicator;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyConfigDialog
/*     */   extends JebDialog
/*     */ {
/*  45 */   private static final ILogger logger = GlobalLog.getLogger(ProxyConfigDialog.class);
/*     */   
/*     */   NetProxyInfo proxyinfo;
/*     */   
/*     */   NetProxyInfo proxyinfo2;
/*     */   IGraphicalTaskExecutor executor;
/*     */   Combo widgetType;
/*     */   Text widgetHostname;
/*     */   Text widgetPort;
/*     */   Text widgetUsername;
/*     */   Text widgetPassword;
/*     */   
/*     */   public ProxyConfigDialog(Shell parent, NetProxyInfo proxyinfo, IGraphicalTaskExecutor executor)
/*     */   {
/*  59 */     super(parent, S.s(668), true, true);
/*  60 */     this.proxyinfo = proxyinfo;
/*  61 */     this.executor = executor;
/*     */   }
/*     */   
/*     */   public NetProxyInfo open()
/*     */   {
/*  66 */     super.open();
/*  67 */     return this.proxyinfo2;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  72 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  74 */     UIUtil.createLabel(parent, S.s(672));
/*  75 */     this.widgetType = new Combo(parent, 12);
/*  76 */     GridData layoutData = UIUtil.createGridDataFillHorizontally();
/*  77 */     layoutData.widthHint = UIUtil.determineTextWidth(this.widgetType, 40);
/*  78 */     this.widgetType.setLayoutData(layoutData);
/*  79 */     this.widgetType.add("Direct (no proxy)");
/*  80 */     for (String proxyType : NetProxyInfo.getProxyTypes()) {
/*  81 */       this.widgetType.add(proxyType);
/*     */     }
/*  83 */     this.widgetType.select(0);
/*     */     
/*  85 */     this.widgetType.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  88 */         ProxyConfigDialog.this.onProxyTypeChange();
/*     */       }
/*     */       
/*  91 */     });
/*  92 */     UIUtil.createLabel(parent, S.s(670));
/*  93 */     this.widgetHostname = new Text(parent, 2052);
/*  94 */     this.widgetHostname.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*     */ 
/*     */ 
/*  98 */     UIUtil.createLabel(parent, S.s(671));
/*  99 */     this.widgetPort = new Text(parent, 2052);
/* 100 */     this.widgetPort.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 102 */     Group grpAuth = UIUtil.createGroupGrid(parent, "Authentication (optional)", 2, 2);
/*     */     
/* 104 */     UIUtil.createLabel(grpAuth, S.s(811));
/* 105 */     this.widgetUsername = new Text(grpAuth, 2052);
/* 106 */     this.widgetUsername.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 108 */     UIUtil.createLabel(grpAuth, S.s(631));
/* 109 */     this.widgetPassword = new Text(grpAuth, 2052);
/* 110 */     this.widgetPassword.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 112 */     if (this.proxyinfo != null) {
/* 113 */       this.widgetHostname.setText(Strings.safe(this.proxyinfo.getHostname()));
/* 114 */       this.widgetPort.setText(Integer.toString(this.proxyinfo.getPort()));
/* 115 */       int index = Arrays.asList(this.widgetType.getItems()).indexOf(this.proxyinfo.getType());
/* 116 */       if (index >= 0) {
/* 117 */         this.widgetType.select(index);
/*     */       }
/* 119 */       this.widgetUsername.setText(Strings.safe(this.proxyinfo.getUser()));
/* 120 */       this.widgetPassword.setText(Strings.safe(this.proxyinfo.getPassword()));
/*     */     }
/*     */     
/* 123 */     onProxyTypeChange();
/*     */     
/* 125 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   private void onProxyTypeChange() {
/* 129 */     boolean enabled = this.widgetType.getSelectionIndex() > 0;
/* 130 */     this.widgetHostname.setEnabled(enabled);
/* 131 */     this.widgetPort.setEnabled(enabled);
/* 132 */     this.widgetUsername.setEnabled(enabled);
/* 133 */     this.widgetPassword.setEnabled(enabled);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 138 */     this.proxyinfo2 = check();
/* 139 */     if (this.proxyinfo2 == null) {
/* 140 */       return;
/*     */     }
/* 142 */     if (!verify(this.proxyinfo2)) {
/* 143 */       return;
/*     */     }
/* 145 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   private NetProxyInfo check() {
/* 149 */     int index = this.widgetType.getSelectionIndex();
/* 150 */     if (index == 0) {
/* 151 */       return new NetProxyInfo(Proxy.NO_PROXY);
/*     */     }
/*     */     
/* 154 */     index--;
/* 155 */     if ((index < 0) || (index >= NetProxyInfo.getProxyTypes().size())) {
/* 156 */       UI.error("Illegal proxy type");
/* 157 */       return null;
/*     */     }
/* 159 */     String proxyType = (String)NetProxyInfo.getProxyTypes().get(index);
/*     */     
/* 161 */     String hostname = this.widgetHostname.getText();
/* 162 */     if (Strings.isBlank(hostname)) {
/* 163 */       UI.error("Illegal hostname");
/* 164 */       return null;
/*     */     }
/*     */     
/* 167 */     int port = Conversion.stringToInt(this.widgetPort.getText());
/* 168 */     if ((port <= 0) || (port >= 65535)) {
/* 169 */       UI.error("Illegal port number");
/* 170 */       return null;
/*     */     }
/*     */     
/* 173 */     String username = this.widgetUsername.getText();
/* 174 */     String password = this.widgetPassword.getText();
/*     */     
/* 176 */     return NetProxyInfo.build(proxyType, hostname, port, username, password);
/*     */   }
/*     */   
/*     */   private boolean verify(NetProxyInfo proxyinfo) {
/* 180 */     final AtomicBoolean r = new AtomicBoolean();
/*     */     
/* 182 */     NetProxyInfo previousProxyinfo = Net.getGlobalProxyInformation();
/* 183 */     Net.setGlobalProxyInformation(proxyinfo);
/*     */     
/* 185 */     final Net net = new Net();
/* 186 */     Runnable task = new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 190 */           net.queryBinary("https://www.pnfsoftware.com/ping");
/* 191 */           r.set(true);
/*     */         }
/*     */         catch (IOException e1) {
/* 194 */           ProxyConfigDialog.logger.catching(e1);
/* 195 */           UI.error("The connectivity test failed:\n\n" + e1);
/*     */         }
/*     */       }
/*     */     };
/* 199 */     if (this.executor == null) {
/* 200 */       logger.info("Verifying connectivity, please wait...", new Object[0]);
/* 201 */       BusyIndicator.showWhile(Display.getCurrent(), task);
/*     */     }
/*     */     else {
/* 204 */       this.executor.executeTaskWithPopupDelay(500, "Verifying connectivity...", false, task);
/*     */     }
/*     */     
/* 207 */     if (!r.get()) {
/* 208 */       Net.setGlobalProxyInformation(previousProxyinfo);
/* 209 */       return false;
/*     */     }
/*     */     
/* 212 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ProxyConfigDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */