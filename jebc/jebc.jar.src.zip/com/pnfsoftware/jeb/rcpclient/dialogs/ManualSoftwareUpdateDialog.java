/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.FileDialog;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManualSoftwareUpdateDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private static final String strNoUpdateFile = "<No update file selected>";
/*     */   private boolean success;
/*     */   private String _filename;
/*     */   private String _password;
/*     */   private Text textFilename;
/*     */   private Text textPassword;
/*     */   private Button btnInstall;
/*     */   
/*     */   public ManualSoftwareUpdateDialog(Shell parent)
/*     */   {
/*  42 */     super(parent, S.s(454), true, true);
/*  43 */     this.scrolledContainer = true;
/*  44 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.NONE;
/*     */   }
/*     */   
/*     */   public String[] open()
/*     */   {
/*  49 */     super.open();
/*  50 */     if (!this.success) {
/*  51 */       return null;
/*     */     }
/*     */     
/*  54 */     return new String[] { this._filename, this._password };
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  59 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  61 */     parent.setLayout(new GridLayout(1, false));
/*     */     
/*  63 */     Group g0 = new Group(parent, 0);
/*  64 */     g0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  65 */     g0.setLayout(new GridLayout(2, false));
/*  66 */     g0.setText("File");
/*     */     
/*  68 */     Label label = new Label(g0, 0);
/*  69 */     label.setText(S.s(453));
/*  70 */     label.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*     */     
/*  72 */     UIUtil.createPushbox(g0, "Select a file", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/*  75 */         FileDialog d = new FileDialog(ManualSoftwareUpdateDialog.this.shell);
/*  76 */         d.setText(S.s(724));
/*  77 */         d.setFilterExtensions(new String[] { "*.zip", "*.*" });
/*  78 */         String filename = d.open();
/*  79 */         if (filename != null) {
/*  80 */           ManualSoftwareUpdateDialog.this._filename = filename;
/*     */         }
/*     */         
/*  83 */         ManualSoftwareUpdateDialog.this.textFilename.setText(Strings.safe(ManualSoftwareUpdateDialog.this._filename, "<No update file selected>"));
/*  84 */         ManualSoftwareUpdateDialog.this.btnInstall.setEnabled(ManualSoftwareUpdateDialog.this._filename != null);
/*     */       }
/*     */       
/*  87 */     });
/*  88 */     this.textFilename = new Text(g0, 2060);
/*  89 */     this.textFilename.setText("<No update file selected>");
/*  90 */     this.textFilename.setLayoutData(UIUtil.createGridDataForText(this.textFilename, 40));
/*     */     
/*  92 */     Group g1 = new Group(parent, 0);
/*  93 */     g1.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  94 */     g1.setLayout(new GridLayout(1, false));
/*  95 */     g1.setText(S.s(631));
/*     */     
/*  97 */     new Label(g1, 0).setText(S.s(673));
/*     */     
/*  99 */     this.textPassword = new Text(g1, 2052);
/* 100 */     this.textPassword.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 102 */     createOkayCancelButtons(parent);
/* 103 */     this.btnInstall = getButtonByStyle(32);
/* 104 */     this.btnInstall.setText(S.s(392));
/* 105 */     this.btnInstall.setEnabled(false);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 110 */     this._password = this.textPassword.getText();
/* 111 */     this.success = (this._filename != null);
/* 112 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ManualSoftwareUpdateDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */