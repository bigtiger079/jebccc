/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.jface.resource.JFaceResources;
/*    */ import org.eclipse.swt.custom.StyledText;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentDialog
/*    */   extends JebDialog
/*    */ {
/* 31 */   private static final ILogger logger = GlobalLog.getLogger(CommentDialog.class);
/*    */   
/*    */ 
/*    */   private StyledText widgetComment;
/*    */   
/*    */ 
/*    */   private String input;
/*    */   
/*    */   private String address;
/*    */   
/*    */   private String comment;
/*    */   
/*    */   String description;
/*    */   
/*    */ 
/*    */   public CommentDialog(Shell parent, String address)
/*    */   {
/* 48 */     super(parent, S.s(203), true, true);
/* 49 */     this.scrolledContainer = true;
/*    */     
/* 51 */     this.address = address;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 55 */     this.description = description;
/*    */   }
/*    */   
/*    */   public void setInitialComment(String comment) {
/* 59 */     this.comment = comment;
/*    */   }
/*    */   
/*    */   public String open()
/*    */   {
/* 64 */     super.open();
/* 65 */     return this.input;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 70 */     UIUtil.setStandardLayout(parent);
/*    */     
/* 72 */     new Label(parent, 0).setText(String.format("Comment at address: %s", new Object[] { this.address }));
/* 73 */     this.widgetComment = new StyledText(parent, 2818);
/* 74 */     this.widgetComment.setAlwaysShowScrollBars(false);
/* 75 */     if (this.comment != null) {
/* 76 */       this.widgetComment.setText(this.comment);
/*    */     }
/* 78 */     this.widgetComment.selectAll();
/* 79 */     this.widgetComment.setFont(JFaceResources.getTextFont());
/* 80 */     GridData griddata = UIUtil.createGridDataForText(this.widgetComment, 50, 3, false);
/* 81 */     griddata.grabExcessHorizontalSpace = true;
/* 82 */     griddata.horizontalAlignment = 4;
/* 83 */     griddata.grabExcessVerticalSpace = true;
/* 84 */     griddata.verticalAlignment = 4;
/* 85 */     this.widgetComment.setLayoutData(griddata);
/* 86 */     UIUtil.disableTabOutput(this.widgetComment);
/*    */     
/* 88 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 93 */     this.input = this.widgetComment.getText();
/* 94 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\CommentDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */