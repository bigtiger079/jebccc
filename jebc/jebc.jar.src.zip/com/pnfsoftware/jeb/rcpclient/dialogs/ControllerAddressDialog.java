/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.AbstractClientContext;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.net.NetProxyInfo;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControllerAddressDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private AbstractClientContext context;
/*     */   private boolean success;
/*     */   private Text widgetHostname;
/*     */   private Text widgetPort;
/*     */   private NetProxyInfo proxyinfo;
/*     */   
/*     */   public ControllerAddressDialog(Shell parent, AbstractClientContext context)
/*     */   {
/*  54 */     super(parent, S.s(221), true, true);
/*  55 */     this.scrolledContainer = true;
/*     */     
/*  57 */     if (context == null) {
/*  58 */       throw new NullPointerException();
/*     */     }
/*  60 */     this.context = context;
/*     */   }
/*     */   
/*     */   public Boolean open()
/*     */   {
/*  65 */     super.open();
/*  66 */     return Boolean.valueOf(this.success);
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  71 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  73 */     Label label = new Label(parent, 64);
/*  74 */     label.setText(String.format("%s. %s.", new Object[] { S.s(223), S.s(225) }));
/*  75 */     label.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*     */     
/*  77 */     Group g0 = UIUtil.createGroupGrid(parent, "Controller", 2, 2);
/*     */     
/*  79 */     Label l = new Label(g0, 64);
/*  80 */     l.setText("Both fields are mandatory.");
/*  81 */     l.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*     */     
/*     */ 
/*  84 */     new Label(g0, 0).setText(S.s(670));
/*  85 */     this.widgetHostname = new Text(g0, 2052);
/*  86 */     this.widgetHostname.setText(Strings.safe(this.context.getControllerInterface()));
/*  87 */     this.widgetHostname.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  88 */     this.widgetHostname.selectAll();
/*  89 */     this.widgetHostname.setFocus();
/*     */     
/*  91 */     new Label(g0, 0).setText(S.s(671));
/*  92 */     this.widgetPort = new Text(g0, 2052);
/*  93 */     this.widgetPort.setText(Integer.toString(this.context.getControllerPort()));
/*  94 */     this.widgetPort.selectAll();
/*  95 */     this.widgetPort.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*  97 */     Group g1 = UIUtil.createGroupGrid(parent, "Connection", 2, 2);
/*     */     
/*  99 */     UIUtil.createPushbox(g1, "Proxy settings...", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 102 */         ProxyConfigDialog dlg = new ProxyConfigDialog(UIUtil.getParentShell(ControllerAddressDialog.this.shell), null, null);
/* 103 */         NetProxyInfo r = dlg.open();
/* 104 */         if (r != null) {
/* 105 */           ControllerAddressDialog.this.proxyinfo = r;
/*     */         }
/*     */         
/*     */       }
/* 109 */     });
/* 110 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 115 */     String hostname = this.widgetHostname.getText();
/* 116 */     if (Strings.isBlank(hostname)) {
/* 117 */       UI.error("Illegal hostname for controller");
/* 118 */       return;
/*     */     }
/*     */     
/* 121 */     int port = Conversion.stringToInt(this.widgetPort.getText());
/* 122 */     if ((port <= 0) || (port >= 65535)) {
/* 123 */       UI.error("Illegal port number for controller");
/* 124 */       return;
/*     */     }
/*     */     
/*     */ 
/* 128 */     this.context.setControllerInterface(hostname);
/* 129 */     this.context.setControllerPort(port);
/* 130 */     if (this.proxyinfo != null) {
/* 131 */       this.context.setProxyString(this.proxyinfo.toString());
/*     */     }
/* 133 */     this.success = Boolean.TRUE.booleanValue();
/* 134 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ControllerAddressDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */