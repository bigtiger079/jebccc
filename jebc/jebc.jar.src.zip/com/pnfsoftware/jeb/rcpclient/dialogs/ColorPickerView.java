/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.UIAssetManager;
/*    */ import org.eclipse.swt.events.MouseEvent;
/*    */ import org.eclipse.swt.events.MouseListener;
/*    */ import org.eclipse.swt.events.SelectionListener;
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ import org.eclipse.swt.graphics.RGB;
/*    */ import org.eclipse.swt.layout.FillLayout;
/*    */ import org.eclipse.swt.widgets.ColorDialog;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.TypedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ColorPickerView
/*    */   extends Composite
/*    */ {
/*    */   private Label c;
/*    */   
/*    */   public ColorPickerView(Composite parent, String text, Color initial)
/*    */   {
/* 38 */     super(parent, 0);
/* 39 */     setLayout(new FillLayout());
/*    */     
/* 41 */     Label l = new Label(parent, 0);
/* 42 */     l.setText(text + ": ");
/*    */     
/* 44 */     this.c = new Label(parent, 2048);
/* 45 */     this.c.setText("            ");
/* 46 */     this.c.setBackground(initial);
/*    */     
/* 48 */     this.c.addMouseListener(new MouseListener()
/*    */     {
/*    */       public void mouseUp(MouseEvent e) {
/* 51 */         ColorDialog cdlg = new ColorDialog(ColorPickerView.this.getShell());
/* 52 */         cdlg.setRGB(ColorPickerView.this.c.getBackground().getRGB());
/* 53 */         RGB rgb = cdlg.open();
/* 54 */         if (rgb != null) {
/* 55 */           ColorPickerView.this.c.setBackground(UIAssetManager.getInstance().getColor(rgb));
/* 56 */           ColorPickerView.this.notifyListeners(13, new Event());
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */       public void mouseDown(MouseEvent e) {}
/*    */       
/*    */ 
/*    */       public void mouseDoubleClick(MouseEvent e) {}
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */   public ColorPickerView(Composite parent, String text)
/*    */   {
/* 71 */     this(parent, text, null);
/*    */   }
/*    */   
/*    */   void addSelectionListener(SelectionListener listener) {
/* 75 */     addListener(13, new TypedListener(listener));
/*    */   }
/*    */   
/*    */   void removeSelectionListener(SelectionListener listener) {
/* 79 */     removeListener(13, listener);
/*    */   }
/*    */   
/*    */   public void setColor(Color color) {
/* 83 */     this.c.setBackground(color);
/*    */   }
/*    */   
/*    */   public Color getColor() {
/* 87 */     return this.c.getBackground();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ColorPickerView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */