/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.AbstractClientContext;
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.UIAssetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ButtonGroup;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.BrowserUtil;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Link;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AboutDialog
/*     */   extends JebDialog
/*     */ {
/*  48 */   static final String[] app_thirdpartylist = { "Android Framework Resources (Apache License 2.0)", "ANTLR4 (The BSD License)", "Apache Commons (Apache License 2.0)", "APKTool (Apache License 2.0)", "AOSP 'dx' package (Apache License 2.0)", "Eclipse Platform (Eclipse Public License)", "Google Guava (Apache License 2.0)", "JSON-Simple (Apache License 2.0)", "Jsoup (MIT License)", "Jython (Python Software Foundation License 2.0)", "LZ4 for Java (Apache License 2.0)", "Objenesis (Apache License 2.0)", "Okhttp, Okio (Apache License 2.0)", "SnakeYAML (Apache License 2.0)", "SQLite (Apache License 2.0)" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractClientContext context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private Color cWhite = UIAssetManager.getInstance().getColor(255, 255, 255);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AboutDialog(Shell parent, AbstractClientContext context)
/*     */   {
/*  77 */     super(parent, String.format(S.s(2), new Object[] { "JEB" }), true, true);
/*  78 */     this.scrolledContainer = true;
/*  79 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object open()
/*     */   {
/*  87 */     if (Licensing.isDebugBuild()) {
/*  88 */       System.gc();
/*     */     }
/*     */     
/*  91 */     super.open();
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   public void createContents(Composite ctl)
/*     */   {
/*  97 */     UIUtil.setStandardLayout(ctl, 2, 10);
/*  98 */     ctl.setBackground(this.cWhite);
/*     */     
/* 100 */     Label l = new Label(ctl, 0);
/* 101 */     l.setLayoutData(new GridData(16384, 128, false, false));
/* 102 */     l.setBackground(this.cWhite);
/* 103 */     l.setImage(UIAssetManager.getInstance().getImage("jeb1/icon-jeb-48.png"));
/*     */     
/* 105 */     Composite c0 = new Composite(ctl, 0);
/* 106 */     GridData data = new GridData();
/* 107 */     data.horizontalIndent = 15;
/* 108 */     data.horizontalAlignment = 4;
/* 109 */     data.grabExcessHorizontalSpace = true;
/* 110 */     c0.setLayoutData(data);
/* 111 */     c0.setLayout(new GridLayout(1, false));
/* 112 */     c0.setBackground(this.cWhite);
/*     */     
/* 114 */     SelectionListener l_visitLink = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 117 */         BrowserUtil.openInBrowser(e.text);
/*     */       }
/*     */       
/*     */ 
/* 121 */     };
/* 122 */     Link t0 = new Link(c0, 64);
/* 123 */     t0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 124 */     t0.setBackground(this.cWhite);
/* 125 */     t0.setText(String.format("<a href=\"%s\">%s</a>", new Object[] { "https://www.pnfsoftware.com", "PNF Software, Inc." }));
/*     */     
/* 127 */     t0.addSelectionListener(l_visitLink);
/*     */     
/*     */ 
/* 130 */     if ((Licensing.isFloatingBuild()) && (this.context != null)) {
/* 131 */       Link t01 = new Link(c0, 64);
/* 132 */       t01.setBackground(this.cWhite);
/* 133 */       String url = String.format("http://%s:%d", new Object[] { this.context.getControllerInterface(), Integer.valueOf(this.context.getControllerPort()) });
/* 134 */       t01.setText(String.format("<a href=\"%s\">%s</a>", new Object[] { url, "Visit your Floating Controller Web Portal" }));
/* 135 */       t01.addSelectionListener(l_visitLink);
/*     */     }
/*     */     
/*     */ 
/* 139 */     Label t1 = new Label(c0, 64);
/* 140 */     t1.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 141 */     t1.setBackground(this.cWhite);
/* 142 */     t1.setText(String.format("\n%s - %s\n%s © %s\n\n", new Object[] { "JEB", "Interactive Decompilation for Software Analysis", "PNF Software, Inc.", "2015-2018" }));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     final Text t2 = new Text(c0, 2114);
/* 148 */     t2.setEditable(false);
/* 149 */     StringBuilder sb = new StringBuilder();
/* 150 */     sb.append(AbstractClientContext.generateLicenseInformation());
/* 151 */     if (this.context != null) {
/* 152 */       String licenseKey = this.context.getPropertyManager().getString(".LicenseKey");
/* 153 */       if ((licenseKey != null) && (!licenseKey.isEmpty())) {
/* 154 */         sb.append(String.format("%s: %s", new Object[] { S.s(436), licenseKey }));
/*     */       }
/*     */     }
/* 157 */     final String text = sb.toString();
/* 158 */     t2.setText(text);
/* 159 */     t2.setFocus();
/* 160 */     t2.selectAll();
/*     */     
/* 162 */     UIUtil.createPushbox(c0, S.s(213), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 165 */         String sel = t2.getSelectionText();
/* 166 */         if (sel.isEmpty()) {
/* 167 */           sel = text;
/*     */         }
/* 169 */         UIUtil.copyTextToClipboard(sel);
/*     */         
/* 171 */         MessageDialog.openInformation(AboutDialog.this.shell, S.s(210), S.s(432));
/*     */       }
/*     */       
/*     */ 
/* 175 */     });
/* 176 */     Label t3 = new Label(c0, 64);
/* 177 */     t3.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 178 */     t3.setBackground(this.cWhite);
/* 179 */     t3.setText(String.format("\n%s.\n", new Object[] { S.s(775) }));
/* 180 */     StringBuilder tplText = new StringBuilder();
/* 181 */     for (String thirdparty : app_thirdpartylist) {
/* 182 */       tplText.append(String.format("- %s\n", new Object[] { thirdparty }));
/*     */     }
/* 184 */     Text t31 = UIUtil.createTextboxInGrid(c0, 2562, 0, 4);
/* 185 */     t31.setEditable(false);
/* 186 */     t31.setText(tplText.toString());
/*     */     
/*     */ 
/* 189 */     Label t4 = new Label(c0, 64);
/* 190 */     t4.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 191 */     t4.setBackground(this.cWhite);
/* 192 */     t4.setText("\n" + AbstractClientContext.formatMemoryUsage());
/* 193 */     Link t41 = new Link(c0, 64);
/* 194 */     t41.setBackground(this.cWhite);
/* 195 */     t41.setText(String.format("<a href=\"%s\">%s</a>", new Object[] { "https://www.pnfsoftware.com/jeb/faqmem", S.s(382) }));
/* 196 */     t41.addSelectionListener(l_visitLink);
/*     */     
/* 198 */     Label t5 = new Label(c0, 64);
/* 199 */     t3.setBackground(this.cWhite);
/* 200 */     t5.setText("\n");
/*     */     
/*     */ 
/* 203 */     ButtonGroup bg = ButtonGroup.buildButtons(ctl, 0, 2);
/* 204 */     bg.setBackground(this.cWhite);
/*     */     
/* 206 */     Button btn_ok = bg.add(S.s(605), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 209 */         AboutDialog.this.shell.close();
/*     */       }
/*     */       
/* 212 */     });
/* 213 */     bg.add("Satisfaction Survey", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 216 */         BrowserUtil.openInBrowser("https://www.pnfsoftware.com/survey");
/*     */       }
/*     */     });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */     if (Licensing.isDemoBuild()) {
/* 228 */       bg.add("Purchase a License", new SelectionAdapter()
/*     */       {
/*     */         public void widgetSelected(SelectionEvent e) {
/* 231 */           BrowserUtil.openInBrowser("https://www.pnfsoftware.com/jeb/buy");
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 236 */     this.shell.setDefaultButton(btn_ok);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\AboutDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */