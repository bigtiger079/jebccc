/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.code.asm.type.CodeConstant;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.NamedConstantsView;
/*    */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*    */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedConstantsChooserDialog
/*    */   extends JebDialog
/*    */ {
/*    */   private INativeCodeUnit<?> unit;
/*    */   private NamedConstantsView v;
/*    */   private Object sourceValue;
/*    */   private CodeConstant selectedConstant;
/*    */   
/*    */   public NamedConstantsChooserDialog(Shell parent, INativeCodeUnit<?> unit, Object sourceValue)
/*    */   {
/* 36 */     super(parent, "Choose a constant", true, false);
/* 37 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*    */     
/* 39 */     if (unit == null) {
/* 40 */       throw new NullPointerException();
/*    */     }
/* 42 */     this.unit = unit;
/* 43 */     this.sourceValue = sourceValue;
/*    */   }
/*    */   
/*    */   public CodeConstant open()
/*    */   {
/* 48 */     super.open();
/* 49 */     return this.selectedConstant;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 54 */     parent.setLayout(new GridLayout(1, false));
/*    */     
/* 56 */     this.v = new NamedConstantsView(parent, 0, null, this.unit, null, this.sourceValue);
/* 57 */     this.v.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*    */     
/* 59 */     this.v.getViewer().addDoubleClickListener(new IDoubleClickListener()
/*    */     {
/*    */       public void doubleClick(DoubleClickEvent e) {
/* 62 */         NamedConstantsChooserDialog.this.onConfirm();
/*    */       }
/*    */       
/* 65 */     });
/* 66 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 71 */     this.selectedConstant = this.v.getSelectedRow();
/* 72 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\NamedConstantsChooserDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */