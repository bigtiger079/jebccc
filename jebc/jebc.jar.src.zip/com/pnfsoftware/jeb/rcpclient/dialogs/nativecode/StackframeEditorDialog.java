/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeMethodItem;
/*    */ import com.pnfsoftware.jeb.rcpclient.FontManager;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.StackEditorView;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StackframeEditorDialog
/*    */   extends JebDialog
/*    */ {
/*    */   INativeCodeUnit<?> unit;
/*    */   INativeMethodItem initialRoutine;
/*    */   FontManager fontman;
/*    */   
/*    */   public StackframeEditorDialog(Shell parent, INativeCodeUnit<?> unit, INativeMethodItem initialRoutine, FontManager fontman)
/*    */   {
/* 35 */     super(parent, String.format("Edit stackframe of method \"%s\"", new Object[] { initialRoutine.getName(true) }), true, true);
/* 36 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*    */     
/* 38 */     this.unit = unit;
/* 39 */     this.initialRoutine = initialRoutine;
/* 40 */     this.fontman = fontman;
/*    */   }
/*    */   
/*    */   public Object open()
/*    */   {
/* 45 */     super.open();
/* 46 */     return null;
/*    */   }
/*    */   
/*    */   protected void createContents(Composite parent)
/*    */   {
/* 51 */     parent.setLayout(new GridLayout());
/*    */     
/* 53 */     StackEditorView v = new StackEditorView(parent, 0, this.unit);
/* 54 */     GridData data = new GridData(4, 4, true, true);
/* 55 */     data.minimumHeight = 300;
/* 56 */     v.setLayoutData(data);
/* 57 */     if (this.fontman != null) {
/* 58 */       v.setCodefont(this.fontman.getCodeFont());
/*    */     }
/* 60 */     v.setInputRoutine(this.initialRoutine);
/*    */     
/* 62 */     createOkayButton(parent);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\StackframeEditorDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */