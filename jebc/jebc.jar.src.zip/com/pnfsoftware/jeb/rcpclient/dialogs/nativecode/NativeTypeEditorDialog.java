/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.code.asm.type.IStructureType;
/*    */ import com.pnfsoftware.jeb.rcpclient.FontManager;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.NativeTypeEditorView;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeTypeEditorDialog
/*    */   extends JebDialog
/*    */ {
/*    */   INativeCodeUnit<?> unit;
/*    */   IStructureType initialType;
/*    */   FontManager fontman;
/*    */   
/*    */   public NativeTypeEditorDialog(Shell parent, INativeCodeUnit<?> unit, IStructureType initialType, FontManager fontman)
/*    */   {
/* 33 */     super(parent, "Type Editor", true, true);
/*    */     
/* 35 */     this.unit = unit;
/* 36 */     this.initialType = initialType;
/* 37 */     this.fontman = fontman;
/*    */   }
/*    */   
/*    */   public Object open()
/*    */   {
/* 42 */     super.open();
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   protected void createContents(Composite parent)
/*    */   {
/* 48 */     parent.setLayout(new GridLayout());
/*    */     
/* 50 */     NativeTypeEditorView v = new NativeTypeEditorView(parent, 0, this.unit);
/* 51 */     GridData data = new GridData(4, 4, true, true);
/* 52 */     data.minimumHeight = 300;
/* 53 */     v.setLayoutData(data);
/* 54 */     if (this.fontman != null) {
/* 55 */       v.setCodefont(this.fontman.getCodeFont());
/*    */     }
/* 57 */     v.setInput(this.initialType);
/*    */     
/* 59 */     createOkayButton(parent);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\NativeTypeEditorDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */