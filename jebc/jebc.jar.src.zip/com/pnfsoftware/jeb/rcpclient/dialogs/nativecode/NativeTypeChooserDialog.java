/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.code.asm.type.INativeType;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.NativeTypesView;
/*    */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*    */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeTypeChooserDialog
/*    */   extends JebDialog
/*    */ {
/*    */   private INativeCodeUnit<?> unit;
/*    */   private NativeTypesView v;
/*    */   private INativeType selectedType;
/*    */   
/*    */   public NativeTypeChooserDialog(Shell parent, INativeCodeUnit<?> unit)
/*    */   {
/* 35 */     super(parent, "Choose a type", true, false);
/* 36 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*    */     
/* 38 */     if (unit == null) {
/* 39 */       throw new NullPointerException();
/*    */     }
/* 41 */     this.unit = unit;
/*    */   }
/*    */   
/*    */   public INativeType open()
/*    */   {
/* 46 */     super.open();
/* 47 */     return this.selectedType;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 52 */     parent.setLayout(new GridLayout(1, false));
/*    */     
/* 54 */     this.v = new NativeTypesView(parent, 0, null, this.unit, null, 3);
/* 55 */     this.v.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*    */     
/*    */ 
/* 58 */     this.v.getViewer().addDoubleClickListener(new IDoubleClickListener()
/*    */     {
/*    */       public void doubleClick(DoubleClickEvent e)
/*    */       {
/* 62 */         NativeTypeChooserDialog.this.onConfirm();
/*    */       }
/*    */       
/* 65 */     });
/* 66 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 71 */     this.selectedType = this.v.getSelectedRow();
/* 72 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\NativeTypeChooserDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */