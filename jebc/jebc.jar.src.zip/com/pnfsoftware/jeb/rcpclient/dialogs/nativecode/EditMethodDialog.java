/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*     */ 
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.cfg.CFG;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeMethodDataItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeMethodItem;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.InputField;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.TriStateField;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.List;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditMethodDialog
/*     */   extends JebDialog
/*     */ {
/*  41 */   private static final ILogger logger = GlobalLog.getLogger(EditMethodDialog.class);
/*     */   
/*     */   private INativeCodeUnit<?> unit;
/*     */   
/*     */   private INativeMethodItem method;
/*     */   
/*     */   private boolean confirmed;
/*     */   
/*  49 */   private MethodSetupInformation info = new MethodSetupInformation();
/*     */   
/*     */   private Text widgetMethodName;
/*     */   
/*     */   private Text widgetSig;
/*     */   
/*     */   private Text widgetAddress;
/*     */   private Text widgetAddressEnd;
/*     */   private InputField wRoutineDataSPDeltaOnReturn;
/*     */   private TriStateField wRoutineNonReturning;
/*     */   
/*     */   public EditMethodDialog(Shell parent, INativeCodeUnit<?> unit, INativeMethodItem method)
/*     */   {
/*  62 */     super(parent, "Edit Method", true, true);
/*  63 */     this.scrolledContainer = true;
/*     */     
/*  65 */     this.unit = unit;
/*  66 */     this.method = method;
/*     */   }
/*     */   
/*     */   public MethodSetupInformation open()
/*     */   {
/*  71 */     super.open();
/*  72 */     if (!this.confirmed) {
/*  73 */       return null;
/*     */     }
/*  75 */     return this.info;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  80 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  82 */     Group grp0 = UIUtil.createGroupGrid(parent, "Declaration", 2, 2);
/*     */     
/*  84 */     new Label(grp0, 0).setText("Name: ");
/*  85 */     this.widgetMethodName = new Text(grp0, 2052);
/*  86 */     this.widgetMethodName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  87 */     this.widgetMethodName.setText(this.method.getName(true));
/*  88 */     this.widgetMethodName.setEditable(false);
/*     */     
/*  90 */     new Label(grp0, 0).setText("Signature: ");
/*  91 */     this.widgetSig = new Text(grp0, 2052);
/*  92 */     this.widgetSig.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  93 */     this.widgetSig.setText(this.method.getSignature(true));
/*  94 */     this.widgetSig.setEditable(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     buildItemAttributesWidget(grp0, this.method);
/*     */     
/*     */ 
/* 105 */     INativeMethodDataItem methodData = this.method.getData();
/* 106 */     if (methodData != null) {
/* 107 */       Group grp1 = UIUtil.createGroupGrid(parent, "Internal Data", 2, 2);
/*     */       
/* 109 */       new Label(grp1, 0).setText("Entry-point: ");
/* 110 */       this.widgetAddress = new Text(grp1, 2052);
/* 111 */       this.widgetAddress.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 112 */       this.widgetAddress.setText(String.format("%Xh", new Object[] { Long.valueOf(methodData.getMemoryAddress()) }));
/* 113 */       this.widgetAddress.setEditable(false);
/*     */       
/* 115 */       new Label(grp1, 0).setText("Begin: ");
/* 116 */       this.widgetAddressEnd = new Text(grp1, 2052);
/* 117 */       this.widgetAddressEnd.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 118 */       this.widgetAddressEnd.setText(String.format("%Xh", new Object[] { Long.valueOf(methodData.getCFG().getFirstAddress()) }));
/* 119 */       this.widgetAddressEnd.setEditable(false);
/*     */       
/* 121 */       new Label(grp1, 0).setText("End: ");
/* 122 */       this.widgetAddressEnd = new Text(grp1, 2052);
/* 123 */       this.widgetAddressEnd.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 124 */       this.widgetAddressEnd.setText(String.format("%Xh", new Object[] { Long.valueOf(methodData.getCFG().getEndAddress()) }));
/* 125 */       this.widgetAddressEnd.setEditable(false);
/*     */       
/* 127 */       buildItemAttributesWidget(grp1, methodData);
/*     */     }
/*     */     
/*     */ 
/* 131 */     createOkayCancelButtons(parent);
/* 132 */     getButtonByStyle(32);
/*     */     
/* 134 */     update();
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 139 */     this.info = new MethodSetupInformation();
/*     */     
/* 141 */     String s = this.wRoutineDataSPDeltaOnReturn.getText();
/* 142 */     this.info.routineDataSPDeltaOnReturn = (s.isEmpty() ? null : Integer.valueOf(Conversion.stringToInt(s)));
/*     */     
/* 144 */     this.info.routineNonReturning = this.wRoutineNonReturning.getState();
/*     */     
/* 146 */     this.confirmed = true;
/* 147 */     super.onConfirm();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void update() {}
/*     */   
/*     */ 
/*     */   public void buildItemAttributesWidget(Composite parent, final INativeItem item)
/*     */   {
/* 157 */     new Label(parent, 0).setText("Attributes: ");
/*     */     
/* 159 */     if (item.getAttributes().isEmpty()) {
/* 160 */       new Label(parent, 0).setText("-");
/*     */     }
/*     */     else {
/* 163 */       final List widgetAttr = new List(parent, 2052);
/* 164 */       GridData layoutData = UIUtil.createGridDataFillHorizontally();
/* 165 */       layoutData.widthHint = UIUtil.determineTextWidth(widgetAttr, 30);
/* 166 */       widgetAttr.setLayoutData(layoutData);
/* 167 */       for (String key : item.getAttributes().keySet()) {
/* 168 */         widgetAttr.add(key);
/*     */       }
/*     */       
/* 171 */       new Label(parent, 0).setText("(Attr. value) ");
/*     */       
/* 173 */       final Label widgetAttrInfo = new Label(parent, 2048);
/* 174 */       widgetAttrInfo.setText("N/A");
/* 175 */       widgetAttrInfo.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */       
/* 177 */       widgetAttr.addSelectionListener(new SelectionAdapter()
/*     */       {
/*     */         public void widgetSelected(SelectionEvent e) {
/* 180 */           String[] sel = widgetAttr.getSelection();
/* 181 */           if (sel.length == 0) {
/* 182 */             widgetAttrInfo.setText("");
/*     */           }
/*     */           else {
/* 185 */             Object o = item.getAttribute(sel[0], Object.class);
/*     */             String val;
/* 187 */             String val; if ((o instanceof INativeItem)) {
/* 188 */               val = ((INativeItem)o).getName(true);
/*     */             }
/*     */             else {
/* 191 */               val = Strings.safe(o);
/*     */             }
/* 193 */             widgetAttrInfo.setText(val);
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 199 */     Group grp = new Group(parent, 0);
/* 200 */     grp.setText("Customizable attributes:");
/* 201 */     grp.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, true));
/* 202 */     UIUtil.setStandardLayout(grp, 1);
/*     */     
/* 204 */     if ((item instanceof INativeMethodDataItem)) {
/* 205 */       INativeMethodDataItem routineData = (INativeMethodDataItem)item;
/*     */       
/* 207 */       Integer spdelta = routineData.getSPDeltaOnReturn();
/*     */       
/* 209 */       this.wRoutineDataSPDeltaOnReturn = new InputField(grp, "Stack pointer delta on return", spdelta == null ? "" : spdelta.toString(), 4);
/*     */     }
/*     */     
/* 212 */     if ((item instanceof INativeMethodItem)) {
/* 213 */       INativeMethodItem routine = (INativeMethodItem)item;
/*     */       
/* 215 */       Boolean nonReturning = routine.getNonReturning();
/* 216 */       this.wRoutineNonReturning = new TriStateField(grp, "Method does not return", nonReturning, null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\EditMethodDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */