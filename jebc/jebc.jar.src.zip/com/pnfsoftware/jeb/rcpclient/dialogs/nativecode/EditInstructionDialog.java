/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.IInstruction;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.analyzer.BranchTarget;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.analyzer.IBranchResolution;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.analyzer.IBranchTarget;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.analyzer.INativeCodeAnalyzer;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.analyzer.INativeCodeModel;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeInstructionItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeMethodItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.InstructionHints;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.IPrototypeItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.TypeStringParseException;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.TypeStringParser;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Formatter;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditInstructionDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private long address;
/*     */   private INativeCodeUnit<?> unit;
/*     */   private boolean confirmed;
/*     */   INativeInstructionItem ii;
/*     */   Text widgetAddress;
/*     */   Text widgetLabel;
/*     */   Text widgetBytes;
/*     */   Text widgetDisas;
/*     */   Text widgetHintSPDelta;
/*     */   Text widgetHintProto;
/*     */   Text widgetDynTarget;
/*     */   private static final String KEY_DYNTARGET = "dynTargetItem";
/*     */   
/*     */   public EditInstructionDialog(Shell parent, long address, INativeCodeUnit<?> unit)
/*     */   {
/*  62 */     super(parent, "Edit the Instruction", true, true);
/*  63 */     this.scrolledContainer = true;
/*     */     
/*  65 */     this.address = address;
/*  66 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public Boolean open()
/*     */   {
/*  71 */     super.open();
/*  72 */     return Boolean.valueOf(this.confirmed);
/*     */   }
/*     */   
/*     */   protected void createContents(final Composite parent)
/*     */   {
/*  77 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  79 */     new Label(parent, 0).setText(S.s(52) + ": ");
/*  80 */     this.widgetAddress = UIUtil.createTextboxInGrid(parent, 2060, 50, 1, true, false);
/*     */     
/*  82 */     new Label(parent, 0).setText(S.s(424) + ": ");
/*  83 */     this.widgetLabel = new Text(parent, 2060);
/*  84 */     this.widgetLabel.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*  86 */     new Label(parent, 0).setText("Bytes: ");
/*  87 */     this.widgetBytes = new Text(parent, 2060);
/*  88 */     this.widgetBytes.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*  90 */     new Label(parent, 0).setText("Disassembly: ");
/*  91 */     this.widgetDisas = new Text(parent, 2060);
/*  92 */     this.widgetDisas.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*  94 */     Group grp = UIUtil.createGroupGrid(parent, "Attributes", 2, 2);
/*     */     
/*  96 */     new Label(grp, 0).setText("SP Delta: ");
/*  97 */     this.widgetHintSPDelta = new Text(grp, 2052);
/*  98 */     this.widgetHintSPDelta.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 100 */     new Label(grp, 0).setText("Prototype Hint: ");
/* 101 */     this.widgetHintProto = new Text(grp, 2052);
/* 102 */     this.widgetHintProto.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 104 */     new Label(grp, 0).setText("Dynamic Target: ");
/* 105 */     Composite c = UIUtil.createCompositeGrid(grp, 1, 3);
/* 106 */     UIUtil.createTightPushbox(c, "Select", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 109 */         INativeMethodItem routine = new NativeRoutineChooserDialog(parent.getShell(), EditInstructionDialog.this.unit).open();
/* 110 */         if (routine != null) {
/* 111 */           EditInstructionDialog.this.setDynTargetWidget(routine);
/*     */         }
/*     */       }
/* 114 */     });
/* 115 */     UIUtil.createTightPushbox(c, "Clear", new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 118 */         EditInstructionDialog.this.setDynTargetWidget(null);
/*     */       }
/* 120 */     });
/* 121 */     this.widgetDynTarget = new Text(c, 2060);
/* 122 */     this.widgetDynTarget.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/* 124 */     loadInstruction(this.address);
/*     */     
/* 126 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   private boolean loadInstruction(long address) {
/* 130 */     this.widgetAddress.setText("");
/* 131 */     this.widgetLabel.setText("");
/* 132 */     this.widgetBytes.setText("");
/* 133 */     this.widgetDisas.setText("");
/* 134 */     this.widgetHintSPDelta.setText("");
/* 135 */     this.widgetHintProto.setText("");
/* 136 */     setDynTargetWidget(null);
/*     */     
/* 138 */     this.ii = null;
/* 139 */     INativeItem item = this.unit.getNativeItemAt(address);
/* 140 */     if (!(item instanceof INativeInstructionItem)) {
/* 141 */       return false;
/*     */     }
/*     */     
/* 144 */     this.ii = ((INativeInstructionItem)item);
/*     */     
/* 146 */     this.widgetAddress.setText(Strings.safe(this.ii.getAddress()));
/* 147 */     this.widgetLabel.setText(Strings.safe(this.ii.getLabel()));
/* 148 */     this.widgetBytes.setText(Formatter.formatBinaryLine(this.ii.getInstruction().getCode()));
/* 149 */     this.widgetDisas.setText(this.ii.getInstruction().format(Long.valueOf(this.ii.getMemoryAddress())));
/*     */     
/* 151 */     InstructionHints hints = this.ii.getHints(false);
/* 152 */     if (hints != null) {
/* 153 */       this.widgetHintSPDelta.setText(Strings.safe(hints.getStackPointerDelta()));
/* 154 */       this.widgetHintProto.setText(Strings.safe(hints.getCallsitePrototype()));
/*     */     }
/*     */     
/* 157 */     IBranchTarget target = getCurrentlyStoredResolvedTarget();
/* 158 */     if (target != null) {
/* 159 */       setDynTargetWidget(target.getRoutine());
/*     */     }
/*     */     
/* 162 */     return true;
/*     */   }
/*     */   
/*     */   private IBranchTarget getCurrentlyStoredResolvedTarget() {
/* 166 */     IBranchResolution reso = this.unit.getCodeModel().getDynamicBranchResolution(this.address);
/* 167 */     return reso.isEmpty() ? null : reso.getResolvedTarget();
/*     */   }
/*     */   
/*     */   private void setDynTargetWidget(INativeMethodItem routine) {
/* 171 */     if (routine == null) {
/* 172 */       this.widgetDynTarget.setText("");
/*     */     }
/*     */     else {
/* 175 */       this.widgetDynTarget.setText(routine.getName(true));
/*     */     }
/* 177 */     this.widgetDynTarget.setData("dynTargetItem", routine);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 182 */     this.confirmed = true;
/*     */     
/*     */ 
/* 185 */     String text = this.widgetHintSPDelta.getText().trim();
/* 186 */     if (text.isEmpty()) {
/* 187 */       if (this.ii.getHints(false) != null) {
/* 188 */         this.ii.getHints(true).setStackPointerDelta(null);
/*     */       }
/*     */     }
/*     */     else {
/*     */       try {
/* 193 */         int spdelta = Integer.parseInt(text);
/* 194 */         this.ii.getHints(true).setStackPointerDelta(Integer.valueOf(spdelta));
/*     */       }
/*     */       catch (NumberFormatException e) {
/* 197 */         UI.error("Cannot parse integer value for SP delta");
/* 198 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 203 */     text = this.widgetHintProto.getText().trim();
/* 204 */     if (text.isEmpty()) {
/* 205 */       if (this.ii.getHints(false) != null) {
/* 206 */         this.ii.getHints(true).setCallsitePrototype(null);
/*     */       }
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 212 */         IPrototypeItem proto = new TypeStringParser(this.unit.getTypeManager()).parsePrototype(text);
/* 213 */         this.ii.getHints(true).setCallsitePrototype(proto);
/*     */       }
/*     */       catch (TypeStringParseException e) {
/* 216 */         UI.error("Cannot parse prototype. The expected format is:\n\n<callingConvention> returnType(param1Type, param2Type, ...)");
/*     */         
/* 218 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 223 */     INativeMethodItem routine = (INativeMethodItem)this.widgetDynTarget.getData("dynTargetItem");
/* 224 */     if (routine == null) {
/* 225 */       IBranchTarget current = getCurrentlyStoredResolvedTarget();
/* 226 */       if (current != null) {
/* 227 */         this.unit.getCodeAnalyzer().unrecordDynamicBranchTarget(this.address, true, current);
/*     */       }
/*     */     }
/*     */     else {
/* 231 */       this.unit.getCodeAnalyzer().recordDynamicBranchTarget(this.address, true, new BranchTarget(routine), false);
/*     */     }
/*     */     
/* 234 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\EditInstructionDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */