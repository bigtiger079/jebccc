/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignaturePackageSetupInformation
/*    */ {
/*    */   String name;
/*    */   
/*    */ 
/*    */   String author;
/*    */   
/*    */   String description;
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 17 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getAuthor() {
/* 21 */     return this.author;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 25 */     return this.description;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\SignaturePackageSetupInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */