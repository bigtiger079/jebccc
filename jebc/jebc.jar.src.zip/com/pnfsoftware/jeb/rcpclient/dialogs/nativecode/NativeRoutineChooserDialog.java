/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*    */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeMethodItem;
/*    */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.NativeRoutinesView;
/*    */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*    */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeRoutineChooserDialog
/*    */   extends JebDialog
/*    */ {
/*    */   private INativeCodeUnit<?> unit;
/*    */   private NativeRoutinesView v;
/*    */   private INativeMethodItem selectedRoutine;
/*    */   
/*    */   public NativeRoutineChooserDialog(Shell parent, INativeCodeUnit<?> unit)
/*    */   {
/* 35 */     super(parent, "Choose a routine", true, false);
/* 36 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*    */     
/* 38 */     if (unit == null) {
/* 39 */       throw new NullPointerException();
/*    */     }
/* 41 */     this.unit = unit;
/*    */   }
/*    */   
/*    */   public INativeMethodItem open()
/*    */   {
/* 46 */     super.open();
/* 47 */     return this.selectedRoutine;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 52 */     parent.setLayout(new GridLayout(1, false));
/*    */     
/* 54 */     this.v = new NativeRoutinesView(parent, 0, null, this.unit, null, 3);
/* 55 */     this.v.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*    */     
/*    */ 
/* 58 */     this.v.getViewer().addDoubleClickListener(new IDoubleClickListener()
/*    */     {
/*    */       public void doubleClick(DoubleClickEvent e)
/*    */       {
/* 62 */         NativeRoutineChooserDialog.this.onConfirm();
/*    */       }
/*    */       
/* 65 */     });
/* 66 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 71 */     this.selectedRoutine = this.v.getSelectedRow();
/* 72 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\NativeRoutineChooserDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */