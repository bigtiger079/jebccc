/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodSetupInformation
/*    */ {
/*    */   Boolean routineNonReturning;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   Integer routineDataSPDeltaOnReturn;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Boolean getRoutineNonReturning()
/*    */   {
/* 23 */     return this.routineNonReturning;
/*    */   }
/*    */   
/*    */   public Integer getRoutineDataSPDeltaOnReturn() {
/* 27 */     return this.routineDataSPDeltaOnReturn;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 32 */     return String.format("routineNonReturning=%s,routineDataSPDeltaOnReturn=%s", new Object[] { this.routineNonReturning, this.routineDataSPDeltaOnReturn });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\MethodSetupInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */