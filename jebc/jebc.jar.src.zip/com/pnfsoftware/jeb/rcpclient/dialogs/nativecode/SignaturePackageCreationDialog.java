/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.processor.IProcessor;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.sig.NativeSignatureDBManager;
/*     */ import com.pnfsoftware.jeb.core.units.codeobject.ProcessorType;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.InputField;
/*     */ import java.io.File;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.MessageBox;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignaturePackageCreationDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private INativeCodeUnit<?> unit;
/*     */   private boolean confirmed;
/*     */   private SignaturePackageSetupInformation info;
/*     */   private InputField packageName;
/*     */   private InputField packageAuthor;
/*     */   private InputField packageDescription;
/*     */   
/*     */   public SignaturePackageCreationDialog(Shell parent, INativeCodeUnit<?> unit)
/*     */   {
/*  37 */     super(parent, "Create Signature Package", true, false);
/*  38 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public SignaturePackageSetupInformation open()
/*     */   {
/*  43 */     super.open();
/*  44 */     if (!this.confirmed) {
/*  45 */       return null;
/*     */     }
/*  47 */     return this.info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void onConfirm()
/*     */   {
/*  54 */     if (this.packageName.getText().isEmpty()) {
/*  55 */       UI.error("Package name cannot be empty");
/*  56 */       return;
/*     */     }
/*  58 */     NativeSignatureDBManager nsdbManager = this.unit.getSignatureManager();
/*  59 */     if (nsdbManager.getUserCreatedPackageFolder() == null)
/*     */     {
/*  61 */       UI.error(String.format("Folder for user-created signatures has not been set. Please create the folder 'siglibs%s%s' in your JEB client folder (and re-start the client).", new Object[] { File.separator, "custom" }));
/*     */       
/*     */ 
/*  64 */       return;
/*     */     }
/*  66 */     File packageFile = new File(nsdbManager.getUserCreatedPackageFolder() + File.separator + this.packageName.getText() + ".siglib");
/*     */     
/*  68 */     if (packageFile.exists()) {
/*  69 */       MessageBox mb = new MessageBox(this.shell, 200);
/*  70 */       mb.setText(S.s(821));
/*  71 */       mb.setMessage("Package already exists, would you like to continue and remove the previous package?");
/*  72 */       int r = mb.open();
/*  73 */       if (r != 64) {
/*  74 */         return;
/*     */       }
/*  76 */       packageFile.delete();
/*     */     }
/*     */     
/*  79 */     this.info = new SignaturePackageSetupInformation();
/*  80 */     this.info.name = this.packageName.getText();
/*  81 */     this.info.author = this.packageAuthor.getText();
/*  82 */     this.info.description = this.packageDescription.getText();
/*     */     
/*  84 */     this.confirmed = true;
/*  85 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  90 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  92 */     new Label(parent, 0).setText("Name: ");
/*  93 */     this.packageName = new InputField(parent, "(cannot be empty)", null, 30);
/*     */     
/*  95 */     new Label(parent, 0).setText("Author: ");
/*  96 */     this.packageAuthor = new InputField(parent, null, Licensing.user_name, 30);
/*     */     
/*  98 */     new Label(parent, 0).setText("Description: ");
/*  99 */     this.packageDescription = new InputField(parent, null, null, 40);
/*     */     
/*     */ 
/* 102 */     new Label(parent, 0).setText("Architecture: ");
/* 103 */     Text packageProcMode = new Text(parent, 2052);
/* 104 */     packageProcMode.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 105 */     packageProcMode.setText(this.unit.getProcessor().getType().toString());
/* 106 */     packageProcMode.setEditable(false);
/*     */     
/* 108 */     UIUtil.setStandardLayout(parent, 1);
/* 109 */     new Label(parent, 0)
/* 110 */       .setText(String.format("Note: package will be created under 'siglibs%s%s' in JEB client folder", new Object[] { File.separator, "custom" }));
/*     */     
/*     */ 
/* 113 */     createOkayCancelButtons(parent);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\SignaturePackageCreationDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */