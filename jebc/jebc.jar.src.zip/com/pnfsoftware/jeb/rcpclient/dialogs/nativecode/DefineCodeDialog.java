/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeItem;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import org.eclipse.swt.events.FocusAdapter;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefineCodeDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private long address;
/*     */   private INativeCodeUnit<?> unit;
/*     */   private boolean confirmed;
/*  43 */   private CodeSetupInformation info = new CodeSetupInformation(-1L);
/*     */   private Label widgetInfo;
/*     */   private Text widgetAddress;
/*     */   private Text widgetProcMode;
/*     */   private Text widgetMaxInsnCount;
/*     */   private Button widgetOk;
/*     */   
/*     */   public DefineCodeDialog(Shell parent, long address, INativeCodeUnit<?> unit)
/*     */   {
/*  52 */     super(parent, "Define code", true, true);
/*  53 */     this.scrolledContainer = true;
/*     */     
/*  55 */     this.address = address;
/*  56 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public void setDefaults(CodeSetupInformation info) {
/*  60 */     if (info == null) {
/*  61 */       throw new IllegalArgumentException();
/*     */     }
/*  63 */     this.info = info;
/*  64 */     this.address = info.getAddress();
/*     */   }
/*     */   
/*     */   public CodeSetupInformation open()
/*     */   {
/*  69 */     super.open();
/*  70 */     if (!this.confirmed) {
/*  71 */       return null;
/*     */     }
/*  73 */     return this.info;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  78 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  80 */     this.widgetInfo = new Label(parent, 0);
/*  81 */     this.widgetInfo.setText("N/A");
/*  82 */     this.widgetInfo.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*     */     
/*  84 */     new Label(parent, 0).setText(S.s(52) + ": ");
/*  85 */     this.widgetAddress = new Text(parent, 2052);
/*  86 */     this.widgetAddress.setLayoutData(UIUtil.createGridDataForText(this.widgetAddress, 16));
/*  87 */     this.widgetAddress.setText(String.format("%Xh", new Object[] { Long.valueOf(this.address) }));
/*  88 */     this.widgetAddress.selectAll();
/*  89 */     this.widgetAddress.setFocus();
/*     */     
/*     */ 
/*     */ 
/*  93 */     Group g1 = new Group(parent, 0);
/*  94 */     g1.setText("Mode");
/*  95 */     g1.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  96 */     g1.setLayout(new GridLayout(2, false));
/*     */     
/*  98 */     createHelpLabel(g1, "0: \"default\" mode; -1: \"current\" mode; else, use 16/32/64/etc.");
/*  99 */     new Label(g1, 0).setText(S.s(723) + ": ");
/* 100 */     this.widgetProcMode = new Text(g1, 2052);
/* 101 */     GridData textGridData = UIUtil.createGridDataFillHorizontally();
/*     */     
/* 103 */     textGridData.minimumWidth = 30;
/* 104 */     this.widgetProcMode.setLayoutData(textGridData);
/* 105 */     this.widgetProcMode.setText("" + this.info.getProcessorMode());
/* 106 */     this.widgetProcMode.selectAll();
/*     */     
/* 108 */     Group g2 = new Group(parent, 0);
/* 109 */     g2.setText("Count");
/* 110 */     g2.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/* 111 */     g2.setLayout(new GridLayout(2, false));
/*     */     
/* 113 */     createHelpLabel(g2, "Use -1 to disassemble as many instructions as possible.");
/* 114 */     new Label(g2, 0).setText("Maximum instruction count: ");
/* 115 */     this.widgetMaxInsnCount = new Text(g2, 2052);
/* 116 */     this.widgetMaxInsnCount.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 117 */     this.widgetMaxInsnCount.setText("" + this.info.getMaxInstructionCount());
/* 118 */     this.widgetMaxInsnCount.selectAll();
/*     */     
/* 120 */     createOkayCancelButtons(parent);
/* 121 */     this.widgetOk = getButtonByStyle(32);
/*     */     
/* 123 */     this.widgetAddress.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/* 126 */         DefineCodeDialog.this.update();
/*     */       }
/* 128 */     });
/* 129 */     this.widgetAddress.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 132 */         DefineCodeDialog.this.update();
/*     */       }
/*     */       
/* 135 */     });
/* 136 */     update();
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 141 */     this.confirmed = true;
/* 142 */     this.info.address = getSelectedAddress();
/* 143 */     this.info.procMode = Conversion.stringToInt(this.widgetProcMode.getText(), -1);
/* 144 */     this.info.maxInsnCount = Conversion.stringToInt(this.widgetMaxInsnCount.getText(), -1);
/* 145 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   private void update() {
/* 149 */     long a = getSelectedAddress();
/* 150 */     this.widgetOk.setEnabled(a >= 0L);
/*     */     String info;
/*     */     String info;
/* 153 */     if (a < 0L) {
/* 154 */       info = "Invalid address";
/*     */     } else {
/*     */       String info;
/* 157 */       if (this.unit == null) {
/* 158 */         info = String.format("No native unit was provided, cannot retrieve information about location %Xh.", new Object[] { Long.valueOf(a) });
/*     */       }
/*     */       else {
/* 161 */         INativeItem item = this.unit.getNativeItemOver(a);
/* 162 */         String info; if (item != null) {
/* 163 */           info = String.format("Beware, an item already occupies address %Xh.", new Object[] { Long.valueOf(a) });
/*     */         }
/*     */         else {
/* 166 */           info = String.format("Will attempt to disassemble code at address %Xh", new Object[] { Long.valueOf(a) });
/*     */         }
/*     */       }
/*     */     }
/* 170 */     this.widgetInfo.setText(info);
/*     */   }
/*     */   
/*     */   private long getSelectedAddress() {
/* 174 */     return Conversion.stringToLong(this.widgetAddress.getText(), -1L);
/*     */   }
/*     */   
/*     */   void createHelpLabel(Composite parent, String text) {
/* 178 */     Label label = new Label(parent, 0);
/* 179 */     label.setText(text);
/* 180 */     label.setLayoutData(UIUtil.createGridDataSpanHorizontally(2));
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\DefineCodeDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */