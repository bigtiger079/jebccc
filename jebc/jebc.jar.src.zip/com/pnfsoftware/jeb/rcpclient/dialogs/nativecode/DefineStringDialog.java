/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.INativeCodeUnit;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.items.INativeItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.type.StringType;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.Conversion;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.events.FocusAdapter;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefineStringDialog
/*     */   extends JebDialog
/*     */ {
/*  41 */   private static final ILogger logger = GlobalLog.getLogger(DefineStringDialog.class);
/*     */   
/*     */   private long address;
/*     */   
/*     */   private INativeCodeUnit<?> unit;
/*     */   private boolean confirmed;
/*  47 */   private StringSetupInformation info = new StringSetupInformation();
/*     */   
/*     */   private Label widgetInfo;
/*     */   
/*     */   private Text widgetAddress;
/*     */   
/*     */   private Text widgetMinCount;
/*     */   
/*     */   private Text widgetMaxCount;
/*     */   
/*     */   private Combo widgetStringTypes;
/*     */   
/*     */   private Button widgetOk;
/*     */   
/*     */   public DefineStringDialog(Shell parent, long address, INativeCodeUnit<?> unit)
/*     */   {
/*  63 */     super(parent, "Define String", true, true);
/*  64 */     this.scrolledContainer = true;
/*     */     
/*  66 */     this.address = address;
/*  67 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public StringSetupInformation open()
/*     */   {
/*  72 */     super.open();
/*  73 */     if (!this.confirmed) {
/*  74 */       return null;
/*     */     }
/*  76 */     return this.info;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  81 */     UIUtil.setStandardLayout(parent, 4);
/*     */     
/*  83 */     this.widgetInfo = new Label(parent, 0);
/*  84 */     this.widgetInfo.setText("N/A");
/*  85 */     this.widgetInfo.setLayoutData(UIUtil.createGridDataSpanHorizontally(4, true, false));
/*     */     
/*  87 */     Group grp = new Group(parent, 0);
/*  88 */     grp.setText("Properties");
/*  89 */     UIUtil.setStandardLayout(grp, 4);
/*  90 */     grp.setLayoutData(UIUtil.createGridDataSpanHorizontally(4, true, false));
/*     */     
/*  92 */     new Label(grp, 0).setText(S.s(52) + ": ");
/*  93 */     this.widgetAddress = new Text(grp, 2052);
/*  94 */     this.widgetAddress.setLayoutData(UIUtil.createGridDataForText(this.widgetAddress, 16));
/*  95 */     this.widgetAddress.setText(String.format("%Xh", new Object[] { Long.valueOf(this.address) }));
/*  96 */     this.widgetAddress.selectAll();
/*  97 */     this.widgetAddress.setFocus();
/*     */     
/*  99 */     new Label(grp, 0).setText("String type: ");
/* 100 */     this.widgetStringTypes = new Combo(grp, 12);
/* 101 */     GridData layoutData = UIUtil.createGridDataFillHorizontally();
/* 102 */     this.widgetStringTypes.setLayoutData(layoutData);
/* 103 */     this.widgetStringTypes.add("(Automatic)");
/* 104 */     for (StringType st : StringType.values()) {
/* 105 */       this.widgetStringTypes.add(st.toString());
/*     */     }
/* 107 */     this.widgetStringTypes.select(0);
/*     */     
/* 109 */     new Label(grp, 0).setText("Min chars: ");
/* 110 */     this.widgetMinCount = new Text(grp, 2052);
/* 111 */     this.widgetMinCount.setLayoutData(UIUtil.createGridDataForText(this.widgetAddress, 8));
/* 112 */     this.widgetMinCount.setText("");
/* 113 */     this.widgetMinCount.selectAll();
/*     */     
/* 115 */     new Label(grp, 0).setText("Max chars: ");
/* 116 */     this.widgetMaxCount = new Text(grp, 2052);
/* 117 */     this.widgetMaxCount.setLayoutData(UIUtil.createGridDataForText(this.widgetAddress, 8));
/* 118 */     this.widgetMaxCount.setText(String.format("%X", new Object[] { Long.valueOf(this.address) }));
/* 119 */     this.widgetMaxCount.setText("");
/* 120 */     this.widgetMaxCount.selectAll();
/*     */     
/* 122 */     createOkayCancelButtons(parent);
/* 123 */     this.widgetOk = getButtonByStyle(32);
/*     */     
/* 125 */     this.widgetAddress.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/* 128 */         DefineStringDialog.this.update();
/*     */       }
/* 130 */     });
/* 131 */     this.widgetAddress.addModifyListener(new ModifyListener()
/*     */     {
/*     */       public void modifyText(ModifyEvent e) {
/* 134 */         DefineStringDialog.this.update();
/*     */       }
/*     */       
/* 137 */     });
/* 138 */     update();
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 143 */     this.info = new StringSetupInformation();
/* 144 */     this.info.address = getSelectedAddress();
/* 145 */     this.info.addressMax = -1L;
/* 146 */     this.info.minChars = Conversion.stringToInt(this.widgetMinCount.getText(), -1);
/* 147 */     this.info.maxChars = Conversion.stringToInt(this.widgetMaxCount.getText(), -1);
/* 148 */     this.info.stringType = getSelectedStringType();
/* 149 */     this.confirmed = true;
/* 150 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   private void update() {
/* 154 */     long a = getSelectedAddress();
/* 155 */     this.widgetOk.setEnabled(a >= 0L);
/*     */     String info;
/*     */     String info;
/* 158 */     if (a < 0L) {
/* 159 */       info = "Invalid address";
/*     */     } else {
/*     */       String info;
/* 162 */       if (this.unit == null) {
/* 163 */         info = String.format("No native unit was provided, cannot retrieve information about location %Xh.", new Object[] { Long.valueOf(a) });
/*     */       }
/*     */       else {
/* 166 */         INativeItem item = this.unit.getNativeItemOver(a);
/* 167 */         String info; if (item != null) {
/* 168 */           info = String.format("Beware, an item already occupies address %Xh.", new Object[] { Long.valueOf(a) });
/*     */         }
/*     */         else {
/* 171 */           info = String.format("Will attempt to define string at address %Xh", new Object[] { Long.valueOf(a) });
/*     */         }
/*     */       }
/*     */     }
/* 175 */     this.widgetInfo.setText(info);
/*     */   }
/*     */   
/*     */   private long getSelectedAddress() {
/* 179 */     return Conversion.stringToLong(this.widgetAddress.getText(), -1L);
/*     */   }
/*     */   
/*     */   private StringType getSelectedStringType() {
/* 183 */     int index = this.widgetStringTypes.getSelectionIndex();
/* 184 */     if ((index <= 0) || (index > StringType.values().length)) {
/* 185 */       return null;
/*     */     }
/*     */     
/* 188 */     return StringType.values()[(index - 1)];
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\DefineStringDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */