/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodeSetupInformation
/*    */ {
/*    */   long address;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int procMode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int maxInsnCount;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CodeSetupInformation(long address)
/*    */   {
/* 26 */     this(address, 0, 100);
/*    */   }
/*    */   
/*    */   public CodeSetupInformation(long address, int procMode, int maxInsnCount) {
/* 30 */     this.address = address;
/* 31 */     this.procMode = procMode;
/* 32 */     this.maxInsnCount = maxInsnCount;
/*    */   }
/*    */   
/*    */   public long getAddress() {
/* 36 */     return this.address;
/*    */   }
/*    */   
/*    */   public int getProcessorMode() {
/* 40 */     return this.procMode;
/*    */   }
/*    */   
/*    */   public int getMaxInstructionCount() {
/* 44 */     return this.maxInsnCount;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\CodeSetupInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */