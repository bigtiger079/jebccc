package com.pnfsoftware.jeb.rcpclient.dialogs.nativecode;

import com.pnfsoftware.jeb.core.units.code.asm.type.StringType;

public class StringSetupInformation
{
  public long address;
  public long addressMax;
  public StringType stringType;
  public int minChars;
  public int maxChars;
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\nativecode\StringSetupInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */