/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.HistoryAssistedTextField;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.graphics.Font;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.layout.RowLayout;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Group;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JumpToDialog
/*    */   extends JebDialog
/*    */ {
/* 33 */   private static final ILogger logger = GlobalLog.getLogger(JumpToDialog.class);
/*    */   private TextHistory textHistory;
/*    */   private HistoryAssistedTextField text;
/*    */   private String input;
/*    */   private Font font;
/*    */   private String initialValue;
/*    */   protected Button btnOk;
/*    */   
/*    */   public JumpToDialog(Shell parent, TextHistory textHistory)
/*    */   {
/* 43 */     super(parent, S.s(420), true, true, null);
/* 44 */     this.scrolledContainer = true;
/*    */     
/* 46 */     this.textHistory = textHistory;
/*    */   }
/*    */   
/*    */   public void setFont(Font font) {
/* 50 */     this.font = font;
/*    */   }
/*    */   
/*    */   public void setInitialValue(String initialValue) {
/* 54 */     this.initialValue = initialValue;
/*    */   }
/*    */   
/*    */   public String open()
/*    */   {
/* 59 */     super.open();
/* 60 */     return this.input;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 65 */     parent.setLayout(new GridLayout(1, false));
/*    */     
/*    */ 
/* 68 */     Group c0 = new Group(parent, 0);
/* 69 */     c0.setText("Jump target");
/* 70 */     c0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 71 */     c0.setLayout(new GridLayout(2, false));
/*    */     
/* 73 */     this.text = new HistoryAssistedTextField(c0, S.s(52) + ":", this.textHistory, true);
/* 74 */     this.text.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*    */     
/* 76 */     this.text.getWidget().setFont(this.font);
/* 77 */     if (this.initialValue != null) {
/* 78 */       this.text.getWidget().setText(this.initialValue);
/* 79 */       this.text.getWidget().selectAll();
/*    */     }
/*    */     
/* 82 */     UIUtil.disableTabOutput(this.text);
/*    */     
/*    */ 
/* 85 */     Composite c1 = new Composite(parent, 0);
/* 86 */     c1.setLayout(new RowLayout(256));
/*    */     
/* 88 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 93 */     this.text.confirm();
/* 94 */     this.input = this.text.getText();
/* 95 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\JumpToDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */