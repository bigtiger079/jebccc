/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.output.tree.ICodeNode;
/*     */ import com.pnfsoftware.jeb.core.units.code.ICodeItem;
/*     */ import com.pnfsoftware.jeb.core.units.code.ICodeUnit;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.code.CodeHierarchyView;
/*     */ import org.eclipse.jface.viewers.DoubleClickEvent;
/*     */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeHierarchyDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private RcpClientContext context;
/*     */   private ICodeUnit unit;
/*     */   private ICodeNode baseNode;
/*     */   private ICodeNode baseNodeUp;
/*     */   private CodeHierarchyView v;
/*     */   private CodeHierarchyView v2;
/*     */   private String selectedAddress;
/*     */   
/*     */   public CodeHierarchyDialog(Shell parent, ICodeUnit unit, ICodeNode baseNode, ICodeNode baseNodeUp, RcpClientContext context)
/*     */   {
/*  53 */     super(parent, S.s(579), true, false);
/*     */     
/*  55 */     this.unit = unit;
/*  56 */     this.baseNode = baseNode;
/*  57 */     this.baseNodeUp = baseNodeUp;
/*  58 */     this.context = context;
/*  59 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/*  64 */     super.open();
/*  65 */     return this.selectedAddress;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  70 */     UIUtil.setStandardLayout(parent);
/*     */     
/*  72 */     boolean displayLabels = (this.baseNode != null) && (this.baseNodeUp != null);
/*     */     
/*  74 */     this.v = setup(parent, true, this.baseNode, displayLabels ? "Descending Hierarchy" : null);
/*  75 */     if (this.baseNodeUp != null) {
/*  76 */       this.v2 = setup(parent, false, this.baseNodeUp, displayLabels ? "Ascending Hierarchy" : null);
/*     */     }
/*     */     
/*     */ 
/*  80 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   private CodeHierarchyView setup(Composite parent, boolean down, ICodeNode node, String label) {
/*  84 */     if (label != null) {
/*  85 */       UIUtil.createWrappedLabelInGridLayout(parent, 0, label, 1);
/*     */     }
/*  87 */     CodeHierarchyView v = new CodeHierarchyView(parent, 0, this.context, this.unit, node, 0, 0, false);
/*  88 */     GridData data = UIUtil.createGridDataSpanHorizontally(1, true, true);
/*  89 */     data.minimumHeight = 200;
/*  90 */     v.setLayoutData(data);
/*  91 */     v.getViewer().addDoubleClickListener(new IDoubleClickListener()
/*     */     {
/*     */       public void doubleClick(DoubleClickEvent e) {
/*  94 */         CodeHierarchyDialog.this.onConfirm();
/*     */       }
/*     */       
/*  97 */     });
/*  98 */     RcpClientContext.wrapWidget(this.context, v, "dlgCodehier" + (down ? "Down" : "Up"));
/*  99 */     return v;
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 104 */     setSelectedAddress();
/* 105 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   private void setSelectedAddress() {
/* 109 */     CodeHierarchyView widget = this.v;
/* 110 */     if ((this.v2 != null) && (this.v2.isFocusControl())) {
/* 111 */       widget = this.v2;
/*     */     }
/*     */     
/* 114 */     ICodeNode node = widget.getSelectedNode();
/* 115 */     if ((node != null) && 
/* 116 */       ((node.getObject() instanceof ICodeItem))) {
/* 117 */       String address = node.getObject().getAddress();
/* 118 */       this.selectedAddress = address;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\CodeHierarchyDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */