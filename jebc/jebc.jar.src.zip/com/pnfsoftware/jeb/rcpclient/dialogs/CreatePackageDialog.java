/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.HistoryAssistedTextField;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreatePackageDialog
/*    */   extends JebDialog
/*    */ {
/* 33 */   private static final ILogger logger = GlobalLog.getLogger(CreatePackageDialog.class);
/*    */   private TextHistory textHistory;
/*    */   private HistoryAssistedTextField text;
/*    */   private String input;
/*    */   String description;
/*    */   private String initialValue;
/*    */   protected Button btn_ok;
/*    */   
/*    */   public CreatePackageDialog(Shell parent, TextHistory textHistory)
/*    */   {
/* 43 */     super(parent, S.s(471), true, true);
/* 44 */     this.scrolledContainer = true;
/*    */     
/* 46 */     this.textHistory = textHistory;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 50 */     this.description = description;
/*    */   }
/*    */   
/*    */   public void setInitialValue(String initialValue) {
/* 54 */     this.initialValue = initialValue;
/*    */   }
/*    */   
/*    */   public String open()
/*    */   {
/* 59 */     super.open();
/* 60 */     return this.input;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 65 */     UIUtil.setStandardLayout(parent);
/*    */     
/* 67 */     Label hint = new Label(parent, 64);
/* 68 */     hint.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 69 */     hint.setText(this.description != null ? this.description : S.s(391));
/*    */     
/* 71 */     this.text = new HistoryAssistedTextField(parent, S.s(591) + ":", this.textHistory, true);
/* 72 */     GridData griddata = UIUtil.createGridDataForText(this.text, 50, 0, false);
/* 73 */     griddata.grabExcessHorizontalSpace = true;
/* 74 */     griddata.horizontalAlignment = 4;
/* 75 */     this.text.setLayoutData(griddata);
/*    */     
/* 77 */     if (this.initialValue != null) {
/* 78 */       this.text.getWidget().setText(this.initialValue);
/* 79 */       this.text.getWidget().selectAll();
/*    */     }
/*    */     
/* 82 */     UIUtil.disableTabOutput(this.text);
/*    */     
/* 84 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 89 */     this.text.confirm();
/* 90 */     this.input = this.text.getText();
/* 91 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\CreatePackageDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */