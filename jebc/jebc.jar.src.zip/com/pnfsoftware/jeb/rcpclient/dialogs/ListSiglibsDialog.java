/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.sig.NativeSignatureDBManager;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.sig.NativeSignaturePackageEntry;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.sig.NativeSignaturePackageMetadata;
/*     */ import com.pnfsoftware.jeb.core.units.codeobject.ProcessorType;
/*     */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilteredTableView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ITableEventListener;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCellLabelProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCheckStateProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.IFilteredTableContentProvider;
/*     */ import com.pnfsoftware.jeb.util.collect.ArrayUtil;
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListSiglibsDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private IGraphicalTaskExecutor executor;
/*     */   private NativeSignatureDBManager dbman;
/*     */   private FilteredTableViewer ftv;
/*     */   
/*     */   public ListSiglibsDialog(Shell parent, IGraphicalTaskExecutor executor)
/*     */   {
/*  43 */     super(parent, "Signature libraries", true, true, "siglibsDialog");
/*  44 */     setVisualBounds(-1, 90, -1, -1);
/*  45 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */     
/*  47 */     this.executor = executor;
/*     */   }
/*     */   
/*     */   public void setInput(NativeSignatureDBManager dbman) {
/*  51 */     this.dbman = dbman;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  56 */     return super.open();
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  61 */     UIUtil.setStandardLayout(parent);
/*     */     
/*     */ 
/*  64 */     FilteredTableView ft = new FilteredTableView(parent, 32, new String[] { "Loaded", "Processor", S.s(591), S.s(268), S.s(86), S.s(341) });
/*  65 */     GridData data = UIUtil.createGridDataFill(true, true);
/*  66 */     data.minimumHeight = 200;
/*  67 */     ft.setLayoutData(data);
/*     */     
/*  69 */     this.ftv = new FilteredTableViewer(ft);
/*  70 */     ContentProviderListener p = new ContentProviderListener();
/*  71 */     this.ftv.setContentProvider(p);
/*  72 */     this.ftv.setCheckStateProvider(new DefaultCheckStateProvider(p));
/*  73 */     this.ftv.setLabelProvider(new DefaultCellLabelProvider(p));
/*  74 */     ft.addTableEventListener(p);
/*  75 */     this.ftv.setInput(this.dbman);
/*     */     
/*  77 */     createOkayButton(parent);
/*     */     
/*  79 */     if (getStandardWidgetManager() != null)
/*  80 */       getStandardWidgetManager().wrapWidget(ft, "listSiglibs");
/*     */   }
/*     */   
/*     */   class ContentProviderListener implements ITableEventListener, IFilteredTableContentProvider {
/*     */     private NativeSignatureDBManager dbman0;
/*     */     
/*     */     ContentProviderListener() {}
/*     */     
/*     */     public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
/*  89 */       this.dbman0 = ((NativeSignatureDBManager)newInput);
/*     */     }
/*     */     
/*     */ 
/*     */     public void dispose() {}
/*     */     
/*     */ 
/*     */     public Object[] getElements(Object inputElement)
/*     */     {
/*  98 */       return this.dbman0.getAvailablePackages().toArray();
/*     */     }
/*     */     
/*     */     public Object[] getRowElements(Object row)
/*     */     {
/* 103 */       if ((row instanceof NativeSignaturePackageEntry)) {
/* 104 */         NativeSignaturePackageEntry e = (NativeSignaturePackageEntry)row;
/*     */         
/* 106 */         String loaded = e.isLoadedInMemory() ? S.s(828) : S.s(594);
/*     */         
/* 108 */         NativeSignaturePackageMetadata hdr = e.getMetadata();
/* 109 */         String processorType = hdr.getTargetProcessorType().toString();
/* 110 */         String name = hdr.getName();
/* 111 */         String description = hdr.getDescription();
/* 112 */         String author = hdr.getAuthor();
/*     */         
/* 114 */         String filepath = e.getFile().getPath();
/*     */         
/* 116 */         return new Object[] { loaded, processorType, name, description, author, filepath };
/*     */       }
/* 118 */       return ArrayUtil.NO_OBJECT;
/*     */     }
/*     */     
/*     */     public boolean isChecked(Object row)
/*     */     {
/* 123 */       if ((row instanceof NativeSignaturePackageEntry)) {
/* 124 */         NativeSignaturePackageEntry e = (NativeSignaturePackageEntry)row;
/* 125 */         return e.isLoadedInMemory();
/*     */       }
/* 127 */       return false;
/*     */     }
/*     */     
/*     */     public void onTableEvent(Object row, boolean isSelected, boolean isChecked)
/*     */     {
/* 132 */       if ((row instanceof NativeSignaturePackageEntry)) {
/* 133 */         final NativeSignaturePackageEntry e = (NativeSignaturePackageEntry)row;
/* 134 */         boolean isLoaded = e.isLoadedInMemory();
/* 135 */         if ((isChecked) && (!isLoaded)) {
/* 136 */           if (ListSiglibsDialog.this.executor == null) {
/* 137 */             this.dbman0.loadPackage(e, true);
/*     */           }
/*     */           else {
/* 140 */             ListSiglibsDialog.this.executor.executeTask("Loading signature library...", new Runnable()
/*     */             {
/*     */ 
/*     */               public void run()
/*     */               {
/* 145 */                 if (!ListSiglibsDialog.ContentProviderListener.this.dbman0.loadPackage(e, true)) {
/* 146 */                   UI.error("Package could not be loaded, no suitable analyzed files were found.");
/*     */                 }
/*     */               }
/*     */             });
/*     */           }
/*     */         }
/* 152 */         else if ((!isChecked) && (isLoaded)) {
/* 153 */           UI.error("Signature libraries cannot be unloaded.");
/*     */         }
/* 155 */         ListSiglibsDialog.this.ftv.refresh();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ListSiglibsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */