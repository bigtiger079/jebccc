/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientProperties;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.options.OptionsChanges;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.options.OptionsChanges.Changes;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.options.OptionsSimpleViewDevelopment;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.options.OptionsSimpleViewGeneral;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.options.OptionsTreeView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.tab.TabFolderView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.tab.TabFolderView.Entry;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.BrowserUtil;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionsDialog
/*     */   extends JebDialog
/*     */ {
/*  42 */   private static final String GENERAL = S.s(361);
/*  43 */   private static final String DEV = S.s(271);
/*     */   
/*     */   public static final String CLIENT = "Client";
/*     */   
/*     */   public static final String ENGINES = "Engines";
/*     */   public static final String PROJECT_SPECIFIC = "Project-specific";
/*  49 */   private static final String[] advancedTabs = { "Client", "Engines", "Project-specific" };
/*  50 */   private static final String[] simpleTabs = { GENERAL, DEV };
/*     */   
/*     */   private RcpClientProperties clientProperties;
/*     */   
/*     */   private IPropertyManager clientPM;
/*     */   
/*     */   private IPropertyManager corePM;
/*     */   private IPropertyManager prjPM;
/*     */   private boolean blockModeChange;
/*     */   private boolean lazyInit;
/*     */   private boolean expandOnFiltering;
/*  61 */   private OptionsChanges changes = new OptionsChanges();
/*  62 */   private boolean advancedOptions = false;
/*  63 */   private boolean saveChanges = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TabFolderView tabman;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OptionsDialog(Shell parent, RcpClientProperties clientProperties, IPropertyManager clientPM, IPropertyManager corePM, IPropertyManager prjPM)
/*     */   {
/*  78 */     super(parent, S.s(616), true, true);
/*  79 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */     
/*  81 */     this.clientProperties = clientProperties;
/*     */     
/*  83 */     if ((clientPM == null) && (corePM == null) && (prjPM == null)) {
/*  84 */       throw new IllegalArgumentException("Please provide at least one property manager.");
/*     */     }
/*  86 */     this.clientPM = clientPM;
/*  87 */     this.corePM = corePM;
/*  88 */     this.prjPM = prjPM;
/*     */     
/*  90 */     boolean advanced = false;
/*  91 */     if (clientProperties != null) {
/*  92 */       advanced = clientProperties.getOptionsDialogAdvancedMode();
/*     */     }
/*  94 */     if ((clientPM == null) || (corePM == null)) {
/*  95 */       advanced = true;
/*  96 */       this.blockModeChange = true;
/*     */     }
/*  98 */     setMode(advanced);
/*     */   }
/*     */   
/*     */   public void setLazyInit(boolean lazyInit) {
/* 102 */     this.lazyInit = lazyInit;
/*     */   }
/*     */   
/*     */   public boolean isLazyInit() {
/* 106 */     return this.lazyInit;
/*     */   }
/*     */   
/*     */   public void setExpandOnFiltering(boolean expandOnFiltering) {
/* 110 */     this.expandOnFiltering = expandOnFiltering;
/*     */   }
/*     */   
/*     */   public boolean isExpandOnFiltering() {
/* 114 */     return this.expandOnFiltering;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean open()
/*     */   {
/* 122 */     super.open();
/* 123 */     if (!this.saveChanges) {
/* 124 */       return Boolean.valueOf(false);
/*     */     }
/* 126 */     OptionsChanges.Changes engChanges = this.changes.get("Engines");
/* 127 */     if (engChanges == null)
/*     */     {
/* 129 */       return Boolean.valueOf(false);
/*     */     }
/* 131 */     return Boolean.valueOf(engChanges.hasChanges());
/*     */   }
/*     */   
/*     */ 
/*     */   protected void createContents(Composite parent)
/*     */   {
/* 137 */     UIUtil.setStandardLayout(parent, 4);
/*     */     
/* 139 */     this.shell.setMinimumSize(600, 500);
/*     */     
/*     */ 
/* 142 */     this.tabman = new TabFolderView(parent, 2048, true, this.lazyInit);
/* 143 */     this.tabman.setLayoutData(UIUtil.createGridDataSpanHorizontally(4, true, true));
/*     */     
/*     */ 
/* 146 */     CTabFolder folder = this.tabman.getContainer();
/* 147 */     if (this.clientPM != null) {
/* 148 */       this.changes.addPropertyManager("Client", this.clientPM);
/* 149 */       this.tabman.addEntry("Client", OptionsTreeView.build(folder, this.clientPM, this.changes.get("Client"), this.expandOnFiltering), this.advancedOptions);
/*     */     }
/* 151 */     if (this.corePM != null) {
/* 152 */       this.changes.addPropertyManager("Engines", this.corePM);
/* 153 */       this.tabman.addEntry("Engines", OptionsTreeView.build(folder, this.corePM, this.changes.get("Engines"), this.expandOnFiltering), this.advancedOptions);
/*     */     }
/* 155 */     if (this.prjPM != null) {
/* 156 */       this.changes.addPropertyManager("Project-specific", this.prjPM);
/* 157 */       this.tabman.addEntry("Project-specific", OptionsTreeView.build(folder, this.prjPM, this.changes.get("Project-specific"), this.expandOnFiltering), this.advancedOptions);
/*     */     }
/*     */     
/* 160 */     if ((this.clientPM != null) && (this.corePM != null)) {
/* 161 */       this.tabman.addEntry(GENERAL, new OptionsSimpleViewGeneral(folder, this.changes), !this.advancedOptions);
/* 162 */       this.tabman.addEntry(DEV, new OptionsSimpleViewDevelopment(folder, this.changes), !this.advancedOptions);
/*     */     }
/*     */     
/* 165 */     createButtons(parent, 288, 32);
/*     */     
/* 167 */     createButtons(parent, 0, new int[][] { { -5, 559 } }, 0);
/* 168 */     if (this.blockModeChange) {
/* 169 */       getButtonByStyle(-5).setEnabled(false);
/*     */     }
/* 171 */     updateButtonText(this.advancedOptions);
/*     */     
/* 173 */     Button btnHelp = UIUtil.createPushbox(parent, S.s(365), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 176 */         BrowserUtil.openInBrowser("https://www.pnfsoftware.com/jeb/manual");
/*     */       }
/* 178 */     });
/* 179 */     GridData data = new GridData();
/* 180 */     data.horizontalAlignment = 3;
/* 181 */     btnHelp.setLayoutData(data);
/*     */     
/*     */ 
/* 184 */     for (TabFolderView.Entry e : this.tabman.getEntries()) {
/* 185 */       if (e.hasTab()) {
/* 186 */         this.tabman.showEntry(e, true);
/* 187 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void onButtonClick(int style)
/*     */   {
/* 194 */     if (style == -5) {
/* 195 */       setMode(!this.advancedOptions);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 201 */       super.onButtonClick(style);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 207 */     this.changes.saveAllChanges(null);
/* 208 */     this.saveChanges = true;
/* 209 */     super.onConfirm();
/*     */   }
/*     */   
/*     */   private void setMode(boolean advancedOptions) {
/* 213 */     if (advancedOptions == this.advancedOptions) {
/* 214 */       return;
/*     */     }
/*     */     
/*     */ 
/* 218 */     if (this.tabman != null) {
/* 219 */       if (advancedOptions) {
/* 220 */         for (String e : advancedTabs) {
/* 221 */           this.tabman.showEntry(e, e.equals("Client"));
/*     */         }
/* 223 */         for (String e : simpleTabs) {
/* 224 */           this.tabman.hideEntry(e);
/*     */         }
/* 226 */         this.tabman.hideEntry(GENERAL);
/*     */       }
/*     */       else {
/* 229 */         for (String e : advancedTabs) {
/* 230 */           this.tabman.hideEntry(e);
/*     */         }
/* 232 */         for (String e : simpleTabs) {
/* 233 */           this.tabman.showEntry(e, e.equals(GENERAL));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 238 */     updateButtonText(advancedOptions);
/*     */     
/*     */ 
/* 241 */     this.advancedOptions = advancedOptions;
/* 242 */     if (this.clientProperties != null) {
/* 243 */       this.clientProperties.setOptionsDialogAdvancedMode(advancedOptions);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateButtonText(boolean advancedOptions) {
/* 248 */     Button b = getButtonByStyle(-5);
/* 249 */     if (b != null) {
/* 250 */       b.setText(S.s(613) + " >>");
/* 251 */       b.getParent().pack();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\OptionsDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */