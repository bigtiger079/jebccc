/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.UIAssetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.BrowserUtil;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Link;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomerActionDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private static final String surveySimpleURL = "pnfsoftware.com/survey";
/*     */   public static final String surveyURL = "https://www.pnfsoftware.com/survey";
/*  40 */   private Color cWhite = UIAssetManager.getInstance().getColor(255, 255, 255);
/*     */   
/*     */   public CustomerActionDialog(Shell parent) {
/*  43 */     super(parent, "Satisfaction Survey", true, true);
/*  44 */     this.scrolledContainer = true;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  49 */     super.open();
/*  50 */     return null;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  55 */     UIUtil.setStandardLayout(parent, 2, 10);
/*     */     
/*  57 */     Color white = parent.getDisplay().getSystemColor(1);
/*  58 */     parent.setBackground(white);
/*     */     
/*  60 */     Label l = new Label(parent, 0);
/*  61 */     l.setLayoutData(new GridData(16384, 128, false, false));
/*  62 */     l.setBackground(parent.getDisplay().getSystemColor(1));
/*  63 */     l.setImage(UIAssetManager.getInstance().getImage("jeb1/icon-jeb-48.png"));
/*     */     
/*  65 */     Composite c0 = new Composite(parent, 0);
/*  66 */     GridData data = new GridData();
/*  67 */     data.horizontalIndent = 15;
/*  68 */     c0.setLayoutData(data);
/*  69 */     c0.setLayout(new RowLayout(512));
/*  70 */     c0.setBackground(white);
/*     */     
/*  72 */     SelectionListener l_visitWebsite = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  75 */         BrowserUtil.openInBrowser("https://www.pnfsoftware.com/survey");
/*     */       }
/*     */       
/*     */ 
/*  79 */     };
/*  80 */     String text = "Dear User,\n\nWe are conducting a satisfaction survey and would love to hear from you.\nThe survey contains 7 questions and will take just a minute of your time.\n\nThank you in advance from your participation! (If you decide to take this survey\nlater, the web link can also be found in the About box of the Help menu.)\n\n";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     Label t1 = new Label(c0, 0);
/*  91 */     t1.setBackground(white);
/*  92 */     t1.setText(text);
/*     */     
/*     */ 
/*  95 */     Link t0 = new Link(c0, 0);
/*  96 */     t0.setBackground(white);
/*  97 */     t0.setText(String.format("<a href=\"%s\">Take the Survey</a> (Will navigate to %s)\n\n", new Object[] { "https://www.pnfsoftware.com/survey", "pnfsoftware.com/survey" }));
/*  98 */     t0.addSelectionListener(l_visitWebsite);
/*     */     
/* 100 */     Composite buttons = createOkayButton(parent);
/* 101 */     buttons.setBackground(this.cWhite);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\CustomerActionDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */