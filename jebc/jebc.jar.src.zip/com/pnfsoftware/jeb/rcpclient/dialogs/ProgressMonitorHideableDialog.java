/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import org.eclipse.jface.dialogs.ProgressMonitorDialog;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProgressMonitorHideableDialog
/*    */   extends ProgressMonitorDialog
/*    */ {
/*    */   public ProgressMonitorHideableDialog(Shell parent)
/*    */   {
/* 22 */     super(parent);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void createButtonsForButtonBar(Composite parent)
/*    */   {
/* 33 */     createCancelButton(parent);
/*    */   }
/*    */   
/*    */   protected void okPressed()
/*    */   {
/* 38 */     setVisible(false);
/*    */   }
/*    */   
/*    */   public void setVisible(boolean visible) {
/* 42 */     getShell().setVisible(visible);
/*    */   }
/*    */   
/*    */   public boolean isAlive() {
/* 46 */     return (getShell() != null) && (!getShell().isDisposed());
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ProgressMonitorHideableDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */