/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.client.SystemInformation;
/*     */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import com.pnfsoftware.jeb.util.net.Net;
/*     */ import com.pnfsoftware.jeb.util.net.NetProxyInfo;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.custom.BusyIndicator;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LicenseKeyAutoDialog
/*     */   extends JebDialog
/*     */ {
/*  46 */   private static final ILogger logger = GlobalLog.getLogger(LicenseKeyAutoDialog.class);
/*     */   
/*     */   private String licdata;
/*     */   
/*     */   private Net net;
/*     */   
/*     */   private boolean success;
/*     */   
/*     */   private String lickey;
/*     */   
/*     */   private IGraphicalTaskExecutor executor;
/*     */   
/*     */   private Text textKeyname;
/*     */   
/*     */   private Text textKey;
/*     */   
/*     */   private Button btnGen;
/*     */   
/*     */   private Button btnManualGen;
/*     */   
/*     */   public LicenseKeyAutoDialog(Shell parent, String licdata, Net net, IGraphicalTaskExecutor executor)
/*     */   {
/*  68 */     super(parent, "JEB", true, true);
/*  69 */     this.scrolledContainer = true;
/*  70 */     setVisualBounds(-1, 50, -1, -1);
/*     */     
/*  72 */     this.licdata = licdata;
/*  73 */     this.net = new Net(net);
/*  74 */     this.executor = executor;
/*     */   }
/*     */   
/*     */   public Net getNet() {
/*  78 */     return this.net;
/*     */   }
/*     */   
/*     */   public String open()
/*     */   {
/*  83 */     super.open();
/*  84 */     return this.lickey;
/*     */   }
/*     */   
/*     */   public void createContents(Composite parent)
/*     */   {
/*  89 */     UIUtil.setStandardLayout(parent);
/*     */     
/*     */ 
/*  92 */     parent.addListener(21, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/*  95 */         if (!LicenseKeyAutoDialog.this.success) {
/*  96 */           LicenseKeyAutoDialog.this.lickey = null;
/*     */         }
/*     */         
/*     */       }
/* 100 */     });
/* 101 */     String hello = String.format(S.s(364), new Object[] { Licensing.user_name });
/* 102 */     String message = String.format("%s. %s.\n\n", new Object[] { hello, S.s(636) });
/* 103 */     Label labelInfo = new Label(parent, 64);
/* 104 */     labelInfo.setText(message);
/* 105 */     labelInfo.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*     */ 
/* 108 */     new Label(parent, 0).setText(S.s(423) + ": ");
/* 109 */     this.textKeyname = new Text(parent, 2052);
/* 110 */     this.textKeyname.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 111 */     this.textKeyname.setText(String.format("%s on %s", new Object[] { SystemInformation.username, SystemInformation.compname }));
/* 112 */     this.textKeyname.selectAll();
/* 113 */     this.textKeyname.setFocus();
/*     */     
/*     */ 
/* 116 */     new Label(parent, 0).setText(S.s(436) + ": ");
/* 117 */     this.textKey = new Text(parent, 2060);
/* 118 */     this.textKey.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*     */ 
/* 121 */     Composite c4 = new Composite(parent, 0);
/* 122 */     c4.setLayout(new RowLayout(256));
/*     */     
/*     */ 
/* 125 */     this.btnGen = UIUtil.createPushbox(c4, S.s(362), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 128 */         Button btn = (Button)event.widget;
/*     */         
/*     */ 
/* 131 */         if (LicenseKeyAutoDialog.this.lickey != null) {
/* 132 */           LicenseKeyAutoDialog.this.success = true;
/* 133 */           LicenseKeyAutoDialog.this.shell.close();
/* 134 */           return;
/*     */         }
/*     */         
/* 137 */         String keyname = LicenseKeyAutoDialog.this.textKeyname.getText();
/* 138 */         final String urlparams = String.format("licdata=%s&keyname=%s", new Object[] { Strings.urlencodeUTF8(LicenseKeyAutoDialog.this.licdata), Strings.urlencodeUTF8(keyname) });
/*     */         
/* 140 */         btn.setText(S.s(638) + "...");
/*     */         
/* 142 */         BusyIndicator.showWhile(event.display, new Runnable()
/*     */         {
/*     */           public void run() {
/* 145 */             String[] urlbases = { "https://www.pnfsoftware.com/jps/genkey", "https://lise.pnfsoftware.com/jps/genkey" };
/* 146 */             for (String urlbase : urlbases) {
/*     */               try {
/* 148 */                 String url = String.format("%s?%s", new Object[] { urlbase, urlparams });
/* 149 */                 byte[] data = LicenseKeyAutoDialog.this.net.queryBinary(url);
/* 150 */                 String str = new String(data, Charset.forName("US-ASCII")).trim();
/* 151 */                 if (LicenseKeyAutoDialog.looksLikeLicenseKey(str)) {
/* 152 */                   LicenseKeyAutoDialog.this.lickey = str;
/* 153 */                   return;
/*     */                 }
/*     */               }
/*     */               catch (IOException e) {
/* 157 */                 LicenseKeyAutoDialog.logger.catchingSilent(e);
/*     */               }
/*     */             }
/* 160 */             LicenseKeyAutoDialog.logger.error("Server did not respond with a license key", new Object[0]);
/*     */           }
/*     */         });
/*     */         
/* 164 */         if (LicenseKeyAutoDialog.this.lickey != null) {
/* 165 */           LicenseKeyAutoDialog.this.onLicenseKeyChange(false);
/* 166 */           String msg = String.format("%s.\n\n%s.", new Object[] { S.s(438), 
/* 167 */             S.s(637) });
/* 168 */           MessageDialog.openInformation(LicenseKeyAutoDialog.this.shell, "JEB", msg);
/*     */         }
/*     */         else {
/* 171 */           btn.setText(S.s(362));
/* 172 */           String msg = String.format("%s. Potential reasons for failure include:\n\n- This machine could be offline or blocking connections to pnfsoftware.com: Automatic Key Generation requires an active Internet connection. If that is the case, you may try Manual Key Generation.\n- You may have reached the maximum number of keys that can be generated for this license: If you need to generate new keys or deprecate old ones, email licensing@pnfsoftware.com.", new Object[] {
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */             S.s(439) });
/* 179 */           MessageDialog.openError(LicenseKeyAutoDialog.this.shell, "JEB", msg);
/*     */         }
/*     */       }
/* 182 */     });
/* 183 */     this.btnGen.setToolTipText("The automatic generation of a license key requires an active Internet connection.\nSpecify your proxy settings first if you are using one.");
/*     */     
/*     */ 
/* 186 */     this.btnManualGen = UIUtil.createPushbox(c4, S.s(452), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 189 */         LicenseKeyDialog dlg2 = new LicenseKeyDialog(UIUtil.getParentShell(LicenseKeyAutoDialog.this.shell), LicenseKeyAutoDialog.this.licdata);
/* 190 */         LicenseKeyAutoDialog.this.lickey = dlg2.open();
/* 191 */         if (LicenseKeyAutoDialog.this.lickey != null) {
/* 192 */           LicenseKeyAutoDialog.this.onLicenseKeyChange(true);
/* 193 */           String msg = String.format("%s.\n\n%s.", new Object[] { S.s(770), S.s(637) });
/* 194 */           MessageDialog.openInformation(LicenseKeyAutoDialog.this.shell, "JEB", msg);
/*     */         }
/*     */         
/*     */       }
/* 198 */     });
/* 199 */     UIUtil.createPushbox(c4, S.s(668), new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/* 203 */         NetProxyInfo proxyinfo = new ProxyConfigDialog(UIUtil.getParentShell(LicenseKeyAutoDialog.this.shell), LicenseKeyAutoDialog.this.net.getProxyInformation(), LicenseKeyAutoDialog.this.executor).open();
/* 204 */         if (proxyinfo != null) {
/* 205 */           Net.setGlobalProxyInformation(proxyinfo);
/*     */         }
/*     */         
/*     */       }
/* 209 */     });
/* 210 */     this.shell.setDefaultButton(this.btnGen);
/*     */   }
/*     */   
/*     */   void onLicenseKeyChange(boolean unknownKeyname) {
/* 214 */     if (this.lickey == null) {
/* 215 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 218 */     if (unknownKeyname) {
/* 219 */       this.textKeyname.setText("N/A");
/*     */     }
/* 221 */     this.textKeyname.setEditable(false);
/* 222 */     this.textKey.setText(this.lickey);
/* 223 */     this.btnGen.setText("Continue");
/* 224 */     this.btnManualGen.setEnabled(false);
/*     */   }
/*     */   
/*     */   static boolean looksLikeLicenseKey(String str) {
/* 228 */     if (str.length() < 10) {
/* 229 */       return false;
/*     */     }
/* 231 */     for (int i = 0; i < str.length(); i++) {
/* 232 */       char c = str.charAt(i);
/* 233 */       if (((c < '0') || (c > '9')) && (c != 'Z')) {
/* 234 */         return false;
/*     */       }
/*     */     }
/* 237 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\LicenseKeyAutoDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */