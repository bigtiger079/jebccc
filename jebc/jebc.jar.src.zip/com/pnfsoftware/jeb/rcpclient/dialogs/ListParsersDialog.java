/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IEnginesContext;
/*     */ import com.pnfsoftware.jeb.core.IPluginInformation;
/*     */ import com.pnfsoftware.jeb.core.IRuntimeProject;
/*     */ import com.pnfsoftware.jeb.core.Version;
/*     */ import com.pnfsoftware.jeb.core.units.IUnitIdentifier;
/*     */ import com.pnfsoftware.jeb.core.units.IUnitProcessor;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilteredTableView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ITableEventListener;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCellLabelProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCheckStateProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.IFilteredTableContentProvider;
/*     */ import com.pnfsoftware.jeb.util.collect.ArrayUtil;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListParsersDialog
/*     */   extends JebDialog
/*     */ {
/*     */   private Object input;
/*     */   
/*     */   public ListParsersDialog(Shell parent)
/*     */   {
/*  41 */     super(parent, S.s(648), true, true, "enginesParsersDialog");
/*  42 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.SIZE_AND_POSITION;
/*     */   }
/*     */   
/*     */   public void setInput(IRuntimeProject prj) {
/*  46 */     this.input = prj;
/*     */   }
/*     */   
/*     */   public void setInput(IEnginesContext engctx) {
/*  50 */     this.input = engctx;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  55 */     if (this.input == null) {
/*  56 */       throw new IllegalStateException("Invalid input: please provide a runtime project or an engines context");
/*     */     }
/*  58 */     return super.open();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  64 */     UIUtil.setStandardLayout(parent);
/*     */     
/*     */ 
/*  67 */     int style = (this.input instanceof IEnginesContext) ? 32 : 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  72 */     FilteredTableView ft = new FilteredTableView(parent, style, new String[] {S.s(779), S.s(656), S.s(591), S.s(268), S.s(818), S.s(86) });
/*  73 */     ft.setLayoutData(UIUtil.createGridDataFill(true, true));
/*     */     
/*  75 */     FilteredTableViewer ftv = new FilteredTableViewer(ft);
/*  76 */     ContentProviderListener p = new ContentProviderListener();
/*  77 */     ftv.setContentProvider(p);
/*  78 */     if ((style & 0x20) != 0) {
/*  79 */       ftv.setCheckStateProvider(new DefaultCheckStateProvider(p));
/*     */     }
/*  81 */     ftv.setLabelProvider(new DefaultCellLabelProvider(p));
/*  82 */     ft.addTableEventListener(p);
/*  83 */     ftv.setInput(this.input);
/*     */     
/*  85 */     createOkayButton(parent);
/*     */     
/*  87 */     if (getStandardWidgetManager() != null) {
/*  88 */       getStandardWidgetManager().wrapWidget(ft, "listParsers");
/*     */     }
/*     */   }
/*     */   
/*     */   static class ContentProviderListener implements ITableEventListener, IFilteredTableContentProvider
/*     */   {
/*     */     private Object input0;
/*     */     
/*     */     public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
/*  97 */       this.input0 = newInput;
/*     */     }
/*     */     
/*     */ 
/*     */     public void dispose() {}
/*     */     
/*     */ 
/*     */     public Object[] getElements(Object inputElement)
/*     */     {
/* 106 */       if ((inputElement instanceof IEnginesContext)) {
/* 107 */         List<IUnitIdentifier> unitIdentifiers = ((IEnginesContext)inputElement).getUnitIdentifiers();
/* 108 */         return unitIdentifiers.toArray();
/*     */       }
/* 110 */       if ((inputElement instanceof IRuntimeProject))
/*     */       {
/* 112 */         List<IUnitIdentifier> unitIdentifiers = ((IRuntimeProject)inputElement).getProcessor().getUnitIdentifiers();
/* 113 */         return unitIdentifiers.toArray();
/*     */       }
/* 115 */       return ArrayUtil.NO_OBJECT;
/*     */     }
/*     */     
/*     */     public Object[] getRowElements(Object row)
/*     */     {
/* 120 */       if ((row instanceof IUnitIdentifier)) {
/* 121 */         IUnitIdentifier p = (IUnitIdentifier)row;
/*     */         
/* 123 */         String name = p.getClass().getName();
/* 124 */         String description = null;
/* 125 */         String author = null;
/* 126 */         String version = null;
/*     */         
/* 128 */         IPluginInformation pi = p.getPluginInformation();
/* 129 */         if (pi != null) {
/* 130 */           name = pi.getName();
/* 131 */           description = pi.getDescription();
/* 132 */           author = pi.getAuthor();
/* 133 */           version = pi.getVersion().toString();
/*     */         }
/*     */         
/* 136 */         return new Object[] { p.getFormatType(), Double.valueOf(p.getPriority()), name, description, version, author };
/*     */       }
/*     */       
/* 139 */       return ArrayUtil.NO_OBJECT;
/*     */     }
/*     */     
/*     */     public boolean isChecked(Object row)
/*     */     {
/* 144 */       if ((row instanceof IUnitIdentifier)) {
/* 145 */         IUnitIdentifier id = (IUnitIdentifier)row;
/* 146 */         if ((this.input0 instanceof IEnginesContext)) {
/* 147 */           return ((IEnginesContext)this.input0).isIdentifierEnabled(id);
/*     */         }
/*     */       }
/* 150 */       return false;
/*     */     }
/*     */     
/*     */     public void onTableEvent(Object row, boolean isSelected, boolean isChecked)
/*     */     {
/* 155 */       if ((row instanceof IUnitIdentifier)) {
/* 156 */         IUnitIdentifier id = (IUnitIdentifier)row;
/* 157 */         if ((this.input0 instanceof IEnginesContext)) {
/* 158 */           ((IEnginesContext)this.input0).setIdentifierEnabled(id, isChecked);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ListParsersDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */