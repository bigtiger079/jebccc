/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import org.eclipse.jface.resource.JFaceResources;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnitPropertiesDialog
/*     */   extends JebDialog
/*     */ {
/*  38 */   private static final ILogger logger = GlobalLog.getLogger(UnitPropertiesDialog.class);
/*     */   private IUnit unit;
/*     */   private Text widgetName;
/*     */   private StyledText widgetNotes;
/*     */   
/*     */   public UnitPropertiesDialog(Shell parent, IUnit unit)
/*     */   {
/*  45 */     super(parent, S.s(787), true, true);
/*  46 */     this.scrolledContainer = true;
/*  47 */     this.unit = unit;
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  52 */     super.open();
/*     */     
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  59 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  61 */     new Label(parent, 0).setText(S.s(786) + ": ");
/*  62 */     this.widgetName = new Text(parent, 2052);
/*  63 */     this.widgetName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  64 */     this.widgetName.setText(this.unit.getName());
/*  65 */     this.widgetName.selectAll();
/*  66 */     this.widgetName.setFocus();
/*     */     
/*  68 */     new Label(parent, 0).setText("Original name: ");
/*  69 */     Text widgetName0 = new Text(parent, 2060);
/*  70 */     widgetName0.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  71 */     widgetName0.setText(Strings.safe(this.unit.getRealName(), "N/A"));
/*  72 */     widgetName0.selectAll();
/*     */     
/*  74 */     new Label(parent, 0).setText(S.s(788) + ": ");
/*  75 */     Text widgetType = new Text(parent, 2060);
/*  76 */     widgetType.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  77 */     widgetType.setText(this.unit.getFormatType());
/*  78 */     widgetType.selectAll();
/*     */     
/*  80 */     new Label(parent, 0).setText(S.s(214) + ": ");
/*  81 */     Text widgetCtime = new Text(parent, 2060);
/*  82 */     widgetCtime.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  83 */     DateFormat df = DateFormat.getDateTimeInstance();
/*  84 */     String str_ctime = df.format(new Date(this.unit.getCreationTimestamp()));
/*  85 */     String str_tz = df.getTimeZone().getDisplayName(false, 0);
/*  86 */     widgetCtime.setText(str_ctime + " " + str_tz);
/*  87 */     widgetCtime.selectAll();
/*     */     
/*  89 */     new Label(parent, 0).setText(S.s(748) + ": ");
/*  90 */     Text widgetStatus = new Text(parent, 2060);
/*  91 */     widgetStatus.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*  92 */     String status = this.unit.getStatus();
/*  93 */     if (status == null) {
/*  94 */       status = "N/A";
/*     */     }
/*  96 */     if (!this.unit.isProcessed()) {
/*  97 */       status = status + " (" + S.s(794) + ")";
/*     */     }
/*  99 */     widgetStatus.setText(status);
/*     */     
/* 101 */     new Label(parent, 0).setText(S.s(599) + ": ");
/* 102 */     new Label(parent, 0).setText("");
/* 103 */     this.widgetNotes = new StyledText(parent, 2818);
/* 104 */     this.widgetNotes.setAlwaysShowScrollBars(false);
/* 105 */     this.widgetNotes.setText(this.unit.getNotes());
/* 106 */     this.widgetNotes.setFont(JFaceResources.getTextFont());
/* 107 */     GridData griddata = UIUtil.createGridDataForText(this.widgetNotes, 50, 3, false);
/* 108 */     griddata.horizontalSpan = 2;
/* 109 */     griddata.grabExcessHorizontalSpace = true;
/* 110 */     griddata.horizontalAlignment = 4;
/* 111 */     griddata.grabExcessVerticalSpace = true;
/* 112 */     griddata.verticalAlignment = 4;
/* 113 */     this.widgetNotes.setLayoutData(griddata);
/* 114 */     UIUtil.disableTabOutput(this.widgetNotes);
/*     */     
/* 116 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void onConfirm()
/*     */   {
/* 122 */     this.unit.setName(this.widgetName.getText());
/* 123 */     this.unit.setNotes(this.widgetNotes.getText());
/* 124 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\UnitPropertiesDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */