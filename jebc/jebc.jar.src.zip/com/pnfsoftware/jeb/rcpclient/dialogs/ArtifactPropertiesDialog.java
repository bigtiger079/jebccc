/*     */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.IArtifact;
/*     */ import com.pnfsoftware.jeb.core.ILiveArtifact;
/*     */ import com.pnfsoftware.jeb.core.input.FileInput;
/*     */ import com.pnfsoftware.jeb.core.input.IInput;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.encoding.HashCalculator;
/*     */ import com.pnfsoftware.jeb.util.format.Formatter;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.jface.resource.JFaceResources;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.FileDialog;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArtifactPropertiesDialog
/*     */   extends JebDialog
/*     */ {
/*  47 */   private static final ILogger logger = GlobalLog.getLogger(ArtifactPropertiesDialog.class);
/*     */   
/*     */   private ILiveArtifact liveArtifact;
/*     */   private IArtifact artifact;
/*     */   private Text widgetName;
/*     */   private StyledText widgetNotes;
/*     */   
/*     */   public ArtifactPropertiesDialog(Shell parent, ILiveArtifact liveArtifact)
/*     */   {
/*  56 */     super(parent, S.s(76), true, true);
/*  57 */     this.scrolledContainer = true;
/*     */     
/*  59 */     this.liveArtifact = liveArtifact;
/*  60 */     this.artifact = liveArtifact.getArtifact();
/*     */   }
/*     */   
/*     */   public Object open()
/*     */   {
/*  65 */     super.open();
/*     */     
/*  67 */     return null;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  72 */     UIUtil.setStandardLayout(parent, 2);
/*     */     
/*  74 */     IInput input = this.artifact.getInput();
/*  75 */     if ((input instanceof FileInput)) {
/*  76 */       FileInput fileInput = (FileInput)input;
/*  77 */       File f = fileInput.getFile();
/*  78 */       if (f == null) {
/*  79 */         String msg = String.format("It appears the input file artifact does not exist.\n\nWould you like to update the artifact path?", new Object[0]);
/*     */         
/*  81 */         if (MessageDialog.openQuestion(this.shell, "Invalid input artifact", msg)) {
/*  82 */           FileDialog dlg2 = new FileDialog(this.shell, 4096);
/*  83 */           dlg2.setText("Artifact Path");
/*  84 */           String path2 = dlg2.open();
/*  85 */           if (path2 != null) {
/*     */             try {
/*  87 */               fileInput.setFile(new File(path2));
/*     */             }
/*     */             catch (IOException e1) {
/*  90 */               UI.error("Cannot set the input artifact.");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     new Label(parent, 0).setText(S.s(73) + ": ");
/*  98 */     this.widgetName = new Text(parent, 2052);
/*  99 */     this.widgetName.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 100 */     this.widgetName.setText(this.artifact.getName());
/* 101 */     this.widgetName.selectAll();
/* 102 */     this.widgetName.setFocus();
/*     */     
/* 104 */     new Label(parent, 0).setText(S.s(214) + ": ");
/* 105 */     Text widgetCtime = new Text(parent, 2060);
/* 106 */     widgetCtime.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 107 */     DateFormat df = DateFormat.getDateTimeInstance();
/* 108 */     String str_ctime = df.format(new Date(this.artifact.getCreationTimestamp()));
/* 109 */     String str_tz = df.getTimeZone().getDisplayName(false, 0);
/* 110 */     widgetCtime.setText(str_ctime + " " + str_tz);
/* 111 */     widgetCtime.selectAll();
/*     */     
/* 113 */     String hashMd5 = "?";
/* 114 */     String hashSha1 = "?";
/* 115 */     String hashSha256 = "?";
/*     */     
/* 117 */     long inputSize = input.getCurrentSize();
/*     */     
/* 119 */     int warnSizeMb = 256;
/*     */     
/* 121 */     boolean skipHashComp = false;
/* 122 */     if (inputSize >= 268435456L) {
/* 123 */       skipHashComp = MessageDialog.openQuestion(this.shell, S.s(821), "The input size is very large. Computing message digests may take a long time.\n\nWould you like to skip hash computations?");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 128 */     if (!skipHashComp) {
/* 129 */       try { InputStream stream = input.getStream();Throwable localThrowable3 = null;
/* 130 */         try { HashCalculator h = new HashCalculator(stream, 28);
/* 131 */           if ((h.compute()) && (h.getSize() == inputSize)) {
/* 132 */             hashMd5 = Formatter.byteArrayToHexString(h.getMd5());
/* 133 */             hashSha1 = Formatter.byteArrayToHexString(h.getSha1());
/* 134 */             hashSha256 = Formatter.byteArrayToHexString(h.getSha256());
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 129 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/* 136 */           if (stream != null) if (localThrowable3 != null) try { stream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else stream.close();
/*     */         }
/* 138 */       } catch (IOException e) { logger.catching(e);
/*     */       }
/*     */     }
/*     */     
/* 142 */     new Label(parent, 0).setText(S.s(232) + ": ");
/* 143 */     new Label(parent, 0).setText(inputSize + " bytes");
/* 144 */     Text widgetData = new Text(parent, 2058);
/* 145 */     StringBuilder sb = new StringBuilder();
/* 146 */     sb.append(String.format("MD5       %s\n", new Object[] { hashMd5 }));
/* 147 */     sb.append(String.format("SHA-1     %s\n", new Object[] { hashSha1 }));
/* 148 */     sb.append(String.format("SHA-256   %s", new Object[] { hashSha256 }));
/* 149 */     widgetData.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/* 150 */     widgetData.setText(sb.toString());
/* 151 */     widgetData.setFont(JFaceResources.getTextFont());
/*     */     
/* 153 */     new Label(parent, 0).setText(S.s(685) + ": ");
/* 154 */     new Label(parent, 0).setText("" + this.liveArtifact.getUnits().size());
/*     */     
/* 156 */     new Label(parent, 0).setText(S.s(599) + ": ");
/* 157 */     new Label(parent, 0).setText("");
/* 158 */     this.widgetNotes = new StyledText(parent, 2818);
/* 159 */     this.widgetNotes.setAlwaysShowScrollBars(false);
/* 160 */     this.widgetNotes.setText(this.artifact.getNotes());
/* 161 */     this.widgetNotes.setFont(JFaceResources.getTextFont());
/* 162 */     GridData griddata = UIUtil.createGridDataForText(this.widgetNotes, 50, 3, false);
/* 163 */     griddata.horizontalSpan = 2;
/* 164 */     griddata.grabExcessHorizontalSpace = true;
/* 165 */     griddata.horizontalAlignment = 4;
/* 166 */     griddata.grabExcessVerticalSpace = true;
/* 167 */     griddata.verticalAlignment = 4;
/* 168 */     this.widgetNotes.setLayoutData(griddata);
/* 169 */     UIUtil.disableTabOutput(this.widgetNotes);
/*     */     
/* 171 */     createOkayCancelButtons(parent);
/*     */   }
/*     */   
/*     */   protected void onConfirm()
/*     */   {
/* 176 */     this.artifact.setName(this.widgetName.getText());
/* 177 */     this.artifact.setNotes(this.widgetNotes.getText());
/* 178 */     super.onConfirm();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\ArtifactPropertiesDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */