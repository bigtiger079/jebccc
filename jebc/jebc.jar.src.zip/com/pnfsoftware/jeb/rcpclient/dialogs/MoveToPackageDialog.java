/*    */ package com.pnfsoftware.jeb.rcpclient.dialogs;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.HistoryAssistedTextField;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.layout.RowLayout;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MoveToPackageDialog
/*    */   extends JebDialog
/*    */ {
/* 34 */   private static final ILogger logger = GlobalLog.getLogger(MoveToPackageDialog.class);
/*    */   private TextHistory textHistory;
/*    */   private HistoryAssistedTextField text;
/*    */   private String input;
/*    */   private String description;
/*    */   private String initialValue;
/*    */   protected Button btnOk;
/*    */   
/*    */   public MoveToPackageDialog(Shell parent, TextHistory textHistory)
/*    */   {
/* 44 */     super(parent, S.s(519), true, true);
/* 45 */     this.scrolledContainer = true;
/*    */     
/* 47 */     this.textHistory = textHistory;
/*    */   }
/*    */   
/*    */   public void setDescription(String description) {
/* 51 */     this.description = description;
/*    */   }
/*    */   
/*    */   public void setInitialValue(String initialValue) {
/* 55 */     this.initialValue = initialValue;
/*    */   }
/*    */   
/*    */   public String open()
/*    */   {
/* 60 */     super.open();
/* 61 */     return this.input;
/*    */   }
/*    */   
/*    */   public void createContents(Composite parent)
/*    */   {
/* 66 */     UIUtil.setStandardLayout(parent);
/*    */     
/* 68 */     Label hint = new Label(parent, 64);
/* 69 */     hint.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 70 */     hint.setText(this.description != null ? this.description : S.s(391));
/*    */     
/* 72 */     this.text = new HistoryAssistedTextField(parent, S.s(591) + ":", this.textHistory, true);
/*    */     
/* 74 */     GridData griddata = UIUtil.createGridDataForText(this.text, 50, 0, false);
/* 75 */     griddata.grabExcessHorizontalSpace = true;
/* 76 */     griddata.horizontalAlignment = 4;
/* 77 */     this.text.setLayoutData(griddata);
/*    */     
/* 79 */     if (this.initialValue != null) {
/* 80 */       this.text.getWidget().setText(this.initialValue);
/* 81 */       this.text.getWidget().selectAll();
/*    */     }
/*    */     
/* 84 */     UIUtil.disableTabOutput(this.text);
/*    */     
/*    */ 
/* 87 */     Composite c1 = new Composite(parent, 0);
/* 88 */     c1.setLayout(new RowLayout(256));
/*    */     
/* 90 */     createOkayCancelButtons(parent);
/*    */   }
/*    */   
/*    */   protected void onConfirm()
/*    */   {
/* 95 */     this.text.confirm();
/* 96 */     this.input = this.text.getText();
/* 97 */     super.onConfirm();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\dialogs\MoveToPackageDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */