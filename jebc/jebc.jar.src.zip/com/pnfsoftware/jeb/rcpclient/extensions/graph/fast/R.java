/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;
/*    */ 
/*    */ 
/*    */ public class R
/*    */ {
/*    */   public double x;
/*    */   
/*    */   public double y;
/*    */   
/*    */   public double w;
/*    */   
/*    */   public double h;
/*    */   
/*    */   public R(double x, double y, double w, double h)
/*    */   {
/* 16 */     this.x = x;
/* 17 */     this.y = y;
/* 18 */     this.w = w;
/* 19 */     this.h = h;
/*    */   }
/*    */   
/*    */   public boolean contains(P p) {
/* 23 */     return (p.x >= this.x) && (p.x < this.x + this.w) && (p.y >= this.y) && (p.y < this.y + this.h);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 28 */     return String.format("%f,%f,%f,%f", new Object[] { Double.valueOf(this.x), Double.valueOf(this.y), Double.valueOf(this.w), Double.valueOf(this.h) });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */