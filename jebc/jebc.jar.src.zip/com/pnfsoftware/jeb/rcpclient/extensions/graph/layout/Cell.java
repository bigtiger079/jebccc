/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cell<T>
/*     */ {
/*     */   T obj;
/*     */   RowCol coords;
/*     */   int horiMergerDisp;
/*     */   int vertMergerDisp;
/*     */   
/*     */   Cell(int row, int col)
/*     */   {
/*  48 */     this.coords = new RowCol(row, col);
/*     */   }
/*     */   
/*     */   public RowCol getCoordinates() {
/*  52 */     return this.coords;
/*     */   }
/*     */   
/*     */   public int getRow() {
/*  56 */     return this.coords.getRow();
/*     */   }
/*     */   
/*     */   public int getColumn() {
/*  60 */     return this.coords.getColumn();
/*     */   }
/*     */   
/*     */   public int getNextRow() {
/*  64 */     return this.coords.getRow() + getVerticalSpan();
/*     */   }
/*     */   
/*     */   public int getNextColumn() {
/*  68 */     return this.coords.getColumn() + getHorizontalSpan();
/*     */   }
/*     */   
/*     */   public int getHorizontalSpan() {
/*  72 */     if (this.horiMergerDisp < 0) {
/*  73 */       throw new RuntimeException();
/*     */     }
/*  75 */     return 1 + this.horiMergerDisp;
/*     */   }
/*     */   
/*     */   public int getVerticalSpan() {
/*  79 */     if (this.vertMergerDisp < 0) {
/*  80 */       throw new RuntimeException();
/*     */     }
/*  82 */     return 1 + this.vertMergerDisp;
/*     */   }
/*     */   
/*     */   Cell<T> getPrimary(Spreadsheet<T> grid) {
/*  86 */     if ((this.horiMergerDisp >= 0) && (this.vertMergerDisp >= 0)) {
/*  87 */       return this;
/*     */     }
/*  89 */     Cell<T> primary = grid.getCellInternal(this.coords.getRow() + this.vertMergerDisp, this.coords.getColumn() + this.horiMergerDisp);
/*  90 */     Assert.a(primary != null, "Expected a primary cell, got null");
/*  91 */     return primary;
/*     */   }
/*     */   
/*     */   boolean isPrimary() {
/*  95 */     return (this.horiMergerDisp >= 0) && (this.vertMergerDisp >= 0);
/*     */   }
/*     */   
/*     */   public boolean isPartOfMergedCell() {
/*  99 */     return (this.horiMergerDisp != 0) || (this.vertMergerDisp != 0);
/*     */   }
/*     */   
/*     */   public void setObject(T obj) {
/* 103 */     this.obj = obj;
/*     */   }
/*     */   
/*     */   public T getObject() {
/* 107 */     return (T)this.obj;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 112 */     StringBuilder sb = new StringBuilder();
/* 113 */     sb.append("[" + this.coords.getRow());
/* 114 */     if (this.horiMergerDisp != 0) {
/* 115 */       sb.append(String.format("%+d", new Object[] { Integer.valueOf(this.horiMergerDisp) }));
/*     */     }
/* 117 */     sb.append("," + this.coords.getColumn());
/* 118 */     if (this.vertMergerDisp != 0) {
/* 119 */       sb.append(String.format("%+d", new Object[] { Integer.valueOf(this.vertMergerDisp) }));
/*     */     }
/* 121 */     sb.append("]");
/* 122 */     if (this.obj != null) {
/* 123 */       sb.append(":" + this.obj);
/*     */     }
/* 125 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\Cell.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */