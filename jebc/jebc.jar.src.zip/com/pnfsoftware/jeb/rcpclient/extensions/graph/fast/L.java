/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class L
/*    */ {
/*    */   int src;
/*    */   
/*    */   int dst;
/*    */   
/*    */ 
/*    */   public L(int src, int dst)
/*    */   {
/* 14 */     this.src = src;
/* 15 */     this.dst = dst;
/*    */   }
/*    */   
/*    */   public int getSrcId() {
/* 19 */     return this.src;
/*    */   }
/*    */   
/*    */   public int getDstId() {
/* 23 */     return this.dst;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 28 */     int prime = 31;
/* 29 */     int result = 1;
/* 30 */     result = 31 * result + this.dst;
/* 31 */     result = 31 * result + this.src;
/* 32 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 37 */     if (this == obj)
/* 38 */       return true;
/* 39 */     if (obj == null)
/* 40 */       return false;
/* 41 */     if (getClass() != obj.getClass())
/* 42 */       return false;
/* 43 */     L other = (L)obj;
/* 44 */     if (this.dst != other.dst)
/* 45 */       return false;
/* 46 */     if (this.src != other.src)
/* 47 */       return false;
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   public L clone()
/*    */   {
/* 53 */     return new L(this.src, this.dst);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 58 */     return String.format("%d>%d", new Object[] { Integer.valueOf(this.src), Integer.valueOf(this.dst) });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\L.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */