/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*     */ 
/*     */ import com.pnfsoftware.jeb.core.units.code.IInstruction;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.cfg.BasicBlock;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.cfg.CFG;
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ class CFGLayoutExp1<T extends IInstruction>
/*     */   implements ICFGLayout<T>
/*     */ {
/*  29 */   private static final ILogger logger = GlobalLog.getLogger(CFGLayoutExp1.class);
/*     */   
/*     */   CFG<T> cfg;
/*     */   
/*     */   Spreadsheet<BasicBlock<T>> grid;
/*     */   
/*     */   LinkedHashMap<Long, BasicBlock<T>> blockmap;
/*     */   
/*     */ 
/*     */   public Spreadsheet<BasicBlock<T>> build(CFG<T> cfg)
/*     */   {
/*  40 */     if (this.grid != null) {
/*  41 */       return this.grid;
/*     */     }
/*     */     
/*  44 */     if ((cfg == null) || (cfg.size() == 0)) {
/*  45 */       throw new IllegalArgumentException("Illegal CFG");
/*     */     }
/*  47 */     this.cfg = cfg;
/*     */     
/*  49 */     this.grid = new Spreadsheet();
/*  50 */     this.blockmap = new LinkedHashMap();
/*  51 */     for (BasicBlock<T> b : cfg) {
/*  52 */       this.blockmap.put(Long.valueOf(b.getFirstAddress()), b);
/*     */     }
/*     */     
/*  55 */     long addr = ((Long)this.blockmap.keySet().iterator().next()).longValue();
/*  56 */     BasicBlock<T> b = (BasicBlock)this.blockmap.remove(Long.valueOf(addr));
/*  57 */     Cell<BasicBlock<T>> cell0 = this.grid.writeCell(0, 0, b);
/*     */     
/*  59 */     List<Cell<BasicBlock<T>>> parents = new ArrayList();
/*  60 */     parents.add(cell0);
/*  61 */     addChildren(parents);
/*     */     
/*     */ 
/*  64 */     improveLayoutMultiPass();
/*     */     
/*  66 */     return this.grid;
/*     */   }
/*     */   
/*     */   private int improveLayoutMultiPass() {
/*  70 */     for (Cell<BasicBlock<T>> cell : this.grid.getRealCells()) {
/*  71 */       logger.i("- Cell %s", new Object[] { cell });
/*     */     }
/*     */     
/*     */ 
/*  75 */     int ipass = 0;
/*  76 */     int totalChanges = 0;
/*     */     for (;;) {
/*  78 */       ipass++;
/*  79 */       int changes = 0;
/*     */       
/*     */ 
/*  82 */       for (int row = 0; row < this.grid.getRowCount(); row++) {
/*  83 */         List<Cell<BasicBlock<T>>> rowcells = this.grid.getRealCellsOnRow(row);
/*     */         
/*     */ 
/*  86 */         int cnt = rowcells.size();
/*  87 */         for (int j = cnt - 1; j >= 0; j--) {
/*  88 */           Cell<BasicBlock<T>> cell = (Cell)rowcells.get(j);
/*  89 */           RowCol srcCoord = cell.getCoordinates();
/*  90 */           BasicBlock<T> bb = (BasicBlock)cell.getObject();
/*     */           
/*     */ 
/*  93 */           List<Cell<BasicBlock<T>>> dstCells = getDestinationCells(bb);
/*  94 */           int[] limits = findLimits(dstCells, row + 1);
/*  95 */           int hspan = limits[1] - limits[0];
/*  96 */           if (hspan != 0)
/*     */           {
/*     */ 
/*  99 */             if (srcCoord.getColumn() <= limits[0])
/*     */             {
/*     */ 
/*     */ 
/* 103 */               if (srcCoord.getColumn() < limits[0]) {
/* 104 */                 if (this.grid.isFree(srcCoord.getRow(), limits[0])) {
/* 105 */                   cell = this.grid.moveCell(cell, srcCoord.getRow(), limits[0], false);
/*     */ 
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/*     */               }
/* 112 */               else if (hspan != cell.getHorizontalSpan())
/*     */               {
/*     */ 
/* 115 */                 if (this.grid.isRangeFree(cell.getRow(), cell.getNextColumn(), limits[1]))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */                   logger.i("Expanding cell %s, new hspan=%d", new Object[] { cell, Integer.valueOf(hspan) });
/* 123 */                   cell = this.grid.mergeCells(cell.getRow(), cell.getColumn(), hspan, 1);
/*     */                   
/* 125 */                   changes++;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 132 */       if (changes == 0) {
/*     */         break;
/*     */       }
/* 135 */       totalChanges += changes;
/* 136 */       logger.i("Layouting Pass %d", new Object[] { Integer.valueOf(ipass) });
/*     */     }
/* 138 */     return totalChanges;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] findLimits(List<Cell<BasicBlock<T>>> dstCells, int wantedRow)
/*     */   {
/* 153 */     int min = 0;
/* 154 */     int max = 0;
/* 155 */     for (Cell<BasicBlock<T>> cell : dstCells) {
/* 156 */       if (cell.getRow() == wantedRow) {
/* 157 */         int col = cell.getColumn();
/* 158 */         if (col < min) {
/* 159 */           min = col;
/*     */         }
/* 161 */         col = cell.getNextColumn();
/* 162 */         if (col > max) {
/* 163 */           max = col;
/*     */         }
/*     */       }
/*     */     }
/* 167 */     return new int[] { min, max };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addChildren(List<Cell<BasicBlock<T>>> parents)
/*     */   {
/* 178 */     while (!parents.isEmpty()) {
/* 179 */       List<Cell<BasicBlock<T>>> nextParents = new ArrayList();
/* 180 */       for (Cell<BasicBlock<T>> parent : parents)
/*     */       {
/* 182 */         srcRow = parent.getCoordinates().getRow();
/* 183 */         srcCol = parent.getCoordinates().getColumn();
/* 184 */         List<BasicBlock<T>> dstlist = ((BasicBlock)parent.getObject()).getOutputBlocks();
/*     */         
/* 186 */         for (BasicBlock<T> dst : dstlist) {
/* 187 */           long addr = dst.getFirstAddress();
/*     */           
/*     */ 
/* 190 */           if (this.blockmap.containsKey(Long.valueOf(addr)))
/*     */           {
/*     */ 
/*     */ 
/* 194 */             this.blockmap.remove(Long.valueOf(addr));
/*     */             
/* 196 */             Cell<BasicBlock<T>> cell = this.grid.createFirstAvailableOnRow(srcRow + 1, srcCol);
/*     */             
/*     */ 
/*     */ 
/* 200 */             cell.setObject(dst);
/* 201 */             nextParents.add(cell);
/*     */           }
/*     */         } }
/*     */       int srcRow;
/*     */       int srcCol;
/* 206 */       parents = nextParents;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Cell<BasicBlock<T>>> getDestinationCells(BasicBlock<T> src)
/*     */   {
/* 220 */     List<Cell<BasicBlock<T>>> r = new ArrayList();
/* 221 */     for (BasicBlock<T> dst : src.getOutputBlocks()) {
/* 222 */       Cell<BasicBlock<T>> cell = this.grid.getCellByObject(dst);
/* 223 */       Assert.a(cell != null, "Cannot find cell for block: " + dst);
/* 224 */       r.add(cell);
/*     */     }
/* 226 */     return r;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\CFGLayoutExp1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */