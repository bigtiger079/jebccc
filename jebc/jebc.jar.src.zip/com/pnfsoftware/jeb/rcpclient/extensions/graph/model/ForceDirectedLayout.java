/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.model;
/*     */ 
/*     */ import com.pnfsoftware.jeb.core.exceptions.InterruptionException;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.fast.P;
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import com.pnfsoftware.jeb.util.base.Couple;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForceDirectedLayout
/*     */ {
/*  24 */   private static final ILogger logger = GlobalLog.getLogger(ForceDirectedLayout.class);
/*     */   
/*     */   private static final double C = 1.0D;
/*     */   
/*     */   public static final double DEFAULT_WIDTH = 1.0D;
/*     */   
/*     */   public static final double DEFAULT_HEIGHT = 1.0D;
/*     */   
/*     */   public static final int DEFAULT_ITERCOUNT = 100;
/*     */   
/*     */   private double width;
/*     */   
/*     */   private double height;
/*     */   private double wh;
/*     */   private double hh;
/*     */   private double area;
/*     */   private double t;
/*     */   private double dt;
/*     */   private double k;
/*     */   private int currentiter;
/*     */   private int itercount;
/*     */   private int vertexcnt;
/*     */   private List<E> uedges;
/*     */   private P[] coords;
/*     */   private P[] disps;
/*     */   
/*     */   public ForceDirectedLayout(Digraph g)
/*     */   {
/*  52 */     this(g, 100, 1.0D, 1.0D, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ForceDirectedLayout(Digraph g, int itercount, double width, double height, P[] coords)
/*     */   {
/*  66 */     this.vertexcnt = g.getVertexCount();
/*     */     
/*     */ 
/*  69 */     Set<Couple<Integer, Integer>> set = new HashSet();
/*  70 */     this.uedges = new ArrayList();
/*  71 */     for (E e : g.getEdges()) {
/*  72 */       int a = e.src.index;
/*  73 */       int b = e.dst.index;
/*     */       Couple<Integer, Integer> c;
/*  75 */       Couple<Integer, Integer> c; if (a < b) {
/*  76 */         c = new Couple(Integer.valueOf(a), Integer.valueOf(b));
/*     */       }
/*     */       else {
/*  79 */         c = new Couple(Integer.valueOf(b), Integer.valueOf(a));
/*     */       }
/*  81 */       if (set.add(c)) {
/*  82 */         this.uedges.add(e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  87 */     this.width = width;
/*  88 */     this.height = height;
/*     */     
/*  90 */     this.wh = (this.width / 2.0D);
/*  91 */     this.hh = (this.height / 2.0D);
/*     */     
/*  93 */     this.t = (width / 10.0D);
/*  94 */     this.dt = (this.t / (itercount + 1));
/*  95 */     this.area = (width * height);
/*  96 */     this.k = (1.0D * Math.sqrt(this.area / this.vertexcnt));
/*     */     
/*  98 */     if (coords == null)
/*     */     {
/* 100 */       Random prng = new Random(0L);
/*     */       
/* 102 */       coords = new P[this.vertexcnt];
/* 103 */       for (int i = 0; i < this.vertexcnt; i++)
/*     */       {
/* 105 */         coords[i] = new P(Integer.valueOf(g.getVertexByIndex(i).id), prng.nextDouble() * width, prng.nextDouble() * height);
/*     */       }
/*     */     }
/*     */     
/* 109 */     for (int i = 0; i < this.vertexcnt; i++) {
/* 110 */       P p = coords[i];
/* 111 */       V v = g.getVertexByIndex(i);
/* 112 */       Assert.a(p.getId() == v.id, "Vertex/Point ID mismatch: expected " + v.id + " got " + p.getId());
/*     */     }
/*     */     
/*     */ 
/* 116 */     this.coords = coords;
/*     */     
/*     */ 
/* 119 */     this.disps = new P[this.vertexcnt];
/* 120 */     for (int i = 0; i < this.vertexcnt; i++) {
/* 121 */       this.disps[i] = new P(Integer.valueOf(g.getVertexByIndex(i).id), 0.0D, 0.0D);
/*     */     }
/*     */     
/* 124 */     this.itercount = itercount;
/* 125 */     this.currentiter = 0;
/*     */   }
/*     */   
/*     */   public P[] getPoints() {
/* 129 */     return this.coords;
/*     */   }
/*     */   
/*     */   public P[] layout() {
/* 133 */     while (this.currentiter < this.itercount) {
/* 134 */       layoutiter();
/*     */     }
/* 136 */     return this.coords;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public P[] layoutiter()
/*     */   {
/* 147 */     for (int i = 0; i < this.vertexcnt; i++) {
/* 148 */       P c0 = this.coords[i];
/*     */       
/* 150 */       P d0 = this.disps[i];
/* 151 */       d0.reset();
/*     */       
/* 153 */       for (int j = 0; j < this.vertexcnt; j++) {
/* 154 */         if (i != j) {
/* 155 */           P c1 = this.coords[j];
/*     */           
/* 157 */           P d = new P(c0.getX() - c1.getX(), c0.getY() - c1.getY());
/* 158 */           double delta = d.dist();
/* 159 */           if (delta != 0.0D) {
/* 160 */             double f = f_r(delta, this.k) / delta;
/* 161 */             d.scale(f);
/* 162 */             d0.add(d);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 167 */       if (Thread.interrupted()) {
/* 168 */         throw new InterruptionException();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 173 */     for (E e : this.uedges) {
/* 174 */       P c0 = this.coords[e.src.index];
/* 175 */       P c1 = this.coords[e.dst.index];
/* 176 */       P d = new P(c0.getX() - c1.getX(), c0.getY() - c1.getY());
/* 177 */       double delta = d.dist();
/* 178 */       if (delta != 0.0D) {
/* 179 */         double f = f_a(delta, this.k) / delta;
/* 180 */         d.scale(f);
/* 181 */         P d0 = this.disps[e.src.index];
/* 182 */         P d1 = this.disps[e.dst.index];
/* 183 */         d0.sub(d);
/* 184 */         d1.add(d);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 189 */     for (int i = 0; i < this.vertexcnt; i++) {
/* 190 */       P d0 = this.disps[i];
/*     */       
/* 192 */       double disp = d0.dist();
/* 193 */       if (disp != 0.0D) {
/* 194 */         P c0 = this.coords[i];
/* 195 */         double d = Math.min(disp, this.t) / disp;
/* 196 */         double x = c0.getX() + d0.getX() * d;
/* 197 */         double y = c0.getY() + d0.getY() * d;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 213 */         c0.set(x, y);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 219 */     this.t *= 0.95D;
/*     */     
/* 221 */     this.currentiter += 1;
/* 222 */     return this.coords;
/*     */   }
/*     */   
/*     */   private double f_a(double d, double k) {
/* 226 */     return d * d / k;
/*     */   }
/*     */   
/*     */   private double f_r(double d, double k) {
/* 230 */     return k * k / d;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\model\ForceDirectedLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */