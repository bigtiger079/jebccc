package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;

public abstract interface IGraphBoundsListener
{
  public abstract void onBoundsUpdate(XYGraph paramXYGraph, R paramR);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\IGraphBoundsListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */