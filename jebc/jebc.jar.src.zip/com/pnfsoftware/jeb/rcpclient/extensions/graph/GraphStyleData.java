/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.ColorsGradient;
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphStyleData
/*    */ {
/*    */   public Color cCanvas;
/*    */   public Color cEdge;
/*    */   public Color cNode;
/*    */   public Color cActiveNode;
/*    */   public Color cBorder;
/*    */   public Color cActiveBorder;
/*    */   public Color cBorderShade;
/*    */   public Color cActiveBorderShade;
/*    */   
/*    */   public static GraphStyleData buildDefault()
/*    */   {
/* 31 */     GraphStyleData r = new GraphStyleData();
/* 32 */     r.cCanvas = get("rosybrown 3");
/* 33 */     r.cEdge = get("indianred");
/* 34 */     r.cNode = get("rosybrown 1");
/* 35 */     r.cActiveNode = get("cadmiumorange");
/* 36 */     r.cBorder = get("royalblue 4");
/* 37 */     r.cActiveBorder = r.cActiveNode;
/* 38 */     r.cBorderShade = get("black");
/* 39 */     r.cActiveBorderShade = r.cBorderShade;
/* 40 */     return r;
/*    */   }
/*    */   
/*    */   private static Color get(String name) {
/* 44 */     return SwtRegistry.getInstance().getColor(ColorsGradient.get(name));
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphStyleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */