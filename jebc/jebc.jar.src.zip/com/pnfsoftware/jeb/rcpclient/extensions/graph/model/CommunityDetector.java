/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.model;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.fast.P;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommunityDetector
/*     */ {
/*  19 */   private static final ILogger logger = GlobalLog.getLogger(CommunityDetector.class);
/*     */   
/*     */ 
/*     */   public static class Node
/*     */   {
/*     */     Digraph originalSubgraphRef;
/*     */     
/*     */     List<Node> children;
/*     */     Integer vertexId;
/*     */     int descCount;
/*     */     
/*     */     Node() {}
/*     */     
/*     */     Node(Digraph g)
/*     */     {
/*  34 */       this.originalSubgraphRef = g;
/*  35 */       this.descCount = this.originalSubgraphRef.getVertexCount();
/*     */     }
/*     */     
/*     */     public List<Node> getChildren() {
/*  39 */       return this.children;
/*     */     }
/*     */     
/*     */     public Integer getVertexId() {
/*  43 */       return this.vertexId;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/*  48 */       if (this.children != null) {
/*  49 */         return this.descCount + ":" + this.children.toString();
/*     */       }
/*  51 */       return Integer.toString(this.vertexId.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node perform(Digraph g)
/*     */   {
/*  64 */     Node root = new Node();
/*  65 */     performRecurse(g, root);
/*  66 */     return root;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node perform(Digraph g, int subgraphCountThreshold)
/*     */   {
/*  76 */     return performIter(g, subgraphCountThreshold);
/*     */   }
/*     */   
/*     */   private int performRecurse(Digraph g, Node node) {
/*  80 */     if (g.getVertexCount() == 1) {
/*  81 */       node.vertexId = Integer.valueOf(g.getVertexByIndex(0).id);
/*  82 */       return 1;
/*     */     }
/*     */     
/*     */     List<Digraph> subgraphs;
/*     */     
/*     */     List<Integer> ebOrder;
/*     */     
/*     */     double score;
/*     */     
/*     */     for (;;)
/*     */     {
/*  93 */       subgraphs = g.getWeaklyConnectedComponents();
/*  94 */       if (subgraphs.size() > 1) {
/*     */         break;
/*     */       }
/*     */       
/*  98 */       ebOrder = g.computeEdgeBetweenness();
/*     */       
/*     */ 
/* 101 */       E e = g.getEdge(((Integer)ebOrder.get(0)).intValue());
/* 102 */       double bestScore = e.ebscore.doubleValue();
/*     */       
/*     */ 
/* 105 */       List<E> tbr = new ArrayList();
/* 106 */       tbr.add(e);
/*     */       
/* 108 */       for (int cnt = 1; cnt < g.getEdgeCount(); cnt++) {
/* 109 */         e = g.getEdge(((Integer)ebOrder.get(cnt)).intValue());
/* 110 */         score = e.ebscore.doubleValue();
/* 111 */         if (!almostEquals(score, bestScore)) {
/*     */           break;
/*     */         }
/* 114 */         tbr.add(e);
/*     */       }
/* 116 */       if (cnt >= 2) {
/* 117 */         logger.i("%d edges have the same EB score: %f", new Object[] { Integer.valueOf(cnt), Double.valueOf(bestScore) });
/*     */       }
/*     */       
/*     */ 
/* 121 */       for (E edge : tbr) {
/* 122 */         g.removeEdge(edge);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 127 */     logger.i("-> %d sub-graphs", new Object[] { Integer.valueOf(subgraphs.size()) });
/* 128 */     node.children = new ArrayList(subgraphs.size());
/* 129 */     for (Digraph subgraph : subgraphs) {
/* 130 */       Node subnode = new Node();
/* 131 */       node.children.add(subnode);
/* 132 */       int cnt = performRecurse(subgraph, subnode);
/* 133 */       node.descCount += cnt;
/*     */     }
/* 135 */     return node.descCount;
/*     */   }
/*     */   
/*     */   private Node performIter(Digraph inputGraph, int subgraphCountThreshold) {
/* 139 */     List<Digraph> q = new ArrayList();
/* 140 */     q.add(inputGraph);
/*     */     
/* 142 */     IdentityHashMap<Digraph, Node> map = new IdentityHashMap();
/* 143 */     Node inputNode = new Node(inputGraph);
/* 144 */     map.put(inputGraph, inputNode);
/*     */     
/* 146 */     while ((!q.isEmpty()) && (
/* 147 */       (subgraphCountThreshold <= 0) || (q.size() < subgraphCountThreshold)))
/*     */     {
/*     */ 
/*     */ 
/* 151 */       Digraph g = (Digraph)q.remove(0);
/* 152 */       Node node = (Node)map.get(g);
/*     */       
/* 154 */       if (g.getVertexCount() == 1) {
/* 155 */         node.vertexId = Integer.valueOf(g.getVertexByIndex(0).id);
/*     */       }
/*     */       else
/*     */       {
/*     */         List<Digraph> subgraphs;
/*     */         List<Integer> ebOrder;
/*     */         double score;
/*     */         for (;;) {
/* 163 */           subgraphs = g.getWeaklyConnectedComponents();
/* 164 */           if (subgraphs.size() > 1) {
/*     */             break;
/*     */           }
/*     */           
/* 168 */           ebOrder = g.computeEdgeBetweenness();
/*     */           
/*     */ 
/* 171 */           E e = g.getEdge(((Integer)ebOrder.get(0)).intValue());
/* 172 */           double bestScore = e.ebscore.doubleValue();
/*     */           
/*     */ 
/* 175 */           List<E> tbr = new ArrayList();
/* 176 */           tbr.add(e);
/*     */           
/* 178 */           for (int cnt = 1; cnt < g.getEdgeCount(); cnt++) {
/* 179 */             e = g.getEdge(((Integer)ebOrder.get(cnt)).intValue());
/* 180 */             score = e.ebscore.doubleValue();
/* 181 */             if (!almostEquals(score, bestScore)) {
/*     */               break;
/*     */             }
/* 184 */             tbr.add(e);
/*     */           }
/* 186 */           if (cnt >= 2) {
/* 187 */             logger.i("%d edges have the same EB score: %f", new Object[] { Integer.valueOf(cnt), Double.valueOf(bestScore) });
/*     */           }
/*     */           
/*     */ 
/* 191 */           for (E edge : tbr) {
/* 192 */             g.removeEdge(edge);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 197 */         logger.i("-> %d sub-graphs", new Object[] { Integer.valueOf(subgraphs.size()) });
/* 198 */         node.children = new ArrayList(subgraphs.size());
/* 199 */         for (Digraph subgraph : subgraphs) {
/* 200 */           Node subnode = new Node(subgraph);
/* 201 */           node.children.add(subnode);
/* 202 */           map.put(subgraph, subnode);
/*     */         }
/*     */         
/* 205 */         q.addAll(subgraphs);
/*     */       }
/*     */     }
/* 208 */     return inputNode;
/*     */   }
/*     */   
/*     */   private static boolean almostEquals(double a, double b) {
/* 212 */     return Math.abs(a - b) <= 1.0E-7D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 217 */   private Random prng = new Random(0L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<P> layout(Node root)
/*     */   {
/* 224 */     return layout(root, 0.0D, 0.0D, 1.0D, 1.0D);
/*     */   }
/*     */   
/*     */   public List<P> layout(Node root, double gridX, double gridY, double gridW, double gridH) {
/* 228 */     List<P> points = new ArrayList();
/* 229 */     layoutInternal(root, gridX, gridY, gridW, gridH, points);
/* 230 */     return points;
/*     */   }
/*     */   
/*     */   public void layoutInternal(Node node, double gridX, double gridY, double gridW, double gridH, List<P> points) { double H;
/* 234 */     if (node.children != null) {
/* 235 */       boolean splitHorz = gridW > gridH;
/*     */       
/* 237 */       int N = node.descCount;
/*     */       double W;
/* 239 */       if (splitHorz)
/*     */       {
/* 241 */         W = gridW / N;
/* 242 */         for (Node child : node.children) {
/* 243 */           double w = W * Math.max(1, child.descCount);
/* 244 */           layoutInternal(child, gridX, gridY, w, gridH, points);
/* 245 */           gridX += w;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 250 */         H = gridH / N;
/* 251 */         for (Node child : node.children) {
/* 252 */           double h = H * Math.max(1, child.descCount);
/* 253 */           layoutInternal(child, gridX, gridY, gridW, h, points);
/* 254 */           gridY += h;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 259 */       double x = gridX + gridW / 2.0D;
/* 260 */       double y = gridY + gridH / 2.0D;
/*     */       
/*     */ 
/* 263 */       points.add(new P(node.vertexId, x, y));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\model\CommunityDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */