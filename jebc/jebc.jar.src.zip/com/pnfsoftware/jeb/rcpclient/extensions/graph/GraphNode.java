/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IZoomable;
/*     */ import com.pnfsoftware.jeb.util.base.Flags;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseListener;
/*     */ import org.eclipse.swt.events.MouseMoveListener;
/*     */ import org.eclipse.swt.events.PaintEvent;
/*     */ import org.eclipse.swt.events.PaintListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Cursor;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.FormAttachment;
/*     */ import org.eclipse.swt.layout.FormData;
/*     */ import org.eclipse.swt.layout.FormLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GraphNode
/*     */   extends Composite
/*     */   implements IZoomable, IGraphNode
/*     */ {
/*  43 */   private static final ILogger logger = GlobalLog.getLogger(GraphNode.class);
/*     */   
/*  45 */   int id = -1;
/*     */   
/*     */   Graph graph;
/*     */   
/*     */   String name;
/*     */   
/*     */   int incount;
/*     */   
/*     */   int outcount;
/*     */   
/*     */   Composite wBar;
/*     */   
/*     */   Composite wTitle;
/*     */   
/*     */   Composite wDragger;
/*     */   Composite wResizer;
/*     */   Composite contents;
/*     */   boolean dragging;
/*     */   int draggingX;
/*     */   int draggingY;
/*     */   boolean resizing;
/*     */   int resizingX;
/*     */   int resizingY;
/*  68 */   private final int bw = 2;
/*  69 */   private final int bh = 2;
/*  70 */   private final int bsw = 1;
/*  71 */   private final int bsh = 1;
/*     */   
/*     */   private Color borderColor;
/*     */   
/*     */   private Color borderShadeColor;
/*     */   
/*     */   private Color activeBorderColor;
/*     */   private Color activeBorderShadeColor;
/*     */   boolean customBorders;
/*     */   boolean hasTitle;
/*     */   boolean isResizable;
/*     */   boolean isDraggable;
/*     */   boolean hasControls;
/*  84 */   private final double titleHeight = 10.0D;
/*  85 */   private final double handleSize = 8.0D;
/*     */   
/*     */ 
/*     */ 
/*     */   boolean active;
/*     */   
/*     */ 
/*     */ 
/*     */   public GraphNode(Graph parent)
/*     */   {
/*  95 */     this(parent, 2065, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GraphNode(Graph parent, String name)
/*     */   {
/* 105 */     this(parent, 2065, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GraphNode(Graph parent, int styles)
/*     */   {
/* 115 */     this(parent, styles, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GraphNode(Graph parent, int style, String name)
/*     */   {
/* 128 */     super(parent, 0x20000000 | style & 0x800);
/* 129 */     this.customBorders = ((style & 0x800) == 0);
/* 130 */     this.hasTitle = ((style & 0x20) == 32);
/* 131 */     this.isResizable = ((style & 0x10) == 16);
/* 132 */     this.isDraggable = ((style & 0x1) == 1);
/* 133 */     this.hasControls = ((this.isResizable) || (this.isDraggable));
/*     */     
/* 135 */     this.graph = parent;
/* 136 */     this.name = name;
/*     */     
/* 138 */     if (this.customBorders) {
/* 139 */       this.borderColor = this.graph.getStyleData().cBorder;
/* 140 */       this.borderShadeColor = this.graph.getStyleData().cBorderShade;
/* 141 */       this.activeBorderColor = this.graph.getStyleData().cActiveBorder;
/* 142 */       this.activeBorderShadeColor = this.graph.getStyleData().cActiveBorderShade;
/*     */     }
/*     */     
/* 145 */     setBackgroundMode(2);
/*     */     
/* 147 */     FormLayout layout = new FormLayout();
/* 148 */     setLayout(layout);
/*     */     
/* 150 */     this.wBar = new Composite(this, 0);
/* 151 */     this.wBar.setLayout(new FormLayout());
/* 152 */     this.wBar.setBackgroundMode(2);
/* 153 */     FormData formData = new FormData();
/* 154 */     formData.top = new FormAttachment(0, 2);
/* 155 */     formData.right = new FormAttachment(100, -3);
/* 156 */     formData.bottom = new FormAttachment(100, -3);
/* 157 */     formData.width = (this.hasControls ? 8 : 0);
/* 158 */     this.wBar.setLayoutData(formData);
/* 159 */     this.wBar.addPaintListener(new PaintListener()
/*     */     {
/*     */ 
/*     */       public void paintControl(PaintEvent e) {}
/*     */ 
/* 164 */     });
/* 165 */     this.wTitle = new Composite(this, 0);
/* 166 */     this.wTitle.setLayout(new FillLayout());
/* 167 */     this.wTitle.setBackground(SwtRegistry.getInstance().getColor(0, 0, 255));
/* 168 */     formData = new FormData();
/* 169 */     formData.left = new FormAttachment(0, 2);
/* 170 */     formData.top = new FormAttachment(0, 2);
/* 171 */     formData.right = new FormAttachment(this.wBar);
/* 172 */     formData.height = (this.hasTitle ? 10 : 0);
/* 173 */     this.wTitle.setLayoutData(formData);
/* 174 */     this.wTitle.addPaintListener(new PaintListener()
/*     */     {
/*     */ 
/*     */       public void paintControl(PaintEvent e) {}
/*     */ 
/* 179 */     });
/* 180 */     this.wResizer = new Composite(this.wBar, 0);
/* 181 */     this.wResizer.setLayout(new FillLayout());
/* 182 */     formData = new FormData();
/* 183 */     formData.bottom = new FormAttachment(100, 0);
/* 184 */     formData.right = new FormAttachment(100, 0);
/* 185 */     formData.height = 8;
/* 186 */     formData.width = 8;
/* 187 */     this.wResizer.setLayoutData(formData);
/* 188 */     this.wResizer.setCursor(new Cursor(getDisplay(), 15));
/* 189 */     this.wResizer.addPaintListener(new PaintListener()
/*     */     {
/*     */       public void paintControl(PaintEvent e) {
/* 192 */         Rectangle r = GraphNode.this.wResizer.getClientArea();
/* 193 */         if (GraphNode.this.customBorders) {
/* 194 */           e.gc.setBackground(GraphNode.this.active ? GraphNode.this.activeBorderColor : GraphNode.this.borderColor);
/*     */         }
/*     */         else {
/* 197 */           e.gc.setBackground(e.display.getSystemColor(16));
/*     */         }
/* 199 */         e.gc.fillPolygon(new int[] { 0, r.height, r.width, 0, r.width, r.height });
/*     */       }
/* 201 */     });
/* 202 */     this.wResizer.setVisible(canResize());
/*     */     
/* 204 */     this.wDragger = new Composite(this.wBar, 0);
/* 205 */     this.wDragger.setLayout(new FillLayout());
/* 206 */     formData = new FormData();
/* 207 */     formData.top = new FormAttachment(0, 0);
/* 208 */     formData.right = new FormAttachment(100, 0);
/* 209 */     formData.height = 8;
/* 210 */     formData.width = 8;
/* 211 */     this.wDragger.setLayoutData(formData);
/* 212 */     this.wDragger.setCursor(new Cursor(getDisplay(), 21));
/* 213 */     this.wDragger.addPaintListener(new PaintListener()
/*     */     {
/*     */       public void paintControl(PaintEvent e) {
/* 216 */         Rectangle r = GraphNode.this.wDragger.getClientArea();
/* 217 */         if (GraphNode.this.customBorders) {
/* 218 */           e.gc.setBackground(GraphNode.this.active ? GraphNode.this.activeBorderColor : GraphNode.this.borderColor);
/*     */         }
/*     */         else {
/* 221 */           e.gc.setBackground(e.display.getSystemColor(16));
/*     */         }
/* 223 */         e.gc.fillPolygon(new int[] { 0, 0, r.width, 0, r.width, r.height });
/*     */       }
/* 225 */     });
/* 226 */     this.wDragger.setVisible(canDrag());
/*     */     
/*     */ 
/* 229 */     setBounds(0, 0, 200, 200);
/*     */     
/* 231 */     layout();
/*     */     
/*     */ 
/* 234 */     this.wDragger.addMouseListener(new MouseListener()
/*     */     {
/*     */       public void mouseUp(MouseEvent e) {
/* 237 */         GraphNode.this.dragging = false;
/*     */       }
/*     */       
/*     */       public void mouseDown(MouseEvent e)
/*     */       {
/* 242 */         GraphNode.this.graph.bringNodeForward(GraphNode.this);
/* 243 */         GraphNode.logger.i("(%d,%d)", new Object[] { Integer.valueOf(e.x), Integer.valueOf(e.y) });
/* 244 */         GraphNode.this.dragging = true;
/* 245 */         GraphNode.this.draggingX = e.x;
/* 246 */         GraphNode.this.draggingY = e.y;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseDoubleClick(MouseEvent e) {}
/* 252 */     });
/* 253 */     this.wDragger.addMouseMoveListener(new MouseMoveListener()
/*     */     {
/*     */       public void mouseMove(MouseEvent e) {
/* 256 */         if (GraphNode.this.dragging) {
/* 257 */           int deltaX = e.x - GraphNode.this.draggingX;
/* 258 */           int deltaY = e.y - GraphNode.this.draggingY;
/* 259 */           GraphNode.this.graph.dragNode(GraphNode.this, deltaX, deltaY);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 264 */     });
/* 265 */     this.wResizer.addMouseListener(new MouseListener()
/*     */     {
/*     */       public void mouseUp(MouseEvent e) {
/* 268 */         GraphNode.this.resizing = false;
/*     */       }
/*     */       
/*     */       public void mouseDown(MouseEvent e)
/*     */       {
/* 273 */         GraphNode.this.graph.bringNodeForward(GraphNode.this);
/* 274 */         GraphNode.logger.i("(%d,%d)", new Object[] { Integer.valueOf(e.x), Integer.valueOf(e.y) });
/* 275 */         GraphNode.this.resizing = true;
/* 276 */         GraphNode.this.resizingX = e.x;
/* 277 */         GraphNode.this.resizingY = e.y;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void mouseDoubleClick(MouseEvent e) {}
/* 283 */     });
/* 284 */     this.wResizer.addMouseMoveListener(new MouseMoveListener()
/*     */     {
/*     */       public void mouseMove(MouseEvent e) {
/* 287 */         if (GraphNode.this.resizing) {
/* 288 */           int deltaX = e.x - GraphNode.this.draggingX;
/* 289 */           int deltaY = e.y - GraphNode.this.draggingY;
/* 290 */           GraphNode.this.graph.resizeNode(GraphNode.this, deltaX, deltaY);
/*     */         }
/*     */         
/*     */       }
/* 294 */     });
/* 295 */     addPaintListener(new PaintListener()
/*     */     {
/*     */       public void paintControl(PaintEvent e) {
/* 298 */         if (GraphNode.this.customBorders) {
/* 299 */           Point p = GraphNode.this.getSize();
/* 300 */           int w = p.x;
/* 301 */           int h = p.y;
/*     */           
/*     */ 
/* 304 */           e.gc.setBackground(GraphNode.this.active ? GraphNode.this.activeBorderColor : GraphNode.this.borderColor);
/* 305 */           e.gc.fillRectangle(0, 0, w - 1, 2);
/* 306 */           e.gc.fillRectangle(0, 0, 2, h - 1);
/* 307 */           e.gc.fillRectangle(0, h - 2 - 1, w - 1, 2);
/* 308 */           e.gc.fillRectangle(w - 2 - 1, 0, 2, h - 1);
/*     */           
/*     */ 
/* 311 */           e.gc.setBackground(GraphNode.this.active ? GraphNode.this.activeBorderShadeColor : GraphNode.this.borderShadeColor);
/* 312 */           e.gc.fillRectangle(2, h - 1, w - 2, 1);
/* 313 */           e.gc.fillRectangle(w - 1, 2, 1, h - 2);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public int getId()
/*     */   {
/* 321 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setNodeName(String name) {
/* 325 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getNodeName() {
/* 329 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNodeInputEdgeCount(int incount)
/*     */   {
/* 338 */     this.incount = incount;
/*     */   }
/*     */   
/*     */   public int getNodeInputEdgeCount() {
/* 342 */     return this.incount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNodeOutputEdgeCount(int outcount)
/*     */   {
/* 351 */     this.outcount = outcount;
/*     */   }
/*     */   
/*     */   public int getNodeOutputEdgeCount() {
/* 355 */     return this.outcount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void acknowledgeContents(boolean notifyGraph)
/*     */   {
/* 366 */     int childcnt = getChildren().length;
/* 367 */     if (childcnt <= 2) {
/* 368 */       return;
/*     */     }
/* 370 */     if (childcnt >= 4) {
/* 371 */       throw new IllegalStateException("Illegal number of composite children");
/*     */     }
/*     */     
/*     */ 
/* 375 */     Control child1 = getChildren()[2];
/* 376 */     if ((!(child1 instanceof Composite)) || (!(child1 instanceof IGraphNodeContents))) {
/* 377 */       throw new IllegalArgumentException();
/*     */     }
/* 379 */     this.contents = ((Composite)child1);
/*     */     
/* 381 */     FormData formData = new FormData();
/* 382 */     formData.left = new FormAttachment(0, 2);
/* 383 */     formData.right = new FormAttachment(this.wBar);
/* 384 */     formData.bottom = new FormAttachment(100, -3);
/* 385 */     formData.top = new FormAttachment(this.wTitle);
/* 386 */     this.contents.setLayoutData(formData);
/*     */     
/* 388 */     this.wBar.setBackground(this.contents.getBackground());
/*     */     
/* 390 */     this.contents.addFocusListener(new FocusListener()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/* 393 */         GraphNode.this.graph.reportNodeFocusChange(GraphNode.this, false);
/*     */       }
/*     */       
/*     */       public void focusGained(FocusEvent e)
/*     */       {
/* 398 */         GraphNode.this.graph.reportNodeFocusChange(GraphNode.this, true);
/*     */       }
/*     */     });
/*     */     
/*     */ 
/*     */ 
/* 404 */     if (notifyGraph) {
/* 405 */       this.graph.onNodeContentsUpdate(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public NodeContentsText setTextContents(String text)
/*     */   {
/* 412 */     if (getChildren().length >= 3) {
/* 413 */       throw new IllegalStateException("Node already has a contents");
/*     */     }
/*     */     
/* 416 */     NodeContentsText t1 = new NodeContentsText(this, 0);
/* 417 */     t1.setText(text);
/* 418 */     t1.setEditable(false);
/* 419 */     t1.setCaret(null);
/* 420 */     t1.setText(text);
/* 421 */     acknowledgeContents(false);
/* 422 */     return t1;
/*     */   }
/*     */   
/*     */   public int getZoomLevel()
/*     */   {
/* 427 */     return this.graph.getZoomLevel();
/*     */   }
/*     */   
/*     */   public boolean applyZoom(int zoom, boolean dryRun)
/*     */   {
/* 432 */     if ((canResize()) || (canDrag())) {
/* 433 */       if (this.graph.getNodeFlags().has(1)) {
/* 434 */         this.wResizer.setVisible(false);
/* 435 */         this.wDragger.setVisible(false);
/* 436 */         this.wBar.setVisible(false);
/*     */       }
/*     */       else {
/* 439 */         this.wResizer.setVisible(canResize());
/* 440 */         this.wDragger.setVisible(canDrag());
/* 441 */         this.wBar.setVisible(true);
/*     */       }
/*     */     }
/*     */     
/* 445 */     this.contents.setVisible(!this.graph.getNodeFlags().has(2));
/*     */     
/* 447 */     boolean success = ((IGraphNodeContents)this.contents).applyZoom(zoom, dryRun);
/* 448 */     if ((!dryRun) && (success)) {
/* 449 */       this.graph.onNodeContentsUpdate(this);
/*     */     }
/* 451 */     return success;
/*     */   }
/*     */   
/*     */   public boolean hasTitle() {
/* 455 */     return this.hasTitle;
/*     */   }
/*     */   
/*     */   public Composite getTitle() {
/* 459 */     return this.wTitle;
/*     */   }
/*     */   
/*     */   public boolean canResize() {
/* 463 */     return this.isResizable;
/*     */   }
/*     */   
/*     */   public boolean canDrag() {
/* 467 */     return this.isDraggable;
/*     */   }
/*     */   
/*     */   public IGraphNodeContents getContents() {
/* 471 */     return (IGraphNodeContents)this.contents;
/*     */   }
/*     */   
/*     */   public boolean setFocus()
/*     */   {
/* 476 */     return this.contents.setFocus();
/*     */   }
/*     */   
/*     */   public boolean forceFocus()
/*     */   {
/* 481 */     return this.contents.forceFocus();
/*     */   }
/*     */   
/*     */   public boolean isFocusControl()
/*     */   {
/* 486 */     return this.contents.isFocusControl();
/*     */   }
/*     */   
/*     */   public void addFocusListener(FocusListener listener)
/*     */   {
/* 491 */     this.contents.addFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void removeFocusListener(FocusListener listener)
/*     */   {
/* 496 */     this.contents.removeFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void setFont(Font font)
/*     */   {
/* 501 */     this.contents.setFont(font);
/*     */   }
/*     */   
/*     */   public Font getFont()
/*     */   {
/* 506 */     return this.contents.getFont();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 511 */     return String.format("Node{%s}", new Object[] { this.name });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */