/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointAndLineFactory
/*    */ {
/*    */   private int id;
/*    */   private List<P> points;
/*    */   private List<L> lines;
/*    */   
/*    */   public PointAndLineFactory()
/*    */   {
/* 18 */     this.points = new ArrayList();
/* 19 */     this.lines = new ArrayList();
/*    */   }
/*    */   
/*    */   public List<P> getPoints() {
/* 23 */     return this.points;
/*    */   }
/*    */   
/*    */   public List<L> getEdges() {
/* 27 */     return this.lines;
/*    */   }
/*    */   
/*    */   public P p(double x, double y) {
/* 31 */     P p = new P(Integer.valueOf(this.id++), x, y);
/* 32 */     this.points.add(p);
/* 33 */     return p;
/*    */   }
/*    */   
/*    */   public L e(int src, int dst) {
/* 37 */     if ((src < 0) || (src >= this.id)) {
/* 38 */       throw new IllegalArgumentException();
/*    */     }
/* 40 */     if ((dst < 0) || (dst >= this.id)) {
/* 41 */       throw new IllegalArgumentException();
/*    */     }
/* 43 */     L e = new L(src, dst);
/* 44 */     this.lines.add(e);
/* 45 */     return e;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 50 */     return String.format("points=%s,edges=%s", new Object[] { this.points, this.lines });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\PointAndLineFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */