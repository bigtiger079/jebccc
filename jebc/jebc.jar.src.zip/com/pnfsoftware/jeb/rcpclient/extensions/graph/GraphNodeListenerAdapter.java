/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphNodeListenerAdapter
/*    */   implements GraphNodeListener
/*    */ {
/* 20 */   private static final ILogger logger = GlobalLog.getLogger(GraphNodeListenerAdapter.class);
/*    */   
/*    */   public void onNodeMouseEnter(GraphNode node) {}
/*    */   
/*    */   public void onNodeMouseExit(GraphNode node) {}
/*    */   
/*    */   public void onNodeFocusGained(GraphNode node) {}
/*    */   
/*    */   public void onNodeFocusLost(GraphNode node) {}
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphNodeListenerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */