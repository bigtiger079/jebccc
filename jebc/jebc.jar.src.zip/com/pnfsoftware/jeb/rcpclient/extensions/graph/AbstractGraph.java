/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseWheelListener;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Canvas;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGraph
/*     */   extends Canvas
/*     */   implements IGraph
/*     */ {
/*  31 */   private static final ILogger logger = GlobalLog.getLogger(AbstractGraph.class);
/*     */   protected static final int DEFAULT_MOUSE_WHEEL_MULTIPLIER = 15;
/*     */   private boolean kbModifier1Pressed;
/*     */   
/*     */   public AbstractGraph(Composite parent, int style) {
/*  36 */     super(parent, style);
/*  37 */     UI.initialize();
/*     */     
/*     */ 
/*  40 */     addMouseWheelListener(new MouseWheelListener()
/*     */     {
/*     */       public void mouseScrolled(MouseEvent e) {
/*  43 */         if (!AbstractGraph.this.mouseControls) {
/*  44 */           return;
/*     */         }
/*  46 */         int delta = e.count;
/*     */         
/*     */ 
/*  49 */         if (!AbstractGraph.this.isPrimaryModifierKeyPressed()) {
/*  50 */           AbstractGraph.this.dragGraph(0, delta * 15);
/*     */         }
/*  52 */         else if (delta != 0)
/*     */         {
/*  54 */           AbstractGraph.this.zoomGraph(delta, new Point(e.x, e.y));
/*     */         }
/*     */       }
/*  57 */     });
/*  58 */     addListener(38, new Listener()
/*     */     {
/*     */       public void handleEvent(Event e) {
/*  61 */         if (!AbstractGraph.this.mouseControls) {
/*  62 */           return;
/*     */         }
/*  64 */         int delta = e.count * 15;
/*  65 */         AbstractGraph.this.dragGraph(delta, 0);
/*     */       }
/*     */       
/*  68 */     });
/*  69 */     addKeyListener(new KeyListener()
/*     */     {
/*     */       public void keyReleased(KeyEvent e) {
/*  72 */         if ((AbstractGraph.this.kbModifier1Pressed) && ((e.stateMask & SWT.MOD1) != 0)) {
/*  73 */           AbstractGraph.this.kbModifier1Pressed = false;
/*     */         }
/*     */       }
/*     */       
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/*  79 */         AbstractGraph.this.kbModifier1Pressed = (e.keyCode == SWT.MOD1);
/*     */         
/*  81 */         if (!AbstractGraph.this.keyboardControls) {
/*  82 */           e.doit = false;
/*  83 */           return;
/*     */         }
/*     */         
/*     */ 
/*  87 */         if (e.character == '\\') {
/*  88 */           AbstractGraph.this.centerGraph();
/*     */         }
/*  90 */         else if (e.character == '[') {
/*  91 */           AbstractGraph.this.zoomGraph(-1);
/*     */         }
/*  93 */         else if (e.character == ']') {
/*  94 */           AbstractGraph.this.zoomGraph(1);
/*     */         }
/*  96 */         else if (((e.stateMask & SWT.MOD1) != 0) && (e.keyCode == 92)) {
/*  97 */           AbstractGraph.this.zoomGraph(0);
/*     */         }
/*  99 */         else if ((e.stateMask == 0) && (e.keyCode == 16777220)) {
/* 100 */           AbstractGraph.this.dragGraph(-10, 0);
/*     */         }
/* 102 */         else if ((e.stateMask == 0) && (e.keyCode == 16777219)) {
/* 103 */           AbstractGraph.this.dragGraph(10, 0);
/*     */         }
/* 105 */         else if ((e.stateMask == 0) && (e.keyCode == 16777217)) {
/* 106 */           AbstractGraph.this.dragGraph(0, 10);
/*     */         }
/* 108 */         else if ((e.stateMask == 0) && (e.keyCode == 16777218)) {
/* 109 */           AbstractGraph.this.dragGraph(0, -10);
/*     */         }
/*     */         else {
/* 112 */           e.doit = false;
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isPrimaryModifierKeyPressed()
/*     */   {
/* 121 */     return (this.kbModifier1Pressed) || ((UI.getKeyboardModifiersState() & SWT.MOD1) != 0);
/*     */   }
/*     */   
/* 124 */   private boolean mouseControls = true;
/* 125 */   private boolean keyboardControls = true;
/*     */   
/*     */   public void setMouseControls(boolean mouseControls) {
/* 128 */     this.mouseControls = mouseControls;
/*     */   }
/*     */   
/*     */   public boolean isMouseControls() {
/* 132 */     return this.mouseControls;
/*     */   }
/*     */   
/*     */   public void setKeyboardControls(boolean keyboardControls) {
/* 136 */     this.keyboardControls = keyboardControls;
/*     */   }
/*     */   
/*     */   public boolean isKeyboardControls() {
/* 140 */     return this.keyboardControls;
/*     */   }
/*     */   
/* 143 */   private List<GraphChangeListener> graphChangeListeners = new ArrayList();
/*     */   
/*     */   public void addGraphChangeListener(GraphChangeListener listener) {
/* 146 */     this.graphChangeListeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeGraphChangeListener(GraphChangeListener listener) {
/* 150 */     this.graphChangeListeners.remove(listener);
/*     */   }
/*     */   
/*     */   protected void notifyGraphChange() {
/* 154 */     for (GraphChangeListener listener : this.graphChangeListeners) {
/* 155 */       listener.onGraphChange(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 160 */   private List<GraphMode> modes = new ArrayList();
/*     */   private GraphMode currentMode;
/*     */   
/*     */   public List<GraphMode> getSupportedModes()
/*     */   {
/* 165 */     return this.modes;
/*     */   }
/*     */   
/*     */   protected void addSupportedMode(GraphMode mode) {
/* 169 */     this.modes.add(mode);
/*     */   }
/*     */   
/*     */   public GraphMode getMode() {
/* 173 */     return this.currentMode;
/*     */   }
/*     */   
/*     */   public int getModeId() {
/* 177 */     return this.currentMode == null ? 0 : this.currentMode.getId();
/*     */   }
/*     */   
/*     */   public GraphMode setMode(GraphMode mode) {
/* 181 */     if ((mode != null) && (!this.modes.contains(mode))) {
/* 182 */       throw new IllegalArgumentException();
/*     */     }
/* 184 */     GraphMode previousMode = this.currentMode;
/* 185 */     if (mode != this.currentMode) {
/* 186 */       this.currentMode = mode;
/* 187 */       refreshGraph();
/*     */     }
/* 189 */     return previousMode;
/*     */   }
/*     */   
/*     */   public GraphMode cycleMode() {
/* 193 */     if (this.modes.size() == 0) {
/* 194 */       return null;
/*     */     }
/* 196 */     if (this.currentMode == null) {
/* 197 */       return setMode((GraphMode)this.modes.get(0));
/*     */     }
/* 199 */     int index = (this.modes.indexOf(this.currentMode) + 1) % this.modes.size();
/* 200 */     return setMode((GraphMode)this.modes.get(index));
/*     */   }
/*     */   
/*     */   protected abstract Rectangle getContainerArea();
/*     */   
/*     */   protected abstract Rectangle generatePreview(GC paramGC, Rectangle paramRectangle, GraphStyleData paramGraphStyleData, boolean paramBoolean);
/*     */   
/*     */   public abstract void zoomGraph(int paramInt, Point paramPoint);
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\AbstractGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */