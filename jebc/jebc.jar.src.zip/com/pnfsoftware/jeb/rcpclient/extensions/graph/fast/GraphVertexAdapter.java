package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;

public class GraphVertexAdapter
  implements IGraphVertexListener
{
  public void onVertexHoverIn(XYGraph graph, P p) {}
  
  public void onVertexHoverOut(XYGraph graph, P p) {}
  
  public void onVertexClicked(XYGraph graph, P p) {}
  
  public void onVertexDoubleClicked(XYGraph graph, P p) {}
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\GraphVertexAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */