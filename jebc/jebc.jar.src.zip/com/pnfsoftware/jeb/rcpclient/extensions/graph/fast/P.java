/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.IGraphNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class P
/*     */   implements IGraphNode
/*     */ {
/*     */   Integer id;
/*     */   double x;
/*     */   double y;
/*     */   
/*     */   public P() {}
/*     */   
/*     */   public P(double x, double y)
/*     */   {
/*  20 */     this.x = x;
/*  21 */     this.y = y;
/*     */   }
/*     */   
/*     */   public P(Integer id, double x, double y) {
/*  25 */     this.id = id;
/*  26 */     this.x = x;
/*  27 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getId()
/*     */   {
/*  32 */     return this.id == null ? -1 : this.id.intValue();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  36 */     this.x = 0.0D;
/*  37 */     this.y = 0.0D;
/*     */   }
/*     */   
/*     */   public void set(double x, double y) {
/*  41 */     this.x = x;
/*  42 */     this.y = y;
/*     */   }
/*     */   
/*     */   public double getX() {
/*  46 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(double x) {
/*  50 */     this.x = x;
/*     */   }
/*     */   
/*     */   public double getY() {
/*  54 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(double y) {
/*  58 */     this.y = y;
/*     */   }
/*     */   
/*     */   public P clone()
/*     */   {
/*  63 */     return new P(this.id, this.x, this.y);
/*     */   }
/*     */   
/*     */   public double dist() {
/*  67 */     if ((this.x == 0.0D) && (this.y == 0.0D)) {
/*  68 */       return 0.0D;
/*     */     }
/*  70 */     return Math.sqrt(this.x * this.x + this.y * this.y);
/*     */   }
/*     */   
/*     */   public double dist(P other) {
/*  74 */     if ((this.x == other.x) && (this.y == other.y)) {
/*  75 */       return 0.0D;
/*     */     }
/*  77 */     return Math.sqrt((this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y));
/*     */   }
/*     */   
/*     */   public double distsquare(P other) {
/*  81 */     if ((this.x == other.x) && (this.y == other.y)) {
/*  82 */       return 0.0D;
/*     */     }
/*  84 */     return (this.x - other.x) * (this.x - other.x) + (this.y - other.y) * (this.y - other.y);
/*     */   }
/*     */   
/*     */   public void add(P other) {
/*  88 */     this.x += other.x;
/*  89 */     this.y += other.y;
/*     */   }
/*     */   
/*     */   public void sub(P other) {
/*  93 */     this.x -= other.x;
/*  94 */     this.y -= other.y;
/*     */   }
/*     */   
/*     */   public void scale(double r) {
/*  98 */     this.x *= r;
/*  99 */     this.y *= r;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 104 */     int prime = 31;
/* 105 */     int result = 1;
/* 106 */     result = 31 * result + (this.id == null ? 0 : this.id.hashCode());
/* 107 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 112 */     if (this == obj)
/* 113 */       return true;
/* 114 */     if (obj == null)
/* 115 */       return false;
/* 116 */     if (getClass() != obj.getClass())
/* 117 */       return false;
/* 118 */     P other = (P)obj;
/* 119 */     if ((this.id == null) || (other.id == null))
/* 120 */       return false;
/* 121 */     return this.id.equals(other.id);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 126 */     if (this.id == null) {
/* 127 */       return String.format("(%f,%f)", new Object[] { Double.valueOf(this.x), Double.valueOf(this.y) });
/*     */     }
/* 129 */     return String.format("%d:(%f,%f)", new Object[] { this.id, Double.valueOf(this.x), Double.valueOf(this.y) });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\P.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */