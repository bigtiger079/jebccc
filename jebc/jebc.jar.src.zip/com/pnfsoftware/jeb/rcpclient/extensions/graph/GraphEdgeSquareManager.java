/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphEdgeSquareManager
/*     */   extends GraphEdgeManager
/*     */ {
/*  22 */   private static final ILogger logger = GlobalLog.getLogger(GraphEdgeSquareManager.class);
/*     */   
/*     */ 
/*  25 */   private int SPACING_MIN = 20;
/*  26 */   private int MARGIN_MIN = 10;
/*     */   
/*  28 */   private int EDGE_SEP = 8;
/*     */   
/*  30 */   private boolean minimizeBlockCrossover = true;
/*  31 */   private boolean preferStraightRouting = true;
/*     */   
/*     */   public GraphEdgeSquareManager(Graph graph) {
/*  34 */     super(graph);
/*     */   }
/*     */   
/*     */   public GraphEdgeSquare create(GraphNode src, GraphNode dst)
/*     */   {
/*  39 */     GraphEdgeSquare edge = new GraphEdgeSquare(this.graph, src, dst);
/*     */     
/*  41 */     return edge;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void draw(GC gc, int redrawCause, Object redrawObject)
/*     */   {
/*  48 */     determineAnchorPoints();
/*     */     
/*  50 */     for (GraphEdge edge : this.graph.getEdges()) {
/*  51 */       drawEdge((GraphEdgeSquare)edge, gc);
/*     */     }
/*     */   }
/*     */   
/*     */   private void determineAnchorPoints()
/*     */   {
/*  57 */     int xdeltasep = this.graph.virtualOrigin.x % this.EDGE_SEP;
/*     */     
/*  59 */     for (GraphNode src : this.graph.getNodes()) {
/*  60 */       List<GraphNode> outnodes = this.graph.getOutNodes(src);
/*  61 */       if (!outnodes.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/*  65 */         orderControls(outnodes, OrderType.CENTER_X);
/*     */         
/*  67 */         int outcnt = outnodes.size();
/*  68 */         Rectangle r0 = src.getBounds();
/*  69 */         int xstart = r0.x + (r0.width - (outcnt - 1) * this.EDGE_SEP) / 2;
/*  70 */         int r = (xstart - xdeltasep) % this.EDGE_SEP;
/*  71 */         if (r != 0) {
/*  72 */           xstart += this.EDGE_SEP - r;
/*     */         }
/*     */         
/*  75 */         int[] xlist = new int[outcnt];
/*  76 */         int i = 0; for (int x = xstart; i < outnodes.size(); x += this.EDGE_SEP) {
/*  77 */           xlist[i] = x;i++;
/*     */         }
/*  79 */         src.setData("outedges_ordered_nodes", outnodes);
/*  80 */         src.setData("outedges_ordered_x", xlist);
/*     */       }
/*     */     }
/*  83 */     for (GraphNode dst : this.graph.getNodes()) {
/*  84 */       List<GraphNode> innodes = this.graph.getInNodes(dst);
/*  85 */       if (!innodes.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/*  89 */         orderControls(innodes, OrderType.CENTER_X);
/*     */         
/*  91 */         int incnt = innodes.size();
/*  92 */         Rectangle r1 = dst.getBounds();
/*  93 */         int xstart = r1.x + (r1.width - (incnt - 1) * this.EDGE_SEP) / 2;
/*  94 */         int r = (xstart - xdeltasep) % this.EDGE_SEP;
/*  95 */         if (r != 0) {
/*  96 */           xstart += this.EDGE_SEP - r;
/*     */         }
/*     */         
/*  99 */         int[] xlist = new int[incnt];
/* 100 */         int i = 0; for (int x = xstart; i < innodes.size(); x += this.EDGE_SEP) {
/* 101 */           xlist[i] = x;i++;
/*     */         }
/* 103 */         dst.setData("inedges_ordered_nodes", innodes);
/* 104 */         dst.setData("inedges_ordered_x", xlist);
/*     */       }
/*     */     }
/*     */     
/* 108 */     for (GraphNode src : this.graph.getNodes()) {
/* 109 */       List<GraphNode> outnodes = (List)src.getData("outedges_ordered_nodes");
/* 110 */       if ((outnodes != null) && (outnodes.size() == 2))
/*     */       {
/*     */ 
/*     */ 
/* 114 */         GraphNode dst0 = (GraphNode)outnodes.get(0);
/* 115 */         GraphNode dst1 = (GraphNode)outnodes.get(1);
/*     */         
/* 117 */         Rectangle a = src.getBounds();
/* 118 */         int a_x0 = a.x;
/* 119 */         int a_y0 = a.y;
/* 120 */         int a_x1 = a.x + a.width;
/* 121 */         int a_y1 = a.y + a.height;
/* 122 */         int a_xcenter = a.x + a.width / 2;
/*     */         
/* 124 */         int[] dirs = new int[2];
/* 125 */         int i = 0;
/* 126 */         for (GraphNode dst : outnodes) {
/* 127 */           Rectangle b = dst.getBounds();
/* 128 */           int b_x0 = b.x;
/* 129 */           int b_y0 = b.y;
/* 130 */           int b_x1 = b.x + b.width;
/* 131 */           int b_y1 = b.y + b.height;
/* 132 */           int b_xcenter = b.x + b.width / 2;
/*     */           
/* 134 */           boolean xOverlap = ((b_x0 <= a.x) && (b_x1 > a.x)) || ((b_x0 <= a_x1) && (b_x1 > a_x1)) || ((b_x0 >= a.x) && (b_x1 <= a_x1));
/*     */           
/*     */ 
/* 137 */           if ((b_y0 - a_y1 >= this.SPACING_MIN) || ((b_y0 - a_y1 >= 0) && (xOverlap))) {
/* 138 */             dirs[i] = 0;
/* 139 */             if ((this.minimizeBlockCrossover) && 
/* 140 */               (this.graph.optCheckAvoidVerticalLineOverlapWithNodes(a_xcenter, a_y1, b_y0))) {
/* 141 */               dirs[i] = 10;
/*     */             }
/*     */           }
/* 144 */           else if (b_x0 > a_x1 + 2 * this.MARGIN_MIN) {
/* 145 */             dirs[i] = 1;
/*     */           }
/* 147 */           else if (b_x1 + 2 * this.MARGIN_MIN < a_x0) {
/* 148 */             dirs[i] = -1;
/*     */           }
/* 150 */           else if (b_xcenter >= a_xcenter) {
/* 151 */             dirs[i] = 1;
/*     */           }
/*     */           else {
/* 154 */             dirs[i] = -1;
/*     */           }
/* 156 */           i++;
/*     */         }
/*     */         
/* 159 */         boolean flip = false;
/*     */         
/* 161 */         if (((dirs[0] == 1) && (dirs[1] == 0)) || ((dirs[0] == 1) && (dirs[1] == -1)) || ((dirs[0] == 0) && (dirs[1] == -1)) || ((dirs[0] == 1) && (dirs[1] == -1))) {
/* 162 */           flip = true;
/*     */ 
/*     */         }
/* 165 */         else if ((dirs[0] == 10) && (dirs[1] == 0)) {
/* 166 */           flip = true;
/*     */ 
/*     */         }
/* 169 */         else if ((dirs[0] == 0) && (dirs[1] == 0)) {
/* 170 */           int dst0x = getCenterX(dst0);
/* 171 */           int dst1x = getCenterX(dst1);
/* 172 */           int dst0y = getCenterY(dst0);
/* 173 */           int dst1y = getCenterY(dst1);
/*     */           
/* 175 */           if (((dst0y >= dst1y) || (dst0x >= a_xcenter)) && ((dst1y >= dst0y) || (dst1x <= a_xcenter))) {
/* 176 */             flip = true;
/*     */           }
/*     */         }
/* 179 */         if (flip) {
/* 180 */           List<GraphNode> outedges_ordered_nodes = (List)src.getData("outedges_ordered_nodes");
/* 181 */           Collections.reverse(outedges_ordered_nodes);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void drawEdge(GraphEdgeSquare edge, GC gc)
/*     */   {
/* 192 */     if ((edge.srcAnchor != Anchor.BOTTOM) || (edge.dstAnchor != Anchor.TOP)) {
/* 193 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 196 */     Rectangle a = edge.src.getBounds();
/* 197 */     Rectangle b = edge.dst.getBounds();
/*     */     
/* 199 */     int a_x0 = a.x;
/*     */     
/* 201 */     int b_x0 = b.x;
/* 202 */     int b_y0 = b.y;
/* 203 */     int a_x1 = a.x + a.width;
/* 204 */     int a_y1 = a.y + a.height;
/* 205 */     int b_x1 = b.x + b.width;
/* 206 */     int b_y1 = b.y + b.height;
/* 207 */     int a_xcenter = a.x + a.width / 2;
/* 208 */     int b_xcenter = b.x + b.width / 2;
/*     */     
/*     */ 
/* 211 */     boolean xOverlap = ((b_x0 <= a.x) && (b_x1 > a.x)) || ((b_x0 <= a_x1) && (b_x1 > a_x1)) || ((b_x0 >= a.x) && (b_x1 <= a_x1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     List<GraphNode> outnodes = (List)edge.src.getData("outedges_ordered_nodes");
/* 217 */     int[] xlist = (int[])edge.src.getData("outedges_ordered_x");
/* 218 */     int x0 = xlist[outnodes.indexOf(edge.dst)];
/*     */     
/* 220 */     List<GraphNode> innodes = (List)edge.dst.getData("inedges_ordered_nodes");
/* 221 */     xlist = (int[])edge.dst.getData("inedges_ordered_x");
/* 222 */     int x1 = xlist[innodes.indexOf(edge.src)];
/*     */     
/* 224 */     int originalX0 = x0;
/* 225 */     int originalX1 = x1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 230 */     if ((b_y0 - a_y1 >= this.SPACING_MIN) || ((b_y0 - a_y1 >= 0) && (xOverlap)))
/*     */     {
/* 232 */       int yi = this.graph.requestHorizontalLine(x0, x1, b_y0 - this.MARGIN_MIN, -this.EDGE_SEP);
/* 233 */       x0 = this.graph.requestVerticalLine(a_y1, yi, x0, this.EDGE_SEP);
/* 234 */       x1 = this.graph.requestVerticalLine(yi, b_y0, x1, this.EDGE_SEP);
/*     */       
/* 236 */       int[] r = null;
/* 237 */       if (this.minimizeBlockCrossover) {
/* 238 */         r = this.graph.optAvoidVerticalLineOverlapWithNodes(x0, a_y1, yi, this.MARGIN_MIN);
/*     */       }
/* 240 */       if (r != null) {
/* 241 */         int yE = r[0];
/* 242 */         int xE = r[1];
/* 243 */         int yE1 = r[2];
/*     */         
/* 245 */         this.graph.releaseHorizontalLine(originalX0, originalX1, yi);
/*     */         
/* 247 */         yE = this.graph.requestHorizontalLine(x0, xE, yE, -this.EDGE_SEP);
/* 248 */         xE = this.graph.requestVerticalLine(yE, yE1, xE, this.EDGE_SEP);
/* 249 */         yE1 = this.graph.requestHorizontalLine(xE, x1, yE1, this.EDGE_SEP);
/*     */         
/* 251 */         this.graph.releaseVerticalLine(yi, b_y0, x1);
/* 252 */         x1 = this.graph.requestVerticalLine(yE1, b_y0, x1, this.EDGE_SEP);
/*     */         
/* 254 */         this.graph.releaseVerticalLine(a_y1, yi, x0);
/* 255 */         x0 = this.graph.requestVerticalLine(a_y1, yE, x0, this.EDGE_SEP);
/*     */         
/* 257 */         edge.drawLine(gc, x0, a_y1, x0, yE);
/* 258 */         edge.drawLine(gc, x0, yE, xE, yE);
/* 259 */         edge.drawLine(gc, xE, yE, xE, yE1);
/* 260 */         edge.drawLine(gc, xE, yE1, x1, yE1);
/* 261 */         edge.drawLine(gc, x1, yE1, x1, b_y0);
/*     */       }
/*     */       else
/*     */       {
/* 265 */         if ((this.preferStraightRouting) && (x0 != x1) && (Math.abs(x0 - x1) < this.SPACING_MIN) && (x0 > b_x0) && (x0 < b_x1)) {
/* 266 */           this.graph.releaseHorizontalLine(originalX0, originalX1, yi);
/* 267 */           this.graph.releaseVerticalLine(a_y1, yi, x0);
/* 268 */           this.graph.releaseVerticalLine(yi, b_y0, x1);
/*     */           
/* 270 */           x0 = this.graph.requestVerticalLine(a_y1, b_y0, x0, this.EDGE_SEP);
/* 271 */           x1 = x0;
/*     */         }
/*     */         
/* 274 */         if (x1 != x0) {
/* 275 */           edge.drawLine(gc, x0, a_y1, x0, yi);
/* 276 */           edge.drawLine(gc, x0, yi, x1, yi);
/* 277 */           edge.drawLine(gc, x1, yi, x1, b_y0);
/*     */         }
/*     */         else {
/* 280 */           edge.drawLine(gc, x0, a_y1, x0, b_y0);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       int adjxi;
/*     */       
/*     */       int adjx0;
/*     */       
/*     */       int adjx1;
/*     */       
/*     */       int adjxi;
/* 293 */       if (b_x0 > a_x1 + 2 * this.MARGIN_MIN) {
/* 294 */         int xi = b_x0 - this.MARGIN_MIN;
/* 295 */         int yi = a_y1 + this.MARGIN_MIN;
/* 296 */         int yj = b_y0 - this.MARGIN_MIN;
/* 297 */         int adjx0 = 1;
/* 298 */         int adjx1 = -1;
/* 299 */         adjxi = -1;
/*     */       } else { int adjxi;
/* 301 */         if (b_x1 + 2 * this.MARGIN_MIN < a_x0) {
/* 302 */           int xi = b_x1 + this.MARGIN_MIN;
/* 303 */           int yi = a_y1 + this.MARGIN_MIN;
/* 304 */           int yj = b_y0 - this.MARGIN_MIN;
/* 305 */           int adjx0 = -1;
/* 306 */           int adjx1 = 1;
/* 307 */           adjxi = 1;
/*     */         } else { int adjxi;
/* 309 */           if (b_xcenter >= a_xcenter) {
/* 310 */             int xi = Math.max(b_x1 + this.MARGIN_MIN, a_x1 + this.MARGIN_MIN);
/* 311 */             int yi = Math.max(a_y1 + this.MARGIN_MIN, b_y1 + this.MARGIN_MIN);
/* 312 */             int yj = b_y0 - this.MARGIN_MIN;
/* 313 */             int adjx0 = 1;
/* 314 */             int adjx1 = 1;
/* 315 */             adjxi = 1;
/*     */           }
/*     */           else {
/* 318 */             xi = Math.min(b_x0 - this.MARGIN_MIN, a_x0 - this.MARGIN_MIN);
/* 319 */             yi = Math.max(a_y1 + this.MARGIN_MIN, b_y1 + this.MARGIN_MIN);
/* 320 */             yj = b_y0 - this.MARGIN_MIN;
/* 321 */             adjx0 = -1;
/* 322 */             adjx1 = -1;
/* 323 */             adjxi = -1;
/*     */           }
/*     */         } }
/* 326 */       x0 = this.graph.requestVerticalLine(a_y1, yi, x0, adjx0 * this.EDGE_SEP);
/* 327 */       x1 = this.graph.requestVerticalLine(yj, b_y0, x1, adjx1 * this.EDGE_SEP);
/*     */       
/* 329 */       int yi = this.graph.requestHorizontalLine(x0, xi, yi, this.EDGE_SEP);
/* 330 */       int yj = this.graph.requestHorizontalLine(xi, x1, yj, -this.EDGE_SEP);
/*     */       
/*     */ 
/* 333 */       int xi = this.graph.requestVerticalLine(yi, yj, xi, adjxi * this.EDGE_SEP);
/*     */       
/* 335 */       edge.drawLine(gc, x0, a_y1, x0, yi);
/* 336 */       edge.drawLine(gc, x0, yi, xi, yi);
/* 337 */       edge.drawLine(gc, xi, yi, xi, yj);
/* 338 */       edge.drawLine(gc, xi, yj, x1, yj);
/* 339 */       edge.drawLine(gc, x1, yj, x1, b_y0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 344 */     edge.drawArrow(gc, x1, b_y0 - 1, x1, b_y0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum OrderType
/*     */   {
/* 352 */     TOP,  CENTER_Y,  BOTTOM,  LEFT,  CENTER_X,  RIGHT;
/*     */     
/*     */     private OrderType() {} }
/* 355 */   static final Comparator<Control> cmpTop = new Comparator()
/*     */   {
/*     */     public int compare(Control o1, Control o2) {
/* 358 */       return o1.getLocation().y - o2.getLocation().y;
/*     */     }
/*     */   };
/*     */   
/* 362 */   static final Comparator<Control> cmpCenterY = new Comparator()
/*     */   {
/*     */     public int compare(Control o1, Control o2) {
/* 365 */       return GraphEdgeSquareManager.getCenterY(o1) - GraphEdgeSquareManager.getCenterY(o2);
/*     */     }
/*     */   };
/*     */   
/* 369 */   static final Comparator<Control> cmpLeft = new Comparator()
/*     */   {
/*     */     public int compare(Control o1, Control o2) {
/* 372 */       return o1.getLocation().x - o2.getLocation().x;
/*     */     }
/*     */   };
/*     */   
/* 376 */   static final Comparator<Control> cmpCenterX = new Comparator()
/*     */   {
/*     */     public int compare(Control o1, Control o2) {
/* 379 */       return GraphEdgeSquareManager.getCenterX(o1) - GraphEdgeSquareManager.getCenterX(o2);
/*     */     }
/*     */   };
/*     */   
/*     */   static void orderControls(List<? extends Control> nodes, OrderType comparePoint) {
/* 384 */     switch (comparePoint) {
/*     */     case TOP: 
/* 386 */       Collections.sort(nodes, cmpTop);
/* 387 */       break;
/*     */     case CENTER_Y: 
/* 389 */       Collections.sort(nodes, cmpCenterY);
/* 390 */       break;
/*     */     case LEFT: 
/* 392 */       Collections.sort(nodes, cmpLeft);
/* 393 */       break;
/*     */     case CENTER_X: 
/* 395 */       Collections.sort(nodes, cmpCenterX);
/* 396 */       break;
/*     */     default: 
/* 398 */       throw new RuntimeException("Not supported: " + comparePoint);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getCenterX(Control ctl) {
/* 403 */     Rectangle r = ctl.getBounds();
/* 404 */     return r.x + r.width / 2;
/*     */   }
/*     */   
/*     */   public static int getCenterY(Control ctl) {
/* 408 */     Rectangle r = ctl.getBounds();
/* 409 */     return r.y + r.height / 2;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphEdgeSquareManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */