/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.model;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class V
/*    */ {
/*    */   int index;
/*    */   final int id;
/*    */   public Double weight;
/*    */   public String label;
/*    */   public Double score;
/*    */   public Double vcscore;
/*    */   
/*    */   V(int index, int id, Double weight, String label)
/*    */   {
/* 30 */     this.index = index;
/* 31 */     this.id = id;
/* 32 */     this.weight = weight;
/* 33 */     this.label = label;
/*    */   }
/*    */   
/*    */   V(int index, int id) {
/* 37 */     this(index, id, null, null);
/*    */   }
/*    */   
/*    */   V(int index) {
/* 41 */     this(index, index, null, null);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 45 */     return this.id;
/*    */   }
/*    */   
/*    */   public Double getWeight() {
/* 49 */     return this.weight;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 53 */     return this.label;
/*    */   }
/*    */   
/*    */   public void setLabel(String label) {
/* 57 */     this.label = label;
/*    */   }
/*    */   
/*    */   public V clone()
/*    */   {
/* 62 */     V v = new V(this.index, this.id, this.weight, this.label);
/* 63 */     v.score = this.score;
/* 64 */     v.vcscore = this.vcscore;
/* 65 */     return v;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 70 */     if (Strings.isBlank(this.label)) {
/* 71 */       return Integer.toString(this.id);
/*    */     }
/*    */     
/* 74 */     return this.label;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\model\V.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */