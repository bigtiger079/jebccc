/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.FormAttachment;
/*     */ import org.eclipse.swt.layout.FormData;
/*     */ import org.eclipse.swt.layout.FormLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Combo;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.ToolBar;
/*     */ import org.eclipse.swt.widgets.ToolItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GraphPlaceholder<G extends AbstractGraph>
/*     */   extends Composite
/*     */ {
/*     */   G graph;
/*     */   GraphPreview<G> preview;
/*     */   ToolBar toolbar;
/*     */   
/*     */   public GraphPlaceholder(Composite parent, int style, boolean createPreview, boolean createToolbar)
/*     */   {
/*  48 */     super(parent, style);
/*     */     
/*  50 */     FormLayout layout = new FormLayout();
/*  51 */     setLayout(layout);
/*     */     
/*  53 */     this.graph = createGraph(this, null);
/*  54 */     attachGraph();
/*     */     
/*  56 */     if (createPreview) {
/*  57 */       this.preview = new GraphPreview(this, 2048, true);
/*  58 */       this.preview.moveAbove(this.graph);
/*  59 */       this.preview.setGraph(this.graph);
/*  60 */       FormData formData = new FormData();
/*  61 */       formData.top = new FormAttachment(0, 0);
/*  62 */       formData.left = new FormAttachment(0, 0);
/*  63 */       formData.bottom = new FormAttachment(10, 0);
/*  64 */       formData.right = new FormAttachment(10, 0);
/*  65 */       this.preview.setLayoutData(formData);
/*     */     }
/*     */     
/*  68 */     if (createToolbar) {
/*  69 */       this.toolbar = new ToolBar(this, 320);
/*  70 */       this.toolbar.moveAbove(this.graph);
/*  71 */       FormData formData = new FormData();
/*  72 */       formData.top = new FormAttachment(0, 0);
/*  73 */       formData.left = (this.preview == null ? new FormAttachment(0, 0) : new FormAttachment(this.preview));
/*  74 */       formData.right = new FormAttachment(100, 0);
/*  75 */       this.toolbar.setLayoutData(formData);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract G createGraph(GraphPlaceholder<G> paramGraphPlaceholder, G paramG);
/*     */   
/*     */   private void attachGraph() {
/*  82 */     FormData formData = new FormData();
/*  83 */     formData.top = new FormAttachment(0, 0);
/*  84 */     formData.left = new FormAttachment(0, 0);
/*  85 */     formData.bottom = new FormAttachment(100, 0);
/*  86 */     formData.right = new FormAttachment(100, 0);
/*  87 */     this.graph.setLayoutData(formData);
/*     */   }
/*     */   
/*     */   public G getGraph() {
/*  91 */     return this.graph;
/*     */   }
/*     */   
/*     */   public GraphPreview<G> getGraphPreview() {
/*  95 */     return this.preview;
/*     */   }
/*     */   
/*     */   public ToolBar getToolbar() {
/*  99 */     return this.toolbar;
/*     */   }
/*     */   
/*     */   public boolean setFocus()
/*     */   {
/* 104 */     return this.graph.setFocus();
/*     */   }
/*     */   
/*     */   public G reset() {
/* 108 */     if (this.graph != null) {
/* 109 */       this.graph.dispose();
/* 110 */       this.graph = null;
/*     */     }
/* 112 */     this.graph = createGraph(this, this.graph);
/* 113 */     attachGraph();
/* 114 */     if (this.preview != null) {
/* 115 */       this.preview.setGraph(this.graph);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     return this.graph;
/*     */   }
/*     */   
/*     */   private void verifyPreview()
/*     */   {
/* 128 */     if (this.preview == null) {
/* 129 */       throw new IllegalStateException("There is no preview widget");
/*     */     }
/*     */   }
/*     */   
/*     */   private void verifyToolbar() {
/* 134 */     if (this.toolbar == null) {
/* 135 */       throw new IllegalStateException("There is no toolbar widget");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */   public static final String standardHepMessage = "Standard graph controls:\n\n" + UI.MOD1 + "+Wheel ... Zoom in or out\n] ... Zoom in\n[ ... Zoom out\n" + UI.MOD1 + "+\\ (slash) ... Reset zoom\n\\ (slash) ... Center the graph\nClick on Edge ... Go to the destination node\n" + UI.MOD1 + "+Click on Edge ... Go to the source node\n";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolItem addHelpButtonToToolbar(String msg)
/*     */   {
/* 192 */     verifyToolbar();
/* 193 */     final String msg0 = Strings.safe(msg, standardHepMessage);
/* 194 */     ToolItem item = new ToolItem(this.toolbar, 8);
/* 195 */     item.setText("Help");
/* 196 */     item.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 199 */         UI.info(null, "Help", msg0);
/*     */       }
/* 201 */     });
/* 202 */     return item;
/*     */   }
/*     */   
/*     */   public Combo addComboBox(List<String> entries, int initialSelection) {
/* 206 */     verifyToolbar();
/* 207 */     ToolItem item = new ToolItem(this.toolbar, 2);
/* 208 */     item = new ToolItem(this.toolbar, 2);
/* 209 */     Combo w = new Combo(this.toolbar, 8);
/* 210 */     for (String entry : entries) {
/* 211 */       w.add(entry);
/*     */     }
/* 213 */     w.select(initialSelection);
/* 214 */     w.pack();
/* 215 */     item.setWidth(w.getSize().x);
/* 216 */     item.setControl(w);
/* 217 */     return w;
/*     */   }
/*     */   
/*     */   public Button addPushbox(String name) {
/* 221 */     verifyToolbar();
/* 222 */     ToolItem item = new ToolItem(this.toolbar, 2);
/* 223 */     item = new ToolItem(this.toolbar, 2);
/* 224 */     Button w = new Button(this.toolbar, 8);
/* 225 */     w.setText(name);
/* 226 */     w.pack();
/* 227 */     item.setWidth(w.getSize().x);
/* 228 */     item.setControl(w);
/* 229 */     return w;
/*     */   }
/*     */   
/*     */   public Button addCheckbox(String name, boolean initialState) {
/* 233 */     verifyToolbar();
/* 234 */     ToolItem item = new ToolItem(this.toolbar, 2);
/* 235 */     item = new ToolItem(this.toolbar, 2);
/* 236 */     Button w = new Button(this.toolbar, 32);
/* 237 */     w.setText(name);
/* 238 */     w.setSelection(initialState);
/* 239 */     w.pack();
/* 240 */     item.setWidth(w.getSize().x);
/* 241 */     item.setControl(w);
/* 242 */     return w;
/*     */   }
/*     */   
/*     */   public void addModesBoxToToolbar()
/*     */   {
/* 247 */     List<String> modenames = new ArrayList();
/* 248 */     for (GraphMode mode : this.graph.getSupportedModes()) {
/* 249 */       modenames.add(mode.getName());
/*     */     }
/* 251 */     addComboBox(modenames, 0).addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/* 254 */         if (GraphPlaceholder.this.graph == null) {
/* 255 */           return;
/*     */         }
/* 257 */         int index = ((Combo)e.widget).getSelectionIndex();
/* 258 */         if ((index < 0) || (index >= GraphPlaceholder.this.graph.getSupportedModes().size())) {
/* 259 */           return;
/*     */         }
/* 261 */         GraphPlaceholder.this.graph.setMode((GraphMode)GraphPlaceholder.this.graph.getSupportedModes().get(index));
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphPlaceholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */