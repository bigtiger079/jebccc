/*      */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.fast;
/*      */ 
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.AbstractGraph;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.GraphStyleData;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.model.ILabelProvider;
/*      */ import com.pnfsoftware.jeb.util.base.Assert;
/*      */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*      */ import com.pnfsoftware.jeb.util.format.Strings;
/*      */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*      */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.eclipse.swt.SWTException;
/*      */ import org.eclipse.swt.events.ControlAdapter;
/*      */ import org.eclipse.swt.events.ControlEvent;
/*      */ import org.eclipse.swt.events.MouseAdapter;
/*      */ import org.eclipse.swt.events.MouseEvent;
/*      */ import org.eclipse.swt.events.MouseMoveListener;
/*      */ import org.eclipse.swt.events.PaintEvent;
/*      */ import org.eclipse.swt.events.PaintListener;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XYGraph
/*      */   extends AbstractGraph
/*      */ {
/*   54 */   private static final ILogger logger = GlobalLog.getLogger(XYGraph.class);
/*      */   
/*      */   public static final double DEFAULT_ZOOM_LEVEL_IN = 0.8D;
/*      */   
/*      */   public static final double DEFAULT_ZOOM_LEVEL_OUT = 1.2D;
/*      */   
/*      */   private static final long DEFAULT_ACTIVE_VERTEX_ANIMATION_PERIOD_MS = 600L;
/*      */   
/*      */   private static final long DEFAULT_DRAG_ANIMATION_PERIOD_MS = 50L;
/*      */   
/*   64 */   private List<IGraphVertexListener> vertexListeners = new ArrayList();
/*   65 */   private List<IGraphBoundsListener> boundsListeners = new ArrayList();
/*      */   
/*      */   private Thread aniThread;
/*      */   
/*      */   private boolean directed;
/*      */   
/*   71 */   private Map<Integer, P> pointmap = new HashMap();
/*   72 */   private List<L> lines = new ArrayList();
/*      */   private P selectedVertex;
/*      */   private P hoveredVertex;
/*   75 */   private Collection<P> visiblePoints = new HashSet();
/*   76 */   private Collection<L> visibleLines = new HashSet();
/*      */   
/*      */   private Map<Integer, Point> pointsCoordMap;
/*      */   
/*   80 */   protected Set<P> activePoints = new HashSet();
/*   81 */   protected Set<Integer> activeVertices = new HashSet();
/*   82 */   protected Set<L> activeLines = new HashSet();
/*      */   private volatile int activeState;
/*   84 */   private volatile boolean activeNodeAnimationEnabled = true;
/*      */   
/*      */   private ILabelProvider labelProvider;
/*      */   
/*   88 */   private Rectangle clientArea = new Rectangle(0, 0, 0, 0);
/*      */   private double gx;
/*      */   private double gy;
/*      */   private double gw;
/*      */   private double gh;
/*   93 */   private P mouseCoord = new P();
/*      */   
/*      */   private boolean dragging;
/*   96 */   private Point dragPoint = new Point(0, 0);
/*   97 */   private Point mouseDownPoint = new Point(0, 0);
/*   98 */   private Point mousePoint = new Point(0, 0);
/*      */   
/*  100 */   private boolean trackVertexHovering = true;
/*      */   
/*      */   public XYGraph(Composite parent) {
/*  103 */     super(parent, 536870912);
/*  104 */     setLayout(null);
/*      */     
/*      */ 
/*  107 */     this.clientArea = getClientArea();
/*      */     
/*  109 */     UI.initialize();
/*      */     
/*  111 */     addControlListener(new ControlAdapter()
/*      */     {
/*      */       public void controlResized(ControlEvent e) {
/*  114 */         XYGraph.this.clientArea = XYGraph.this.getClientArea();
/*  115 */         XYGraph.this.adjustGraphBounds();
/*      */       }
/*      */       
/*  118 */     });
/*  119 */     addPaintListener(new PaintListener()
/*      */     {
/*      */       public void paintControl(PaintEvent e) {
/*  122 */         GC gc = e.gc;
/*      */         try {
/*  124 */           gc.setAntialias(1);
/*      */         }
/*      */         catch (SWTException localSWTException) {}
/*      */         
/*      */ 
/*  129 */         Map<Integer, Point> m = XYGraph.this.getVertexViewportCoordinates();
/*      */         
/*  131 */         XYGraph.this.visiblePoints = XYGraph.this.determineVisibleVertices(XYGraph.this.pointmap.values());
/*  132 */         XYGraph.this.visibleLines = XYGraph.this.determineVisibleEdges(XYGraph.this.visiblePoints, XYGraph.this.lines);
/*      */         
/*  134 */         XYGraph.this.preDrawing(gc);
/*      */         
/*      */ 
/*  137 */         XYGraph.this.preEdgesDrawing(gc);
/*  138 */         for (L line : XYGraph.this.visibleLines) {
/*  139 */           Point a = (Point)m.get(Integer.valueOf(line.getSrcId()));
/*  140 */           Point b = (Point)m.get(Integer.valueOf(line.getDstId()));
/*  141 */           XYGraph.this.drawEdge(gc, line, a, b);
/*      */         }
/*  143 */         XYGraph.this.postEdgesDrawing(gc);
/*      */         
/*      */ 
/*  146 */         XYGraph.this.preVerticesDrawing(gc);
/*  147 */         for (P p : XYGraph.this.visiblePoints) {
/*  148 */           Point pt = (Point)m.get(Integer.valueOf(p.getId()));
/*  149 */           XYGraph.this.drawVertex(gc, p, pt);
/*      */         }
/*  151 */         XYGraph.this.postVerticesDrawing(gc);
/*      */         
/*      */ 
/*  154 */         XYGraph.this.preVertexLabelsDrawing(gc);
/*  155 */         for (P p : XYGraph.this.visiblePoints) {
/*  156 */           Point pt = (Point)m.get(Integer.valueOf(p.getId()));
/*  157 */           XYGraph.this.drawVertexLabel(gc, p, pt);
/*      */         }
/*  159 */         XYGraph.this.postVertexLabelsDrawing(gc);
/*      */         
/*  161 */         XYGraph.this.postDrawing(gc);
/*      */       }
/*      */       
/*      */ 
/*  165 */     });
/*  166 */     addMouseListener(new MouseAdapter()
/*      */     {
/*      */       public void mouseDoubleClick(MouseEvent e) {
/*  169 */         if (e.button != 1) {
/*  170 */           return;
/*      */         }
/*      */         
/*  173 */         if (XYGraph.this.hoveredVertex != null) {
/*  174 */           XYGraph.this.notifyVertexDoubleClicked(XYGraph.this.hoveredVertex);
/*      */         }
/*      */       }
/*      */       
/*      */       public void mouseDown(MouseEvent e)
/*      */       {
/*  180 */         if (e.button != 1) {
/*  181 */           return;
/*      */         }
/*      */         
/*  184 */         XYGraph.this.mouseDownPoint.x = e.x;
/*  185 */         XYGraph.this.mouseDownPoint.y = e.y;
/*      */         
/*  187 */         XYGraph.this.dragging = true;
/*  188 */         XYGraph.this.dragPoint.x = e.x;
/*  189 */         XYGraph.this.dragPoint.y = e.y;
/*      */       }
/*      */       
/*      */       public void mouseUp(MouseEvent e)
/*      */       {
/*  194 */         if (e.button != 1) {
/*  195 */           return;
/*      */         }
/*      */         
/*  198 */         if ((XYGraph.this.mouseDownPoint != null) && (new Point(e.x, e.y).equals(XYGraph.this.mouseDownPoint)))
/*      */         {
/*  200 */           if (XYGraph.this.hoveredVertex != null) {
/*  201 */             XYGraph.this.selectedVertex = XYGraph.this.hoveredVertex;
/*  202 */             XYGraph.this.refreshGraph();
/*  203 */             XYGraph.this.notifyVertexClicked(XYGraph.this.selectedVertex);
/*      */           }
/*      */         }
/*  206 */         XYGraph.this.dragging = false;
/*      */       }
/*  208 */     });
/*  209 */     addMouseMoveListener(new MouseMoveListener()
/*      */     {
/*      */       public void mouseMove(MouseEvent e)
/*      */       {
/*  213 */         XYGraph.this.mousePoint.x = e.x;
/*  214 */         XYGraph.this.mousePoint.y = e.y;
/*  215 */         XYGraph.this.mouseCoord = XYGraph.this.convertCoord(XYGraph.this.mousePoint);
/*      */         
/*  217 */         if (XYGraph.this.dragging) {
/*  218 */           int deltaX = e.x - XYGraph.this.dragPoint.x;
/*  219 */           int deltaY = e.y - XYGraph.this.dragPoint.y;
/*  220 */           XYGraph.this.dragPoint.x = e.x;
/*  221 */           XYGraph.this.dragPoint.y = e.y;
/*  222 */           XYGraph.this.dragGraph(deltaX, deltaY);
/*      */ 
/*      */         }
/*  225 */         else if (XYGraph.this.trackVertexHovering) {
/*  226 */           P closestVertex = XYGraph.this.findClosestVertex(XYGraph.this.mouseCoord, XYGraph.this.visiblePoints);
/*  227 */           if (closestVertex != null) {
/*  228 */             double dist = closestVertex.dist(XYGraph.this.mouseCoord);
/*  229 */             double distPx = dist * XYGraph.this.clientArea.width / XYGraph.this.gw;
/*  230 */             if (distPx > 20.0D) {
/*  231 */               closestVertex = null;
/*      */             }
/*      */           }
/*      */           
/*  235 */           if ((XYGraph.this.hoveredVertex != null) && (closestVertex != XYGraph.this.hoveredVertex)) {
/*  236 */             XYGraph.this.notifyVertexHoverOut(XYGraph.this.hoveredVertex);
/*      */           }
/*  238 */           XYGraph.this.hoveredVertex = null;
/*  239 */           if (closestVertex != null) {
/*  240 */             XYGraph.this.hoveredVertex = closestVertex;
/*  241 */             XYGraph.this.notifyVertexHoverIn(XYGraph.this.hoveredVertex);
/*      */           }
/*  243 */           XYGraph.this.redraw();
/*      */         }
/*      */         
/*      */       }
/*  247 */     });
/*  248 */     this.aniThread = ThreadUtil.start(new Runnable() {
/*      */       public void run() {
/*      */         for (;;) {
/*  251 */           if (!XYGraph.this.isDisposed()) {
/*      */             try {
/*  253 */               Thread.sleep(600L);
/*      */             }
/*      */             catch (InterruptedException e)
/*      */             {
/*      */               return;
/*      */             }
/*  259 */             if ((XYGraph.this.activeNodeAnimationEnabled) && (
/*      */             
/*      */ 
/*      */ 
/*  263 */               (!XYGraph.this.activePoints.isEmpty()) || (!XYGraph.this.activeLines.isEmpty())))
/*      */             {
/*      */               try
/*      */               {
/*      */ 
/*  268 */                 if (!XYGraph.this.getDisplay().isDisposed())
/*      */                 {
/*      */ 
/*      */ 
/*  272 */                   XYGraph.this.getDisplay().syncExec(new Runnable()
/*      */                   {
/*      */                     public void run() {
/*  275 */                       if (!XYGraph.this.isDisposed()) {
/*  276 */                         XYGraph.this.redraw();
/*  277 */                         XYGraph.this.activeState = (1 - XYGraph.this.activeState);
/*      */                       }
/*      */                     }
/*      */                   });
/*      */                 }
/*      */               }
/*      */               catch (SWTException e) {}
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   public void dispose()
/*      */   {
/*  293 */     if (this.aniThread != null) {
/*  294 */       this.aniThread.interrupt();
/*  295 */       this.aniThread = null;
/*      */     }
/*  297 */     super.dispose();
/*      */   }
/*      */   
/*      */   public void reset() {
/*  301 */     this.pointmap.clear();
/*  302 */     this.lines.clear();
/*      */     
/*  304 */     this.selectedVertex = null;
/*  305 */     this.hoveredVertex = null;
/*  306 */     this.visiblePoints.clear();
/*  307 */     this.visibleLines.clear();
/*      */     
/*  309 */     this.pointsCoordMap = null;
/*      */     
/*  311 */     this.activePoints.clear();
/*  312 */     this.activeVertices.clear();
/*  313 */     this.activeLines.clear();
/*      */     
/*  315 */     this.labelProvider = null;
/*      */   }
/*      */   
/*      */   public int getVertexCount()
/*      */   {
/*  320 */     return this.pointmap.size();
/*      */   }
/*      */   
/*      */   public Collection<P> getPoints() {
/*  324 */     return this.pointmap.values();
/*      */   }
/*      */   
/*      */   public Collection<P> getVisiblePoints() {
/*  328 */     return this.visiblePoints;
/*      */   }
/*      */   
/*      */   public boolean isVertexVisible(int vertexId) {
/*  332 */     for (P p : this.visiblePoints) {
/*  333 */       if (p.id.intValue() == vertexId) {
/*  334 */         return true;
/*      */       }
/*      */     }
/*  337 */     return false;
/*      */   }
/*      */   
/*      */   public int getEdgeCount()
/*      */   {
/*  342 */     return this.lines.size();
/*      */   }
/*      */   
/*      */   public Collection<L> getLines() {
/*  346 */     return this.lines;
/*      */   }
/*      */   
/*      */   public Collection<L> getVisibleLines() {
/*  350 */     return this.visibleLines;
/*      */   }
/*      */   
/*      */   public Rectangle getContainerArea()
/*      */   {
/*  355 */     int xmin = Integer.MAX_VALUE;
/*  356 */     int ymin = Integer.MAX_VALUE;
/*  357 */     int xmax = Integer.MIN_VALUE;
/*  358 */     int ymax = Integer.MIN_VALUE;
/*  359 */     Map<Integer, Point> m = getVertexViewportCoordinates();
/*  360 */     for (Point pt : m.values()) {
/*  361 */       if (pt.x < xmin) {
/*  362 */         xmin = pt.x;
/*      */       }
/*  364 */       if (pt.x > xmax) {
/*  365 */         xmax = pt.x;
/*      */       }
/*  367 */       if (pt.y < ymin) {
/*  368 */         ymin = pt.y;
/*      */       }
/*  370 */       if (pt.y > ymax) {
/*  371 */         ymax = pt.y;
/*      */       }
/*      */     }
/*  374 */     return new Rectangle(xmin, ymin, xmax - xmin, ymax - ymin);
/*      */   }
/*      */   
/*      */   public P getSelectedPoint() {
/*  378 */     return this.selectedVertex;
/*      */   }
/*      */   
/*      */   public void setSelectedPoint(P p) {
/*  382 */     this.selectedVertex = p;
/*      */   }
/*      */   
/*      */   public Integer getSelection() {
/*  386 */     return this.selectedVertex == null ? null : this.selectedVertex.id;
/*      */   }
/*      */   
/*      */   public void setSelection(Integer vertexId) {
/*  390 */     this.selectedVertex = (vertexId == null ? null : (P)this.pointmap.get(vertexId));
/*      */   }
/*      */   
/*      */   public void setTrackVertexHovering(boolean trackVertexHovering) {
/*  394 */     this.trackVertexHovering = trackVertexHovering;
/*      */   }
/*      */   
/*      */   public boolean isTrackVertexHovering() {
/*  398 */     return this.trackVertexHovering;
/*      */   }
/*      */   
/*      */   public P getHoveredPoint() {
/*  402 */     return this.hoveredVertex;
/*      */   }
/*      */   
/*      */   public void setActiveNodeAnimationEnabled(boolean activeNodeAnimationEnabled) {
/*  406 */     this.activeNodeAnimationEnabled = activeNodeAnimationEnabled;
/*      */   }
/*      */   
/*      */   public boolean isActiveNodeAnimationEnabled() {
/*  410 */     return this.activeNodeAnimationEnabled;
/*      */   }
/*      */   
/*      */   public Collection<P> getActivePoints() {
/*  414 */     return this.activePoints;
/*      */   }
/*      */   
/*      */   public boolean getActivePointsStatus() {
/*  418 */     return this.activeState == 1;
/*      */   }
/*      */   
/*      */   public boolean isActivePoint(P p) {
/*  422 */     return this.activePoints.contains(p);
/*      */   }
/*      */   
/*      */   public boolean isActiveVertex(int id) {
/*  426 */     return this.activeVertices.contains(Integer.valueOf(id));
/*      */   }
/*      */   
/*      */   public void addActivePoint(P p) {
/*  430 */     this.activePoints.add(p);
/*  431 */     if (this.activeVertices.add(p.id)) {
/*  432 */       notifyGraphChange();
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeActivePoint(P p) {
/*  437 */     this.activePoints.remove(p);
/*  438 */     if (this.activeVertices.remove(p.id)) {
/*  439 */       notifyGraphChange();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isDragging() {
/*  444 */     return this.dragging;
/*      */   }
/*      */   
/*      */   public void dragGraph(int deltaX, int deltaY)
/*      */   {
/*  449 */     dragGraph(deltaX, deltaY, false);
/*      */   }
/*      */   
/*      */   public void dragGraph(int deltaX, int deltaY, boolean progressive)
/*      */   {
/*  454 */     Rectangle r = this.clientArea;
/*  455 */     double gx1 = this.gx - this.gw * deltaX / r.width;
/*  456 */     double gy1 = this.gy + this.gh * deltaY / r.height;
/*      */     
/*  458 */     if (progressive) {
/*  459 */       int frameCount = 10;
/*  460 */       int incrX = deltaX / 10;
/*  461 */       int incrY = deltaY / 10;
/*      */       
/*      */ 
/*  464 */       if ((incrX != 0) || (incrY != 0)) {
/*  465 */         for (int i = 0; i < 9; i++) {
/*  466 */           this.gx -= this.gw * incrX / r.width;
/*  467 */           this.gy += this.gh * incrY / r.height;
/*  468 */           scroll(incrX, incrY, 0, 0, r.width, r.height, true);
/*  469 */           refreshGraph();
/*      */           
/*      */           try
/*      */           {
/*  473 */             Thread.sleep(50L);
/*      */           }
/*      */           catch (InterruptedException e)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*  480 */         deltaX -= 10 * incrX;
/*  481 */         deltaY -= 10 * incrY;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  486 */     this.gx = gx1;
/*  487 */     this.gy = gy1;
/*      */     
/*      */ 
/*  490 */     notifyBoundsChange();
/*      */     
/*  492 */     scroll(deltaX, deltaY, 0, 0, r.width, r.height, true);
/*  493 */     refreshGraph();
/*      */   }
/*      */   
/*      */   public void refreshGraph()
/*      */   {
/*  498 */     this.pointsCoordMap = null;
/*  499 */     redraw();
/*  500 */     update();
/*      */   }
/*      */   
/*      */   public void zoomGraph(int zoom)
/*      */   {
/*  505 */     zoomGraph(zoom, null);
/*      */   }
/*      */   
/*      */   public void zoomGraph(int zoom, Point centerPoint)
/*      */   {
/*  510 */     double ratio = 1.0D;
/*  511 */     if (zoom > 0) {
/*  512 */       ratio = 0.8D;
/*      */     }
/*  514 */     else if (zoom < 0) {
/*  515 */       ratio = 1.2D;
/*      */     }
/*  517 */     applyZoom(ratio, centerPoint == null ? null : convertCoord(centerPoint));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void applyZoom(double ratio, P centerPoint)
/*      */   {
/*  526 */     Assert.a(ratio > 0.0D);
/*  527 */     if (ratio == 1.0D) {
/*  528 */       return;
/*      */     }
/*      */     
/*  531 */     if (centerPoint == null) {
/*  532 */       centerPoint = new P(this.gx + this.gw / 2.0D, this.gy + this.gh / 2.0D);
/*      */     }
/*  534 */     double rx = (centerPoint.x - this.gx) / this.gw;
/*  535 */     double ry = (centerPoint.y - this.gy) / this.gh;
/*  536 */     this.gw = (ratio * this.gw);
/*  537 */     this.gh = (ratio * this.gh);
/*  538 */     this.gx = (centerPoint.x - rx * this.gw);
/*  539 */     this.gy = (centerPoint.y - ry * this.gh);
/*      */     
/*      */ 
/*  542 */     notifyBoundsChange();
/*      */     
/*  544 */     redraw();
/*  545 */     update();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParameters(Collection<P> allpoints, Collection<L> alllines, boolean directedGraph)
/*      */   {
/*  556 */     if (allpoints == null) {
/*  557 */       throw new IllegalArgumentException();
/*      */     }
/*  559 */     if (alllines == null) {
/*  560 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  563 */     this.pointmap.clear();
/*  564 */     for (P p : allpoints) {
/*  565 */       this.pointmap.put(Integer.valueOf(p.getId()), p);
/*      */     }
/*      */     
/*  568 */     this.lines.clear();
/*  569 */     this.lines.addAll(alllines);
/*      */     
/*  571 */     this.directed = directedGraph;
/*      */     
/*  573 */     this.hoveredVertex = null;
/*  574 */     this.visiblePoints = null;
/*  575 */     this.visibleLines = null;
/*      */     
/*  577 */     fitGraph(0.05D, false);
/*  578 */     notifyBoundsChange();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportParametersUpdate()
/*      */   {
/*  586 */     this.pointsCoordMap = null;
/*  587 */     redraw();
/*      */   }
/*      */   
/*      */   public void centerGraph()
/*      */   {
/*  592 */     fitGraph(0.1D, true);
/*      */   }
/*      */   
/*      */   public void centerGraph(int vertexId) {
/*  596 */     P p = (P)this.pointmap.get(Integer.valueOf(vertexId));
/*  597 */     Assert.a(p != null, "Vertex id " + vertexId + " does not exist");
/*  598 */     setGraphLocation(p.x - this.gw / 2.0D, p.y - this.gh / 2.0D);
/*      */   }
/*      */   
/*      */   public void positionGraph(double xRatio, double yRatio)
/*      */   {
/*  603 */     Rectangle container = getContainerArea();
/*  604 */     int x0 = (int)(container.x + xRatio * container.width);
/*  605 */     int y0 = (int)(container.y + yRatio * container.height);
/*      */     
/*  607 */     int deltaX = this.clientArea.width / 2 - x0;
/*  608 */     int deltaY = this.clientArea.height / 2 - y0;
/*  609 */     dragGraph(deltaX, deltaY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void centerGraph(int vertexId, int clientAnchorFlags, boolean progressive)
/*      */   {
/*  617 */     Point pt = (Point)getVertexViewportCoordinates().get(Integer.valueOf(vertexId));
/*      */     
/*  619 */     Rectangle client = this.clientArea;
/*      */     
/*      */ 
/*  622 */     int x0 = pt.x;
/*  623 */     int y0 = pt.y;
/*      */     
/*      */ 
/*  626 */     int x1 = client.width / 2;
/*  627 */     int y1 = client.height / 2;
/*  628 */     if ((clientAnchorFlags & 0x80) != 0) {
/*  629 */       y1 = client.height / 10;
/*      */     }
/*  631 */     else if ((clientAnchorFlags & 0x400) != 0) {
/*  632 */       y1 = client.height * 9 / 10;
/*      */     }
/*  634 */     if ((clientAnchorFlags & 0x4000) != 0) {
/*  635 */       x1 = client.width / 10;
/*      */     }
/*  637 */     else if ((clientAnchorFlags & 0x20000) != 0) {
/*  638 */       x1 = client.width * 9 / 10;
/*      */     }
/*      */     
/*  641 */     int deltaX = x1 - x0;
/*  642 */     int deltaY = y1 - y0;
/*  643 */     dragGraph(deltaX, deltaY, progressive);
/*      */   }
/*      */   
/*      */   public void fitGraph() {
/*  647 */     fitGraph(0.05D, true);
/*      */   }
/*      */   
/*      */   private void fitGraph(double marginRatio, boolean redraw) {
/*  651 */     double x = Double.MAX_VALUE;
/*  652 */     double xmax = -1.7976931348623157E308D;
/*  653 */     double y = Double.MAX_VALUE;
/*  654 */     double ymax = -1.7976931348623157E308D;
/*  655 */     for (P p : this.pointmap.values()) {
/*  656 */       if (p.getX() < x) {
/*  657 */         x = p.getX();
/*      */       }
/*  659 */       if (p.getX() > xmax) {
/*  660 */         xmax = p.getX();
/*      */       }
/*  662 */       if (p.getY() < y) {
/*  663 */         y = p.getY();
/*      */       }
/*  665 */       if (p.getY() > ymax) {
/*  666 */         ymax = p.getY();
/*      */       }
/*      */     }
/*  669 */     double w = xmax - x;
/*  670 */     double h = ymax - y;
/*  671 */     double dist = Math.sqrt(Math.pow(w, 2.0D) + Math.pow(h, 2.0D));
/*  672 */     double margin = dist * marginRatio;
/*  673 */     x -= margin;
/*  674 */     y -= margin;
/*  675 */     w += 2.0D * margin;
/*  676 */     h += 2.0D * margin;
/*  677 */     setGraphBounds(x, y, w, h, redraw);
/*      */   }
/*      */   
/*      */   private boolean setGraphBounds(R bounds, boolean redraw) {
/*  681 */     return setGraphBounds(bounds.x, bounds.y, bounds.w, bounds.h, redraw);
/*      */   }
/*      */   
/*      */   private boolean setGraphBounds(double x, double y, double w, double h, boolean redrawOnChange) {
/*  685 */     boolean changed = false;
/*  686 */     if (this.gx != x) {
/*  687 */       this.gx = x;
/*  688 */       changed = true;
/*      */     }
/*  690 */     if (this.gy != y) {
/*  691 */       this.gy = y;
/*  692 */       changed = true;
/*      */     }
/*  694 */     if (this.gw != w) {
/*  695 */       this.gw = w;
/*  696 */       changed = true;
/*      */     }
/*  698 */     if (this.gh != h) {
/*  699 */       this.gh = h;
/*  700 */       changed = true;
/*      */     }
/*      */     
/*  703 */     if (changed) {
/*  704 */       if (!adjustGraphBounds()) {
/*  705 */         notifyBoundsChange();
/*      */       }
/*  707 */       if (redrawOnChange) {
/*  708 */         redraw();
/*      */       }
/*      */     }
/*  711 */     return changed;
/*      */   }
/*      */   
/*      */   public boolean setGraphBounds(R bounds) {
/*  715 */     return setGraphBounds(bounds, true);
/*      */   }
/*      */   
/*      */   public R getGraphBounds() {
/*  719 */     return new R(this.gx, this.gy, this.gw, this.gh);
/*      */   }
/*      */   
/*      */   public void setGraphLocation(double x, double y) {
/*  723 */     setGraphBounds(new R(x, y, this.gw, this.gh));
/*      */   }
/*      */   
/*      */   public void setGraphSize(double w, double h) {
/*  727 */     setGraphBounds(new R(this.gx, this.gy, w, h));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean adjustGraphBounds()
/*      */   {
/*  736 */     boolean changed = false;
/*  737 */     Rectangle r = this.clientArea;
/*  738 */     double viewport_ratio = r.width / r.height;
/*  739 */     double graph_ratio = this.gw / this.gh;
/*  740 */     if (graph_ratio > viewport_ratio) {
/*  741 */       double updated = this.gw * r.height / r.width;
/*  742 */       this.gy -= (updated - this.gh) / 2.0D;
/*  743 */       this.gh = updated;
/*  744 */       changed = true;
/*      */     }
/*  746 */     else if (graph_ratio < viewport_ratio) {
/*  747 */       double updated = this.gh * r.width / r.height;
/*  748 */       this.gx -= (updated - this.gw) / 2.0D;
/*  749 */       this.gw = updated;
/*  750 */       changed = true;
/*      */     }
/*  752 */     if (changed) {
/*  753 */       notifyBoundsChange();
/*      */     }
/*  755 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point convertCoord(P p)
/*      */   {
/*  765 */     Rectangle r = this.clientArea;
/*  766 */     int x = (int)((p.getX() - this.gx) / this.gw * r.width);
/*  767 */     int y = r.height - (int)((p.getY() - this.gy) / this.gh * r.height);
/*  768 */     return new Point(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public P convertCoord(Point p)
/*      */   {
/*  778 */     Rectangle r = this.clientArea;
/*  779 */     double x = p.x / r.width * this.gw + this.gx;
/*  780 */     double y = (p.y - r.height) / -r.height * this.gh + this.gy;
/*  781 */     return new P(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Map<Integer, Point> getVertexViewportCoordinates()
/*      */   {
/*  788 */     if (this.pointsCoordMap == null) {
/*  789 */       this.pointsCoordMap = new HashMap();
/*  790 */       for (P p : this.pointmap.values()) {
/*  791 */         Point pc = convertCoord(p);
/*  792 */         this.pointsCoordMap.put(Integer.valueOf(p.getId()), pc);
/*      */       }
/*      */     }
/*  795 */     return this.pointsCoordMap;
/*      */   }
/*      */   
/*      */   public void setLabelProvider(ILabelProvider labelProvider) {
/*  799 */     this.labelProvider = labelProvider;
/*      */   }
/*      */   
/*      */   public ILabelProvider getLabelProvider() {
/*  803 */     return this.labelProvider;
/*      */   }
/*      */   
/*      */   public String generateLabelForVertex(P p) {
/*  807 */     if (this.labelProvider != null) {
/*  808 */       String s = this.labelProvider.getLabel(p.getId());
/*  809 */       if (!Strings.isBlank(s))
/*      */       {
/*  811 */         return s;
/*      */       }
/*      */     }
/*  814 */     return "" + p.getId();
/*      */   }
/*      */   
/*      */ 
/*      */   protected void preDrawing(GC gc) {}
/*      */   
/*      */   protected void postDrawing(GC gc) {}
/*      */   
/*      */   protected Collection<P> determineVisibleVertices(Collection<P> points)
/*      */   {
/*  824 */     return points;
/*      */   }
/*      */   
/*      */   protected Collection<L> determineVisibleEdges(Collection<P> visiblePoints, Collection<L> edges) {
/*  828 */     return edges;
/*      */   }
/*      */   
/*      */   protected void preEdgesDrawing(GC gc) {
/*  832 */     gc.setForeground(getDisplay().getSystemColor(15));
/*      */   }
/*      */   
/*      */   protected void drawEdge(GC gc, L l, Point a, Point b) {
/*  836 */     gc.drawLine(a.x, a.y, b.x, b.y);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void postEdgesDrawing(GC gc) {}
/*      */   
/*      */   protected void preVerticesDrawing(GC gc)
/*      */   {
/*  844 */     gc.setBackground(getDisplay().getSystemColor(2));
/*      */   }
/*      */   
/*      */   protected void drawVertex(GC gc, P p, Point pt) {
/*  848 */     int pr = 6;
/*  849 */     gc.fillOval(pt.x - 3, pt.y - 3, 6, 6);
/*      */   }
/*      */   
/*      */   protected void postVerticesDrawing(GC gc) {}
/*      */   
/*      */   protected void preVertexLabelsDrawing(GC gc)
/*      */   {
/*  856 */     gc.setForeground(getDisplay().getSystemColor(4));
/*      */   }
/*      */   
/*      */   protected void drawVertexLabel(GC gc, P p, Point pt) {
/*  860 */     gc.drawText(generateLabelForVertex(p), pt.x, pt.y, true);
/*      */   }
/*      */   
/*      */   protected void postVertexLabelsDrawing(GC gc) {}
/*      */   
/*      */   public P findClosestVertex(P p0, Collection<P> candidates)
/*      */   {
/*  867 */     if (candidates == null) {
/*  868 */       if (this.pointmap == null) {
/*  869 */         return null;
/*      */       }
/*  871 */       candidates = this.pointmap.values();
/*      */     }
/*  873 */     P closestVertex = null;
/*  874 */     double min = Double.MAX_VALUE;
/*  875 */     for (P p : candidates) {
/*  876 */       double dx = Math.abs(p.getX() - p0.getX());
/*  877 */       if (dx < min)
/*      */       {
/*      */ 
/*  880 */         double dy = Math.abs(p.getY() - p0.getY());
/*  881 */         if (dy < min)
/*      */         {
/*      */ 
/*  884 */           double dx2 = dx * dx;
/*  885 */           if (dx2 < min)
/*      */           {
/*      */ 
/*  888 */             double dy2 = dy * dy;
/*  889 */             if (dy2 < min)
/*      */             {
/*      */ 
/*  892 */               double sum2 = dx2 + dy2;
/*  893 */               if (sum2 < min)
/*      */               {
/*      */ 
/*  896 */                 min = sum2;
/*  897 */                 closestVertex = p;
/*      */               } } } } } }
/*  899 */     return closestVertex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addGraphVertexListener(IGraphVertexListener listener)
/*      */   {
/*  907 */     this.vertexListeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeGraphVertexListener(IGraphVertexListener listener) {
/*  911 */     this.vertexListeners.remove(listener);
/*      */   }
/*      */   
/*      */   private void notifyVertexHoverIn(P p) {
/*  915 */     for (IGraphVertexListener listener : this.vertexListeners) {
/*  916 */       listener.onVertexHoverIn(this, p);
/*      */     }
/*      */   }
/*      */   
/*      */   private void notifyVertexHoverOut(P p) {
/*  921 */     for (IGraphVertexListener listener : this.vertexListeners) {
/*  922 */       listener.onVertexHoverOut(this, p);
/*      */     }
/*      */   }
/*      */   
/*      */   private void notifyVertexClicked(P p) {
/*  927 */     for (IGraphVertexListener listener : this.vertexListeners) {
/*  928 */       listener.onVertexClicked(this, p);
/*      */     }
/*      */   }
/*      */   
/*      */   private void notifyVertexDoubleClicked(P p) {
/*  933 */     for (IGraphVertexListener listener : this.vertexListeners) {
/*  934 */       listener.onVertexDoubleClicked(this, p);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addGraphBoundsListener(IGraphBoundsListener listener) {
/*  939 */     this.boundsListeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeGraphBoundsListener(IGraphBoundsListener listener) {
/*  943 */     this.boundsListeners.remove(listener);
/*      */   }
/*      */   
/*      */   private void notifyBoundsChange() {
/*  947 */     this.pointsCoordMap = null;
/*  948 */     for (IGraphBoundsListener listener : this.boundsListeners) {
/*  949 */       listener.onBoundsUpdate(this, new R(this.gx, this.gy, this.gw, this.gh));
/*      */     }
/*      */     
/*  952 */     notifyGraphChange();
/*      */   }
/*      */   
/*      */   public Rectangle generatePreview(GC gc, Rectangle preview, GraphStyleData styleDataOverride, boolean renderEdges)
/*      */   {
/*  957 */     Rectangle container = getContainerArea();
/*  958 */     if ((container.width == 0) || (container.height == 0) || (preview.width == 0) || (preview.height == 0)) {
/*  959 */       return null;
/*      */     }
/*      */     
/*  962 */     GraphStyleData styles = styleDataOverride != null ? styleDataOverride : GraphStyleData.buildDefault();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  969 */     int usedHeight = Math.max(1, preview.width * container.height / container.width);
/*  970 */     int offsetHeight; int offsetHeight; int usedWidth; int offsetWidth; if (usedHeight > preview.height) {
/*  971 */       int usedWidth = Math.max(1, preview.height * container.width / container.height);
/*  972 */       Assert.a(usedWidth <= preview.width);
/*  973 */       int offsetWidth = (preview.width - usedWidth) / 2;
/*  974 */       usedHeight = preview.height;
/*  975 */       offsetHeight = 0;
/*      */     }
/*      */     else {
/*  978 */       offsetHeight = (preview.height - usedHeight) / 2;
/*  979 */       usedWidth = preview.width;
/*  980 */       offsetWidth = 0;
/*      */     }
/*      */     
/*  983 */     double xRatio = usedWidth / container.width;
/*  984 */     double yRatio = usedHeight / container.height;
/*      */     
/*  986 */     Rectangle b = this.clientArea;
/*  987 */     int x = (int)((b.x - container.x) * xRatio) + offsetWidth;
/*  988 */     int y = (int)((b.y - container.y) * yRatio) + offsetHeight;
/*  989 */     int w = Math.max(3, (int)(b.width * xRatio));
/*  990 */     int h = Math.max(3, (int)(b.height * yRatio));
/*  991 */     gc.setBackground(styles.cCanvas);
/*  992 */     gc.fillRectangle(x, y, w, h);
/*      */     
/*  994 */     List<Point> activePts = new ArrayList();
/*  995 */     for (Map.Entry<Integer, Point> entry : getVertexViewportCoordinates().entrySet()) {
/*  996 */       int id = ((Integer)entry.getKey()).intValue();
/*  997 */       Point pt = (Point)entry.getValue();
/*  998 */       if (isActiveVertex(id)) {
/*  999 */         activePts.add(pt);
/*      */       }
/*      */       else {
/* 1002 */         x = (int)((pt.x - container.x) * xRatio) + offsetWidth;
/* 1003 */         y = (int)((pt.y - container.y) * yRatio) + offsetHeight;
/* 1004 */         gc.setBackground(styles.cNode);
/* 1005 */         gc.fillOval(x, y, 3, 3);
/*      */       } }
/* 1007 */     for (Point pt : activePts) {
/* 1008 */       x = (int)((pt.x - container.x) * xRatio) + offsetWidth;
/* 1009 */       y = (int)((pt.y - container.y) * yRatio) + offsetHeight;
/* 1010 */       gc.setBackground(styles.cActiveNode);
/* 1011 */       gc.fillOval(x, y, 6, 6);
/*      */     }
/*      */     
/* 1014 */     return new Rectangle(offsetWidth, offsetHeight, usedWidth, usedHeight);
/*      */   }
/*      */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\fast\XYGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */