/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Spreadsheet<T>
/*     */ {
/*  27 */   private static final ILogger logger = GlobalLog.getLogger(Spreadsheet.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */   List<List<Cell<T>>> grid = new ArrayList();
/*     */   
/*     */ 
/*     */   int lastRowIndex;
/*     */   
/*     */ 
/*     */   int lastColumnIndex;
/*     */   
/*     */ 
/*     */ 
/*     */   public Spreadsheet()
/*     */   {
/*  56 */     this(0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public Spreadsheet(int idealRowCount, int idealColumnCount) {}
/*     */   
/*     */   public int getLastRowIndex()
/*     */   {
/*  64 */     return this.lastRowIndex;
/*     */   }
/*     */   
/*     */   public int getLastColumnIndex() {
/*  68 */     return this.lastColumnIndex;
/*     */   }
/*     */   
/*     */   public int getRowCount()
/*     */   {
/*  73 */     return this.lastRowIndex + 1;
/*     */   }
/*     */   
/*     */   public int getColumnCount()
/*     */   {
/*  78 */     return this.lastColumnIndex + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void verify()
/*     */   {
/*  87 */     if (this.grid.size() != getRowCount()) {
/*  88 */       throw new RuntimeException(String.format("Expected %d rows, got %d", new Object[] { Integer.valueOf(getRowCount()), Integer.valueOf(this.grid.size()) }));
/*     */     }
/*  90 */     for (int row = 0; row < getRowCount(); row++) {
/*  91 */       List<Cell<T>> cellrow = (List)this.grid.get(row);
/*  92 */       if ((cellrow != null) && (cellrow.size() != getColumnCount()))
/*     */       {
/*  94 */         throw new RuntimeException(String.format("Row %d: Expected %d columns, got %d", new Object[] {Integer.valueOf(row), Integer.valueOf(getColumnCount()), Integer.valueOf(cellrow.size()) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  99 */     for (int row = 0; row < getRowCount(); row++) {
/* 100 */       List<Cell<T>> cellrow = (List)this.grid.get(row);
/* 101 */       if (cellrow != null)
/*     */       {
/*     */ 
/*     */ 
/* 105 */         for (int col = 0; col < getColumnCount(); col++) {
/* 106 */           Cell<T> cell = (Cell)cellrow.get(col);
/* 107 */           if ((cell != null) && (cell.isPartOfMergedCell()))
/*     */           {
/*     */ 
/*     */ 
/* 111 */             if ((cell.getRow() != row) || (cell.getColumn() != col))
/*     */             {
/* 113 */               throw new RuntimeException(String.format("Inconsistent cell coordinates: expected (%d,%d), got (%d,%d)", new Object[] {Integer.valueOf(row), Integer.valueOf(col), 
/* 114 */                 Integer.valueOf(cell.getRow()), Integer.valueOf(cell.getColumn()) }));
/*     */             }
/* 116 */             if ((cell.horiMergerDisp > 0) && (cell.horiMergerDisp < 0)) {
/* 117 */               throw new RuntimeException();
/*     */             }
/* 119 */             if ((cell.vertMergerDisp > 0) && (cell.vertMergerDisp < 0)) {
/* 120 */               throw new RuntimeException();
/*     */             }
/*     */             
/*     */ 
/* 124 */             if (cell.isPrimary()) {
/* 125 */               int i = 0;
/* 126 */               for (int row2 = row; row2 <= row + cell.vertMergerDisp; row2++) {
/* 127 */                 for (int col2 = col; col2 <= col + cell.horiMergerDisp; col2++) {
/* 128 */                   if (i++ != 0)
/*     */                   {
/*     */ 
/* 131 */                     Cell<T> slave = getCellInternal(row2, col2);
/* 132 */                     if (slave == null)
/*     */                     {
/* 134 */                       throw new RuntimeException(String.format("%d,%d: Expected slave cell, got null", new Object[] {Integer.valueOf(row2), Integer.valueOf(col2) }));
/*     */                     }
/* 136 */                     if (row2 + slave.vertMergerDisp != row)
/*     */                     {
/* 138 */                       throw new RuntimeException(String.format("%d,%d: Bad slave vertical displacement", new Object[] {Integer.valueOf(row2), Integer.valueOf(col2) }));
/*     */                     }
/* 140 */                     if (col2 + slave.horiMergerDisp != col)
/*     */                     {
/* 142 */                       throw new RuntimeException(String.format("%d,%d: Bad slave horizontal displacement", new Object[] {Integer.valueOf(row2), Integer.valueOf(col2) }));
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } else {
/* 148 */               int row2 = row + cell.vertMergerDisp;
/* 149 */               int col2 = col + cell.horiMergerDisp;
/* 150 */               Cell<T> master = getCellInternal(row2, col2);
/* 151 */               if ((master == null) || (!master.isPrimary()) || (!master.isPartOfMergedCell()))
/*     */               {
/* 153 */                 throw new RuntimeException(String.format("%d,%d: slave does not reference a master cell", new Object[] {Integer.valueOf(row), Integer.valueOf(col) }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int clearNullCells(boolean includeNullMergers)
/*     */   {
/* 171 */     int cnt = 0;
/* 172 */     for (int row = 0; row < getRowCount(); row++) {
/* 173 */       List<Cell<T>> cellrow = (List)this.grid.get(row);
/* 174 */       if (cellrow != null)
/*     */       {
/*     */ 
/* 177 */         for (int col = 0; col < getColumnCount(); col++) {
/* 178 */           Cell<T> cell = (Cell)cellrow.get(col);
/* 179 */           if ((cell != null) && (cell.getObject() == null))
/*     */           {
/*     */ 
/* 182 */             if ((includeNullMergers) || (!cell.isPartOfMergedCell()))
/*     */             {
/*     */ 
/*     */ 
/* 186 */               for (int row2 = row; row2 <= row + cell.vertMergerDisp; row2++)
/* 187 */                 for (int col2 = col; col2 <= col + cell.horiMergerDisp; col2++) {
/* 188 */                   ((List)this.grid.get(row2)).set(col2, null);
/* 189 */                   cnt++;
/*     */                 } } }
/*     */         }
/*     */       }
/*     */     }
/* 194 */     return cnt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int findNullRow(int rowStart, boolean includeNullMergers)
/*     */   {
/*     */     label112:
/*     */     
/* 203 */     for (int row = rowStart; row < getRowCount(); row++) {
/* 204 */       List<Cell<T>> cellrow = (List)this.grid.get(row);
/* 205 */       if (cellrow == null) {
/* 206 */         return row;
/*     */       }
/* 208 */       for (int col = 0; col < getColumnCount(); col++) {
/* 209 */         Cell<T> cell = (Cell)cellrow.get(col);
/* 210 */         if (cell != null)
/*     */         {
/*     */ 
/* 213 */           if (cell.getObject() != null) {
/*     */             break label112;
/*     */           }
/* 216 */           if ((cell.isPartOfMergedCell()) && (
/* 217 */             (!includeNullMergers) || (cell.getPrimary(this).getObject() != null))) {
/*     */             break label112;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 223 */       return row;
/*     */     }
/* 225 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int findNullColumn(int columnStart, boolean includeNullMergers)
/*     */   {
/*     */     label85:
/*     */     
/*     */ 
/* 235 */     for (int col = columnStart; col < getColumnCount(); col++) {
/* 236 */       for (int row = 0; row < getRowCount(); row++) {
/* 237 */         Cell<T> cell = getCellInternal(row, col);
/* 238 */         if (cell != null)
/*     */         {
/*     */ 
/* 241 */           if (cell.getObject() != null) {
/*     */             break label85;
/*     */           }
/* 244 */           if ((cell.isPartOfMergedCell()) && (
/* 245 */             (!includeNullMergers) || (cell.getPrimary(this).getObject() != null))) {
/*     */             break label85;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 251 */       return col;
/*     */     }
/* 253 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRow(int row)
/*     */   {
/* 262 */     List<Cell<T>> cells = (List)this.grid.get(row);
/* 263 */     if (cells == null) {
/* 264 */       this.grid.remove(row);
/* 265 */       return;
/*     */     }
/*     */     
/* 268 */     for (int col = 0; col < getColumnCount(); col++) {
/* 269 */       Cell<T> cell = (Cell)cells.get(col);
/* 270 */       if (cell == null) {
/* 271 */         cells.remove(col);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 276 */         if (cell.isPartOfMergedCell()) {
/* 277 */           throw new RuntimeException();
/*     */         }
/*     */         
/* 280 */         cells.remove(col);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeColumn(int col)
/*     */   {
/* 290 */     for (int row = 0; row < getRowCount(); row++) {
/* 291 */       List<Cell<T>> cells = (List)this.grid.get(row);
/* 292 */       if (cells != null)
/*     */       {
/*     */ 
/*     */ 
/* 296 */         Cell<T> cell = (Cell)cells.get(col);
/* 297 */         if (cell == null) {
/* 298 */           cells.remove(col);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 303 */           if (cell.isPartOfMergedCell()) {
/* 304 */             throw new RuntimeException();
/*     */           }
/*     */           
/* 307 */           cells.remove(col);
/*     */         }
/*     */       }
/*     */     } }
/*     */   
/* 312 */   private Cell<T> nullifyCell(int row, int col) { return writeCell(row, col, null); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> writeCell(int row, int col, T object)
/*     */   {
/* 324 */     return writeCell(row, col, 0, 0, object, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> writeCell(int row, int col, int hspan, int vspan, T object)
/*     */   {
/* 339 */     return writeCell(row, col, hspan, vspan, object, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> writeCell(int row, int col, int hspan, int vspan, T object, boolean failOnOverwrite)
/*     */   {
/* 358 */     if ((row < 0) || (col < 0)) {
/* 359 */       throw new IllegalArgumentException("Illegal cell coordinates");
/*     */     }
/* 361 */     if ((hspan < 0) || (vspan < 0)) {
/* 362 */       throw new IllegalArgumentException("Illegal spanning");
/*     */     }
/* 364 */     if (((hspan == 0) && (vspan != 0)) || ((hspan != 0) && (vspan == 0))) {
/* 365 */       throw new IllegalArgumentException("Illegal hspan/vspan combo");
/*     */     }
/*     */     
/* 368 */     while (row >= this.grid.size()) {
/* 369 */       this.grid.add(null);
/*     */     }
/* 371 */     List<Cell<T>> cells = (List)this.grid.get(row);
/* 372 */     if (cells == null) {
/* 373 */       cells = new ArrayList();
/* 374 */       this.grid.set(row, cells);
/*     */     }
/* 376 */     if (row > this.lastRowIndex) {
/* 377 */       this.lastRowIndex = row;
/*     */     }
/*     */     
/* 380 */     while (col >= cells.size()) {
/* 381 */       cells.add(null);
/*     */     }
/* 383 */     Cell<T> cell = (Cell)cells.get(col);
/* 384 */     if (cell == null) {
/* 385 */       cell = new Cell(row, col);
/* 386 */       cells.set(col, cell);
/*     */     }
/* 388 */     if (col > this.lastColumnIndex) {
/* 389 */       this.lastColumnIndex = col;
/*     */     }
/* 391 */     else if (col < this.lastColumnIndex) {
/* 392 */       while (cells.size() < this.lastColumnIndex + 1) {
/* 393 */         cells.add(null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 398 */     if ((hspan == 0) && (vspan == 0)) {
/* 399 */       cell = cell.getPrimary(this);
/*     */     }
/*     */     else {
/* 402 */       cell = mergeCells(row, col, hspan, vspan);
/*     */     }
/*     */     
/* 405 */     if ((failOnOverwrite) && (cell.obj != null))
/*     */     {
/* 407 */       throw new RuntimeException(String.format("Cell: Cannot overwrite '%s' by '%s'", new Object[] { cell.obj, object }));
/*     */     }
/* 409 */     cell.obj = object;
/* 410 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Cell<T> getCellInternal(int row, int col)
/*     */   {
/* 418 */     if ((row < 0) || (col < 0)) {
/* 419 */       throw new IllegalArgumentException("Illegal cell coordinnates");
/*     */     }
/* 421 */     if (row >= this.grid.size()) {
/* 422 */       return null;
/*     */     }
/* 424 */     List<Cell<T>> cells = (List)this.grid.get(row);
/* 425 */     if (cells == null) {
/* 426 */       return null;
/*     */     }
/* 428 */     if (col >= cells.size()) {
/* 429 */       return null;
/*     */     }
/* 431 */     return (Cell)cells.get(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> getCellSmart(int row, int col, boolean adjustCoordinatesForMergedCells)
/*     */   {
/* 445 */     Cell<T> cell = getCellInternal(row, col);
/* 446 */     if ((cell != null) && (adjustCoordinatesForMergedCells)) {
/* 447 */       cell = cell.getPrimary(this);
/*     */     }
/* 449 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> getCell(int row, int col)
/*     */   {
/* 461 */     return getCell(row, col, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> getCell(int row, int col, boolean createIfNull)
/*     */   {
/* 474 */     Cell<T> cell = getCellInternal(row, col);
/* 475 */     if (cell == null) {
/* 476 */       if (createIfNull) {
/* 477 */         cell = writeCell(row, col, null);
/*     */       }
/*     */     }
/* 480 */     else if (!cell.isPrimary()) {
/* 481 */       throw new IllegalArgumentException(String.format("The cell at (%d,%d) is not a primary cell", new Object[] { Integer.valueOf(row), Integer.valueOf(col) }));
/*     */     }
/* 483 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFree(int row, int col)
/*     */   {
/* 491 */     return isFree(row, col, 1, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRangeFree(int row, int colBegin, int colEnd)
/*     */   {
/* 501 */     return isFree(row, colBegin, colEnd - colBegin, 1);
/*     */   }
/*     */   
/*     */   public boolean isFree(int row, int col, int hspan, int vspan) {
/* 505 */     for (int i = row; i < row + vspan; i++) {
/* 506 */       for (int j = col; j < col + hspan; j++) {
/* 507 */         if (getCellInternal(i, j) != null) {
/* 508 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 512 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> mergeCells(int row, int col, int horizontalSpan, int verticalSpan)
/*     */   {
/* 527 */     if ((horizontalSpan <= 0) || (verticalSpan <= 0)) {
/* 528 */       throw new IllegalArgumentException("Spanning requirements cannot be negative or zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 536 */     Cell<T> cell = getCellInternal(row, col);
/* 537 */     if (cell == null) {
/* 538 */       cell = writeCell(row, col, null);
/*     */     } else {
/* 540 */       if (!cell.isPrimary()) {
/* 541 */         throw new IllegalArgumentException("Main cell is not a primary");
/*     */       }
/* 543 */       if ((cell.getHorizontalSpan() == horizontalSpan) && (cell.getVerticalSpan() == verticalSpan))
/*     */       {
/* 545 */         return cell;
/*     */       }
/*     */     }
/*     */     
/* 549 */     for (int i = row; i < row + verticalSpan; i++) {
/* 550 */       for (int j = col; j < col + horizontalSpan; j++) {
/* 551 */         Cell<T> c = getCellInternal(i, j);
/* 552 */         if (c != null)
/*     */         {
/*     */ 
/*     */ 
/* 556 */           Cell<T> master = c.getPrimary(this);
/* 557 */           if ((master.getRow() < row) || (master.getNextRow() > row + verticalSpan) || (master.getColumn() < col) || 
/* 558 */             (master.getColumn() > col + horizontalSpan)) {
/* 559 */             throw new RuntimeException("Merging partially overlaps other merged cells");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 568 */     int vdisp = 0;
/* 569 */     for (int i = row; i < row + verticalSpan; i++) {
/* 570 */       int hdisp = 0;
/* 571 */       for (int j = col; j < col + horizontalSpan; j++) {
/* 572 */         Cell<T> c = getCellInternal(i, j);
/* 573 */         if (c == null) {
/* 574 */           c = nullifyCell(i, j);
/*     */         }
/* 576 */         else if (c != cell) {
/* 577 */           c.obj = null;
/*     */         }
/* 579 */         if ((i == row) && (j == col)) {
/* 580 */           c.horiMergerDisp = (horizontalSpan - 1);
/* 581 */           c.vertMergerDisp = (verticalSpan - 1);
/*     */         }
/*     */         else {
/* 584 */           c.horiMergerDisp = hdisp;
/* 585 */           c.vertMergerDisp = vdisp;
/*     */         }
/* 587 */         hdisp--;
/*     */       }
/* 589 */       vdisp--;
/*     */     }
/*     */     
/* 592 */     return cell;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> splitCell(Cell<T> cell, boolean horizontal)
/*     */   {
/* 605 */     if (!cell.isPrimary()) {
/* 606 */       throw new IllegalArgumentException("The cell must be a primary cell");
/*     */     }
/*     */     
/* 609 */     Cell<T> splitcell = null;
/*     */     
/* 611 */     if (horizontal) {
/* 612 */       int targetrow = cell.getRow();
/* 613 */       int targetcol = cell.getColumn();
/*     */       
/*     */       List<Cell<T>> cells;
/* 616 */       if (cell.horiMergerDisp > 0) {
/* 617 */         int i = 0;
/* 618 */         for (int row = targetrow; row <= targetrow + cell.vertMergerDisp; row++) {
/* 619 */           cells = (List)this.grid.get(row);
/* 620 */           for (int col = targetcol + 1; col <= targetcol + cell.horiMergerDisp; col++) {
/* 621 */             Cell<T> cell2 = (Cell)cells.get(col);
/* 622 */             if (i++ == 0) {
/* 623 */               cell.horiMergerDisp -= 1;
/* 624 */               cell2.vertMergerDisp = cell.vertMergerDisp;
/* 625 */               splitcell = cell2;
/*     */             }
/*     */             else {
/* 628 */               cell2.horiMergerDisp += 1;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 634 */         for (int row = targetrow; row <= targetrow + cell.vertMergerDisp; row++) {
/* 635 */           getCellInternal(row, targetcol).horiMergerDisp = 0;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 640 */         int inscol = targetcol + 1;
/*     */         
/*     */ 
/* 643 */         int row = 0;
/* 644 */         for (List<Cell<T>> cellrow : this.grid)
/*     */         {
/* 646 */           if (cellrow != null) {
/* 647 */             int base = 0;
/*     */             
/*     */ 
/* 650 */             if (row != targetrow) {
/* 651 */               for (int col = targetcol; col >= 0; col--) {
/* 652 */                 Cell<T> c = (Cell)cellrow.get(col);
/* 653 */                 if (c == null)
/*     */                 {
/* 655 */                   c = new Cell(row, col);
/* 656 */                   cellrow.set(col, c);
/*     */                 }
/*     */                 
/* 659 */                 if (c.horiMergerDisp >= 0) {
/* 660 */                   c.horiMergerDisp += 1;
/* 661 */                   break;
/*     */                 }
/*     */                 
/* 664 */                 base--;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 669 */             Cell<T> ci = new Cell(row, inscol);
/* 670 */             cellrow.add(inscol, ci);
/* 671 */             if (row != targetrow) {
/* 672 */               ci.horiMergerDisp = (base - 1);
/*     */             }
/*     */             else {
/* 675 */               splitcell = ci;
/*     */             }
/*     */             
/*     */ 
/* 679 */             boolean mergerUpdate = true;
/* 680 */             for (int col = inscol + 1; col < cellrow.size(); col++) {
/* 681 */               Cell<T> c = (Cell)cellrow.get(col);
/* 682 */               if (c == null) {
/* 683 */                 c = new Cell(row, col);
/* 684 */                 cellrow.set(col, c);
/*     */               }
/*     */               
/* 687 */               c.coords = new RowCol(row, col);
/* 688 */               if (mergerUpdate) {
/* 689 */                 if (c.horiMergerDisp >= 0) {
/* 690 */                   mergerUpdate = false;
/*     */                 }
/*     */                 else {
/* 693 */                   c.horiMergerDisp -= 1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 698 */           row++;
/*     */         }
/*     */         
/* 701 */         this.lastColumnIndex += 1;
/*     */       }
/*     */     }
/*     */     else {
/* 705 */       throw new RuntimeException("Vertical splits for cells are not supported yet");
/*     */     }
/*     */     
/* 708 */     return splitcell;
/*     */   }
/*     */   
/*     */   public Cell<T> moveCell(Cell<T> cell, int dstRow, int dstCol, boolean keepSpanning) {
/* 712 */     int dstHspan = 1;
/* 713 */     int dstVspan = 1;
/* 714 */     if (keepSpanning) {
/* 715 */       dstHspan = cell.getHorizontalSpan();
/* 716 */       dstVspan = cell.getVerticalSpan();
/*     */     }
/*     */     
/* 719 */     if (!isFree(dstRow, dstCol, dstHspan, dstVspan)) {
/* 720 */       return null;
/*     */     }
/*     */     
/* 723 */     Cell<T> dst = writeCell(dstRow, dstCol, dstHspan, dstVspan, cell.getObject());
/* 724 */     Assert.a(dst != null, "Unexpected cell creation failure");
/* 725 */     return dst;
/*     */   }
/*     */   
/*     */   public boolean deleteCell(Cell<T> cell, boolean keepMerger) {
/* 729 */     throw new RuntimeException("TBI");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Cell<T>> getRealCells()
/*     */   {
/* 738 */     List<Cell<T>> r = new ArrayList();
/* 739 */     for (int row = 0; row < this.grid.size(); row++) {
/* 740 */       getRealCellsOnRow(row, r);
/*     */     }
/* 742 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Cell<T>> getRealCellsOnRow(int row)
/*     */   {
/* 753 */     List<Cell<T>> r = new ArrayList();
/* 754 */     getRealCellsOnRow(row, r);
/* 755 */     return r;
/*     */   }
/*     */   
/*     */   private void getRealCellsOnRow(int row, List<Cell<T>> sink) {
/* 759 */     List<Cell<T>> cells = (List)this.grid.get(row);
/* 760 */     if (cells != null) {
/* 761 */       for (int col = 0; col < cells.size(); col++) {
/* 762 */         Cell<T> cell = (Cell)cells.get(col);
/* 763 */         if ((cell != null) && (cell.obj != null) && (cell.horiMergerDisp >= 0) && (cell.vertMergerDisp >= 0))
/*     */         {
/*     */ 
/* 766 */           sink.add(cell);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cell<T> createFirstAvailableOnRow(int row, int col)
/*     */   {
/* 780 */     Cell<T> cell = getCellInternal(row, col);
/* 781 */     if (cell == null) {
/* 782 */       cell = nullifyCell(row, col);
/* 783 */       Assert.a((cell.getRow() == row) && (cell.getColumn() == col));
/* 784 */       return cell;
/*     */     }
/*     */     
/* 787 */     cell = cell.getPrimary(this);
/*     */     do {
/* 789 */       Assert.a(cell.isPrimary());
/* 790 */       if (cell.obj == null) {
/* 791 */         return cell;
/*     */       }
/*     */       
/* 794 */       col = cell.getColumn() + cell.getHorizontalSpan();
/* 795 */       cell = getCellSmart(row, col, false);
/* 796 */     } while (cell != null);
/* 797 */     return nullifyCell(row, col);
/*     */   }
/*     */   
/*     */ 
/*     */   public Cell<T> getCellByObject(Object obj)
/*     */   {
/* 803 */     if (obj == null) {
/* 804 */       throw new IllegalArgumentException();
/*     */     }
/* 806 */     for (Cell<T> cell : getRealCells()) {
/* 807 */       if (obj.equals(cell.obj)) {
/* 808 */         return cell;
/*     */       }
/*     */     }
/* 811 */     return null;
/*     */   }
/*     */   
/*     */   public String formatCells() {
/* 815 */     return getRealCells().toString();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 820 */     return format();
/*     */   }
/*     */   
/*     */   public String format()
/*     */   {
/* 825 */     if (this.grid.isEmpty()) {
/* 826 */       return "(empty)";
/*     */     }
/* 828 */     StringBuilder sb = new StringBuilder();
/* 829 */     for (int row = 0; row <= this.lastRowIndex; row++) {
/* 830 */       List<Cell<T>> rowcells = (List)this.grid.get(row);
/* 831 */       int col = 0;
/* 832 */       if (rowcells != null) {
/* 833 */         for (; col < rowcells.size(); col++) {
/* 834 */           Cell<T> cell = (Cell)rowcells.get(col);
/* 835 */           if (cell != null) {
/* 836 */             if (cell.horiMergerDisp > 0) {
/* 837 */               sb.append("x");
/*     */             }
/* 839 */             else if (cell.horiMergerDisp < 0) {
/* 840 */               sb.append("=x");
/* 841 */               if ((col + 1 > this.lastColumnIndex) || (rowcells.get(col + 1) == null) || 
/* 842 */                 (((Cell)rowcells.get(col + 1)).horiMergerDisp >= 0)) {
/* 843 */                 sb.append(" ");
/*     */               }
/*     */             }
/*     */             else {
/* 847 */               sb.append("x ");
/*     */             }
/*     */           }
/*     */           else {
/* 851 */             sb.append("- ");
/*     */           }
/*     */         }
/*     */       }
/* 855 */       for (; col <= this.lastColumnIndex; col++) {
/* 856 */         sb.append("- ");
/*     */       }
/* 858 */       if (row < this.lastRowIndex) {
/* 859 */         sb.append("\n");
/*     */       }
/*     */     }
/* 862 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\Spreadsheet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */