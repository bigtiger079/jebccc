/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*     */ 
/*     */ import com.pnfsoftware.jeb.core.units.code.IInstruction;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.cfg.BasicBlock;
/*     */ import com.pnfsoftware.jeb.core.units.code.asm.cfg.CFG;
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CFGLayout<T extends IInstruction>
/*     */   implements ICFGLayout<T>
/*     */ {
/*  29 */   private static final ILogger logger = GlobalLog.getLogger(CFGLayout.class);
/*     */   
/*     */ 
/*     */   private boolean disregardIrregularFlows;
/*     */   
/*     */   private CFG<T> cfg;
/*     */   
/*     */   private Spreadsheet<BasicBlock<T>> grid;
/*     */   
/*     */   private Set<Long> processed;
/*     */   
/*  40 */   private boolean specialHandlingForDiamonds = true;
/*  41 */   private Set<Long> skipDstProc = new HashSet();
/*  42 */   private Set<Long> diamondExits = new HashSet();
/*     */   
/*     */   public CFGLayout(boolean disregardIrregularFlows) {
/*  45 */     this.disregardIrregularFlows = disregardIrregularFlows;
/*     */   }
/*     */   
/*     */   public void setDisregardIrregularFlows(boolean disregardIrregularFlows) {
/*  49 */     this.disregardIrregularFlows = disregardIrregularFlows;
/*     */   }
/*     */   
/*     */   public boolean isDisregardIrregularFlows() {
/*  53 */     return this.disregardIrregularFlows;
/*     */   }
/*     */   
/*     */   public Spreadsheet<BasicBlock<T>> build(CFG<T> cfg)
/*     */   {
/*  58 */     if (this.grid != null) {
/*  59 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*  62 */     if ((cfg == null) || (cfg.size() == 0)) {
/*  63 */       throw new IllegalArgumentException("Illegal CFG");
/*     */     }
/*  65 */     this.cfg = cfg;
/*     */     
/*  67 */     this.grid = new Spreadsheet();
/*  68 */     this.processed = new HashSet();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */     process(cfg.getEntryBlock(), 0, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     logger.i("Layout:\n%s", new Object[] { this.grid });
/* 101 */     return this.grid;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean process(BasicBlock<T> b, int row, int col)
/*     */   {
/* 107 */     long base = b.getFirstAddress();
/* 108 */     if (this.processed.contains(Long.valueOf(base))) {
/* 109 */       return false;
/*     */     }
/* 111 */     this.processed.add(Long.valueOf(base));
/*     */     
/* 113 */     Cell<BasicBlock<T>> cell0 = this.grid.writeCell(row, col, b);
/* 114 */     Assert.a(cell0.isPrimary());
/*     */     
/*     */ 
/* 117 */     if (this.skipDstProc.contains(Long.valueOf(base))) {
/* 118 */       return true;
/*     */     }
/*     */     
/* 121 */     if (this.diamondExits.contains(Long.valueOf(base))) {
/* 122 */       this.grid.mergeCells(row, col, 2, 1);
/*     */     }
/*     */     
/* 125 */     if (cell0.isPartOfMergedCell()) {
/* 126 */       col += cell0.getHorizontalSpan() - 1;
/*     */     }
/* 128 */     Cell<BasicBlock<T>> c1 = this.grid.writeCell(row + 1, col, null);
/* 129 */     Assert.a(c1.isPrimary());
/*     */     
/*     */ 
/* 132 */     List<BasicBlock<T>> dstlist = getDests(b);
/*     */     
/*     */     BasicBlock<T> bB;
/* 135 */     if ((this.specialHandlingForDiamonds) && (dstlist.size() == 2)) {
/* 136 */       BasicBlock<T> bA = (BasicBlock)dstlist.get(0);
/* 137 */       bB = (BasicBlock)dstlist.get(1);
/* 138 */       if ((!this.processed.contains(Long.valueOf(bA.getFirstAddress()))) && (!this.processed.contains(Long.valueOf(bB.getFirstAddress())))) {
/* 139 */         List<BasicBlock<T>> d_bA = getDests(bA);
/* 140 */         if ((d_bA.size() == 1) && (d_bA.equals(getDests(bB))) && 
/* 141 */           (!this.processed.contains(Long.valueOf(((BasicBlock)d_bA.get(0)).getFirstAddress()))))
/*     */         {
/* 143 */           this.skipDstProc.add(Long.valueOf(bB.getFirstAddress()));
/* 144 */           this.diamondExits.add(Long.valueOf(((BasicBlock)d_bA.get(0)).getFirstAddress()));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 150 */     int splitcount = 0;
/* 151 */     for (BasicBlock<T> b2 : dstlist) {
/* 152 */       if (!this.processed.contains(Long.valueOf(b2.getFirstAddress()))) {
/* 153 */         splitcount++;
/*     */       }
/*     */     }
/* 156 */     while (splitcount-- >= 2) {
/* 157 */       c1 = this.grid.splitCell(c1, true);
/*     */     }
/* 159 */     this.grid.clearNullCells(true);
/*     */     
/* 161 */     int col2 = col;
/* 162 */     int i = 0;
/* 163 */     for (BasicBlock<T> b2 : dstlist)
/*     */     {
/* 165 */       boolean wroteCell = process(b2, row + 1, col2);
/* 166 */       i++; if (i >= dstlist.size()) {
/*     */         break;
/*     */       }
/* 169 */       if (wroteCell) {
/* 170 */         col2 = this.grid.getCell(row + 1, col2, true).getNextColumn();
/*     */       }
/*     */     }
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   private List<BasicBlock<T>> getDests(BasicBlock<T> b) {
/* 177 */     return this.disregardIrregularFlows ? b.getOutputBlocks() : b.getAllOutputBlocks();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\CFGLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */