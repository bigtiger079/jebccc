package com.pnfsoftware.jeb.rcpclient.extensions.graph.model;

public abstract interface ILabelProvider
{
  public abstract String getLabel(int paramInt);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\model\ILabelProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */