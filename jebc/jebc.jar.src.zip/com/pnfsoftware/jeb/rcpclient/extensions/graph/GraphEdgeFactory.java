/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphEdgeFactory
/*    */ {
/* 20 */   Anchor srcAnchor = Anchor.AUTO;
/* 21 */   Anchor dstAnchor = Anchor.AUTO;
/* 22 */   int style = 1;
/* 23 */   int thickness = 2;
/* 24 */   Color color = Display.getCurrent().getSystemColor(2);
/* 25 */   Orientation orientation = Orientation.NONE;
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAnchors(Anchor srcAnchor, Anchor dstAnchor)
/*    */   {
/* 31 */     this.srcAnchor = srcAnchor;
/* 32 */     this.dstAnchor = dstAnchor;
/*    */   }
/*    */   
/*    */   public void setStyle(int style) {
/* 36 */     this.style = style;
/*    */   }
/*    */   
/*    */   public void setThickness(int thickness) {
/* 40 */     this.thickness = thickness;
/*    */   }
/*    */   
/*    */   public void setColor(Color color) {
/* 44 */     if (color == null) {
/* 45 */       color = Display.getCurrent().getSystemColor(2);
/*    */     }
/* 47 */     this.color = color;
/*    */   }
/*    */   
/*    */   public void setOrientation(Orientation orientation) {
/* 51 */     this.orientation = orientation;
/*    */   }
/*    */   
/*    */   public GraphEdge createEdge(Graph graph, GraphNode src, GraphNode dst) {
/* 55 */     GraphEdge e = new GraphEdge(graph, src, dst);
/* 56 */     e.setAnchors(this.srcAnchor, this.dstAnchor);
/* 57 */     e.setStyle(this.style);
/* 58 */     e.setThickness(this.thickness);
/* 59 */     e.setColor(0, this.color);
/* 60 */     e.setOrientation(this.orientation);
/* 61 */     return e;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphEdgeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */