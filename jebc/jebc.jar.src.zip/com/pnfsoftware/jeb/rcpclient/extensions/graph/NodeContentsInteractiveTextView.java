/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.api.IOperable;
/*     */ import com.pnfsoftware.jeb.client.api.Operation;
/*     */ import com.pnfsoftware.jeb.client.api.OperationRequest;
/*     */ import com.pnfsoftware.jeb.core.output.AddressConversionPrecision;
/*     */ import com.pnfsoftware.jeb.core.output.IActionableItem;
/*     */ import com.pnfsoftware.jeb.core.output.IItem;
/*     */ import com.pnfsoftware.jeb.core.output.text.ICoordinates;
/*     */ import com.pnfsoftware.jeb.core.output.text.ITextDocument;
/*     */ import com.pnfsoftware.jeb.core.output.text.ITextItem;
/*     */ import com.pnfsoftware.jeb.core.properties.IPropertyManager;
/*     */ import com.pnfsoftware.jeb.core.properties.impl.ConfigurationMemoryMap;
/*     */ import com.pnfsoftware.jeb.core.properties.impl.SimplePropertyManager;
/*     */ import com.pnfsoftware.jeb.core.units.IUnit;
/*     */ import com.pnfsoftware.jeb.rcpclient.FontManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.GlobalPosition;
/*     */ import com.pnfsoftware.jeb.rcpclient.IStatusIndicator;
/*     */ import com.pnfsoftware.jeb.rcpclient.IViewManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ZoomableUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.text.BufferPoint;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.text.IPositionListener;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.text.ITextDocumentViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.text.InteractiveTextViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.text.TextDocumentLocationGenerator;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.UIState;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.AbstractInteractiveTextView;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.ItemStyleProvider2;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.TextHoverableProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.units.UnitTextAnnotator;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.resource.FontDescriptor;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Cursor;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Caret;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Menu;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeContentsInteractiveTextView
/*     */   extends AbstractInteractiveTextView
/*     */   implements IGraphNodeContents
/*     */ {
/*  70 */   private static final ILogger logger = GlobalLog.getLogger(NodeContentsInteractiveTextView.class);
/*     */   private StyledText w;
/*     */   private ItemStyleProvider2 styleProvider;
/*     */   private UnitTextAnnotator textAnnotator;
/*     */   private int zoomLevel;
/*     */   private Integer defaultHeight;
/*     */   
/*     */   public NodeContentsInteractiveTextView(Composite parent, int style, ITextDocument idoc, FontManager fontManager, ItemStyleProvider2 styleProvider, IUnit unit, final IStatusIndicator statusIndicator, IOperable master, final IGraphController controller, final RcpClientContext context)
/*     */   {
/*  79 */     super(parent, style, unit, null, context, idoc);
/*  80 */     setLayout(new FillLayout());
/*     */     
/*  82 */     this.master = master;
/*     */     
/*  84 */     this.styleProvider = styleProvider;
/*     */     
/*  86 */     IPropertyManager propManager = new SimplePropertyManager(new ConfigurationMemoryMap());
/*  87 */     propManager.setBoolean(".ui.text.ShowVerticalScrollbar", Boolean.valueOf(false));
/*  88 */     propManager.setBoolean(".ui.text.ShowHorizontalScrollbar", Boolean.valueOf(false));
/*  89 */     propManager.setBoolean(".ui.text.DisplayEolAtEod", Boolean.valueOf(false));
/*  90 */     propManager.setInteger(".ui.text.CharactersPerLineMax", Integer.valueOf(4000));
/*  91 */     propManager.setInteger(".ui.text.CharactersPerLineAtEnd", Integer.valueOf(100));
/*  92 */     propManager.setBoolean(".ui.text.AllowLineWrapping", Boolean.valueOf(false));
/*  93 */     propManager.setInteger(".ui.text.CharactersWrap", Integer.valueOf(-1));
/*  94 */     propManager.setInteger(".ui.text.ScrollLineSize", Integer.valueOf(0));
/*  95 */     propManager.setInteger(".ui.text.PageLineSize", Integer.valueOf(0));
/*  96 */     propManager.setInteger(".ui.text.PageMultiplier", Integer.valueOf(0));
/*  97 */     propManager.setBoolean(".ui.text.CaretBehaviorViewportStatic", Boolean.valueOf(false));
/*  98 */     propManager.setInteger(".ui.NavigationBarPosition", Integer.valueOf(0));
/*  99 */     propManager.setInteger(".ui.NavigationBarThickness", Integer.valueOf(2));
/*     */     
/* 101 */     int flags = 2;
/* 102 */     this.iviewer = new InteractiveTextViewer(this, flags, idoc, propManager, null);
/* 103 */     this.w = this.iviewer.getTextWidget();
/*     */     
/* 105 */     if (fontManager != null) {
/* 106 */       this.w.setFont(fontManager.getCodeFont());
/*     */     }
/*     */     
/* 109 */     if (styleProvider != null) {
/* 110 */       styleProvider.registerTextViewer(this.iviewer);
/* 111 */       this.iviewer.setStyleAdapter(styleProvider);
/*     */     }
/*     */     
/*     */ 
/* 115 */     final TextDocumentLocationGenerator locationGenerator = new TextDocumentLocationGenerator(unit, this.iviewer);
/* 116 */     this.iviewer.addPositionListener(new IPositionListener()
/*     */     {
/*     */       public void positionChanged(ITextDocumentViewer viewer, ICoordinates coordinates, int focusChange) {
/* 119 */         if (context != null) {
/* 120 */           context.refreshHandlersStates();
/*     */         }
/*     */         
/* 123 */         if (statusIndicator != null)
/*     */         {
/* 125 */           String status = locationGenerator.generateStatus(coordinates);
/* 126 */           statusIndicator.setText(status);
/*     */         }
/*     */       }
/*     */       
/*     */       public void positionUnchangedAttemptBreakout(ITextDocumentViewer viewer, int direction)
/*     */       {
/* 132 */         if (controller != null) {
/* 133 */           controller.onNodeBreakoutAttempt(NodeContentsInteractiveTextView.this, direction);
/*     */         }
/*     */       }
/*     */     });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */     if (context != null) {
/* 149 */       UIState uiState = context.getUIState(unit);
/* 150 */       this.textAnnotator = new UnitTextAnnotator(uiState, this.iviewer);
/*     */     }
/*     */     
/* 153 */     this.iviewer.initialize(false);
/*     */     
/* 155 */     this.w.setDoubleClickEnabled(false);
/* 156 */     this.w.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseDoubleClick(MouseEvent e) {
/* 159 */         NodeContentsInteractiveTextView.this.requestOperation(new OperationRequest(Operation.ITEM_FOLLOW));
/*     */       }
/*     */     });
/*     */     
/* 163 */     if (context != null) {
/* 164 */       this.iviewer.setHoverText(new TextHoverableProvider(context, unit, this.iviewer));
/*     */     }
/*     */     
/* 167 */     addStandardContextMenu(new int[] { 4 });
/*     */     
/* 169 */     addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/* 172 */         NodeContentsInteractiveTextView.this.iviewer.dispose();
/* 173 */         if (NodeContentsInteractiveTextView.this.textAnnotator != null) {
/* 174 */           NodeContentsInteractiveTextView.this.textAnnotator.dispose();
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point computeSize(int wHint, int hHint, boolean changed)
/*     */   {
/* 196 */     if (this.w.isDisposed()) {
/* 197 */       return new Point(0, 0);
/*     */     }
/* 199 */     return this.iviewer.computeIdealSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setFocus()
/*     */   {
/* 208 */     if (this.w.isDisposed()) {
/* 209 */       return false;
/*     */     }
/* 211 */     return this.w.setFocus();
/*     */   }
/*     */   
/*     */   public boolean forceFocus()
/*     */   {
/* 216 */     if (this.w.isDisposed()) {
/* 217 */       return false;
/*     */     }
/* 219 */     return this.w.forceFocus();
/*     */   }
/*     */   
/*     */   public boolean isFocusControl()
/*     */   {
/* 224 */     if (this.w.isDisposed()) {
/* 225 */       return false;
/*     */     }
/* 227 */     return this.w.isFocusControl();
/*     */   }
/*     */   
/*     */   public void addFocusListener(FocusListener listener)
/*     */   {
/* 232 */     if (this.w.isDisposed()) {
/* 233 */       return;
/*     */     }
/* 235 */     super.addFocusListener(listener);
/* 236 */     this.w.addFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void removeFocusListener(FocusListener listener)
/*     */   {
/* 241 */     if (this.w.isDisposed()) {
/* 242 */       return;
/*     */     }
/* 244 */     super.removeFocusListener(listener);
/* 245 */     this.w.removeFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void setFont(Font font)
/*     */   {
/* 250 */     if (this.w.isDisposed()) {
/* 251 */       return;
/*     */     }
/* 253 */     super.setFont(font);
/* 254 */     this.w.setFont(font);
/*     */   }
/*     */   
/*     */   public Color getForeground()
/*     */   {
/* 259 */     return this.w.getForeground();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForeground(Color color)
/*     */   {
/* 271 */     if (this.w.isDisposed()) {
/* 272 */       return;
/*     */     }
/* 274 */     super.setForeground(color);
/* 275 */     this.w.setForeground(color);
/*     */   }
/*     */   
/*     */   public Color getBackground()
/*     */   {
/* 280 */     return this.w.getBackground();
/*     */   }
/*     */   
/*     */   public void setBackground(Color color)
/*     */   {
/* 285 */     if (this.w.isDisposed()) {
/* 286 */       return;
/*     */     }
/* 288 */     super.setBackground(color);
/* 289 */     this.w.setBackground(color);
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/* 294 */     if (this.w.isDisposed()) {
/* 295 */       return;
/*     */     }
/* 297 */     super.setEnabled(enabled);
/* 298 */     this.w.setEnabled(enabled);
/*     */   }
/*     */   
/*     */   public void setMenu(Menu menu)
/*     */   {
/* 303 */     if (this.w.isDisposed()) {
/* 304 */       return;
/*     */     }
/* 306 */     super.setMenu(menu);
/* 307 */     this.w.setMenu(menu);
/*     */   }
/*     */   
/*     */   public void setToolTipText(String string)
/*     */   {
/* 312 */     if (this.w.isDisposed()) {
/* 313 */       return;
/*     */     }
/* 315 */     super.setToolTipText(string);
/* 316 */     this.w.setToolTipText(string);
/*     */   }
/*     */   
/*     */   public void setCursor(Cursor cursor)
/*     */   {
/* 321 */     if (this.w.isDisposed()) {
/* 322 */       return;
/*     */     }
/* 324 */     super.setCursor(cursor);
/* 325 */     this.w.setCursor(cursor);
/*     */   }
/*     */   
/*     */   public void setText(String text) {
/* 329 */     if (this.w.isDisposed()) {
/* 330 */       return;
/*     */     }
/* 332 */     this.w.setText(text);
/*     */   }
/*     */   
/*     */   public String getText() {
/* 336 */     if (this.w.isDisposed()) {
/* 337 */       return "";
/*     */     }
/* 339 */     return this.w.getText();
/*     */   }
/*     */   
/*     */   public void setEditable(boolean editable) {
/* 343 */     if (this.w.isDisposed()) {
/* 344 */       return;
/*     */     }
/* 346 */     this.w.setEditable(editable);
/*     */   }
/*     */   
/*     */   public void setCaret(Caret caret) {
/* 350 */     if (this.w.isDisposed()) {
/* 351 */       return;
/*     */     }
/* 353 */     this.w.setCaret(caret);
/*     */   }
/*     */   
/*     */   public Caret getCaret() {
/* 357 */     if (this.w.isDisposed()) {
/* 358 */       return null;
/*     */     }
/* 360 */     return this.w.getCaret();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verifyOperation(OperationRequest req)
/*     */   {
/* 369 */     if (this.iviewer.verifyOperation(req)) {
/* 370 */       return true;
/*     */     }
/*     */     
/* 373 */     switch (req.getOperation()) {
/*     */     case JUMP_TO: 
/* 375 */       return true;
/*     */     case ITEM_FOLLOW: 
/* 377 */       return getActiveItem() instanceof IActionableItem;
/*     */     }
/* 379 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean doOperation(OperationRequest req)
/*     */   {
/* 385 */     if (this.iviewer.doOperation(req)) {
/* 386 */       return true;
/*     */     }
/* 388 */     if (!req.proceed()) {
/* 389 */       return false;
/*     */     }
/* 391 */     switch (req.getOperation()) {
/*     */     case JUMP_TO: 
/* 393 */       return false;
/*     */     case ITEM_FOLLOW: 
/* 395 */       return doItemFollow();
/*     */     }
/* 397 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IUnit getUnit()
/*     */   {
/* 407 */     return this.unit;
/*     */   }
/*     */   
/*     */   public boolean isActiveItem(IItem item)
/*     */   {
/* 412 */     return this.styleProvider == null ? false : this.styleProvider.isActiveItem(item);
/*     */   }
/*     */   
/*     */   public IItem getActiveItem()
/*     */   {
/* 417 */     return this.styleProvider == null ? null : this.styleProvider.getActiveItem();
/*     */   }
/*     */   
/*     */   public String getActiveItemAsText()
/*     */   {
/* 422 */     IItem item = getActiveItem();
/* 423 */     if (!(item instanceof ITextItem)) {
/* 424 */       return null;
/*     */     }
/* 426 */     return ((ITextItem)item).getText();
/*     */   }
/*     */   
/*     */   public String getActiveAddress(AddressConversionPrecision precision)
/*     */   {
/* 431 */     ICoordinates coords = this.iviewer.getCaretCoordinates();
/* 432 */     if (coords != null) {
/* 433 */       return this.idoc.coordinatesToAddress(coords, AddressConversionPrecision.FINE);
/*     */     }
/* 435 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isValidActiveAddress(String address, Object object)
/*     */   {
/*     */     try {
/* 441 */       ICoordinates coord = this.idoc.addressToCoordinates(address);
/* 442 */       return coord != null;
/*     */     }
/*     */     catch (Exception e) {
/* 445 */       logger.catching(e); }
/* 446 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean setActiveAddress(String address, Object extra, boolean record)
/*     */   {
/* 453 */     ICoordinates coord = null;
/*     */     try {
/* 455 */       coord = this.idoc.addressToCoordinates(address);
/*     */     }
/*     */     catch (Exception e) {
/* 458 */       logger.catching(e);
/*     */     }
/*     */     
/* 461 */     if (coord == null) {
/* 462 */       return false;
/*     */     }
/*     */     
/* 465 */     GlobalPosition pos0 = null;
/* 466 */     if (record) {
/* 467 */       pos0 = getViewManager() == null ? null : getViewManager().getCurrentGlobalPosition();
/*     */     }
/*     */     
/* 470 */     BufferPoint vp = null;
/* 471 */     if ((extra instanceof BufferPoint)) {
/* 472 */       vp = (BufferPoint)extra;
/*     */     }
/*     */     
/* 475 */     if (!this.iviewer.setCaretCoordinates(coord, vp, false)) {
/* 476 */       return false;
/*     */     }
/*     */     
/* 479 */     if (pos0 != null) {
/* 480 */       getViewManager().recordGlobalPosition(pos0);
/*     */     }
/* 482 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getZoomLevel()
/*     */   {
/* 494 */     return this.zoomLevel;
/*     */   }
/*     */   
/*     */   public boolean applyZoom(int zoom, boolean dryRun)
/*     */   {
/* 499 */     zoom = ZoomableUtil.sanitizeZoom(zoom);
/* 500 */     if (ZoomableUtil.updateZoom(this.zoomLevel, zoom) == 0) {
/* 501 */       zoom = 0;
/*     */     }
/*     */     
/* 504 */     FontData[] fdlist = this.w.getFont().getFontData();
/* 505 */     FontData fd0 = fdlist[0];
/* 506 */     int currentHeight = fd0.getHeight();
/*     */     
/* 508 */     if (this.defaultHeight == null) {
/* 509 */       this.defaultHeight = Integer.valueOf(currentHeight);
/*     */     }
/*     */     
/* 512 */     int newHeight = determineNextFontHeight(currentHeight, zoom);
/* 513 */     if ((newHeight == currentHeight) || (newHeight <= 1)) {
/* 514 */       return false;
/*     */     }
/*     */     
/* 517 */     if (!dryRun) {
/* 518 */       logger.i("New font height after zoom: %d", new Object[] { Integer.valueOf(newHeight) });
/* 519 */       FontDescriptor desc = FontDescriptor.createFrom(fdlist).setHeight(newHeight);
/* 520 */       Font f = createFont(getDisplay(), desc);
/* 521 */       this.w.setFont(f);
/* 522 */       this.zoomLevel = ZoomableUtil.updateZoom(this.zoomLevel, zoom);
/*     */     }
/* 524 */     return true;
/*     */   }
/*     */   
/* 527 */   private static Map<FontDescriptor, Font> fontmap = new HashMap();
/*     */   
/*     */   private static Font createFont(Display display, FontDescriptor desc)
/*     */   {
/* 531 */     Font f = (Font)fontmap.get(desc);
/* 532 */     if (f == null) {
/* 533 */       f = desc.createFont(display);
/* 534 */       fontmap.put(desc, f);
/*     */     }
/* 536 */     return f;
/*     */   }
/*     */   
/* 539 */   private static final int[] wkhsuite = { 1, 2, 4, 6, 8, 10, 14, 20 };
/* 540 */   private static final int wkhLastIndex = wkhsuite.length - 1;
/*     */   
/*     */   private int determineNextFontHeight(int h, int zoom) {
/* 543 */     if (zoom == 0) {
/* 544 */       return this.defaultHeight.intValue();
/*     */     }
/*     */     
/* 547 */     int i = 0;
/* 548 */     for (int v : wkhsuite) {
/* 549 */       if (v >= h) {
/*     */         break;
/*     */       }
/* 552 */       i++;
/*     */     }
/* 554 */     if (i < wkhsuite.length) {
/* 555 */       int v = wkhsuite[i];
/* 556 */       if (v > h) {
/* 557 */         i--;
/*     */       }
/*     */     }
/*     */     
/* 561 */     if (i <= 0) {
/* 562 */       return wkhsuite[0];
/*     */     }
/*     */     
/* 565 */     if (zoom > 0) {
/* 566 */       if (i >= wkhLastIndex) {
/* 567 */         return (int)(1.5D * h);
/*     */       }
/* 569 */       return wkhsuite[(i + 1)];
/*     */     }
/*     */     
/* 572 */     if (i >= wkhsuite.length) {
/* 573 */       return wkhsuite[wkhLastIndex];
/*     */     }
/* 575 */     return wkhsuite[(i - 1)];
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\NodeContentsInteractiveTextView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */