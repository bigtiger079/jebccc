/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphMode
/*    */ {
/*    */   int id;
/*    */   String name;
/*    */   String description;
/*    */   
/*    */   public GraphMode(int id, String name, String description)
/*    */   {
/* 17 */     this.id = id;
/* 18 */     this.name = Strings.safe(name, "Mode " + id);
/* 19 */     this.description = Strings.safe(description);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 23 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 27 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 31 */     return this.description;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 36 */     return this.name;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */