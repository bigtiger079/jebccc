package com.pnfsoftware.jeb.rcpclient.extensions.graph;

public abstract interface IGraphController
{
  public abstract void onNodeBreakoutAttempt(IGraphNodeContents paramIGraphNodeContents, int paramInt);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\IGraphController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */