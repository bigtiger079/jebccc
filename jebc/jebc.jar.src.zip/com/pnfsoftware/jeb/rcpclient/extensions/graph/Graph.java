/*      */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*      */ 
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.UI;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IZoomable;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ZoomableUtil;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.layout.Cell;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.layout.ConstraintSolver;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.layout.Spreadsheet;
/*      */ import com.pnfsoftware.jeb.rcpclient.extensions.graph.layout.Vector;
/*      */ import com.pnfsoftware.jeb.rcpclient.util.ColorsGradient;
/*      */ import com.pnfsoftware.jeb.util.base.Assert;
/*      */ import com.pnfsoftware.jeb.util.base.Flags;
/*      */ import com.pnfsoftware.jeb.util.collect.IMultiSegmentMap;
/*      */ import com.pnfsoftware.jeb.util.collect.ISegmentMap;
/*      */ import com.pnfsoftware.jeb.util.collect.IntegerSegment;
/*      */ import com.pnfsoftware.jeb.util.collect.MultiMap;
/*      */ import com.pnfsoftware.jeb.util.collect.MultiSegmentMap;
/*      */ import com.pnfsoftware.jeb.util.collect.SegmentMap;
/*      */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*      */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.SWTException;
/*      */ import org.eclipse.swt.events.DisposeEvent;
/*      */ import org.eclipse.swt.events.DisposeListener;
/*      */ import org.eclipse.swt.events.MouseEvent;
/*      */ import org.eclipse.swt.events.MouseListener;
/*      */ import org.eclipse.swt.events.MouseMoveListener;
/*      */ import org.eclipse.swt.events.PaintEvent;
/*      */ import org.eclipse.swt.events.PaintListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Control;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ import org.eclipse.swt.widgets.Event;
/*      */ import org.eclipse.swt.widgets.Listener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Graph
/*      */   extends AbstractGraph
/*      */   implements IZoomable
/*      */ {
/*   71 */   private static final ILogger logger = GlobalLog.getLogger(Graph.class);
/*      */   
/*      */   static final int FLAG_NODE_NO_HANDLES = 1;
/*      */   
/*      */   static final int FLAG_NODE_NO_CONTENTS = 2;
/*   76 */   private boolean keyboardControls = true;
/*   77 */   private boolean mouseControls = true;
/*      */   
/*      */   private boolean kbModifier1Pressed;
/*   80 */   private GraphStyleData styleData = GraphStyleData.buildDefault();
/*      */   
/*   82 */   private List<GraphNode> nodes = new ArrayList();
/*   83 */   private List<GraphEdge> edges = new ArrayList();
/*      */   
/*      */   private Spreadsheet<GraphNode> grid;
/*   86 */   private Point lastMouseCursor = new Point(-1, -1);
/*   87 */   private Point lastMouseCursorDown = new Point(-1, -1);
/*      */   
/*   89 */   private boolean zoomingAllowed = true;
/*      */   
/*      */   private int initialZoomLevel;
/*      */   
/*      */   private int zoomLevel;
/*   94 */   Point virtualOrigin = new Point(0, 0);
/*      */   
/*   96 */   private int[] xConstraints = new int[0];
/*   97 */   private int[] yConstraints = new int[0];
/*      */   
/*      */   private boolean dragging;
/*      */   
/*      */   private int draggingX;
/*      */   
/*      */   private int draggingY;
/*      */   private boolean activeEdgeColoringEnabled;
/*  105 */   private int activeEdgeId = -1;
/*  106 */   private GraphNode hoverNode = null;
/*  107 */   private GraphNode activeNode = null;
/*      */   
/*  109 */   private Flags nodeFlags = new Flags();
/*      */   
/*      */   private static final int defaultNodeWidth = 150;
/*      */   
/*      */   private static final int defaultNodeHeight = 100;
/*      */   
/*      */   private static final double nodeMarginTop = 10.0D;
/*      */   
/*      */   private static final double nodeMarginBottom = 10.0D;
/*      */   
/*      */   private static final double nodeMarginLeft = 10.0D;
/*      */   private static final double nodeMarginRight = 10.0D;
/*  121 */   private boolean debugging = false;
/*  122 */   private boolean dbgDoNotDisplayNodesGrid = false;
/*  123 */   private Color[] dbgNodeColors = { SwtRegistry.getInstance().getColor(14737408), 
/*  124 */     SwtRegistry.getInstance().getColor(57568) };
/*      */   
/*      */   private long lastRedrawExectime;
/*      */   
/*      */   static final int REDRAW_CAUSE_OTHER = 0;
/*      */   
/*      */   static final int REDRAW_CAUSE_DRAG = 1;
/*      */   private int redrawCause;
/*      */   private Object redrawObject;
/*      */   private GraphEdgeManager edgeman;
/*      */   
/*      */   public Graph(Composite parent, int style)
/*      */   {
/*  137 */     super(parent, 537919488);
/*  138 */     setLayout(null);
/*      */     
/*  140 */     UI.initialize();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  152 */     addPaintListener(new PaintListener()
/*      */     {
/*      */       public void paintControl(PaintEvent e)
/*      */       {
/*  156 */         Assert.a(Graph.this.nodes.size() == Graph.this.getChildren().length, "Illegal children were detected");
/*      */         
/*      */         try
/*      */         {
/*  160 */           e.gc.setAntialias(1); } catch (SWTException localSWTException) {}
/*      */         int[] xBases;
/*      */         int[] yBases;
/*      */         int icol;
/*      */         Iterator<Integer> colors;
/*  165 */         if ((Graph.this.debugging) && (!Graph.this.dbgDoNotDisplayNodesGrid)) {
/*  166 */           boolean betterNodeGridColoring = true;
/*      */           
/*  168 */           xBases = Graph.this.buildCoordsFromSizes(Graph.this.virtualOrigin.x, Graph.this.xConstraints);
/*  169 */           yBases = Graph.this.buildCoordsFromSizes(Graph.this.virtualOrigin.y, Graph.this.yConstraints);
/*  170 */           List<Cell<GraphNode>> cells = Graph.this.grid.getRealCells();
/*  171 */           icol = 0;
/*  172 */           colors = ColorsGradient.getSequentialIterator(0, 10);
/*  173 */           for (Cell<GraphNode> cell : cells) {
/*  174 */             int x0 = xBases[cell.getColumn()];
/*  175 */             int x1 = xBases[cell.getNextColumn()];
/*  176 */             int y0 = yBases[cell.getRow()];
/*  177 */             int y1 = yBases[cell.getNextRow()];
/*  178 */             e.gc.setBackground(SwtRegistry.getInstance().getColor(((Integer)colors.next()).intValue()));
/*  179 */             e.gc.fillRectangle(x0, y0, x1 - x0, y1 - y0);
/*  180 */             icol = 1 - icol;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  210 */         Graph.this.redrawEdges(e.gc);
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  217 */     });
/*  218 */     addMouseListener(new MouseListener()
/*      */     {
/*      */       public void mouseDown(MouseEvent e) {
/*  221 */         if (e.button != 1) {
/*  222 */           return;
/*      */         }
/*      */         
/*  225 */         Graph.this.lastMouseCursorDown.x = e.x;
/*  226 */         Graph.this.lastMouseCursorDown.y = e.y;
/*      */         
/*      */ 
/*  229 */         if (Graph.this.activeEdgeId != -1) {
/*  230 */           Graph.logger.i("Mouse click on Edge: %d", new Object[] { Integer.valueOf(Graph.this.activeEdgeId) });
/*      */           
/*  232 */           GraphNode target = Graph.this.isPrimaryModifierKeyPressed() ? ((GraphEdge)Graph.this.edges.get(Graph.this.activeEdgeId)).src : ((GraphEdge)Graph.this.edges.get(Graph.this.activeEdgeId)).dst;
/*  233 */           Graph.this.centerGraph(target, 16777216, 16777216, true);
/*  234 */           Graph.this.setActiveNode(target, false);
/*      */ 
/*      */         }
/*  237 */         else if (Graph.this.hoverNode != null) {
/*  238 */           Graph.logger.i("Mouse click on Node: %s", new Object[] { Graph.this.activeNode });
/*      */         }
/*      */         else
/*      */         {
/*  242 */           Graph.this.dragging = true;
/*  243 */           Graph.this.draggingX = e.x;
/*  244 */           Graph.this.draggingY = e.y;
/*      */         }
/*      */       }
/*      */       
/*      */       public void mouseUp(MouseEvent e)
/*      */       {
/*  250 */         if (e.button != 1) {
/*  251 */           return;
/*      */         }
/*      */         
/*  254 */         if (Graph.this.dragging)
/*      */         {
/*      */ 
/*  257 */           if (new Point(e.x, e.y).equals(Graph.this.lastMouseCursorDown)) {
/*  258 */             Graph.this.setFocus();
/*      */           }
/*  260 */           Graph.this.dragging = false;
/*      */         }
/*      */       }
/*      */       
/*      */       public void mouseDoubleClick(MouseEvent e)
/*      */       {
/*  266 */         if (e.button != 1) {
/*  267 */           return;
/*      */         }
/*  269 */         Graph.logger.i("DBLCLK: active edge: " + Graph.this.activeEdgeId, new Object[0]);
/*      */       }
/*  271 */     });
/*  272 */     addMouseMoveListener(new MouseMoveListener()
/*      */     {
/*      */ 
/*      */       public void mouseMove(MouseEvent e)
/*      */       {
/*  277 */         Graph.this.lastMouseCursor.x = e.x;
/*  278 */         Graph.this.lastMouseCursor.y = e.y;
/*      */         
/*  280 */         if (Graph.this.dragging) {
/*  281 */           int deltaX = e.x - Graph.this.draggingX;
/*  282 */           int deltaY = e.y - Graph.this.draggingY;
/*  283 */           Graph.this.draggingX = e.x;
/*  284 */           Graph.this.draggingY = e.y;
/*  285 */           Graph.this.dragGraph(deltaX, deltaY);
/*  286 */           return;
/*      */         }
/*      */         
/*      */ 
/*  290 */         Graph.this.determineActiveEdge(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  378 */     });
/*  379 */     final Listener mouseMoveFilter = new Listener()
/*      */     {
/*      */       public void handleEvent(Event e) {
/*  382 */         if (!(e.widget instanceof Control)) {
/*  383 */           return;
/*      */         }
/*  385 */         Control ctl = (Control)e.widget;
/*      */         
/*      */ 
/*      */ 
/*  389 */         if (!Graph.this.isVisible()) {
/*  390 */           return;
/*      */         }
/*      */         
/*  393 */         Point p = Display.getCurrent().map(ctl, Graph.this, new Point(e.x, e.y));
/*      */         
/*      */ 
/*  396 */         GraphNode currentNode = null;
/*  397 */         for (GraphNode node : Graph.this.nodes) {
/*  398 */           Rectangle b = node.getBounds();
/*  399 */           if ((p.x >= b.x) && (p.x < b.x + b.width) && (p.y >= b.y) && (p.y < b.y + b.height)) {
/*  400 */             currentNode = node;
/*  401 */             break;
/*      */           }
/*      */         }
/*  404 */         if ((Graph.this.hoverNode != null) && ((currentNode == null) || (currentNode != Graph.this.hoverNode))) {
/*  405 */           Graph.this.notifyNodeMouseExit(Graph.this.hoverNode);
/*  406 */           Graph.this.hoverNode = null;
/*      */         }
/*  408 */         if ((Graph.this.hoverNode == null) && (currentNode != null)) {
/*  409 */           Graph.this.notifyNodeMouseEnter(currentNode);
/*  410 */           Graph.this.hoverNode = currentNode;
/*      */         }
/*      */       }
/*  413 */     };
/*  414 */     getDisplay().addFilter(5, mouseMoveFilter);
/*      */     
/*  416 */     addDisposeListener(new DisposeListener()
/*      */     {
/*      */       public void widgetDisposed(DisposeEvent e) {
/*  419 */         Graph.this.getDisplay().removeFilter(5, mouseMoveFilter);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   public void setStyleData(GraphStyleData styleData) {
/*  425 */     this.styleData = (styleData == null ? GraphStyleData.buildDefault() : styleData);
/*      */   }
/*      */   
/*      */   public GraphStyleData getStyleData() {
/*  429 */     return this.styleData;
/*      */   }
/*      */   
/*      */   private boolean isPrimaryModifierKeyPressed() {
/*  433 */     return (this.kbModifier1Pressed) || ((UI.getKeyboardModifiersState() & SWT.MOD1) != 0);
/*      */   }
/*      */   
/*      */   private int[] buildCoordsFromSizes(int start, int[] sizes)
/*      */   {
/*  438 */     int[] coords = new int[sizes.length + 1];
/*  439 */     for (int i = 0; i < coords.length; i++) {
/*  440 */       coords[i] = start;
/*      */     }
/*  442 */     for (int i = 1; i < coords.length; i++) {
/*  443 */       int size = sizes[(i - 1)];
/*  444 */       for (int j = i; j < coords.length; j++) {
/*  445 */         coords[j] += size;
/*      */       }
/*      */     }
/*  448 */     return coords;
/*      */   }
/*      */   
/*      */   public boolean setFocus()
/*      */   {
/*  453 */     return forceFocus();
/*      */   }
/*      */   
/*      */   public void setDebugging(boolean debugging) {
/*  457 */     this.debugging = debugging;
/*      */   }
/*      */   
/*      */   public boolean isDebugging() {
/*  461 */     return this.debugging;
/*      */   }
/*      */   
/*      */   public void setZoomingAllowed(boolean zoomingAllowed) {
/*  465 */     this.zoomingAllowed = zoomingAllowed;
/*      */   }
/*      */   
/*      */   public boolean isZoomingAllowed() {
/*  469 */     return this.zoomingAllowed;
/*      */   }
/*      */   
/*      */   public void setInitialZoomLevel(int initialZoomLevel) {
/*  473 */     this.initialZoomLevel = initialZoomLevel;
/*      */   }
/*      */   
/*      */   public int getInitialZoomLevel() {
/*  477 */     return this.initialZoomLevel;
/*      */   }
/*      */   
/*      */   public void setKeyboardControls(boolean keyboardControls) {
/*  481 */     this.keyboardControls = keyboardControls;
/*      */   }
/*      */   
/*      */   public boolean isKeyboardControls() {
/*  485 */     return this.keyboardControls;
/*      */   }
/*      */   
/*      */   public void setMouseControls(boolean mouseControls) {
/*  489 */     this.mouseControls = mouseControls;
/*      */   }
/*      */   
/*      */   public boolean isMouseControls() {
/*  493 */     return this.mouseControls;
/*      */   }
/*      */   
/*      */   public void setActiveEdgeColoringEnabled(boolean activeEdgeColoringEnabled) {
/*  497 */     this.activeEdgeColoringEnabled = activeEdgeColoringEnabled;
/*      */   }
/*      */   
/*      */   public boolean isActiveEdgeColoringEnabled() {
/*  501 */     return this.activeEdgeColoringEnabled;
/*      */   }
/*      */   
/*      */   private void determineActiveEdge(Point pt) {
/*  505 */     if (pt == null) {
/*  506 */       pt = this.lastMouseCursor;
/*      */     }
/*  508 */     int edgeId = getActiveLineGroupId(pt.x, pt.y, 4, 4);
/*  509 */     changeActiveEdge(edgeId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void changeActiveEdge(int edgeId)
/*      */   {
/*  520 */     if (edgeId >= 0) {
/*  521 */       if (this.activeEdgeId != edgeId)
/*      */       {
/*      */ 
/*      */ 
/*  525 */         if (this.activeEdgeId >= 0) {
/*  526 */           GraphEdge edge = (GraphEdge)this.edges.get(this.activeEdgeId);
/*  527 */           edge.setState(0);
/*  528 */           notifyEdgeMouseExit(edge);
/*      */         }
/*  530 */         GraphEdge edge = (GraphEdge)this.edges.get(edgeId);
/*  531 */         edge.setState(1);
/*  532 */         this.activeEdgeId = edgeId;
/*  533 */         if (!this.activeEdgeColoringEnabled) {
/*  534 */           refreshGraph();
/*      */         }
/*  536 */         notifyEdgeMouseEnter(edge);
/*      */       }
/*      */       
/*      */     }
/*  540 */     else if (this.activeEdgeId >= 0) {
/*  541 */       GraphEdge edge = (GraphEdge)this.edges.get(this.activeEdgeId);
/*  542 */       edge.setState(0);
/*  543 */       this.activeEdgeId = -1;
/*  544 */       if (!this.activeEdgeColoringEnabled) {
/*  545 */         refreshGraph();
/*      */       }
/*  547 */       notifyEdgeMouseExit(edge);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getVertexCount()
/*      */   {
/*  557 */     return getNodeCount();
/*      */   }
/*      */   
/*      */   public int getNodeCount() {
/*  561 */     return this.nodes.size();
/*      */   }
/*      */   
/*      */   public GraphNode getNode(int index) {
/*  565 */     return (GraphNode)this.nodes.get(index);
/*      */   }
/*      */   
/*      */   public List<GraphNode> getNodes() {
/*  569 */     return this.nodes;
/*      */   }
/*      */   
/*      */   public GraphNode getActiveNode() {
/*  573 */     return this.activeNode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActiveNode(GraphNode node, boolean centerOnNode)
/*      */   {
/*  582 */     if (node == null) {
/*  583 */       if (this.activeNode != null)
/*      */       {
/*  585 */         setFocus();
/*      */       }
/*      */     }
/*  588 */     else if (node != this.activeNode)
/*      */     {
/*  590 */       node.setFocus();
/*  591 */       if (centerOnNode) {
/*  592 */         centerGraph(node);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean checkNodeVisibility(GraphNode node, boolean wantFullyVisible) {
/*  598 */     Rectangle a = getClientArea();
/*  599 */     int left0 = a.x;
/*  600 */     int right0 = a.x + a.width;
/*  601 */     int top0 = a.y;
/*  602 */     int bottom0 = a.y + a.height;
/*      */     
/*  604 */     Rectangle b = node.getBounds();
/*  605 */     int left1 = b.x;
/*  606 */     int right1 = b.x + b.width;
/*  607 */     int top1 = b.y;
/*  608 */     int bottom1 = b.y + b.height;
/*      */     
/*      */ 
/*  611 */     if ((left1 >= left0) && (right1 <= right0) && (top1 >= top0) && (bottom1 <= bottom0)) {
/*  612 */       return true;
/*      */     }
/*      */     
/*  615 */     if (wantFullyVisible) {
/*  616 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  620 */     left0 -= b.width;
/*  621 */     right0 += b.width;
/*  622 */     top0 -= b.height;
/*  623 */     bottom0 += b.height;
/*  624 */     if ((left1 > left0) && (right1 < right0) && (top1 > top0) && (bottom1 < bottom0)) {
/*  625 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  629 */     return false;
/*      */   }
/*      */   
/*      */   public void showNode(GraphNode node, boolean wantFullyVisible) {
/*  633 */     if (!checkNodeVisibility(node, wantFullyVisible)) {
/*  634 */       centerGraph(node, 128, 128, true);
/*      */     }
/*      */   }
/*      */   
/*      */   public List<GraphEdge> getEdges() {
/*  639 */     return this.edges;
/*      */   }
/*      */   
/*      */   public GraphEdge getActiveEdge() {
/*  643 */     if (this.activeEdgeId < 0) {
/*  644 */       return null;
/*      */     }
/*  646 */     return (GraphEdge)this.edges.get(this.activeEdgeId);
/*      */   }
/*      */   
/*      */   public void setActiveEdge(GraphEdge edge) {
/*  650 */     int edgeId = this.edges.indexOf(edge);
/*  651 */     changeActiveEdge(edgeId);
/*      */   }
/*      */   
/*      */   public void dragGraph(int deltaX, int deltaY)
/*      */   {
/*  656 */     dragGraph(deltaX, deltaY, false);
/*      */   }
/*      */   
/*      */   public void dragGraph(int deltaX, int deltaY, boolean progressive)
/*      */   {
/*  661 */     int virtualOriginX1 = this.virtualOrigin.x + deltaX;
/*  662 */     int virtualOriginY1 = this.virtualOrigin.y + deltaY;
/*      */     int frameCount;
/*  664 */     if (progressive)
/*      */     {
/*      */ 
/*  667 */       frameCount = 10;
/*  668 */       int incrX = deltaX / 10;
/*  669 */       int incrY = deltaY / 10;
/*      */       
/*      */ 
/*  672 */       if ((incrX != 0) || (incrY != 0)) {
/*  673 */         for (int i = 0; i < 9; i++) {
/*  674 */           this.virtualOrigin.x += incrX;
/*  675 */           this.virtualOrigin.y += incrY;
/*  676 */           for (GraphNode node : this.nodes) {
/*  677 */             Point loc = node.getLocation();
/*  678 */             loc.x += incrX;
/*  679 */             loc.y += incrY;
/*  680 */             node.setLocation(loc);
/*      */           }
/*  682 */           refreshGraph(1, new Point(incrX, incrY));
/*      */           
/*      */           try
/*      */           {
/*  686 */             Thread.sleep(10L);
/*      */           }
/*      */           catch (InterruptedException e)
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  696 */     deltaX = virtualOriginX1 - this.virtualOrigin.x;
/*  697 */     deltaY = virtualOriginY1 - this.virtualOrigin.y;
/*  698 */     this.virtualOrigin.x = virtualOriginX1;
/*  699 */     this.virtualOrigin.y = virtualOriginY1;
/*  700 */     for (GraphNode node : this.nodes) {
/*  701 */       Point loc = node.getLocation();
/*  702 */       loc.x += deltaX;
/*  703 */       loc.y += deltaY;
/*  704 */       node.setLocation(loc);
/*      */     }
/*  706 */     refreshGraph(1, new Point(deltaX, deltaY));
/*      */   }
/*      */   
/*      */   public void centerGraph(int nodeIndex) {
/*  710 */     if ((nodeIndex < 0) || (nodeIndex >= this.nodes.size())) {
/*  711 */       return;
/*      */     }
/*  713 */     centerGraph((GraphNode)this.nodes.get(nodeIndex));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void centerGraph(GraphNode node)
/*      */   {
/*  723 */     centerGraph(node, 128, 128, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void centerGraph(GraphNode node, int nodeAnchorFlags, int clientAnchorFlags, boolean progressive)
/*      */   {
/*  737 */     verifyNode(node);
/*  738 */     logger.debug("Centering on node: %s", new Object[] { node });
/*      */     
/*  740 */     Rectangle bounds = node.getBounds();
/*      */     
/*      */ 
/*  743 */     Rectangle client = getClientArea();
/*      */     
/*      */ 
/*  746 */     int x0 = bounds.x + bounds.width / 2;
/*  747 */     int y0 = bounds.y + bounds.height / 2;
/*  748 */     if ((nodeAnchorFlags & 0x80) != 0) {
/*  749 */       y0 = bounds.y;
/*      */     }
/*  751 */     else if ((nodeAnchorFlags & 0x400) != 0) {
/*  752 */       y0 = bounds.y + bounds.height;
/*      */     }
/*  754 */     if ((nodeAnchorFlags & 0x4000) != 0) {
/*  755 */       x0 = bounds.x;
/*      */     }
/*  757 */     else if ((nodeAnchorFlags & 0x20000) != 0) {
/*  758 */       x0 = bounds.x + bounds.width;
/*      */     }
/*      */     
/*      */ 
/*  762 */     int x1 = client.width / 2;
/*  763 */     int y1 = client.height / 2;
/*  764 */     if ((clientAnchorFlags & 0x80) != 0) {
/*  765 */       y1 = client.height / 10;
/*      */     }
/*  767 */     else if ((clientAnchorFlags & 0x400) != 0) {
/*  768 */       y1 = client.height * 9 / 10;
/*      */     }
/*  770 */     if ((clientAnchorFlags & 0x4000) != 0) {
/*  771 */       x1 = client.width / 10;
/*      */     }
/*  773 */     else if ((clientAnchorFlags & 0x20000) != 0) {
/*  774 */       x1 = client.width * 9 / 10;
/*      */     }
/*      */     
/*  777 */     int deltaX = x1 - x0;
/*  778 */     int deltaY = y1 - y0;
/*  779 */     dragGraph(deltaX, deltaY, progressive);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void positionGraph(double xRatio, double yRatio)
/*      */   {
/*  786 */     Rectangle container = getContainerArea();
/*  787 */     Rectangle client = getClientArea();
/*      */     
/*  789 */     int x0 = (int)(container.x + xRatio * container.width);
/*  790 */     int y0 = (int)(container.y + yRatio * container.height);
/*      */     
/*  792 */     int deltaX = client.width / 2 - x0;
/*  793 */     int deltaY = client.height / 2 - y0;
/*  794 */     dragGraph(deltaX, deltaY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void centerGraph()
/*      */   {
/*  802 */     Rectangle container = getContainerArea();
/*  803 */     Rectangle client = getClientArea();
/*      */     
/*      */ 
/*  806 */     int x = (client.width - container.width) / 2;
/*  807 */     int y = (client.height - container.height) / 2;
/*      */     
/*  809 */     int deltaX = x - container.x;
/*  810 */     int deltaY = y - container.y;
/*  811 */     dragGraph(deltaX, deltaY);
/*      */   }
/*      */   
/*      */   public void zoomGraph(int zoom)
/*      */   {
/*  816 */     zoomGraph(zoom, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public void zoomGraph(int zoom, Point centerPoint)
/*      */   {
/*  822 */     applyZoom(zoom, false);
/*      */   }
/*      */   
/*      */   public int getZoomLevel()
/*      */   {
/*  827 */     return this.zoomLevel;
/*      */   }
/*      */   
/*      */   public boolean applyZoom(int zoom, boolean dryRun)
/*      */   {
/*  832 */     if (!this.zoomingAllowed) {
/*  833 */       return false;
/*      */     }
/*  835 */     return internalZoom(zoom, dryRun, true);
/*      */   }
/*      */   
/*      */   private boolean internalZoom(int zoom, boolean dryRun, boolean refresh) {
/*  839 */     zoom = ZoomableUtil.sanitizeZoom(zoom);
/*  840 */     int newZoomLevel = ZoomableUtil.updateZoom(this.zoomLevel, zoom);
/*  841 */     if (newZoomLevel == 0) {
/*  842 */       zoom = 0;
/*      */     }
/*      */     
/*      */ 
/*  846 */     for (GraphNode node : this.nodes) {
/*  847 */       if (!node.applyZoom(zoom, true)) {
/*  848 */         return false;
/*      */       }
/*      */     }
/*  851 */     if (dryRun) {
/*  852 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  856 */     if (this.zoomLevel == 0)
/*      */     {
/*  858 */       for (GraphNode node : this.nodes) {
/*  859 */         node.setData("noZoomBounds", node.getBounds());
/*      */       }
/*      */     }
/*      */     
/*  863 */     this.dbgDoNotDisplayNodesGrid = true;
/*  864 */     this.nodeFlags.update(1, newZoomLevel < 0);
/*  865 */     this.nodeFlags.update(2, newZoomLevel < -5);
/*      */     
/*      */ 
/*  868 */     double xratio = 1.0D;
/*  869 */     double yratio = 1.0D;
/*  870 */     int i = 0;
/*  871 */     for (GraphNode node : this.nodes) {
/*  872 */       Point size0 = node.getSize();
/*      */       
/*  874 */       if (!node.applyZoom(zoom, false)) {
/*  875 */         throw new RuntimeException();
/*      */       }
/*  877 */       if ((i == 0) && (zoom != 0)) {
/*  878 */         Point size1 = node.getSize();
/*  879 */         xratio = 1.0D + (size1.x - size0.x) / size0.x;
/*  880 */         yratio = 1.0D + (size1.y - size0.y) / size0.y;
/*      */       }
/*      */       
/*  883 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  887 */     if (zoom == 0) {
/*  888 */       for (GraphNode node : this.nodes) {
/*  889 */         Rectangle bounds = (Rectangle)node.getData("noZoomBounds");
/*  890 */         if (bounds != null) {
/*  891 */           node.setBounds(bounds);
/*  892 */           node.setData("noZoomBounds", null);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  897 */       for (GraphNode node : this.nodes) {
/*  898 */         Point loc = node.getLocation();
/*  899 */         loc.x = ((int)(loc.x * xratio));
/*  900 */         loc.y = ((int)(loc.y * yratio));
/*  901 */         node.setLocation(loc);
/*      */       }
/*      */       
/*  904 */       this.virtualOrigin.x = ((int)(this.virtualOrigin.x * xratio));
/*  905 */       this.virtualOrigin.y = ((int)(this.virtualOrigin.y * xratio));
/*      */     }
/*      */     
/*      */ 
/*  909 */     if (refresh) {
/*  910 */       refreshGraph();
/*      */     }
/*      */     
/*  913 */     this.zoomLevel = newZoomLevel;
/*  914 */     return true;
/*      */   }
/*      */   
/*      */   public Flags getNodeFlags() {
/*  918 */     return this.nodeFlags;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refreshGraph()
/*      */   {
/*  931 */     refreshGraph(0, null);
/*      */   }
/*      */   
/*      */   public void refreshGraph(int cause, Object object) {
/*  935 */     long t0 = System.currentTimeMillis();
/*      */     try {
/*  937 */       this.redrawCause = cause;
/*  938 */       this.redrawObject = object;
/*  939 */       redraw(0, 0, getSize().x, getSize().y, true);
/*  940 */       update();
/*      */     }
/*      */     finally {
/*  943 */       this.redrawCause = 0;
/*  944 */       this.redrawObject = null;
/*      */     }
/*      */     
/*      */ 
/*  948 */     long exectime = System.currentTimeMillis() - t0;
/*      */     
/*  950 */     this.lastRedrawExectime = exectime;
/*      */     
/*  952 */     determineActiveEdge(null);
/*  953 */     notifyGraphChange();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setEdgeManager(GraphEdgeManager edgeman)
/*      */   {
/*  959 */     this.edgeman = edgeman;
/*      */   }
/*      */   
/*      */   private void redrawEdges(GC gc) {
/*  963 */     invalidateCaches();
/*      */     
/*  965 */     if (this.edgeman != null) {
/*  966 */       this.edgeman.draw(gc, this.redrawCause, this.redrawObject);
/*      */     }
/*      */     else {
/*  969 */       for (GraphEdge edge : this.edges) {
/*  970 */         edge.draw(gc);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void verifyNode(GraphNode node) {
/*  976 */     if (node == null) {
/*  977 */       throw new IllegalArgumentException("Null node");
/*      */     }
/*  979 */     if (!this.nodes.contains(node)) {
/*  980 */       throw new RuntimeException("The node does not belong to the current graph: " + node);
/*      */     }
/*  982 */     if (node.getParent() != this) {
/*  983 */       throw new RuntimeException("Parent of composite node must be the owner composite graph: " + node);
/*      */     }
/*      */   }
/*      */   
/*      */   public GraphNode registerNode(GraphNode node, boolean autoAssignBounds)
/*      */   {
/*  989 */     if (this.nodes.contains(node)) {
/*  990 */       throw new RuntimeException("The node already belongs to the current graph");
/*      */     }
/*      */     
/*  993 */     int i = this.nodes.size();
/*  994 */     node.id = i;
/*  995 */     this.nodes.add(node);
/*      */     
/*      */ 
/*  998 */     if (autoAssignBounds)
/*      */     {
/* 1000 */       node.setBounds(50 + i * 200, 50 + i * 200, 150, 100);
/*      */     }
/* 1002 */     return node;
/*      */   }
/*      */   
/*      */   public void registerNodesGrid(Spreadsheet<GraphNode> grid) {
/* 1006 */     Assert.a(this.nodes.isEmpty(), "Nodes were already registered");
/* 1007 */     this.grid = grid;
/*      */     
/* 1009 */     int rowcnt = grid.getRowCount();
/* 1010 */     int colcnt = grid.getColumnCount();
/*      */     
/* 1012 */     ConstraintSolver xsolver = new ConstraintSolver(colcnt);
/* 1013 */     ConstraintSolver ysolver = new ConstraintSolver(rowcnt);
/*      */     
/*      */ 
/* 1016 */     boolean[] seenRows = new boolean[grid.getRowCount()];
/* 1017 */     boolean[] seenCols = new boolean[grid.getColumnCount()];
/*      */     
/* 1019 */     List<Cell<GraphNode>> cells = grid.getRealCells();
/* 1020 */     for (Cell<GraphNode> cell : cells) {
/* 1021 */       seenRows[cell.getRow()] = true;
/* 1022 */       seenCols[cell.getColumn()] = true;
/*      */       
/* 1024 */       GraphNode node = (GraphNode)cell.getObject();
/* 1025 */       Point nodesize = node.computeSize(-1, -1);
/* 1026 */       node.setSize(nodesize);
/*      */       
/* 1028 */       int incnt = 2 + Math.max(0, node.getNodeInputEdgeCount() - 2);
/* 1029 */       outcnt = 2 + Math.max(0, node.getNodeOutputEdgeCount() - 2);
/*      */       
/* 1031 */       int x = cell.getColumn();
/* 1032 */       int xspan = cell.getHorizontalSpan();
/* 1033 */       xsolver.add(new Vector(colcnt).onRange(x, xspan).get(), (int)(nodesize.x + 10.0D * incnt + 10.0D * outcnt));
/*      */       
/*      */ 
/* 1036 */       int y = cell.getRow();
/* 1037 */       int yspan = cell.getVerticalSpan();
/* 1038 */       ysolver.add(new Vector(rowcnt).onRange(y, yspan).get(), (int)(nodesize.y + 10.0D * incnt + 10.0D * outcnt));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int outcnt;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1064 */     this.xConstraints = xsolver.solve();
/* 1065 */     logger.i("x-constraints= %s", new Object[] { Arrays.toString(this.xConstraints) });
/* 1066 */     this.yConstraints = ysolver.solve();
/* 1067 */     logger.i("y-constraints= %s", new Object[] { Arrays.toString(this.yConstraints) });
/*      */     
/* 1069 */     int[] xBases = buildCoordsFromSizes(this.virtualOrigin.x, this.xConstraints);
/* 1070 */     int[] yBases = buildCoordsFromSizes(this.virtualOrigin.y, this.yConstraints);
/*      */     
/* 1072 */     int[] xNodes = new int[cells.size()];
/* 1073 */     int[] yNodes = new int[cells.size()];
/* 1074 */     int i = 0;
/* 1075 */     for (Cell<GraphNode> cell : cells) {
/* 1076 */       GraphNode node = (GraphNode)cell.getObject();
/* 1077 */       Point psize = node.getSize();
/* 1078 */       logger.i("- node size: %s", new Object[] { psize });
/*      */       
/* 1080 */       int x0 = xBases[cell.getColumn()];
/* 1081 */       int x1 = xBases[cell.getNextColumn()];
/* 1082 */       int y0 = yBases[cell.getRow()];
/* 1083 */       int y1 = yBases[cell.getNextRow()];
/*      */       
/*      */ 
/* 1086 */       xNodes[i] = (x0 + (x1 - x0 - psize.x) / 2);
/*      */       
/*      */ 
/* 1089 */       int in = 2 + Math.max(0, node.getNodeInputEdgeCount() - 2);
/* 1090 */       int out = 2 + Math.max(0, node.getNodeOutputEdgeCount() - 2);
/* 1091 */       int sliceHeight = (y1 - y0 - psize.y) / (in + out);
/* 1092 */       yNodes[i] = (y0 + in * sliceHeight);
/*      */       
/* 1094 */       i++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1099 */     i = 0;
/* 1100 */     for (Cell<GraphNode> cell : cells) {
/* 1101 */       GraphNode node = (GraphNode)cell.getObject();
/* 1102 */       registerNode(node, false);
/* 1103 */       node.setLocation(xNodes[i], yNodes[i]);
/* 1104 */       i++;
/*      */     }
/*      */     
/* 1107 */     if (this.initialZoomLevel != 0) {
/* 1108 */       int count = Math.abs(this.initialZoomLevel);
/* 1109 */       while (count-- > 0) {
/* 1110 */         internalZoom(this.initialZoomLevel, false, false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onNodeContentsUpdate(GraphNode node)
/*      */   {
/* 1124 */     verifyNode(node);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1131 */     node.pack(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int registerEdge(GraphEdge edge)
/*      */   {
/* 1138 */     verifyNode(edge.src);
/* 1139 */     verifyNode(edge.dst);
/*      */     
/* 1141 */     int id = this.edges.size();
/* 1142 */     this.edges.add(edge);
/* 1143 */     return id;
/*      */   }
/*      */   
/*      */   public void bringNodeForward(GraphNode node) {
/* 1147 */     verifyNode(node);
/* 1148 */     node.moveAbove(null);
/*      */   }
/*      */   
/*      */   public void bringNodeBackward(GraphNode node) {
/* 1152 */     verifyNode(node);
/* 1153 */     node.moveBelow(null);
/*      */   }
/*      */   
/*      */   public void dragNode(GraphNode node, int deltaX, int deltaY) {
/* 1157 */     verifyNode(node);
/*      */     
/*      */ 
/* 1160 */     Point loc = node.getLocation();
/* 1161 */     loc.x += deltaX;
/* 1162 */     loc.y += deltaY;
/* 1163 */     node.setLocation(loc);
/*      */     
/*      */ 
/* 1166 */     refreshGraph();
/*      */   }
/*      */   
/*      */   public void resizeNode(GraphNode node, int deltaX, int deltaY) {
/* 1170 */     verifyNode(node);
/*      */     
/*      */ 
/* 1173 */     Point size = node.getSize();
/* 1174 */     size.x += deltaX;
/* 1175 */     size.y += deltaY;
/* 1176 */     node.setSize(size);
/*      */     
/*      */ 
/* 1179 */     refreshGraph();
/*      */   }
/*      */   
/*      */   public void setNodeBounds(GraphNode node, Rectangle bounds) {
/* 1183 */     verifyNode(node);
/*      */     
/* 1185 */     Rectangle bounds0 = node.getBounds();
/* 1186 */     if (bounds0.equals(bounds)) {
/* 1187 */       return;
/*      */     }
/*      */     
/* 1190 */     node.setBounds(bounds);
/* 1191 */     refreshGraph();
/*      */   }
/*      */   
/*      */   public Rectangle getNodeBounds(GraphNode node) {
/* 1195 */     verifyNode(node);
/*      */     
/* 1197 */     return node.getBounds();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle generatePreview(GC gc, Rectangle preview, GraphStyleData styleDataOverride, boolean renderEdges)
/*      */   {
/* 1207 */     GraphStyleData styles = styleDataOverride != null ? styleDataOverride : getStyleData();
/*      */     
/* 1209 */     Rectangle container = getContainerArea();
/* 1210 */     if ((container.width == 0) || (container.height == 0) || (preview.width == 0) || (preview.height == 0)) {
/* 1211 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1222 */     int usedHeight = Math.max(1, preview.width * container.height / container.width);
/* 1223 */     int offsetHeight; int offsetHeight; int usedWidth; int offsetWidth; if (usedHeight > preview.height) {
/* 1224 */       int usedWidth = Math.max(1, preview.height * container.width / container.height);
/* 1225 */       Assert.a(usedWidth <= preview.width);
/* 1226 */       int offsetWidth = (preview.width - usedWidth) / 2;
/* 1227 */       usedHeight = preview.height;
/* 1228 */       offsetHeight = 0;
/*      */     }
/*      */     else {
/* 1231 */       offsetHeight = (preview.height - usedHeight) / 2;
/* 1232 */       usedWidth = preview.width;
/* 1233 */       offsetWidth = 0;
/*      */     }
/*      */     
/* 1236 */     double xRatio = usedWidth / container.width;
/* 1237 */     double yRatio = usedHeight / container.height;
/*      */     
/*      */ 
/* 1240 */     Rectangle b = getClientArea();
/* 1241 */     int x = (int)((b.x - container.x) * xRatio) + offsetWidth;
/* 1242 */     int y = (int)((b.y - container.y) * yRatio) + offsetHeight;
/* 1243 */     int w = Math.max(3, (int)(b.width * xRatio));
/* 1244 */     int h = Math.max(3, (int)(b.height * yRatio));
/* 1245 */     gc.setBackground(styles.cCanvas);
/* 1246 */     gc.fillRectangle(x, y, w, h);
/*      */     
/*      */ 
/* 1249 */     List<PreviewNode> pnodes = new ArrayList();
/* 1250 */     Map<GraphNode, PreviewNode> pnodemap = new IdentityHashMap();
/* 1251 */     for (GraphNode node : this.nodes) {
/* 1252 */       b = node.getBounds();
/* 1253 */       x = (int)((b.x - container.x) * xRatio) + offsetWidth;
/* 1254 */       y = (int)((b.y - container.y) * yRatio) + offsetHeight;
/* 1255 */       w = Math.max(3, (int)(b.width * xRatio));
/* 1256 */       h = Math.max(3, (int)(b.height * yRatio));
/*      */       
/* 1258 */       PreviewNode pnode = new PreviewNode(null);
/* 1259 */       pnode.r = new Rectangle(x, y, w, h);
/* 1260 */       pnode.active = (getActiveNode() == node);
/* 1261 */       pnodes.add(pnode);
/* 1262 */       pnodemap.put(node, pnode);
/*      */     }
/*      */     
/* 1265 */     if (renderEdges) {
/* 1266 */       gc.setLineWidth(1);
/* 1267 */       gc.setLineStyle(1);
/* 1268 */       gc.setForeground(styles.cEdge);
/* 1269 */       for (GraphEdge edge : this.edges) {
/* 1270 */         PreviewNode src = (PreviewNode)pnodemap.get(edge.src);
/* 1271 */         PreviewNode dst = (PreviewNode)pnodemap.get(edge.dst);
/* 1272 */         Point p1 = UIUtil.getRectangleCenter(src.r);
/* 1273 */         Point p2 = UIUtil.getRectangleCenter(dst.r);
/* 1274 */         gc.drawLine(p1.x, p1.y, p2.x, p2.y);
/*      */       }
/*      */     }
/*      */     
/* 1278 */     for (PreviewNode pnode : pnodes) {
/* 1279 */       gc.setBackground(pnode.active ? styles.cActiveNode : styles.cNode);
/* 1280 */       gc.fillRectangle(pnode.r);
/*      */     }
/*      */     
/* 1283 */     return new Rectangle(offsetWidth, offsetHeight, usedWidth, usedHeight);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getContainerArea()
/*      */   {
/* 1301 */     int xmin = Integer.MAX_VALUE;
/* 1302 */     int ymin = Integer.MAX_VALUE;
/* 1303 */     int xmax = Integer.MIN_VALUE;
/* 1304 */     int ymax = Integer.MIN_VALUE;
/* 1305 */     for (GraphNode n : this.nodes) {
/* 1306 */       Rectangle r = n.getBounds();
/* 1307 */       int x0 = r.x;
/* 1308 */       int y0 = r.y;
/* 1309 */       int x1 = r.x + r.width;
/* 1310 */       int y1 = r.y + r.height;
/* 1311 */       if (x0 < xmin) {
/* 1312 */         xmin = x0;
/*      */       }
/* 1314 */       if (y0 < ymin) {
/* 1315 */         ymin = y0;
/*      */       }
/* 1317 */       if (x1 > xmax) {
/* 1318 */         xmax = x1;
/*      */       }
/* 1320 */       if (y1 > ymax) {
/* 1321 */         ymax = y1;
/*      */       }
/*      */     }
/* 1324 */     return new Rectangle(xmin, ymin, xmax - xmin, ymax - ymin);
/*      */   }
/*      */   
/*      */   int getOutEdgeCount(GraphNode node) {
/* 1328 */     verifyNode(node);
/*      */     
/* 1330 */     int cnt = 0;
/* 1331 */     for (GraphEdge e : this.edges) {
/* 1332 */       if (e.src == node) {
/* 1333 */         cnt++;
/*      */       }
/*      */     }
/* 1336 */     return cnt;
/*      */   }
/*      */   
/*      */   List<GraphNode> getOutNodes(GraphNode node) {
/* 1340 */     verifyNode(node);
/*      */     
/* 1342 */     List<GraphNode> r = new ArrayList();
/* 1343 */     for (GraphEdge e : this.edges) {
/* 1344 */       if (e.src == node) {
/* 1345 */         r.add(e.dst);
/*      */       }
/*      */     }
/* 1348 */     return r;
/*      */   }
/*      */   
/*      */   int getInEdgeCount(GraphNode node) {
/* 1352 */     verifyNode(node);
/*      */     
/* 1354 */     int cnt = 0;
/* 1355 */     for (GraphEdge e : this.edges) {
/* 1356 */       if (e.dst == node) {
/* 1357 */         cnt++;
/*      */       }
/*      */     }
/* 1360 */     return cnt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   List<GraphNode> getInNodes(GraphNode targetNode)
/*      */   {
/* 1370 */     verifyNode(targetNode);
/*      */     
/* 1372 */     List<GraphNode> r = new ArrayList();
/* 1373 */     for (GraphEdge e : this.edges) {
/* 1374 */       if (e.dst == targetNode) {
/* 1375 */         r.add(e.src);
/*      */       }
/*      */     }
/* 1378 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void invalidateCaches()
/*      */   {
/* 1387 */     this.horzLineCache.clear();
/* 1388 */     this.vertLineCache.clear();
/*      */     
/* 1390 */     this.linesByGroup.clear();
/* 1391 */     this.activeHoriLineCache.clear();
/* 1392 */     this.activeVertLineCache.clear();
/*      */   }
/*      */   
/* 1395 */   private Map<Integer, ISegmentMap<Integer, IntegerSegment>> horzLineCache = new HashMap();
/* 1396 */   private Map<Integer, ISegmentMap<Integer, IntegerSegment>> vertLineCache = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int requestHorizontalLine(int x0, int x1, int yReq, int adjustStep)
/*      */   {
/* 1406 */     Assert.a(adjustStep != 0);
/* 1407 */     if (x0 == x1) {
/* 1408 */       return yReq;
/*      */     }
/* 1410 */     if (x0 > x1) {
/* 1411 */       int tmp = x1;
/* 1412 */       x1 = x0;
/* 1413 */       x0 = tmp;
/*      */     }
/*      */     for (;;) {
/* 1416 */       ISegmentMap<Integer, IntegerSegment> m = (ISegmentMap)this.horzLineCache.get(Integer.valueOf(yReq));
/* 1417 */       if (m == null) {
/* 1418 */         m = new SegmentMap();
/* 1419 */         this.horzLineCache.put(Integer.valueOf(yReq), m);
/* 1420 */         m.add(new IntegerSegment(x0, x1 - x0 + 1));
/* 1421 */         return yReq;
/*      */       }
/* 1423 */       if (m.isEmptyRange(Integer.valueOf(x0), Integer.valueOf(x1 + 1))) {
/* 1424 */         m.add(new IntegerSegment(x0, x1 - x0 + 1));
/* 1425 */         return yReq;
/*      */       }
/* 1427 */       yReq += adjustStep;
/*      */     }
/*      */   }
/*      */   
/*      */   void releaseHorizontalLine(int x0, int x1, int y) {
/* 1432 */     if (x0 == x1) {
/* 1433 */       return;
/*      */     }
/* 1435 */     ((ISegmentMap)this.horzLineCache.get(Integer.valueOf(y))).remove(Integer.valueOf(Math.min(x0, x1)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int requestVerticalLine(int y0, int y1, int xReq, int adjustStep)
/*      */   {
/* 1446 */     Assert.a(adjustStep != 0);
/* 1447 */     if (y0 == y1) {
/* 1448 */       return xReq;
/*      */     }
/* 1450 */     if (y0 > y1) {
/* 1451 */       int tmp = y1;
/* 1452 */       y1 = y0;
/* 1453 */       y0 = tmp;
/*      */     }
/*      */     for (;;) {
/* 1456 */       ISegmentMap<Integer, IntegerSegment> m = (ISegmentMap)this.vertLineCache.get(Integer.valueOf(xReq));
/* 1457 */       if (m == null) {
/* 1458 */         m = new SegmentMap();
/* 1459 */         this.vertLineCache.put(Integer.valueOf(xReq), m);
/* 1460 */         m.add(new IntegerSegment(y0, y1 - y0 + 1));
/* 1461 */         return xReq;
/*      */       }
/* 1463 */       if (m.isEmptyRange(Integer.valueOf(y0), Integer.valueOf(y1 + 1))) {
/* 1464 */         m.add(new IntegerSegment(y0, y1 - y0 + 1));
/* 1465 */         return xReq;
/*      */       }
/* 1467 */       xReq += adjustStep;
/*      */     }
/*      */   }
/*      */   
/*      */   void releaseVerticalLine(int y0, int y1, int x) {
/* 1472 */     if (y0 == y1) {
/* 1473 */       return;
/*      */     }
/* 1475 */     ((ISegmentMap)this.vertLineCache.get(Integer.valueOf(x))).remove(Integer.valueOf(Math.min(y0, y1)));
/*      */   }
/*      */   
/*      */   boolean optCheckAvoidVerticalLineOverlapWithNodes(int x, int y0, int y1) {
/* 1479 */     for (GraphNode node : this.nodes) {
/* 1480 */       Rectangle r = node.getBounds();
/* 1481 */       if ((r.x < x) && (r.x + r.width > x) && 
/* 1482 */         (y0 < r.y) && (y1 > r.y + r.height)) {
/* 1483 */         return true;
/*      */       }
/*      */     }
/*      */     
/* 1487 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int[] optAvoidVerticalLineOverlapWithNodes(int x, int y0, int y1, int margin)
/*      */   {
/* 1497 */     List<Rectangle> tba = new ArrayList();
/* 1498 */     for (GraphNode node : this.nodes) {
/* 1499 */       Rectangle r = node.getBounds();
/* 1500 */       if ((r.x < x) && (r.x + r.width > x) && 
/* 1501 */         (y0 < r.y) && (y1 > r.y + r.height)) {
/* 1502 */         tba.add(r);
/*      */       }
/*      */     }
/*      */     
/* 1506 */     if (tba.isEmpty()) {
/* 1507 */       return null;
/*      */     }
/* 1509 */     int yE = Integer.MAX_VALUE;
/* 1510 */     int xE = Integer.MIN_VALUE;
/* 1511 */     int yE1 = Integer.MIN_VALUE;
/* 1512 */     for (Rectangle r : tba) {
/* 1513 */       if (r.y < yE) {
/* 1514 */         yE = r.y;
/*      */       }
/* 1516 */       if (r.x + r.width > xE) {
/* 1517 */         xE = r.x + r.width;
/*      */       }
/* 1519 */       if (r.y + r.height > yE1) {
/* 1520 */         yE1 = r.y + r.height;
/*      */       }
/*      */     }
/* 1523 */     return new int[] { yE - margin, xE + margin, yE1 + margin };
/*      */   }
/*      */   
/*      */   static class ActiveLine extends IntegerSegment {
/*      */     int groupId;
/*      */     
/*      */     public ActiveLine(int groupId, int address, int size) {
/* 1530 */       super(size);
/* 1531 */       if (size <= 0) {
/* 1532 */         throw new RuntimeException();
/*      */       }
/* 1534 */       this.groupId = groupId;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1539 */       return String.format("%d:[%d-%d)", new Object[] { Integer.valueOf(this.groupId), getBegin(), getEnd() });
/*      */     }
/*      */   }
/*      */   
/* 1543 */   private MultiMap<Integer, ActiveLine> linesByGroup = new MultiMap();
/* 1544 */   private Map<Integer, IMultiSegmentMap<Integer, ActiveLine>> activeHoriLineCache = new HashMap();
/* 1545 */   private Map<Integer, IMultiSegmentMap<Integer, ActiveLine>> activeVertLineCache = new HashMap();
/*      */   
/*      */   void registerActiveHorizontalLine(int x0, int x1, int y, int groupId) {
/* 1548 */     if (x0 == x1) {
/* 1549 */       return;
/*      */     }
/* 1551 */     IMultiSegmentMap<Integer, ActiveLine> map = (IMultiSegmentMap)this.activeHoriLineCache.get(Integer.valueOf(y));
/* 1552 */     if (map == null) {
/* 1553 */       map = new MultiSegmentMap();
/* 1554 */       this.activeHoriLineCache.put(Integer.valueOf(y), map);
/*      */     }
/* 1556 */     ActiveLine line = (ActiveLine)map.add(new ActiveLine(groupId, Math.min(x0, x1), Math.abs(x1 - x0)));
/* 1557 */     this.linesByGroup.put(Integer.valueOf(groupId), line);
/*      */   }
/*      */   
/*      */   void registerActiveVerticalLine(int y0, int y1, int x, int groupId) {
/* 1561 */     if (y0 == y1) {
/* 1562 */       return;
/*      */     }
/* 1564 */     IMultiSegmentMap<Integer, ActiveLine> map = (IMultiSegmentMap)this.activeVertLineCache.get(Integer.valueOf(x));
/* 1565 */     if (map == null) {
/* 1566 */       map = new MultiSegmentMap();
/* 1567 */       this.activeVertLineCache.put(Integer.valueOf(x), map);
/*      */     }
/* 1569 */     ActiveLine line = (ActiveLine)map.add(new ActiveLine(groupId, Math.min(y0, y1), Math.abs(y1 - y0)));
/* 1570 */     this.linesByGroup.put(Integer.valueOf(groupId), line);
/*      */   }
/*      */   
/*      */   int getActiveLineGroupId(int x, int y) {
/* 1574 */     IMultiSegmentMap<Integer, ActiveLine> map = (IMultiSegmentMap)this.activeHoriLineCache.get(Integer.valueOf(y));
/* 1575 */     if (map != null) {
/* 1576 */       ActiveLine line = (ActiveLine)map.getFirstSegmentContaining(Integer.valueOf(x));
/* 1577 */       if (line != null) {
/* 1578 */         return line.groupId;
/*      */       }
/*      */     }
/* 1581 */     map = (IMultiSegmentMap)this.activeVertLineCache.get(Integer.valueOf(x));
/* 1582 */     if (map != null) {
/* 1583 */       ActiveLine line = (ActiveLine)map.getFirstSegmentContaining(Integer.valueOf(y));
/* 1584 */       if (line != null) {
/* 1585 */         return line.groupId;
/*      */       }
/*      */     }
/* 1588 */     return -1;
/*      */   }
/*      */   
/*      */   int getActiveLineGroupId(int x, int y, int toleranceX, int toleranceY) {
/* 1592 */     int id = getActiveLineGroupId(x, y);
/* 1593 */     if (id >= 0) {
/* 1594 */       return id;
/*      */     }
/* 1596 */     for (int x0 = x - toleranceX; x0 <= x + toleranceX; x0++) {
/* 1597 */       for (int y0 = y - toleranceY; y0 <= y + toleranceY; y0++) {
/* 1598 */         if ((x0 != x) || (y0 != y))
/*      */         {
/*      */ 
/* 1601 */           id = getActiveLineGroupId(x0, y0);
/* 1602 */           if (id >= 0)
/* 1603 */             return id;
/*      */         }
/*      */       }
/*      */     }
/* 1607 */     return -1;
/*      */   }
/*      */   
/* 1610 */   private List<GraphEdgeListener> graphEdgeListeners = new ArrayList();
/*      */   
/*      */   public void addGraphEdgeListener(GraphEdgeListener listener) {
/* 1613 */     this.graphEdgeListeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeGraphEdgeListener(GraphEdgeListener listener) {
/* 1617 */     this.graphEdgeListeners.remove(listener);
/*      */   }
/*      */   
/*      */   private void notifyEdgeMouseEnter(GraphEdge edge) {
/* 1621 */     for (GraphEdgeListener listener : this.graphEdgeListeners) {
/* 1622 */       listener.onEdgeMouseEnter(edge);
/*      */     }
/*      */   }
/*      */   
/*      */   private void notifyEdgeMouseExit(GraphEdge edge) {
/* 1627 */     for (GraphEdgeListener listener : this.graphEdgeListeners) {
/* 1628 */       listener.onEdgeMouseExit(edge);
/*      */     }
/*      */   }
/*      */   
/* 1632 */   private List<GraphNodeListener> graphNodeListeners = new ArrayList();
/*      */   
/*      */   public void addGraphNodeListener(GraphNodeListener listener) {
/* 1635 */     this.graphNodeListeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeGraphNodeListener(GraphNodeListener listener) {
/* 1639 */     this.graphNodeListeners.add(listener);
/*      */   }
/*      */   
/*      */   void notifyNodeMouseEnter(GraphNode node) {
/* 1643 */     for (GraphNodeListener listener : this.graphNodeListeners) {
/* 1644 */       listener.onNodeMouseEnter(node);
/*      */     }
/*      */   }
/*      */   
/*      */   void notifyNodeMouseExit(GraphNode node) {
/* 1649 */     for (GraphNodeListener listener : this.graphNodeListeners) {
/* 1650 */       listener.onNodeMouseExit(node);
/*      */     }
/*      */   }
/*      */   
/*      */   void reportNodeFocusChange(GraphNode node, boolean gained)
/*      */   {
/* 1656 */     boolean needsRedrawAndNotify = false;
/* 1657 */     if (gained) {
/* 1658 */       notifyNodeFocusGained(node);
/* 1659 */       if (this.activeNode != node) {
/* 1660 */         this.activeNode = node;
/* 1661 */         this.activeNode.active = true;
/* 1662 */         needsRedrawAndNotify = true;
/*      */       }
/*      */     }
/*      */     else {
/* 1666 */       notifyNodeFocusLost(node);
/* 1667 */       if (this.activeNode == node) {
/* 1668 */         this.activeNode.active = false;
/* 1669 */         this.activeNode = null;
/* 1670 */         needsRedrawAndNotify = true;
/*      */       }
/*      */     }
/*      */     
/* 1674 */     if (needsRedrawAndNotify) {
/* 1675 */       refreshGraph();
/* 1676 */       notifyGraphChange();
/*      */     }
/*      */   }
/*      */   
/*      */   void notifyNodeFocusGained(GraphNode node)
/*      */   {
/* 1682 */     for (GraphNodeListener listener : this.graphNodeListeners) {
/* 1683 */       listener.onNodeFocusGained(node);
/*      */     }
/*      */   }
/*      */   
/*      */   void notifyNodeFocusLost(GraphNode node)
/*      */   {
/* 1689 */     for (GraphNodeListener listener : this.graphNodeListeners) {
/* 1690 */       listener.onNodeFocusLost(node);
/*      */     }
/*      */   }
/*      */   
/*      */   public String formatDebugInfo() {
/* 1695 */     StringBuilder sb = new StringBuilder();
/* 1696 */     sb.append(String.format("redrawExectime: %s\n", new Object[] { Long.valueOf(this.lastRedrawExectime) }));
/* 1697 */     sb.append(String.format("mouseCursor: %s\n", new Object[] { this.lastMouseCursor }));
/* 1698 */     sb.append(String.format("horzLineCache: %s\n", new Object[] { this.horzLineCache }));
/* 1699 */     sb.append(String.format("vertLineCache: %s", new Object[] { this.vertLineCache }));
/* 1700 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private static class PreviewNode
/*      */   {
/*      */     Rectangle r;
/*      */     boolean active;
/*      */   }
/*      */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\Graph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */