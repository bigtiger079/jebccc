/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class E
/*    */ {
/*    */   V src;
/*    */   
/*    */ 
/*    */   V dst;
/*    */   
/*    */   public Double weight;
/*    */   
/*    */   public Double score;
/*    */   
/*    */   public Double ebscore;
/*    */   
/*    */ 
/*    */   E(V src, V dst, Double weight)
/*    */   {
/* 21 */     this.src = src;
/* 22 */     this.dst = dst;
/* 23 */     this.weight = weight;
/*    */   }
/*    */   
/*    */   E(V src, V dst) {
/* 27 */     this(src, dst, null);
/*    */   }
/*    */   
/*    */   public V getSrc() {
/* 31 */     return this.src;
/*    */   }
/*    */   
/*    */   public V getDst() {
/* 35 */     return this.dst;
/*    */   }
/*    */   
/*    */   public Double getWeight() {
/* 39 */     return this.weight;
/*    */   }
/*    */   
/*    */   public E clone()
/*    */   {
/* 44 */     E e = new E(this.src, this.dst, this.weight);
/* 45 */     e.score = this.score;
/* 46 */     e.ebscore = this.ebscore;
/* 47 */     return e;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     if (this.weight == null) {
/* 53 */       return String.format("%d>%d", new Object[] { Integer.valueOf(this.src.id), Integer.valueOf(this.dst.id) });
/*    */     }
/* 55 */     return String.format("%d>%d(%f)", new Object[] { Integer.valueOf(this.src.id), Integer.valueOf(this.dst.id), this.weight });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\model\E.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */