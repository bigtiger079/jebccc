/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowCol
/*    */ {
/*    */   private int row;
/*    */   
/*    */ 
/*    */ 
/*    */   private int col;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RowCol(int row, int col)
/*    */   {
/* 20 */     this.row = row;
/* 21 */     this.col = col;
/*    */   }
/*    */   
/*    */   public int getRow() {
/* 25 */     return this.row;
/*    */   }
/*    */   
/*    */   public int getColumn() {
/* 29 */     return this.col;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 34 */     int prime = 31;
/* 35 */     int result = 1;
/* 36 */     result = 31 * result + this.col;
/* 37 */     result = 31 * result + this.row;
/* 38 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 43 */     if (this == obj)
/* 44 */       return true;
/* 45 */     if (obj == null)
/* 46 */       return false;
/* 47 */     if (getClass() != obj.getClass())
/* 48 */       return false;
/* 49 */     RowCol other = (RowCol)obj;
/* 50 */     if (this.col != other.col)
/* 51 */       return false;
/* 52 */     if (this.row != other.row)
/* 53 */       return false;
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return String.format("[%d,%d]", new Object[] { Integer.valueOf(this.row), Integer.valueOf(this.col) });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\RowCol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */