package com.pnfsoftware.jeb.rcpclient.extensions.graph;

import com.pnfsoftware.jeb.client.api.Operation;

@Deprecated
public abstract interface INodeContentsMasterController
{
  public abstract boolean requestOperation(IGraphNodeContents paramIGraphNodeContents, Operation paramOperation);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\INodeContentsMasterController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */