/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Caret;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeContentsText
/*     */   extends Composite
/*     */   implements IGraphNodeContents
/*     */ {
/*  38 */   private static final ILogger logger = GlobalLog.getLogger(NodeContentsText.class);
/*     */   
/*     */   private static final int minFontHeight = 1;
/*     */   private static final int maxFontHeight = 80;
/*     */   private int defaultFontHeight;
/*     */   private StyledText w;
/*     */   
/*     */   public NodeContentsText(Composite parent, int style)
/*     */   {
/*  47 */     super(parent, style);
/*  48 */     setLayout(new FillLayout());
/*  49 */     setBackgroundMode(2);
/*     */     
/*  51 */     this.w = new StyledText(this, 0);
/*     */     
/*  53 */     Color bgcol = SwtRegistry.getInstance().getColor(14737632);
/*  54 */     setBackground(bgcol);
/*     */     
/*  56 */     FontData[] fdlist = getFont().getFontData();
/*  57 */     this.defaultFontHeight = fdlist[0].getHeight();
/*     */     
/*  59 */     addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setFocus()
/*     */   {
/*  71 */     return this.w.setFocus();
/*     */   }
/*     */   
/*     */   public void setFont(Font font)
/*     */   {
/*  76 */     super.setFont(font);
/*  77 */     this.w.setFont(font);
/*     */   }
/*     */   
/*     */   public Font getFont()
/*     */   {
/*  82 */     return this.w.getFont();
/*     */   }
/*     */   
/*     */   public void setForeground(Color color)
/*     */   {
/*  87 */     super.setForeground(color);
/*  88 */     this.w.setForeground(color);
/*     */   }
/*     */   
/*     */   public Color getForeground()
/*     */   {
/*  93 */     return this.w.getForeground();
/*     */   }
/*     */   
/*     */   public void setBackground(Color color)
/*     */   {
/*  98 */     super.setBackground(color);
/*  99 */     this.w.setBackground(color);
/*     */   }
/*     */   
/*     */   public Color getBackground()
/*     */   {
/* 104 */     return this.w.getBackground();
/*     */   }
/*     */   
/*     */   public void setText(String text) {
/* 108 */     this.w.setText(text);
/*     */   }
/*     */   
/*     */   public String getText() {
/* 112 */     return this.w.getText();
/*     */   }
/*     */   
/*     */   public void setEditable(boolean editable) {
/* 116 */     this.w.setEditable(editable);
/*     */   }
/*     */   
/*     */   public void setCaret(Caret caret) {
/* 120 */     this.w.setCaret(caret);
/*     */   }
/*     */   
/*     */   public Caret getCaret() {
/* 124 */     return this.w.getCaret();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getZoomLevel()
/*     */   {
/* 130 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean applyZoom(int zoom, boolean dryRun)
/*     */   {
/* 136 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\NodeContentsText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */