package com.pnfsoftware.jeb.rcpclient.extensions.graph;

public abstract interface IGraphNode
{
  public abstract int getId();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\IGraphNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */