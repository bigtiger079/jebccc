/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.PaintEvent;
/*     */ import org.eclipse.swt.events.PaintListener;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Canvas;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphPreview<G extends AbstractGraph>
/*     */   extends Canvas
/*     */ {
/*     */   G graph;
/*     */   GraphChangeListener graphListener;
/*     */   Rectangle activeArea;
/*     */   boolean renderEdges;
/*     */   
/*     */   public GraphPreview(Composite parent, int style, final boolean renderEdges)
/*     */   {
/*  41 */     super(parent, 0x20100000 | style);
/*  42 */     this.renderEdges = renderEdges;
/*     */     
/*  44 */     addPaintListener(new PaintListener()
/*     */     {
/*     */       public void paintControl(PaintEvent e) {
/*  47 */         if ((GraphPreview.this.graph == null) || (GraphPreview.this.graph.isDisposed())) {
/*  48 */           e.gc.fillRectangle(GraphPreview.this.getClientArea());
/*  49 */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  54 */         GraphPreview.this.activeArea = GraphPreview.this.graph.generatePreview(e.gc, GraphPreview.this.getClientArea(), null, renderEdges);
/*     */       }
/*     */       
/*  57 */     });
/*  58 */     addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseDown(MouseEvent e) {
/*  61 */         if ((GraphPreview.this.graph == null) || (GraphPreview.this.graph.isDisposed()) || (GraphPreview.this.activeArea == null)) {
/*  62 */           return;
/*     */         }
/*     */         
/*     */ 
/*  66 */         double xRatio = (e.x - GraphPreview.this.activeArea.x) / GraphPreview.this.activeArea.width;
/*  67 */         double yRatio = (e.y - GraphPreview.this.activeArea.y) / GraphPreview.this.activeArea.height;
/*  68 */         GraphPreview.this.graph.positionGraph(xRatio, yRatio);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public G getGraph()
/*     */   {
/*  79 */     return this.graph;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGraph(G g)
/*     */   {
/*  89 */     if (g == this.graph) {
/*  90 */       return;
/*     */     }
/*     */     
/*  93 */     if (this.graphListener != null) {
/*  94 */       this.graph.removeGraphChangeListener(this.graphListener);
/*  95 */       this.graphListener = null;
/*     */     }
/*     */     
/*  98 */     this.graph = g;
/*  99 */     if (this.graph == null) {
/* 100 */       this.activeArea = null;
/* 101 */       return;
/*     */     }
/*     */     
/* 104 */     this.graphListener = new GraphChangeListener()
/*     */     {
/*     */       public void onGraphChange(AbstractGraph g) {
/* 107 */         GraphPreview.this.redraw();
/*     */       }
/* 109 */     };
/* 110 */     this.graph.addGraphChangeListener(this.graphListener);
/*     */     
/* 112 */     this.graph.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/* 115 */         GraphPreview.this.setGraph(null);
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphPreview.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */