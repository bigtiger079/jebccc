package com.pnfsoftware.jeb.rcpclient.extensions.graph;

public enum Orientation
{
  NONE,  ORIENTED,  ORIENTED_BACKWARD,  ORIENTED_DUAL;
  
  private Orientation() {}
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\Orientation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */