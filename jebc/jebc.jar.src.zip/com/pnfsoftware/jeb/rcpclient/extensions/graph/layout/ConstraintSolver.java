/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstraintSolver
/*     */   implements Cloneable
/*     */ {
/*  36 */   private static final ILogger logger = GlobalLog.getLogger(ConstraintSolver.class);
/*     */   
/*     */   boolean solved;
/*     */   
/*     */   int[] varsmin;
/*     */   
/*  42 */   List<Constraint> constraints = new ArrayList();
/*     */   
/*  44 */   List<Constraint> constraints0 = new ArrayList();
/*     */   
/*     */ 
/*  47 */   private int strategy = 3;
/*     */   
/*     */   static class Constraint
/*     */   {
/*     */     final boolean[] vector;
/*     */     final int minval;
/*     */     int usedCount;
/*     */     int[] usedPositions;
/*     */     
/*     */     public Constraint(boolean[] vector, int minval)
/*     */     {
/*  58 */       this.vector = vector;
/*  59 */       this.minval = minval;
/*     */       
/*  61 */       this.usedPositions = new int[vector.length];
/*  62 */       int pos = 0;int i = 0;
/*  63 */       for (boolean incl : vector) {
/*  64 */         if (incl) {
/*  65 */           this.usedPositions[(i++)] = pos;
/*  66 */           this.usedCount += 1;
/*     */         }
/*  68 */         pos++;
/*     */       }
/*     */     }
/*     */     
/*     */     public int countUsed() {
/*  73 */       return this.usedCount;
/*     */     }
/*     */     
/*     */     public int countKnowns(int[] varsmin) {
/*  77 */       int cnt = 0;
/*  78 */       for (int i = 0; i < varsmin.length; i++) {
/*  79 */         if ((this.vector[i] != 0) && (varsmin[i] > 0)) {
/*  80 */           cnt++;
/*     */         }
/*     */       }
/*  83 */       return cnt;
/*     */     }
/*     */     
/*     */     public int countUnknowns(int[] varsmin) {
/*  87 */       int cnt = 0;
/*  88 */       for (int i = 0; i < varsmin.length; i++) {
/*  89 */         if ((this.vector[i] != 0) && (varsmin[i] == 0)) {
/*  90 */           cnt++;
/*     */         }
/*     */       }
/*  93 */       return cnt;
/*     */     }
/*     */     
/*     */     public void verify(int[] varsmin) {
/*  97 */       int minval1 = this.minval;
/*  98 */       for (int i = 0; i < varsmin.length; i++) {
/*  99 */         if (this.vector[i] != 0) {
/* 100 */           minval1 -= varsmin[i];
/*     */         }
/*     */       }
/* 103 */       if (minval1 > 0) {
/* 104 */         throw new RuntimeException("Constraint verification error: " + this);
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 110 */       return String.format("%s -> %d", new Object[] { Arrays.toString(this.vector), Integer.valueOf(this.minval) });
/*     */     }
/*     */   }
/*     */   
/*     */   public ConstraintSolver(int varcnt) {
/* 115 */     if (varcnt <= 0) {
/* 116 */       throw new IllegalArgumentException();
/*     */     }
/* 118 */     this.varsmin = new int[varcnt];
/*     */   }
/*     */   
/*     */ 
/*     */   private ConstraintSolver() {}
/*     */   
/*     */ 
/*     */   public ConstraintSolver clone()
/*     */   {
/* 127 */     ConstraintSolver r = new ConstraintSolver();
/* 128 */     r.varsmin = ((int[])this.varsmin.clone());
/* 129 */     r.constraints = new ArrayList(this.constraints.size());
/* 130 */     for (Constraint c : this.constraints) {
/* 131 */       r.constraints.add(new Constraint((boolean[])c.vector.clone(), c.minval));
/*     */     }
/* 133 */     r.solved = this.solved;
/* 134 */     return r;
/*     */   }
/*     */   
/*     */   public int getVariableCount() {
/* 138 */     return this.varsmin.length;
/*     */   }
/*     */   
/*     */   public boolean isSolved() {
/* 142 */     return this.solved;
/*     */   }
/*     */   
/*     */   public int[] getResolution() {
/* 146 */     if (!isSolved()) {
/* 147 */       throw new IllegalStateException("The constraints have not been solved yet");
/*     */     }
/* 149 */     return this.varsmin;
/*     */   }
/*     */   
/*     */   public void add(boolean[] vector, int minval) {
/* 153 */     if (isSolved()) {
/* 154 */       throw new IllegalStateException("Constraints were solved already");
/*     */     }
/*     */     
/* 157 */     if (vector.length != getVariableCount()) {
/* 158 */       throw new IllegalArgumentException("Constraints vector size must have length " + this.varsmin.length);
/*     */     }
/*     */     
/* 161 */     int[] usedPositions = new int[getVariableCount()];
/* 162 */     int cnt = countUsedVariables(vector, usedPositions);
/* 163 */     if (cnt == 0) {
/* 164 */       throw new IllegalArgumentException("No constraints to resolve " + minval);
/*     */     }
/*     */     
/* 167 */     if (minval < 0) {
/* 168 */       throw new IllegalArgumentException("Illegal constraint: negative integer: " + minval);
/*     */     }
/*     */     
/* 171 */     this.constraints0.add(new Constraint(vector, minval));
/*     */     
/* 173 */     if (minval == 0)
/*     */     {
/* 175 */       return;
/*     */     }
/*     */     
/* 178 */     logger.i("Adding constraint: %s -> %d", new Object[] { Arrays.toString(vector), Integer.valueOf(minval) });
/*     */     
/*     */ 
/* 181 */     if (cnt == 1) {
/* 182 */       int pos = usedPositions[0];
/* 183 */       if (this.varsmin[pos] < minval) {
/* 184 */         this.varsmin[pos] = minval;
/*     */       }
/* 186 */       return;
/*     */     }
/*     */     
/*     */ 
/* 190 */     this.constraints.add(new Constraint(vector, minval));
/*     */   }
/*     */   
/*     */   static int countUsedVariables(boolean[] vector, int[] positions) {
/* 194 */     int cnt = 0;int i = 0;int j = 0;
/* 195 */     for (boolean incl : vector) {
/* 196 */       if (incl) {
/* 197 */         if (positions != null) {
/* 198 */           positions[(j++)] = i;
/*     */         }
/* 200 */         cnt++;
/*     */       }
/* 202 */       i++;
/*     */     }
/* 204 */     return cnt;
/*     */   }
/*     */   
/*     */   public int[] solve() {
/* 208 */     return solve(true);
/*     */   }
/*     */   
/*     */   public int[] solve(boolean verify) {
/* 212 */     if (isSolved()) {
/* 213 */       throw new IllegalStateException("Constraints were solved already");
/*     */     }
/*     */     Constraint c;
/* 216 */     while (!this.constraints.isEmpty())
/*     */     {
/*     */ 
/*     */ 
/* 220 */       while (!this.constraints.isEmpty()) {
/* 221 */         int changecnt = 0;
/* 222 */         int icst = 0;
/* 223 */         while (icst < this.constraints.size()) {
/* 224 */           if (isUselessConstraint((Constraint)this.constraints.get(icst))) {
/* 225 */             this.constraints.remove(icst);
/* 226 */             changecnt++;
/*     */           }
/*     */           else
/*     */           {
/* 230 */             icst++;
/*     */           }
/*     */         }
/* 233 */         if (changecnt == 0) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 238 */       if (this.constraints.isEmpty()) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */       if (this.strategy != 1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */         if (this.strategy == 2) {
/* 255 */           Collections.sort(this.constraints, new Comparator()
/*     */           {
/*     */             public int compare(ConstraintSolver.Constraint c1, ConstraintSolver.Constraint c2) {
/* 258 */               int r = -(c1.countUnknowns(ConstraintSolver.this.varsmin) - c2.countUnknowns(ConstraintSolver.this.varsmin));
/* 259 */               if (r == 0) {
/* 260 */                 r = -(c1.usedCount - c2.usedCount);
/*     */               }
/* 262 */               return r;
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */           });
/*     */         }
/* 269 */         else if (this.strategy == 3) {
/* 270 */           Collections.sort(this.constraints, new Comparator()
/*     */           {
/*     */             public int compare(ConstraintSolver.Constraint c1, ConstraintSolver.Constraint c2)
/*     */             {
/* 274 */               int r = -(c1.usedCount - c2.usedCount);
/* 275 */               if (r == 0)
/*     */               {
/* 277 */                 r = -(c1.countUnknowns(ConstraintSolver.this.varsmin) - c2.countUnknowns(ConstraintSolver.this.varsmin));
/*     */               }
/* 279 */               return r;
/*     */             }
/*     */             
/*     */           });
/*     */         } else {
/* 284 */           throw new RuntimeException("Unknown strategy: " + this.strategy);
/*     */         }
/*     */       }
/*     */       
/* 288 */       c = (Constraint)this.constraints.remove(0);
/* 289 */       applyFairSplit(c);
/*     */     }
/*     */     
/*     */ 
/* 293 */     if (verify) {
/* 294 */       for (Constraint c : this.constraints0) {
/* 295 */         c.verify(this.varsmin);
/*     */       }
/*     */     }
/*     */     
/* 299 */     this.solved = true;
/* 300 */     return this.varsmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isUselessConstraint(Constraint constraint)
/*     */   {
/* 310 */     int minval1 = constraint.minval;
/*     */     
/* 312 */     for (int i = 0; i < this.varsmin.length; i++) {
/* 313 */       if (constraint.vector[i] != 0)
/*     */       {
/*     */ 
/*     */ 
/* 317 */         int v = this.varsmin[i];
/* 318 */         if (v <= 0) {
/* 319 */           return false;
/*     */         }
/*     */         
/* 322 */         minval1 -= v;
/* 323 */         if (minval1 <= 0)
/* 324 */           return true;
/*     */       }
/*     */     }
/* 327 */     return false;
/*     */   }
/*     */   
/*     */   private void applyFairSplit(Constraint c) {
/* 331 */     Assert.a(c.usedCount >= 2, "Expecting a multi-variable constraint");
/* 332 */     int avg = c.minval / c.usedCount;
/* 333 */     for (int i = 0; i < c.usedCount; i++) {
/* 334 */       int pos = c.usedPositions[i];
/* 335 */       if (this.varsmin[pos] < avg) {
/* 336 */         this.varsmin[pos] = avg;
/*     */       }
/*     */     }
/*     */     
/* 340 */     int rem = c.minval % c.usedCount;
/* 341 */     if (rem != 0) {
/* 342 */       this.varsmin[c.usedPositions[0]] += rem;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\ConstraintSolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */