/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph.layout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector
/*    */ {
/*    */   boolean[] vect;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Vector(int size)
/*    */   {
/* 19 */     this.vect = new boolean[size];
/*    */   }
/*    */   
/*    */   public Vector on(int index) {
/* 23 */     this.vect[index] = true;
/* 24 */     return this;
/*    */   }
/*    */   
/*    */   public Vector onRange(int start, int count) {
/* 28 */     for (int i = start; i < start + count; i++) {
/* 29 */       this.vect[i] = true;
/*    */     }
/* 31 */     return this;
/*    */   }
/*    */   
/*    */   public boolean[] get() {
/* 35 */     return this.vect;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 40 */     StringBuilder sb = new StringBuilder();
/* 41 */     for (boolean v : this.vect) {
/* 42 */       sb.append(v ? '1' : '0');
/*    */     }
/* 44 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\layout\Vector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */