/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.api.IOperable;
/*    */ import com.pnfsoftware.jeb.core.output.text.ITextDocument;
/*    */ import com.pnfsoftware.jeb.core.units.IUnit;
/*    */ import com.pnfsoftware.jeb.rcpclient.FontManager;
/*    */ import com.pnfsoftware.jeb.rcpclient.IStatusIndicator;
/*    */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*    */ import com.pnfsoftware.jeb.rcpclient.iviewers.StyleManager;
/*    */ import com.pnfsoftware.jeb.rcpclient.parts.units.ItemStyleProvider2;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import java.util.Collection;
/*    */ import java.util.IdentityHashMap;
/*    */ import java.util.Iterator;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodeContentsInteractiveTextFactory
/*    */   implements Iterable<NodeContentsInteractiveTextView>
/*    */ {
/* 33 */   static final ILogger logger = GlobalLog.getLogger(NodeContentsInteractiveTextFactory.class);
/*    */   
/*    */   Display display;
/*    */   
/*    */   FontManager fontManager;
/*    */   ItemStyleProvider2 styleProvider;
/*    */   IUnit unit;
/*    */   IStatusIndicator statusIndicator;
/*    */   IOperable master;
/*    */   IGraphController controller;
/*    */   RcpClientContext context;
/* 44 */   IdentityHashMap<GraphNode, NodeContentsInteractiveTextView> map = new IdentityHashMap();
/* 45 */   IdentityHashMap<NodeContentsInteractiveTextView, GraphNode> rmap = new IdentityHashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NodeContentsInteractiveTextFactory(Display display, FontManager fontManager, StyleManager styleman, IUnit unit, IStatusIndicator statusIndicator, IOperable master, IGraphController controller, RcpClientContext context)
/*    */   {
/* 61 */     this.display = display;
/* 62 */     this.fontManager = fontManager;
/* 63 */     this.styleProvider = new ItemStyleProvider2(styleman);
/* 64 */     this.unit = unit;
/* 65 */     this.statusIndicator = statusIndicator;
/* 66 */     this.master = master;
/* 67 */     this.controller = controller;
/* 68 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NodeContentsInteractiveTextView create(GraphNode node, ITextDocument doc)
/*    */   {
/* 78 */     NodeContentsInteractiveTextView t = new NodeContentsInteractiveTextView(node, 0, doc, this.fontManager, this.styleProvider, this.unit, this.statusIndicator, this.master, this.controller, this.context);
/*    */     
/* 80 */     this.map.put(node, t);
/* 81 */     this.rmap.put(t, node);
/* 82 */     return t;
/*    */   }
/*    */   
/*    */   public Iterator<NodeContentsInteractiveTextView> iterator()
/*    */   {
/* 87 */     return this.map.values().iterator();
/*    */   }
/*    */   
/*    */   public NodeContentsInteractiveTextView getContentsForNode(GraphNode node) {
/* 91 */     return (NodeContentsInteractiveTextView)this.map.get(node);
/*    */   }
/*    */   
/*    */   public GraphNode getNodeForContents(NodeContentsInteractiveTextView contents) {
/* 95 */     return (GraphNode)this.rmap.get(contents);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\NodeContentsInteractiveTextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */