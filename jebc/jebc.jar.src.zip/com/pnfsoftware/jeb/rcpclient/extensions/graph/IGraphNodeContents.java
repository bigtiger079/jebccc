package com.pnfsoftware.jeb.rcpclient.extensions.graph;

import com.pnfsoftware.jeb.rcpclient.extensions.controls.IZoomable;

public abstract interface IGraphNodeContents
  extends IZoomable
{}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\IGraphNodeContents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */