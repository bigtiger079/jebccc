/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.graph;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IZoomable;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphEdge
/*     */   implements IZoomable
/*     */ {
/*  35 */   private static final ILogger logger = GlobalLog.getLogger(GraphEdge.class);
/*     */   
/*     */   protected int edgeId;
/*     */   
/*     */   protected Graph graph;
/*     */   
/*     */   protected GraphNode src;
/*     */   
/*     */   protected GraphNode dst;
/*  44 */   protected Anchor srcAnchor = Anchor.AUTO;
/*     */   
/*  46 */   protected Anchor dstAnchor = Anchor.AUTO;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected int style = 1;
/*     */   
/*     */ 
/*  58 */   protected int thickness = 2;
/*     */   
/*     */ 
/*  61 */   protected Orientation orientation = Orientation.NONE;
/*     */   
/*  63 */   protected Map<Integer, Color> colors = new HashMap();
/*     */   
/*  65 */   protected int state = 0;
/*     */   
/*     */   public GraphEdge(Graph graph, GraphNode src, GraphNode dst) {
/*  68 */     this.graph = graph;
/*  69 */     this.src = src;
/*  70 */     this.dst = dst;
/*     */     
/*  72 */     this.edgeId = graph.registerEdge(this);
/*     */     
/*     */ 
/*  75 */     this.colors.put(Integer.valueOf(0), SwtRegistry.getInstance().getColor(4210752));
/*  76 */     this.colors.put(Integer.valueOf(1), SwtRegistry.getInstance().getColor(16750848));
/*     */   }
/*     */   
/*     */   public Graph getGraph() {
/*  80 */     return this.graph;
/*     */   }
/*     */   
/*     */   public GraphNode getSource() {
/*  84 */     return this.src;
/*     */   }
/*     */   
/*     */   public GraphNode getDestination() {
/*  88 */     return this.dst;
/*     */   }
/*     */   
/*     */   public void setAnchors(Anchor srcAnchor, Anchor dstAnchor) {
/*  92 */     this.srcAnchor = srcAnchor;
/*  93 */     this.dstAnchor = dstAnchor;
/*     */   }
/*     */   
/*     */   public void setThickness(int thickness) {
/*  97 */     this.thickness = thickness;
/*     */   }
/*     */   
/*     */   public void setColor(int state, Color color) {
/* 101 */     this.colors.put(Integer.valueOf(state), color);
/*     */   }
/*     */   
/*     */   public Color getColor(int state) {
/* 105 */     return (Color)this.colors.get(Integer.valueOf(state));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setState(int state)
/*     */   {
/* 113 */     this.state = state;
/*     */   }
/*     */   
/*     */   public int getState() {
/* 117 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStyle(int style)
/*     */   {
/* 127 */     this.style = style;
/*     */   }
/*     */   
/*     */   public void setOrientation(Orientation orientation) {
/* 131 */     this.orientation = orientation;
/*     */   }
/*     */   
/*     */   public int getZoomLevel()
/*     */   {
/* 136 */     return this.graph.getZoomLevel();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean applyZoom(int zoom, boolean dryRun)
/*     */   {
/* 142 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void draw(GC gc)
/*     */   {
/*     */     Anchor _dstAnchor;
/*     */     
/*     */     Anchor _srcAnchor;
/*     */     
/*     */     Anchor _dstAnchor;
/* 153 */     if ((this.srcAnchor != Anchor.AUTO) && (this.dstAnchor != Anchor.AUTO)) {
/* 154 */       Anchor _srcAnchor = this.srcAnchor;
/* 155 */       _dstAnchor = this.dstAnchor;
/*     */     } else { Anchor _dstAnchor;
/* 157 */       if ((this.srcAnchor == Anchor.AUTO) && (this.dstAnchor != Anchor.AUTO)) {
/* 158 */         Anchor _srcAnchor = this.dstAnchor;
/* 159 */         _dstAnchor = this.dstAnchor;
/*     */       } else { Anchor _dstAnchor;
/* 161 */         if ((this.srcAnchor != Anchor.AUTO) && (this.dstAnchor == Anchor.AUTO)) {
/* 162 */           Anchor _srcAnchor = this.dstAnchor;
/* 163 */           _dstAnchor = this.srcAnchor;
/*     */         }
/*     */         else {
/* 166 */           Anchor[] a = determineBestAnchors();
/* 167 */           _srcAnchor = a[0];
/* 168 */           _dstAnchor = a[1];
/*     */         }
/*     */       } }
/* 171 */     Point pa = determineSimpleAnchorCoords(this.src, _srcAnchor);
/* 172 */     Point pb = determineSimpleAnchorCoords(this.dst, _dstAnchor);
/*     */     
/*     */ 
/* 175 */     drawLine(gc, pb.x, pb.y, pa.x, pa.y);
/*     */   }
/*     */   
/*     */   protected void drawLine(GC gc, int x0, int y0, int x1, int y1) {
/* 179 */     drawLine(gc, x0, y0, x1, y1, this.edgeId);
/*     */   }
/*     */   
/*     */   protected void drawLine(GC gc, int x0, int y0, int x1, int y1, int groupId)
/*     */   {
/* 184 */     setForeground(gc);
/*     */     
/* 186 */     int th = Math.max(1, this.thickness);
/* 187 */     gc.setLineWidth(th);
/* 188 */     gc.setLineStyle(this.style);
/* 189 */     gc.drawLine(x0, y0, x1, y1);
/*     */     
/* 191 */     if ((th >= 2) && (this.style == 1)) {
/* 192 */       gc.setLineWidth(1);
/* 193 */       gc.setForeground(Display.getCurrent().getSystemColor(16));
/* 194 */       gc.drawLine(x0, y0, x1, y1);
/*     */     }
/*     */     
/* 197 */     if (groupId >= 0) {
/* 198 */       if (x0 == x1) {
/* 199 */         this.graph.registerActiveVerticalLine(y0, y1, x0, groupId);
/*     */       }
/* 201 */       else if (y0 == y1) {
/* 202 */         this.graph.registerActiveHorizontalLine(x0, x1, y0, groupId);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void drawArrow(GC gc, int x0, int y0, int x1, int y1) {
/* 208 */     if ((x0 == x1) && (y0 == y1)) {
/* 209 */       throw new IllegalArgumentException("A point was provided; need a line for orientation");
/*     */     }
/*     */     
/* 212 */     if (this.orientation == Orientation.NONE) {
/* 213 */       return;
/*     */     }
/*     */     
/* 216 */     if ((x0 != x1) && (y0 != y1)) {
/* 217 */       throw new RuntimeException("Non straight arrows are TBI until a use-case shows up");
/*     */     }
/*     */     
/* 220 */     setBackground(gc);
/*     */     
/* 222 */     if ((this.orientation == Orientation.ORIENTED) || (this.orientation == Orientation.ORIENTED_DUAL)) {
/* 223 */       int x = x1;
/* 224 */       int y = y1;
/* 225 */       if (x0 == x1) {
/* 226 */         int deltaX = 3;
/* 227 */         int deltaY = 6;
/* 228 */         if (y0 < y1) {
/* 229 */           gc.fillPolygon(new int[] { x, y, x - 3, y - 6, x + 3, y - 6 });
/*     */         }
/* 231 */         else if (y0 > y1) {
/* 232 */           gc.fillPolygon(new int[] { x, y, x - 3, y + 6, x + 3, y + 6 });
/*     */         }
/*     */       }
/* 235 */       else if (y0 == y1) {
/* 236 */         int deltaX = 6;
/* 237 */         int deltaY = 3;
/* 238 */         if (x0 < x1) {
/* 239 */           gc.fillPolygon(new int[] { x, y, x - 6, y - 3, x - 6, y + 3 });
/*     */         }
/* 241 */         else if (x0 > x1) {
/* 242 */           gc.fillPolygon(new int[] { x, y, x + 6, y - 3, x + 6, y + 3 });
/*     */         }
/*     */       }
/*     */     }
/* 246 */     else if ((this.orientation == Orientation.ORIENTED_BACKWARD) || (this.orientation == Orientation.ORIENTED_DUAL)) {
/* 247 */       throw new RuntimeException("Dual orientation is TBI");
/*     */     }
/*     */   }
/*     */   
/*     */   private Color determineEdgeColor() {
/* 252 */     return (Color)this.colors.get(Integer.valueOf(this.state));
/*     */   }
/*     */   
/*     */   private void setForeground(GC gc) {
/* 256 */     Color color = determineEdgeColor();
/* 257 */     if (color != null) {
/* 258 */       gc.setForeground(color);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setBackground(GC gc) {
/* 263 */     Color color = determineEdgeColor();
/* 264 */     if (color != null) {
/* 265 */       gc.setBackground(color);
/*     */     }
/*     */   }
/*     */   
/*     */   private Point determineSimpleAnchorCoords(GraphNode node, Anchor anchor) {
/* 270 */     Rectangle r = node.getBounds();
/*     */     int y;
/* 272 */     int y; int y; int y; int y; int x; int y; switch (anchor) {
/*     */     case CENTER: 
/* 274 */       int x = r.x + r.width / 2;
/* 275 */       y = r.y + r.height / 2;
/* 276 */       break;
/*     */     case TOP: 
/* 278 */       int x = r.x + r.width / 2;
/* 279 */       y = r.y;
/* 280 */       break;
/*     */     case BOTTOM: 
/* 282 */       int x = r.x + r.width / 2;
/* 283 */       y = r.y + r.height;
/* 284 */       break;
/*     */     case LEFT: 
/* 286 */       int x = r.x;
/* 287 */       y = r.y + r.height / 2;
/* 288 */       break;
/*     */     
/*     */     case RIGHT: 
/* 291 */       int x = r.x + r.width;
/* 292 */       y = r.y + r.height / 2;
/* 293 */       break;
/*     */     default: 
/* 295 */       x = r.x;
/* 296 */       y = r.y;
/*     */     }
/*     */     
/* 299 */     return new Point(x, y);
/*     */   }
/*     */   
/*     */   private Anchor[] determineBestAnchors() {
/* 303 */     Rectangle r0 = this.src.getBounds();
/* 304 */     Rectangle r1 = this.dst.getBounds();
/*     */     
/* 306 */     if (r1.x + r1.width < r0.x) {
/* 307 */       int dY = r0.y - (r1.y + r1.height);
/* 308 */       int dX = r0.x - (r1.x + r1.width);
/* 309 */       int dZ = r1.y - (r0.y + r0.height);
/* 310 */       if ((dX >= dY) && (dX >= dZ)) {
/* 311 */         return new Anchor[] { Anchor.LEFT, Anchor.RIGHT };
/*     */       }
/* 313 */       if (dY > dZ) {
/* 314 */         return new Anchor[] { Anchor.TOP, Anchor.BOTTOM };
/*     */       }
/* 316 */       return new Anchor[] { Anchor.BOTTOM, Anchor.TOP };
/*     */     }
/*     */     
/* 319 */     if (r1.x > r0.x + r0.width) {
/* 320 */       int dY = r0.y - (r1.y + r1.height);
/* 321 */       int dX = r1.x - (r0.x + r0.width);
/* 322 */       int dZ = r1.y - (r0.y + r0.height);
/* 323 */       if ((dX >= dY) && (dX >= dZ)) {
/* 324 */         return new Anchor[] { Anchor.RIGHT, Anchor.LEFT };
/*     */       }
/* 326 */       if (dY > dZ) {
/* 327 */         return new Anchor[] { Anchor.TOP, Anchor.BOTTOM };
/*     */       }
/* 329 */       return new Anchor[] { Anchor.BOTTOM, Anchor.TOP };
/*     */     }
/*     */     
/* 332 */     if (r1.y + r1.height < r0.y) {
/* 333 */       return new Anchor[] { Anchor.TOP, Anchor.BOTTOM };
/*     */     }
/*     */     
/* 336 */     if (r1.y > r0.y + r0.height) {
/* 337 */       return new Anchor[] { Anchor.BOTTOM, Anchor.TOP };
/*     */     }
/*     */     
/* 340 */     return new Anchor[] { Anchor.CENTER, Anchor.CENTER };
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 345 */     return String.format("Edge{%s->%s}", new Object[] { this.src, this.dst });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\GraphEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */