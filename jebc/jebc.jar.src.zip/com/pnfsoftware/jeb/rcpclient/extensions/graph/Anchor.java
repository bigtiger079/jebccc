package com.pnfsoftware.jeb.rcpclient.extensions.graph;

public enum Anchor
{
  AUTO,  CENTER,  TOP,  BOTTOM,  LEFT,  RIGHT;
  
  private Anchor() {}
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\graph\Anchor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */