/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.api.IOperable;
/*     */ import com.pnfsoftware.jeb.client.api.Operation;
/*     */ import com.pnfsoftware.jeb.client.api.OperationRequest;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IFilterText;
/*     */ import com.pnfsoftware.jeb.rcpclient.operations.ContextMenu;
/*     */ import com.pnfsoftware.jeb.rcpclient.operations.IContextMenu;
/*     */ import com.pnfsoftware.jeb.rcpclient.operations.OperationCopy;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.IValueProvider;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.action.IMenuManager;
/*     */ import org.eclipse.jface.action.Separator;
/*     */ import org.eclipse.jface.viewers.ColumnViewer;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextMenuFilter
/*     */   implements IContextMenu
/*     */ {
/*     */   private ColumnViewer viewer;
/*     */   private IFilterText filterText;
/*     */   private IValueProvider valueProvider;
/*     */   private String[] filterLabels;
/*     */   private Boolean[] displayPrefixes;
/*     */   
/*     */   public static ContextMenu addContextMenu(ColumnViewer viewer, IFilterText filterText, IValueProvider valueProvider, String[] filterLabels, Boolean[] displayPrefix)
/*     */   {
/*  57 */     return addContextMenu(viewer, filterText, valueProvider, filterLabels, displayPrefix, null);
/*     */   }
/*     */   
/*     */   public static ContextMenu addContextMenu(ColumnViewer viewer, IFilterText filterText, IValueProvider valueProvider, String[] filterLabels, Boolean[] displayPrefix, IContextMenu contextMenu)
/*     */   {
/*  62 */     ContextMenu contextMenuMgr = new ContextMenu(viewer.getControl());
/*  63 */     if (contextMenu != null) {
/*  64 */       contextMenuMgr.addContextMenu(contextMenu);
/*     */     }
/*  66 */     ContextMenuFilter cmf = new ContextMenuFilter(viewer, filterText, valueProvider, filterLabels, displayPrefix);
/*  67 */     contextMenuMgr.addContextMenu(cmf);
/*  68 */     return contextMenuMgr;
/*     */   }
/*     */   
/*     */   public static ContextMenu addCopyEntry(ContextMenu ctxMenu, Control control, IOperable operable) {
/*  72 */     ctxMenu.addContextMenu(new IContextMenu()
/*     */     {
/*     */       public void fillContextMenu(IMenuManager menuMgr) {
/*  75 */         menuMgr.add(new Separator());
/*  76 */         menuMgr.add(new OperationCopy(this.val$operable));
/*     */       }
/*  78 */     });
/*  79 */     control.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/*  83 */         if (((e.stateMask & SWT.MOD1) == SWT.MOD1) && (e.keyCode == 99)) {
/*  84 */           OperationRequest op = new OperationRequest(Operation.COPY);
/*  85 */           if (this.val$operable.verifyOperation(op)) {
/*  86 */             boolean success = this.val$operable.doOperation(op);
/*  87 */             if (success) {
/*  88 */               e.doit = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  93 */     });
/*  94 */     return ctxMenu;
/*     */   }
/*     */   
/*     */   protected ContextMenuFilter(ColumnViewer viewer, IFilterText filterText, IValueProvider valueProvider, String[] filterLabels, Boolean[] displayPrefixes)
/*     */   {
/*  99 */     this.viewer = viewer;
/* 100 */     this.filterText = filterText;
/* 101 */     this.valueProvider = valueProvider;
/* 102 */     this.filterLabels = filterLabels;
/* 103 */     this.displayPrefixes = displayPrefixes;
/*     */   }
/*     */   
/*     */   public void fillContextMenu(IMenuManager menuMgr)
/*     */   {
/* 108 */     IStructuredSelection selection = (IStructuredSelection)this.viewer.getSelection();
/* 109 */     Object element = selection.getFirstElement();
/* 110 */     if (element == null)
/*     */     {
/* 112 */       return;
/*     */     }
/* 114 */     for (int i = 0; i < this.filterLabels.length; i++) {
/* 115 */       if ((this.filterLabels[i] != null) && (this.valueProvider.getStringAt(element, i) != null)) {
/* 116 */         boolean displayPrefix = true;
/* 117 */         if ((this.displayPrefixes != null) && (i < this.displayPrefixes.length)) {
/* 118 */           displayPrefix = this.displayPrefixes[i].booleanValue();
/*     */         }
/* 120 */         menuMgr.add(new FilterAction(this.filterLabels[i], i, displayPrefix));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class FilterAction extends Action {
/*     */     private int filterLabelIndex;
/*     */     private boolean displayPrefix;
/*     */     private String columnName;
/*     */     
/*     */     public FilterAction(String columnName, int filterLabelIndex, boolean displayPrefix) {
/* 131 */       super();
/* 132 */       setEnabled(true);
/* 133 */       this.filterLabelIndex = filterLabelIndex;
/* 134 */       this.displayPrefix = displayPrefix;
/* 135 */       this.columnName = columnName;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 140 */       IStructuredSelection selection = (IStructuredSelection)ContextMenuFilter.this.viewer.getSelection();
/* 141 */       String newFilterValue = ContextMenuFilter.this.valueProvider.getStringAt(selection.getFirstElement(), this.filterLabelIndex);
/* 142 */       if (newFilterValue != null) {
/* 143 */         ContextMenuFilter.this.filterText.submitText(this.displayPrefix ? addSearchPrefix(newFilterValue) : newFilterValue);
/*     */       }
/*     */     }
/*     */     
/*     */     protected String addSearchPrefix(String value) {
/* 148 */       if (Strings.isBlank(this.columnName)) {
/* 149 */         return value;
/*     */       }
/* 151 */       return this.columnName.toLowerCase() + ":\"" + value.replace("\"", "\\\"") + "\"";
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\ContextMenuFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */