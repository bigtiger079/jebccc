/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.api.IOperable;
/*     */ import com.pnfsoftware.jeb.client.api.OperationRequest;
/*     */ import com.pnfsoftware.jeb.core.units.AutocompletionResult;
/*     */ import com.pnfsoftware.jeb.core.units.ExecutionResult;
/*     */ import com.pnfsoftware.jeb.core.units.ICommandInterpreter;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.FindTextDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.FindTextOptions;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.GraphicalTextFinder;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.SimpleTextFindResults;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.search.StyledTextFindImpl;
/*     */ import com.pnfsoftware.jeb.util.collect.ItemHistory;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.jface.resource.JFaceResources;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.custom.VerifyKeyListener;
/*     */ import org.eclipse.swt.events.VerifyEvent;
/*     */ import org.eclipse.swt.events.VerifyListener;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConsoleViewer
/*     */   extends Viewer
/*     */   implements IOperable
/*     */ {
/*  45 */   private static final ILogger logger = GlobalLog.getLogger(ConsoleViewer.class);
/*     */   
/*     */   public static final String DEFAULT_PROMPT = "> ";
/*     */   
/*     */   private StyledText console;
/*     */   
/*     */   private StyledTextFindImpl findimpl;
/*     */   
/*     */   private GraphicalTextFinder<SimpleTextFindResults> finder;
/*     */   private ICommandInterpreter interpreter;
/*  55 */   private String prompt = "> ";
/*     */   private boolean shouldSetNewPrompt;
/*     */   private String newPrompt;
/*  58 */   private boolean allowEmptyCommands = true;
/*  59 */   private final AtomicBoolean previousKeyWasTab = new AtomicBoolean(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConsoleViewer(Composite parent, int style)
/*     */   {
/*  73 */     style &= 0x800;
/*  74 */     this.console = new StyledText(parent, style | 0x2 | 0x200 | 0x100);
/*  75 */     this.console.setFont(JFaceResources.getTextFont());
/*     */     
/*  77 */     this.findimpl = new StyledTextFindImpl(this.console);
/*  78 */     this.finder = new GraphicalTextFinder(this.findimpl, null);
/*     */     
/*  80 */     this.console.addVerifyListener(new VerifyListener()
/*     */     {
/*     */       public void verifyText(VerifyEvent e) {
/*  83 */         if (ConsoleViewer.this.console.isTextSelected())
/*     */         {
/*  85 */           if (ConsoleViewer.this.console.getSelection().x < ConsoleViewer.this.getFirstValidCaretPosition()) {
/*  86 */             e.doit = false;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*  91 */     });
/*  92 */     this.console.addVerifyKeyListener(new VerifyKeyListener()
/*     */     {
/*     */       public void verifyKey(VerifyEvent e) {
/*  95 */         int key = e.keyCode;
/*  96 */         int mask = e.stateMask;
/*  97 */         ConsoleViewer.logger.i("key=%Xh mask=%Xh", new Object[] { Integer.valueOf(key), Integer.valueOf(e.stateMask) });
/*     */         
/*     */ 
/* 100 */         if ((mask == 0) && ((key & SWT.MODIFIER_MASK) != 0)) {
/* 101 */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */         if (e.stateMask == SWT.MOD1)
/*     */         {
/* 111 */           if (key == 108) {
/* 112 */             ConsoleViewer.this.clearConsole();
/* 113 */             return;
/*     */           }
/*     */           
/* 116 */           if (key == 99) {
/* 117 */             return;
/*     */           }
/*     */           
/* 120 */           if (key == 118) {
/* 121 */             if (!ConsoleViewer.this.isValidCaret()) {
/* 122 */               ConsoleViewer.this.setCaretEnd();
/*     */             }
/* 124 */             String s = UIUtil.getTextFromClipboard();
/* 125 */             if ((s != null) && (s.length() > 0)) {
/* 126 */               s = Strings.splitLines(s)[0];
/* 127 */               ConsoleViewer.logger.i("Pasting: %s", new Object[] { s });
/* 128 */               ConsoleViewer.this.replaceSelection(s);
/*     */             }
/* 130 */             ConsoleViewer.this.showInputLine();
/* 131 */             e.doit = false;
/* 132 */             return;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 137 */         if (e.stateMask == SWT.MOD2)
/*     */         {
/* 139 */           if (UIUtil.isArrowKey(key)) {
/* 140 */             return;
/*     */           }
/*     */         }
/*     */         
/* 144 */         if (!ConsoleViewer.this.isValidCaret()) {
/* 145 */           ConsoleViewer.this.setCaretEnd();
/*     */         }
/*     */         
/* 148 */         if (key == 9) {
/* 149 */           e.doit = false;
/* 150 */           if (ConsoleViewer.this.previousKeyWasTab.get()) {
/* 151 */             ConsoleViewer.this.previousKeyWasTab.set(false);
/* 152 */             AutocompletionResult auto = ConsoleViewer.this.interpreter.autoComplete(ConsoleViewer.this.getCurrentUserInput());
/* 153 */             if ((auto == null) || (auto.getAutocompletes() == null) || (auto.getAutocompletes().isEmpty()))
/*     */             {
/* 155 */               return;
/*     */             }
/* 157 */             ConsoleViewer.this.executeAutoComplete(auto);
/*     */           }
/*     */           else {
/* 160 */             ConsoleViewer.this.previousKeyWasTab.set(true);
/*     */           }
/*     */         }
/*     */         else {
/* 164 */           ConsoleViewer.this.previousKeyWasTab.set(false);
/*     */         }
/* 166 */         if ((key == 16777217) || (key == 16777218))
/*     */         {
/* 168 */           String s = key == 16777217 ? (String)ConsoleViewer.this.getHistory().getPrevious() : (String)ConsoleViewer.this.getHistory().getNext();
/* 169 */           if (ConsoleViewer.this.getCurrentUserInput().equals(s)) {
/* 170 */             s = key == 16777217 ? (String)ConsoleViewer.this.getHistory().getPrevious() : (String)ConsoleViewer.this.getHistory().getNext();
/*     */           }
/* 172 */           else if ((key == 16777218) && (s == null)) {
/* 173 */             s = "";
/*     */           }
/*     */           
/*     */ 
/* 177 */           if (s != null) {
/* 178 */             ConsoleViewer.this.clearLine();
/* 179 */             ConsoleViewer.this.appendText(s);
/* 180 */             ConsoleViewer.this.setCaretEnd();
/*     */           }
/* 182 */           e.doit = false;
/*     */         }
/* 184 */         else if ((key == 16777221) || (key == 16777222)) {
/* 185 */           e.doit = false;
/*     */         }
/* 187 */         else if (key == 16777219) {
/* 188 */           if (ConsoleViewer.this.getCaretColumnOffset() <= ConsoleViewer.this.prompt.length()) {
/* 189 */             ConsoleViewer.this.console.setSelection(ConsoleViewer.this.console.getCaretOffset());
/* 190 */             e.doit = false;
/*     */           }
/*     */         }
/* 193 */         else if (key == 8) {
/* 194 */           int thres = ConsoleViewer.this.prompt.length();
/* 195 */           if (ConsoleViewer.this.console.getSelectionCount() == 0) {
/* 196 */             thres++;
/*     */           }
/* 198 */           if (ConsoleViewer.this.getCaretColumnOffset() < thres) {
/* 199 */             ConsoleViewer.this.console.setSelection(ConsoleViewer.this.console.getCaretOffset());
/* 200 */             e.doit = false;
/*     */           }
/*     */         }
/* 203 */         else if (key == 16777223)
/*     */         {
/* 205 */           if (e.stateMask == SWT.MOD2) {
/* 206 */             if (!ConsoleViewer.this.isValidCaret()) {
/* 207 */               ConsoleViewer.this.setCaretEnd();
/*     */             }
/* 209 */             ConsoleViewer.this.console.setSelection(ConsoleViewer.this.console.getCaretOffset(), ConsoleViewer.this.getFirstValidCaretPosition());
/*     */           }
/*     */           else {
/* 212 */             ConsoleViewer.this.setCaretBegin();
/*     */           }
/* 214 */           e.doit = false;
/*     */         }
/* 216 */         else if ((key == 13) || (key == 16777296)) {
/* 217 */           String userInput = ConsoleViewer.this.getCurrentUserInput();
/* 218 */           ConsoleViewer.logger.i("User requested execution of command: \"%s\"", new Object[] { userInput });
/* 219 */           if ((ConsoleViewer.this.allowEmptyCommands) || (!userInput.trim().isEmpty())) {
/* 220 */             ConsoleViewer.this.executeCommand(userInput);
/*     */           }
/* 222 */           ConsoleViewer.this.showInputLine();
/* 223 */           e.doit = false;
/*     */         }
/*     */         
/*     */       }
/* 227 */     });
/* 228 */     generatePromp();
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/* 232 */     this.console.setFont(font);
/*     */   }
/*     */   
/*     */   public Font getFont() {
/* 236 */     return this.console.getFont();
/*     */   }
/*     */   
/*     */   public void setInterpreter(ICommandInterpreter interpreter) {
/* 240 */     this.interpreter = interpreter;
/*     */   }
/*     */   
/*     */   public ICommandInterpreter getInterpreter() {
/* 244 */     return this.interpreter;
/*     */   }
/*     */   
/*     */   public void setAllowEmptyCommands(boolean enabled) {
/* 248 */     this.allowEmptyCommands = enabled;
/*     */   }
/*     */   
/*     */   public boolean getAllowEmptyCommands() {
/* 252 */     return this.allowEmptyCommands;
/*     */   }
/*     */   
/*     */   public void updatePromptAfterCommand(String prompt) {
/* 256 */     this.shouldSetNewPrompt = true;
/* 257 */     this.newPrompt = prompt;
/*     */   }
/*     */   
/*     */   public void updatePrompt(String prompt) {
/* 261 */     if (prompt == null) {
/* 262 */       prompt = "> ";
/*     */     }
/*     */     
/* 265 */     String currentPrompt = getPrompt();
/* 266 */     if (prompt.equals(currentPrompt)) {
/* 267 */       return;
/*     */     }
/*     */     
/* 270 */     String line = getLastLine();
/* 271 */     String currentCommand = "";
/* 272 */     if (line.startsWith(currentPrompt)) {
/* 273 */       currentCommand = line.substring(currentPrompt.length());
/*     */     }
/* 275 */     removeTrailingCharacters(line.length());
/* 276 */     appendText(prompt);
/* 277 */     appendText(currentCommand);
/*     */     
/* 279 */     this.prompt = prompt;
/*     */   }
/*     */   
/*     */   public String getPrompt() {
/* 283 */     return this.prompt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void generatePromp()
/*     */   {
/* 290 */     appendText(getPrompt());
/* 291 */     setCaretEnd();
/*     */     
/* 293 */     updateNewPrompt();
/*     */   }
/*     */   
/*     */   public void updateNewPrompt()
/*     */   {
/* 298 */     if (this.shouldSetNewPrompt) {
/* 299 */       updatePrompt(this.newPrompt);
/* 300 */       this.shouldSetNewPrompt = false;
/* 301 */       setCaretEnd();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clearConsole()
/*     */   {
/* 309 */     setText("", true);
/* 310 */     generatePromp();
/*     */   }
/*     */   
/*     */   public void clearLine() {
/* 314 */     removeTrailingCharacters(getCurrentUserInput().length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getCaretColumnOffset()
/*     */   {
/* 323 */     int offset = this.console.getCaretOffset();
/* 324 */     int lineIndex = this.console.getLineAtOffset(offset);
/* 325 */     return offset - this.console.getOffsetAtLine(lineIndex);
/*     */   }
/*     */   
/*     */   private String getLastLine() {
/* 329 */     return this.console.getLine(this.console.getLineCount() - 1);
/*     */   }
/*     */   
/*     */   private String getCurrentUserInput() {
/* 333 */     String raw = this.console.getLine(this.console.getLineCount() - 1);
/* 334 */     if (raw.length() < getPrompt().length()) {
/* 335 */       return "";
/*     */     }
/*     */     
/* 338 */     return raw.substring(getPrompt().length());
/*     */   }
/*     */   
/*     */   public void simulateInputAndExecute(String command) {
/* 342 */     setCaretEnd();
/* 343 */     appendText(command);
/* 344 */     executeCommand(command);
/*     */   }
/*     */   
/*     */   private void executeCommand(String command) {
/* 348 */     if (!command.trim().isEmpty()) {
/* 349 */       getHistory().add(command);
/*     */     }
/*     */     
/* 352 */     if (this.interpreter == null) {
/* 353 */       appendText("\rInterpreter is unavailable\r");
/*     */     }
/*     */     else {
/* 356 */       ExecutionResult result = this.interpreter.executeCommand(command);
/* 357 */       String msg = "\r";
/* 358 */       if (result.getCode() != 0) {
/* 359 */         msg = msg + String.format("%d: ", new Object[] { Integer.valueOf(result.getCode()) });
/* 360 */         if (!Strings.isBlank(result.getMessage())) {
/* 361 */           msg = msg + Strings.rtrim(result.getMessage());
/*     */         }
/*     */         else {
/* 364 */           msg = msg + "An error occurred";
/*     */         }
/* 366 */         msg = msg + String.format(" (\"%s\")", new Object[] { command });
/* 367 */         msg = msg + "\r";
/*     */       }
/* 369 */       else if (result.getMessage() != null) {
/* 370 */         msg = msg + Strings.rtrim(result.getMessage());
/* 371 */         if (!Strings.isBlank(msg)) {
/* 372 */           msg = msg + "\r";
/*     */         }
/*     */       }
/* 375 */       appendText(msg);
/*     */     }
/* 377 */     generatePromp();
/*     */   }
/*     */   
/*     */   private void appendText(String text) {
/* 381 */     this.console.append(text);
/*     */   }
/*     */   
/*     */   private void executeAutoComplete(AutocompletionResult auto) {
/* 385 */     String userInput = getCurrentUserInput();
/* 386 */     if (auto.getAutocompletes().size() > 1) {
/* 387 */       StringBuilder msg = new StringBuilder();
/* 388 */       msg.append("\r");
/* 389 */       int maxSize = 0;
/* 390 */       for (String tok : auto.getAutocompletes()) {
/* 391 */         maxSize = Math.max(maxSize, tok.length());
/*     */       }
/* 393 */       maxSize += 4;
/* 394 */       int perLine = 80;
/* 395 */       int currentLine = 0;
/* 396 */       for (String tok : auto.getAutocompletes()) {
/* 397 */         if (currentLine + maxSize > perLine) {
/* 398 */           msg.append('\r');
/* 399 */           currentLine = 0;
/*     */         }
/* 401 */         msg.append(String.format("%-" + maxSize + "s", new Object[] { tok }));
/* 402 */         currentLine += maxSize;
/*     */       }
/* 404 */       msg.append('\r');
/* 405 */       appendText(msg.toString());
/* 406 */       generatePromp();
/* 407 */       int from = userInput.lastIndexOf(auto.getLastSeparator());
/* 408 */       if (from == -1)
/*     */       {
/* 410 */         appendText(userInput);
/*     */       }
/*     */       else {
/* 413 */         appendText(userInput.substring(0, from + 1));
/*     */         
/* 415 */         appendText(getCommon(auto.getAutocompletes()));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 420 */       int from = userInput.lastIndexOf(auto.getLastSeparator()) + 1;
/* 421 */       String autocompl = (String)auto.getAutocompletes().get(0);
/* 422 */       int fromAuto = userInput.length() - from;
/* 423 */       appendText(autocompl.substring(fromAuto));
/*     */     }
/* 425 */     setCaretEnd();
/* 426 */     showInputLine();
/*     */   }
/*     */   
/*     */   private String getCommon(List<String> autocompletes) {
/* 430 */     String reference = (String)autocompletes.get(0);
/* 431 */     for (int i = 1; i < autocompletes.size(); i++) {
/* 432 */       String comparison = (String)autocompletes.get(i);
/* 433 */       int commonLength = getCommonLength(reference, comparison);
/* 434 */       if (reference.length() > commonLength) {
/* 435 */         reference = reference.substring(0, commonLength);
/*     */       }
/* 437 */       if (commonLength == 0) {
/* 438 */         return reference;
/*     */       }
/*     */     }
/* 441 */     return reference;
/*     */   }
/*     */   
/*     */   private int getCommonLength(String reference, String comparison) {
/* 445 */     for (int i = 0; 
/* 446 */         (i < reference.length()) && (i < comparison.length()); i++) {
/* 447 */       if (reference.charAt(i) != comparison.charAt(i)) {
/* 448 */         return i;
/*     */       }
/*     */     }
/* 451 */     return i;
/*     */   }
/*     */   
/*     */   private void replaceSelection(String text) {
/* 455 */     int offset = -1;
/* 456 */     if (this.console.getSelectionCount() == 0) {
/* 457 */       offset = this.console.getCaretOffset() + text.length();
/*     */     }
/* 459 */     this.console.insert(text);
/* 460 */     if (offset >= 0) {
/* 461 */       this.console.setCaretOffset(offset);
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeTrailingCharacters(int count) {
/* 466 */     String text = this.console.getText();
/* 467 */     this.console.replaceTextRange(text.length() - count, count, "");
/*     */   }
/*     */   
/*     */   private void setText(String text, boolean show) {
/* 471 */     this.console.setText(text);
/* 472 */     if (show) {
/* 473 */       showInputLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void showInputLine() {
/* 478 */     this.console.setTopIndex(this.console.getLineCount() - 1);
/*     */   }
/*     */   
/*     */   private void setCaretBegin() {
/* 482 */     int offset = this.console.getCaretOffset();
/* 483 */     int lineIndex = this.console.getLineAtOffset(offset);
/* 484 */     this.console.setCaretOffset(this.console.getOffsetAtLine(lineIndex) + getPrompt().length());
/*     */   }
/*     */   
/*     */   private int getFirstValidCaretPosition() {
/* 488 */     return this.console.getOffsetAtLine(this.console.getLineCount() - 1) + getPrompt().length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isValidCaret()
/*     */   {
/* 501 */     int offset = this.console.getCaretOffset();
/* 502 */     if (offset == this.console.getText().length()) {
/* 503 */       return true;
/*     */     }
/*     */     
/* 506 */     int lineIndex = this.console.getLineAtOffset(offset);
/* 507 */     if (lineIndex != this.console.getLineCount() - 1) {
/* 508 */       return false;
/*     */     }
/*     */     
/* 511 */     int delta = offset - this.console.getOffsetAtLine(lineIndex);
/* 512 */     return delta >= getPrompt().length();
/*     */   }
/*     */   
/*     */   private void setCaretEnd() {
/* 516 */     this.console.setCaretOffset(this.console.getText().length());
/*     */   }
/*     */   
/*     */   public Control getControl()
/*     */   {
/* 521 */     return this.console;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInput(Object input)
/*     */   {
/* 529 */     if (!(input instanceof ICommandInterpreter)) {
/* 530 */       throw new IllegalArgumentException();
/*     */     }
/* 532 */     setInterpreter((ICommandInterpreter)input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ICommandInterpreter getInput()
/*     */   {
/* 540 */     return this.interpreter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void refresh() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(ISelection selection, boolean reveal) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ISelection getSelection()
/*     */   {
/* 563 */     return null;
/*     */   }
/*     */   
/*     */   public boolean verifyOperation(OperationRequest req)
/*     */   {
/* 568 */     switch (req.getOperation()) {
/*     */     case SELECT_ALL: 
/* 570 */       return true;
/*     */     case COPY: 
/* 572 */       return this.console.isTextSelected();
/*     */     case CLEAR: 
/* 574 */       return true;
/*     */     case FIND: 
/* 576 */       return true;
/*     */     case FIND_NEXT: 
/* 578 */       return this.finder.isReady();
/*     */     }
/* 580 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean doOperation(OperationRequest req)
/*     */   {
/* 586 */     switch (req.getOperation()) {
/*     */     case SELECT_ALL: 
/* 588 */       this.console.selectAll();
/* 589 */       return true;
/*     */     case COPY: 
/* 591 */       this.console.copy();
/* 592 */       return true;
/*     */     case CLEAR: 
/* 594 */       clearConsole();
/* 595 */       return true;
/*     */     case FIND: 
/* 597 */       String selectedText = this.console.getSelectionText();
/* 598 */       if (selectedText.length() > 0) {
/* 599 */         this.findimpl.getFindTextOptions(false).setSearchString(selectedText);
/*     */       }
/* 601 */       FindTextDialog dlg = new FindTextDialog(this.console.getShell(), this.finder, null);
/* 602 */       dlg.open();
/* 603 */       return true;
/*     */     case FIND_NEXT: 
/* 605 */       this.finder.search(null);
/* 606 */       return true;
/*     */     }
/* 608 */     return false;
/*     */   }
/*     */   
/*     */   public ItemHistory<String> getHistory()
/*     */   {
/* 613 */     return this.interpreter.getHistory();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\ConsoleViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */