/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.media;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineListener;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundManager
/*     */   implements LineListener
/*     */ {
/*  42 */   private static final ILogger logger = GlobalLog.getLogger(SoundManager.class);
/*     */   
/*     */   public static final int STOPPED = 0;
/*     */   
/*     */   public static final int RECORDING = 1;
/*     */   
/*     */   public static final int PLAYING = 2;
/*  49 */   final float sampleRate = 8000.0F;
/*  50 */   final int sampleSizeInBits = 8;
/*  51 */   final int channels = 1;
/*  52 */   final boolean signed = true;
/*  53 */   final boolean bigEndian = true;
/*     */   
/*     */ 
/*     */ 
/*  57 */   List<IStateChangedListener> listeners = new ArrayList();
/*     */   
/*  59 */   int state = 0;
/*  60 */   ByteArrayOutputStream datastream = new ByteArrayOutputStream();
/*  61 */   Thread captureThread = null;
/*  62 */   Thread playThread = null;
/*     */   
/*     */   public SoundManager() {}
/*     */   
/*     */   public SoundManager(InputStream in)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/*  69 */     load(in);
/*     */   }
/*     */   
/*     */   public void load(InputStream in) throws UnsupportedAudioFileException, IOException {
/*  73 */     AudioInputStream ais = AudioSystem.getAudioInputStream((in instanceof BufferedInputStream) ? in : new BufferedInputStream(in));
/*     */     
/*     */ 
/*  76 */     int bytesPerFrame = ais.getFormat().getFrameSize();
/*  77 */     if (bytesPerFrame == -1)
/*     */     {
/*     */ 
/*  80 */       bytesPerFrame = 1;
/*     */     }
/*     */     
/*     */ 
/*  84 */     this.datastream = new ByteArrayOutputStream();
/*  85 */     byte[] buffer = new byte[8000 * bytesPerFrame];
/*     */     int cnt;
/*  87 */     while ((cnt = ais.read(buffer)) != -1) {
/*  88 */       this.datastream.write(buffer, 0, cnt);
/*     */     }
/*  90 */     ais.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean dump(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 105 */     if (this.state != 0) {
/* 106 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 110 */     byte[] data = this.datastream.toByteArray();
/* 111 */     InputStream input = new ByteArrayInputStream(data);
/* 112 */     AudioFormat format = new AudioFormat(8000.0F, 8, 1, true, true);
/* 113 */     AudioInputStream ais = new AudioInputStream(input, format, data.length / format.getFrameSize());
/*     */     
/*     */ 
/*     */ 
/* 117 */     AudioFileFormat.Type type = AudioFileFormat.Type.AIFF;
/* 118 */     if (!AudioSystem.isFileTypeSupported(type, ais)) {
/* 119 */       AudioFileFormat.Type[] types = AudioSystem.getAudioFileTypes(ais);
/* 120 */       if (types.length == 0) {
/* 121 */         ais.close();
/* 122 */         return false;
/*     */       }
/* 124 */       type = types[0];
/*     */     }
/*     */     
/*     */ 
/* 128 */     AudioSystem.write(ais, type, out);
/* 129 */     ais.close();
/* 130 */     return true;
/*     */   }
/*     */   
/*     */   public void addStateChangedListener(IStateChangedListener listener) {
/* 134 */     this.listeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeStateChangedListener(IStateChangedListener listener) {
/* 138 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public int getState() {
/* 142 */     return this.state;
/*     */   }
/*     */   
/*     */   private void setState(int new_state) {
/* 146 */     if (this.state == new_state) {
/* 147 */       return;
/*     */     }
/*     */     
/* 150 */     int old_state = this.state;
/* 151 */     this.state = new_state;
/* 152 */     for (IStateChangedListener listener : this.listeners) {
/* 153 */       listener.stateChanged(old_state, new_state);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasAudioData() {
/* 158 */     return this.datastream.size() > 0;
/*     */   }
/*     */   
/*     */   public boolean waitForState(int wanted_state, long max_wait_ms) {
/* 162 */     long start = System.currentTimeMillis();
/* 163 */     for (;;) { if ((this.state != wanted_state) && ((max_wait_ms < 0L) || (System.currentTimeMillis() - start < max_wait_ms))) {
/*     */         try {
/* 165 */           Thread.sleep(200L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*     */     }
/*     */     
/* 171 */     return this.state == wanted_state;
/*     */   }
/*     */   
/*     */   public boolean reset() {
/* 175 */     if (this.state != 0) {
/* 176 */       logger.i("reset() FAILED", new Object[0]);
/* 177 */       return false;
/*     */     }
/*     */     
/* 180 */     this.datastream = new ByteArrayOutputStream();
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   public boolean stop() throws Exception {
/* 185 */     if (this.state == 0) {
/* 186 */       return true;
/*     */     }
/* 188 */     if (this.state == 1) {
/* 189 */       return stopRecording();
/*     */     }
/* 191 */     if (this.state == 2) {
/* 192 */       return stopPlaying();
/*     */     }
/* 194 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */   public boolean record() throws Exception {
/* 198 */     if (this.state != 0) {
/* 199 */       logger.i("record() FAILED", new Object[0]);
/* 200 */       return false;
/*     */     }
/*     */     
/* 203 */     setState(1);
/*     */     
/* 205 */     final ByteArrayOutputStream sample = new ByteArrayOutputStream();
/*     */     
/* 207 */     final AudioFormat format = new AudioFormat(8000.0F, 8, 1, true, true);
/* 208 */     DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
/* 209 */     final TargetDataLine line = (TargetDataLine)AudioSystem.getLine(info);
/*     */     
/*     */ 
/* 212 */     line.open(format);
/* 213 */     line.start();
/*     */     
/* 215 */     Runnable runner = new Runnable() {
/* 216 */       int bufferSize = (int)(format.getSampleRate() * format.getFrameSize());
/* 217 */       byte[] buffer = new byte[this.bufferSize];
/*     */       
/*     */       public void run()
/*     */       {
/*     */         try {
/* 222 */           while (SoundManager.this.state == 1) {
/* 223 */             int count = line.read(this.buffer, 0, this.buffer.length);
/* 224 */             if (count > 0) {
/* 225 */               sample.write(this.buffer, 0, count);
/*     */             }
/*     */           }
/*     */           
/* 229 */           line.stop();
/* 230 */           line.close();
/*     */           
/*     */ 
/* 233 */           SoundManager.this.datastream.write(sample.toByteArray());
/*     */         }
/*     */         catch (Exception e) {
/* 236 */           SoundManager.this.setState(0);
/*     */         }
/*     */       }
/* 239 */     };
/* 240 */     this.captureThread = new Thread(runner);
/* 241 */     this.captureThread.start();
/* 242 */     return true;
/*     */   }
/*     */   
/*     */   public boolean stopRecording() throws Exception {
/* 246 */     if (this.state != 1) {
/* 247 */       logger.i("stopRecording() FAILED", new Object[0]);
/* 248 */       return false;
/*     */     }
/*     */     
/* 251 */     setState(0);
/* 252 */     this.captureThread.join();
/* 253 */     this.captureThread = null;
/* 254 */     return true;
/*     */   }
/*     */   
/*     */   public boolean play() throws LineUnavailableException {
/* 258 */     if ((this.state != 0) || (this.datastream == null)) {
/* 259 */       logger.i("play() FAILED", new Object[0]);
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     setState(2);
/* 264 */     byte[] data = this.datastream.toByteArray();
/* 265 */     InputStream input = new ByteArrayInputStream(data);
/* 266 */     final AudioFormat format = new AudioFormat(8000.0F, 8, 1, true, true);
/* 267 */     DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
/* 268 */     final SourceDataLine line = (SourceDataLine)AudioSystem.getLine(info);
/*     */     
/* 270 */     final AudioInputStream ais = new AudioInputStream(input, format, data.length / format.getFrameSize());
/* 271 */     line.open(format);
/* 272 */     line.start();
/*     */     
/* 274 */     Runnable runner = new Runnable() {
/* 275 */       int bufferSize = (int)(format.getSampleRate() * format.getFrameSize());
/*     */       
/* 277 */       byte[] buffer = new byte[this.bufferSize];
/*     */       
/*     */       public void run()
/*     */       {
/*     */         try {
/*     */           int count;
/* 283 */           while ((SoundManager.this.state == 2) && ((count = ais.read(this.buffer, 0, this.buffer.length)) != -1)) {
/* 284 */             if (count > 0) {
/* 285 */               line.write(this.buffer, 0, count);
/*     */             }
/*     */           }
/* 288 */           line.drain();
/* 289 */           line.close();
/* 290 */           SoundManager.this.setState(0);
/*     */         }
/*     */         catch (IOException e) {
/* 293 */           SoundManager.this.setState(0);
/*     */         }
/*     */       }
/* 296 */     };
/* 297 */     this.playThread = new Thread(runner);
/* 298 */     this.playThread.start();
/* 299 */     return true;
/*     */   }
/*     */   
/*     */   public boolean stopPlaying() throws Exception {
/* 303 */     if (this.state != 2) {
/* 304 */       logger.i("stopPlaying() FAILED", new Object[0]);
/* 305 */       return false;
/*     */     }
/*     */     
/* 308 */     setState(0);
/* 309 */     this.playThread.join();
/* 310 */     this.playThread = null;
/* 311 */     return true;
/*     */   }
/*     */   
/*     */   public void update(LineEvent e)
/*     */   {
/* 316 */     logger.i("[+] Event: %s", new Object[] { e });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\media\SoundManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */