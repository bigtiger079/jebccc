/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.custom.CTabItem;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DropZones
/*     */ {
/*  33 */   private static final ILogger logger = ;
/*     */   
/*     */   Display display;
/*     */   
/*     */   Control topLevelContainer;
/*     */   boolean includeDockingAreas;
/*     */   boolean includeSelfDockingAreas;
/*     */   CTabItem srcTab;
/*     */   CTabFolder srcFolder;
/*  42 */   List<DropZone> dropzones = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DropZones(Control topLevelContainer, CTabItem srcTab, boolean includeDockingAreas, boolean includeSelfDockingAreas)
/*     */   {
/*  53 */     this.display = topLevelContainer.getDisplay();
/*  54 */     this.topLevelContainer = topLevelContainer;
/*     */     
/*  56 */     this.includeDockingAreas = includeDockingAreas;
/*  57 */     this.includeSelfDockingAreas = includeSelfDockingAreas;
/*     */     
/*  59 */     this.srcTab = srcTab;
/*  60 */     this.srcFolder = (srcTab == null ? null : srcTab.getParent());
/*     */   }
/*     */   
/*     */   public Control getTopLevelContainer() {
/*  64 */     return this.topLevelContainer;
/*     */   }
/*     */   
/*     */   public List<DropZone> determine() {
/*  68 */     this.dropzones.clear();
/*  69 */     determineRecurse(this.topLevelContainer, 0);
/*  70 */     return this.dropzones;
/*     */   }
/*     */   
/*     */   private void determineRecurse(Control ctl, int depth) {
/*     */     CTabFolder folder;
/*     */     Set<Integer> avoidIndexes;
/*     */     int index;
/*  77 */     if (((ctl instanceof Folder)) && (ctl.isVisible())) {
/*  78 */       folder = ((Folder)ctl).getFolderWidget();
/*     */       
/*     */ 
/*  81 */       if (folder.getItemCount() == 0) {
/*  82 */         Rectangle client = folder.getClientArea();
/*  83 */         Rectangle r = this.display.map(folder, this.topLevelContainer, client);
/*  84 */         DropZone dropzone = new DropZone(this.topLevelContainer, r);
/*  85 */         dropzone.ctl = ctl;
/*  86 */         dropzone.index = 0;
/*  87 */         this.dropzones.add(dropzone);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  92 */         avoidIndexes = new HashSet();
/*  93 */         if (folder == this.srcFolder) {
/*  94 */           int srcIndex = Arrays.asList(this.srcFolder.getItems()).indexOf(this.srcTab);
/*  95 */           if (srcIndex >= 0) {
/*  96 */             avoidIndexes.add(Integer.valueOf(srcIndex));
/*  97 */             avoidIndexes.add(Integer.valueOf(srcIndex + 1));
/*     */           }
/*     */         }
/*     */         
/* 101 */         index = 0;
/*     */         
/* 103 */         if (!avoidIndexes.contains(Integer.valueOf(index))) {
/* 104 */           r = this.display.map(folder, this.topLevelContainer, new Rectangle(0, 0, 4, folder.getTabHeight()));
/* 105 */           dropzone = new DropZone(this.topLevelContainer, r);
/* 106 */           dropzone.ctl = ctl;
/* 107 */           dropzone.index = 0;
/* 108 */           this.dropzones.add(dropzone);
/*     */         }
/* 110 */         index++;
/*     */         
/* 112 */         Rectangle r = folder.getItems();DropZone dropzone = r.length; for (DropZone localDropZone1 = 0; localDropZone1 < dropzone; localDropZone1++) { CTabItem item = r[localDropZone1];
/* 113 */           if (!avoidIndexes.contains(Integer.valueOf(index))) {
/* 114 */             Rectangle b = item.getBounds();
/* 115 */             int x0 = b.x + b.width - 2;
/* 116 */             int width = 4;
/*     */             
/* 118 */             if (index == folder.getItemCount()) {
/* 119 */               Rectangle folderCA = folder.getClientArea();
/* 120 */               width = folderCA.x + folderCA.width - x0;
/*     */             }
/* 122 */             Rectangle r = this.display.map(folder, this.topLevelContainer, new Rectangle(x0, b.y, width, b.height));
/* 123 */             DropZone dropzone = new DropZone(this.topLevelContainer, r);
/* 124 */             dropzone.ctl = ctl;
/* 125 */             dropzone.index = index;
/* 126 */             this.dropzones.add(dropzone);
/*     */           }
/* 128 */           index++;
/*     */         }
/*     */         
/*     */ 
/* 132 */         if ((this.includeDockingAreas) && ((this.includeSelfDockingAreas) || (folder != this.srcFolder))) {
/* 133 */           Rectangle client = folder.getClientArea();
/*     */           
/* 135 */           int sqSpacing = 10;
/* 136 */           int minSqSize = 10;
/* 137 */           int min = 70;
/* 138 */           if ((client.width >= 70) && (client.height >= 70)) {
/* 139 */             int sqWidth = (client.width - 40) / 3;
/* 140 */             int sqHeight = (client.height - 40) / 3;
/*     */             
/* 142 */             Rectangle r = this.display.map(folder, this.topLevelContainer, new Rectangle(client.x + 20 + sqWidth, client.y + 10, sqWidth, sqHeight));
/*     */             
/* 144 */             DropZone dropzone = new DropZone(this.topLevelContainer, r);
/* 145 */             dropzone.ctl = ctl;
/* 146 */             dropzone.index = -1;
/* 147 */             this.dropzones.add(dropzone);
/*     */             
/* 149 */             r = this.display.map(folder, this.topLevelContainer, new Rectangle(client.x + 20 + sqWidth, client.y + 30 + 2 * sqHeight, sqWidth, sqHeight));
/*     */             
/* 151 */             dropzone = new DropZone(this.topLevelContainer, r);
/* 152 */             dropzone.ctl = ctl;
/* 153 */             dropzone.index = -2;
/* 154 */             this.dropzones.add(dropzone);
/*     */             
/* 156 */             r = this.display.map(folder, this.topLevelContainer, new Rectangle(client.x + 10, client.y + 20 + sqHeight, sqWidth, sqHeight));
/*     */             
/* 158 */             dropzone = new DropZone(this.topLevelContainer, r);
/* 159 */             dropzone.ctl = ctl;
/* 160 */             dropzone.index = -3;
/* 161 */             this.dropzones.add(dropzone);
/*     */             
/* 163 */             r = this.display.map(folder, this.topLevelContainer, new Rectangle(client.x + 30 + 2 * sqWidth, client.y + 20 + sqHeight, sqWidth, sqHeight));
/*     */             
/* 165 */             dropzone = new DropZone(this.topLevelContainer, r);
/* 166 */             dropzone.ctl = ctl;
/* 167 */             dropzone.index = -4;
/* 168 */             this.dropzones.add(dropzone);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 174 */     if ((ctl instanceof Composite)) {
/* 175 */       for (Control c : ((Composite)ctl).getChildren()) {
/* 176 */         determineRecurse(c, depth + 1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\DropZones.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */