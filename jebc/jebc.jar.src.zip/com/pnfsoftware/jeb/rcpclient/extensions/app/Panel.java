/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMElement;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPanel;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPanelElement;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.custom.SashForm;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Sash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Panel
/*     */   extends Composite
/*     */   implements IMPanel
/*     */ {
/*  40 */   private static final ILogger logger = GlobalLog.getLogger(Panel.class);
/*     */   
/*  42 */   private static int internalPanelCreationCount = 0;
/*     */   
/*     */ 
/*     */   int internalPanelId;
/*     */   
/*     */ 
/*     */   String elementId;
/*     */   
/*     */   private SashForm sashform;
/*     */   
/*     */ 
/*     */   public Panel(Composite parent, int style)
/*     */   {
/*  55 */     super(parent, 0);
/*  56 */     this.internalPanelId = (internalPanelCreationCount++);
/*     */     
/*  58 */     setLayout(new FillLayout());
/*  59 */     this.sashform = new SashForm(this, style);
/*  60 */     this.sashform.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/*  63 */         Panel.this.dispose();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SashForm getSashFormWidget()
/*     */   {
/*  74 */     return this.sashform;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  78 */     return this.sashform.getWeights().length == 0;
/*     */   }
/*     */   
/*     */   public Control[] getElements() {
/*  82 */     int cnt = this.sashform.getWeights().length;
/*  83 */     Control[] parts = new Control[cnt];
/*  84 */     int i = 0;
/*  85 */     for (Control child : this.sashform.getChildren())
/*     */     {
/*     */ 
/*     */ 
/*  89 */       if (!(child instanceof Sash)) {
/*  90 */         parts[(i++)] = child;
/*     */       }
/*     */     }
/*  93 */     if (i != parts.length) {
/*  94 */       throw new RuntimeException("The panel is missing an element");
/*     */     }
/*  96 */     if (i > 2) {
/*  97 */       throw new IllegalStateException("A panel should contain less than 2 elements");
/*     */     }
/*  99 */     return parts;
/*     */   }
/*     */   
/*     */   public int getElementIndex(Control elt) {
/* 103 */     if (elt.getParent() != this.sashform) {
/* 104 */       throw new RuntimeException("Element is not part of this panel");
/*     */     }
/* 106 */     int index = Arrays.asList(getElements()).indexOf(elt);
/* 107 */     if (index == -1) {
/* 108 */       throw new RuntimeException("Child not referenced by its parent!");
/*     */     }
/* 110 */     return index;
/*     */   }
/*     */   
/*     */   public List<Part> getParts() {
/* 114 */     List<Part> parts = new ArrayList();
/* 115 */     getParts(parts);
/* 116 */     return parts;
/*     */   }
/*     */   
/*     */   private void getParts(List<Part> parts) {
/* 120 */     for (Control c : getElements()) {
/* 121 */       if ((c instanceof Folder)) {
/* 122 */         parts.addAll(((Folder)c).getParts());
/*     */       }
/* 124 */       else if ((c instanceof Panel)) {
/* 125 */         ((Panel)c).getParts(parts);
/*     */       }
/*     */       else {
/* 128 */         throw new RuntimeException("Invalid element in panel");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int[] getWeights() {
/* 134 */     return this.sashform.getWeights();
/*     */   }
/*     */   
/*     */   public void setWeights(int[] weights) {
/* 138 */     this.sashform.setWeights(weights);
/*     */   }
/*     */   
/*     */   public void setOrientation(int orientation)
/*     */   {
/* 143 */     super.setOrientation(orientation);
/* 144 */     this.sashform.setOrientation(orientation);
/*     */   }
/*     */   
/*     */   Folder createFolder(int style, int tabStyle, boolean onEmptyCloseFolder) {
/* 148 */     return new Folder(this.sashform, style, tabStyle, true, onEmptyCloseFolder);
/*     */   }
/*     */   
/*     */   Panel createPanel(int style) {
/* 152 */     return new Panel(this.sashform, style);
/*     */   }
/*     */   
/*     */   public void setElementId(String elementId)
/*     */   {
/* 157 */     this.elementId = elementId;
/*     */   }
/*     */   
/*     */   public String getElementId()
/*     */   {
/* 162 */     return this.elementId;
/*     */   }
/*     */   
/*     */   public IMElement getParentElement()
/*     */   {
/* 167 */     Control p0 = getParent();
/* 168 */     if ((p0 instanceof Dock)) {
/* 169 */       return (Dock)p0;
/*     */     }
/* 171 */     if (((p0 instanceof SashForm)) && ((p0.getParent() instanceof Panel))) {
/* 172 */       return (Panel)p0.getParent();
/*     */     }
/* 174 */     throw new IllegalStateException("Illegal parent for Panel");
/*     */   }
/*     */   
/*     */   public List<IMPanelElement> getChildrenElements()
/*     */   {
/* 179 */     List<IMPanelElement> list = new ArrayList(2);
/* 180 */     for (Control elt : getElements()) {
/* 181 */       list.add((IMPanelElement)elt);
/*     */     }
/* 183 */     return list;
/*     */   }
/*     */   
/*     */   public IMPanelElement getFirstElement()
/*     */   {
/* 188 */     List<IMPanelElement> list = getChildrenElements();
/* 189 */     if (list.size() >= 1) {
/* 190 */       return (IMPanelElement)list.get(0);
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */   
/*     */   public IMPanelElement getSecondElement()
/*     */   {
/* 197 */     List<IMPanelElement> list = getChildrenElements();
/* 198 */     if (list.size() >= 2) {
/* 199 */       return (IMPanelElement)list.get(1);
/*     */     }
/* 201 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isVertical()
/*     */   {
/* 206 */     return this.sashform.getOrientation() == 512;
/*     */   }
/*     */   
/*     */   public int getSplitRatio()
/*     */   {
/* 211 */     int[] weights = this.sashform.getWeights();
/* 212 */     if (weights.length == 1) {
/* 213 */       return 100;
/*     */     }
/* 215 */     if (weights.length == 2) {
/* 216 */       return (int)(100.0D * (weights[0] / (weights[0] + weights[1])));
/*     */     }
/* 218 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */   public boolean setSplitRatio(int ratio)
/*     */   {
/* 223 */     int[] weights = this.sashform.getWeights();
/* 224 */     if (weights.length == 1) {
/* 225 */       return false;
/*     */     }
/* 227 */     if (weights.length == 2) {
/* 228 */       if ((ratio < 0) || (ratio > 100)) {
/* 229 */         return false;
/*     */       }
/* 231 */       weights[0] = (10 * ratio);
/* 232 */       weights[1] = (1000 - weights[0]);
/* 233 */       return true;
/*     */     }
/* 235 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 240 */     return String.format("Panel@%d", new Object[] { Integer.valueOf(this.internalPanelId) });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SashSelectionFilter
/*     */     implements Listener
/*     */   {
/*     */     int maxSizeAllowed;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public SashSelectionFilter(int maxSizeAllowed)
/*     */     {
/* 261 */       this.maxSizeAllowed = maxSizeAllowed;
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleEvent(Event event)
/*     */     {
/* 267 */       if (!(event.widget instanceof Sash)) {
/* 268 */         return;
/*     */       }
/* 270 */       Sash s = (Sash)event.widget;
/* 271 */       Rectangle bounds = s.getBounds();
/* 272 */       if ((bounds.x == event.x) && (bounds.y == event.y)) {
/* 273 */         return;
/*     */       }
/* 275 */       if (!(s.getParent() instanceof SashForm)) {
/* 276 */         return;
/*     */       }
/* 278 */       SashForm sf = (SashForm)s.getParent();
/* 279 */       if (sf.getChildren().length != 3)
/*     */       {
/* 281 */         return;
/*     */       }
/*     */       
/*     */ 
/* 285 */       boolean horizontal = (sf.getStyle() & 0x100) != 0;
/* 286 */       int maxSize = horizontal ? sf.getSize().x : sf.getSize().y;
/*     */       
/*     */ 
/* 289 */       if (this.maxSizeAllowed * 2 + (horizontal ? s.getSize().x : s.getSize().y) > maxSize)
/*     */       {
/* 291 */         event.x = bounds.x;
/* 292 */         event.y = bounds.y;
/* 293 */         return;
/*     */       }
/*     */       
/* 296 */       int eventPosition = horizontal ? event.x : event.y;
/* 297 */       int eventEndPosition = horizontal ? event.x + bounds.width : event.y + bounds.height;
/* 298 */       int sashPosition = horizontal ? bounds.x : bounds.y;
/* 299 */       int sashEndPosition = horizontal ? bounds.x + bounds.width : bounds.y + bounds.height;
/*     */       
/*     */ 
/* 302 */       if (eventPosition < this.maxSizeAllowed)
/*     */       {
/* 304 */         if (sashPosition < this.maxSizeAllowed) {
/* 305 */           if (sashPosition >= eventPosition)
/*     */           {
/*     */ 
/*     */ 
/* 309 */             updateEvent(horizontal, event, sashPosition);
/*     */           }
/* 311 */           return;
/*     */         }
/* 313 */         updateEvent(horizontal, event, this.maxSizeAllowed);
/*     */ 
/*     */       }
/* 316 */       else if (maxSize - eventEndPosition < this.maxSizeAllowed)
/*     */       {
/* 318 */         if (maxSize - sashEndPosition < this.maxSizeAllowed) {
/* 319 */           if (sashPosition <= eventPosition)
/*     */           {
/*     */ 
/*     */ 
/* 323 */             updateEvent(horizontal, event, sashPosition);
/*     */           }
/* 325 */           return;
/*     */         }
/* 327 */         updateEvent(horizontal, event, maxSize - this.maxSizeAllowed);
/*     */       }
/*     */     }
/*     */     
/*     */     private void updateEvent(boolean horizontal, Event event, int sashPosition) {
/* 332 */       if (horizontal) {
/* 333 */         event.x = sashPosition;
/*     */       }
/*     */       else {
/* 336 */         event.y = sashPosition;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\Panel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */