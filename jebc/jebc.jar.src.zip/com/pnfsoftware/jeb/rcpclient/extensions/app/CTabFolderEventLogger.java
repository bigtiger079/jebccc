/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.custom.CTabFolder2Listener;
/*    */ import org.eclipse.swt.custom.CTabFolderEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CTabFolderEventLogger
/*    */   implements CTabFolder2Listener
/*    */ {
/* 22 */   private static final ILogger logger = GlobalLog.getLogger(CTabFolderEventLogger.class);
/*    */   
/*    */   public void close(CTabFolderEvent event)
/*    */   {
/* 26 */     logger.i("Close: %s", new Object[] { event });
/*    */   }
/*    */   
/*    */   public void minimize(CTabFolderEvent event)
/*    */   {
/* 31 */     logger.i("Min: %s", new Object[] { event });
/*    */   }
/*    */   
/*    */   public void maximize(CTabFolderEvent event)
/*    */   {
/* 36 */     logger.i("Max: %s", new Object[] { event });
/*    */   }
/*    */   
/*    */   public void restore(CTabFolderEvent event)
/*    */   {
/* 41 */     logger.i("Restore: %s", new Object[] { event });
/*    */   }
/*    */   
/*    */   public void showList(CTabFolderEvent event)
/*    */   {
/* 46 */     logger.i("List: %s", new Object[] { event });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\CTabFolderEventLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */