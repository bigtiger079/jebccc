/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app.model;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.App;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.Dock;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.Folder;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.Part;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.PartUtil;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppService
/*     */   implements IAppService
/*     */ {
/*  34 */   private static final ILogger logger = GlobalLog.getLogger(AppService.class);
/*     */   
/*     */ 
/*     */   App app;
/*     */   
/*     */ 
/*     */ 
/*     */   public AppService(App app)
/*     */   {
/*  43 */     if (app == null) {
/*  44 */       throw new NullPointerException();
/*     */     }
/*  46 */     this.app = app;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IMElement> List<T> findElements(IMElement root, String id, Class<T> type, Collection<String> tags, int flags)
/*     */   {
/*  52 */     if (id != null) {
/*  53 */       throw new RuntimeException("Not supported yet");
/*     */     }
/*  55 */     if ((tags != null) && (!tags.isEmpty())) {
/*  56 */       throw new RuntimeException("Not supported yet");
/*     */     }
/*  58 */     List<T> out = new ArrayList();
/*  59 */     if (root == null) {
/*  60 */       for (Shell s : this.app.getDisplay().getShells()) {
/*  61 */         for (Control c : s.getChildren())
/*     */         {
/*  63 */           if ((c instanceof Dock)) {
/*  64 */             findElementsRecurse((Dock)c, id, type, tags, flags, out);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */     } else {
/*  70 */       findElementsRecurse(root, id, type, tags, flags, out);
/*     */     }
/*  72 */     return out;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IMElement> void findElementsRecurse(IMElement elt, String id, Class<T> type, Collection<String> tags, int flags, List<T> out)
/*     */   {
/*  78 */     boolean include = true;
/*  79 */     if ((type != null) && 
/*  80 */       (!type.isAssignableFrom(elt.getClass()))) {
/*  81 */       include = false;
/*     */     }
/*     */     
/*     */ 
/*  85 */     if (include) {
/*  86 */       out.add(elt);
/*     */     }
/*  88 */     for (IMElement c : elt.getChildrenElements()) {
/*  89 */       findElementsRecurse(c, id, type, tags, flags, out);
/*     */     }
/*     */   }
/*     */   
/*     */   public IMDock createDock()
/*     */   {
/*  95 */     return this.app.getDock().createAdditionalDock();
/*     */   }
/*     */   
/*     */   public IMDock createDock(boolean onTop, Rectangle initialBounds)
/*     */   {
/* 100 */     IMDock dock2 = this.app.getDock().createAdditionalDock(onTop, 16, initialBounds);
/* 101 */     return dock2;
/*     */   }
/*     */   
/*     */   public IMPart createPart(IMFolder folder, IMPartManager partManager)
/*     */   {
/* 106 */     if (folder == null) {
/* 107 */       folder = (IMFolder)this.app.getDock().getFolders().get(0);
/*     */     }
/* 109 */     IMPart part = folder.addPart();
/* 110 */     if (partManager != null) {
/* 111 */       part.setManager(partManager);
/*     */     }
/* 113 */     return part;
/*     */   }
/*     */   
/*     */   public void activate(IMPart part)
/*     */   {
/* 118 */     activate(part, false);
/*     */   }
/*     */   
/*     */   public void activate(IMPart part, boolean focus)
/*     */   {
/* 123 */     if (focus) {
/* 124 */       focusPart(part);
/*     */     }
/*     */     else {
/* 127 */       showPart(part);
/*     */     }
/*     */   }
/*     */   
/*     */   public void hidePart(IMPart part)
/*     */   {
/* 133 */     Folder folder = (Folder)part.getParentElement();
/* 134 */     folder.hidePart((Part)part);
/*     */   }
/*     */   
/*     */   public void unhidePart(IMPart part)
/*     */   {
/* 139 */     Folder folder = (Folder)part.getParentElement();
/* 140 */     folder.unhidePart((Part)part);
/*     */   }
/*     */   
/*     */   public void clearPart(IMPart part)
/*     */   {
/* 145 */     Folder folder = (Folder)part.getParentElement();
/* 146 */     folder.clearPart((Part)part);
/*     */   }
/*     */   
/*     */   public void showPart(IMPart part)
/*     */   {
/* 151 */     Folder folder = (Folder)part.getParentElement();
/* 152 */     folder.showPart((Part)part);
/*     */   }
/*     */   
/*     */   public void focusPart(IMPart part)
/*     */   {
/* 157 */     Folder folder = (Folder)part.getParentElement();
/* 158 */     folder.focusPart((Part)part);
/*     */   }
/*     */   
/*     */   public boolean isPartVisible(IMPart part)
/*     */   {
/* 163 */     return !((Part)part).isHidden();
/*     */   }
/*     */   
/*     */   public IMPart getActivePart()
/*     */   {
/* 168 */     Control ctl = this.app.getDisplay().getFocusControl();
/*     */     
/* 170 */     return PartUtil.getPart(ctl);
/*     */   }
/*     */   
/*     */   public Collection<IMPart> getParts()
/*     */   {
/* 175 */     List<IMPart> r = new ArrayList();
/* 176 */     for (Dock dock : Dock.findDocks(this.app.getDisplay())) {
/* 177 */       for (Folder folder : dock.getFolders()) {
/* 178 */         for (Part part : folder.getParts()) {
/* 179 */           r.add(part);
/*     */         }
/*     */       }
/*     */     }
/* 183 */     return r;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\model\AppService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */