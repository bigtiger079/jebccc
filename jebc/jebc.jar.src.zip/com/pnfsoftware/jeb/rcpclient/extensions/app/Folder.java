/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMElement;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMFolder;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPartManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.CTabFolderUtils;
/*     */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.SWTException;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.custom.CTabFolder2Adapter;
/*     */ import org.eclipse.swt.custom.CTabFolderEvent;
/*     */ import org.eclipse.swt.custom.CTabItem;
/*     */ import org.eclipse.swt.custom.SashForm;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.FocusAdapter;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Folder
/*     */   extends Composite
/*     */   implements IMFolder
/*     */ {
/*  64 */   private static final ILogger logger = GlobalLog.getLogger(Folder.class);
/*     */   
/*  66 */   private static int internalFolderCreationCount = 0;
/*     */   
/*     */   int internalFolderId;
/*     */   
/*     */   String elementId;
/*     */   
/*     */   int defaultTabStyle;
/*     */   boolean insideDock;
/*     */   boolean closeOnEmpty;
/*     */   private CTabFolder folderWidget;
/*  76 */   List<IFolderListener> folderListeners = new ArrayList();
/*     */   
/*     */   GhostWidget g;
/*     */   
/*     */   CTabItem draggedTab;
/*     */   CTabItem previouslySelectedTab;
/*     */   CTabItem selectedTab;
/*  83 */   List<Part> parts = new ArrayList();
/*     */   
/*     */   public static final int HIDDEN = 0;
/*     */   public static final int VISIBLE = 1;
/*     */   public static final int SHOWN = 2;
/*     */   public static final int FOCUSED = 3;
/*     */   
/*     */   public Folder(Composite parent, int style, int tabStyle)
/*     */   {
/*  92 */     this(parent, style, tabStyle, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Folder(Composite parent, int style, int tabStyle, boolean insideDock, boolean closeOnEmpty)
/*     */   {
/* 109 */     super(parent, 0);
/* 110 */     this.internalFolderId = (internalFolderCreationCount++);
/*     */     
/* 112 */     this.defaultTabStyle = tabStyle;
/* 113 */     this.insideDock = insideDock;
/* 114 */     this.closeOnEmpty = closeOnEmpty;
/*     */     
/* 116 */     setLayout(new FillLayout());
/* 117 */     this.folderWidget = new CTabFolder(this, style);
/*     */     
/* 119 */     CTabFolderUtils.setCTabFolderHeight(this.folderWidget, (int)(this.folderWidget.getTabHeight() * 1.2D));
/*     */     
/*     */ 
/*     */ 
/* 123 */     this.folderWidget.addCTabFolder2Listener(new CTabFolder2Adapter()
/*     */     {
/*     */       public void close(CTabFolderEvent event) {
/* 126 */         CTabItem tab = (CTabItem)event.item;
/* 127 */         Part part = Folder.this.getPartByTab(tab);
/* 128 */         Folder.this.hidePart(part);
/* 129 */         event.doit = false;
/*     */       }
/*     */       
/*     */ 
/* 133 */     });
/* 134 */     this.folderWidget.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 137 */         Folder.this.previouslySelectedTab = Folder.this.selectedTab;
/*     */         
/* 139 */         CTabItem tab = Folder.this.folderWidget.getSelection();
/* 140 */         Folder.this.selectedTab = tab;
/* 141 */         if (tab != null) {
/* 142 */           Part part = Folder.this.getPartByTab(tab);
/* 143 */           part.getControl().setFocus();
/* 144 */           if (part.getManager() != null) {
/* 145 */             part.getManager().setFocus();
/*     */           }
/* 147 */           Folder.this.notifyPartSelected(Folder.this.getPartByTab(tab));
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 152 */     });
/* 153 */     this.folderWidget.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusGained(FocusEvent e)
/*     */       {
/* 157 */         Folder.logger.i("FocusGained: %s@%d", new Object[] { e.widget, Integer.valueOf(e.widget.hashCode()) });
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void focusLost(FocusEvent e)
/*     */       {
/* 170 */         Folder.logger.i("FocusLost: %s@%d", new Object[] { e.widget, Integer.valueOf(e.widget.hashCode()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */     });
/* 188 */     this.folderWidget.addListener(29, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 191 */         CTabItem item = Folder.this.folderWidget.getSelection();
/* 192 */         if (item == null) {
/* 193 */           return;
/*     */         }
/*     */         
/* 196 */         Display display = Folder.this.getDisplay();
/*     */         Control topLevelContainer;
/*     */         List<DropZone> list;
/*     */         Control topLevelContainer;
/* 200 */         if (!Folder.this.isInsideDock()) {
/* 201 */           List<DropZone> list = new DropZones(Folder.this, item, false, false).determine();
/* 202 */           topLevelContainer = Folder.this;
/*     */         }
/*     */         else {
/* 205 */           Dock dock = Folder.this.getDock();
/*     */           
/*     */ 
/* 208 */           boolean includeSelfDockingAreas = (!dock.onEmptyCloseFolder) || (item.getParent().getItemCount() != 1);
/* 209 */           list = new DropZones(dock, item, true, includeSelfDockingAreas).determine();
/* 210 */           topLevelContainer = dock;
/*     */           
/*     */ 
/* 213 */           if (dock.allowForeignDocking) {
/* 214 */             for (Dock dock2 : Dock.findDocks(display))
/* 215 */               if (dock2 != dock)
/*     */               {
/*     */ 
/* 218 */                 List<DropZone> list2 = new DropZones(dock2, item, true, true).determine();
/* 219 */                 list.addAll(list2);
/*     */               }
/* 221 */             topLevelContainer = null;
/*     */           }
/*     */         }
/*     */         
/* 225 */         if (list.isEmpty()) {
/* 226 */           return;
/*     */         }
/*     */         
/* 229 */         Folder.this.folderWidget.forceFocus();
/* 230 */         Folder.this.draggedTab = Folder.this.folderWidget.getSelection();
/*     */         
/* 232 */         Folder.this.g = new GhostWidget(topLevelContainer, display);
/* 233 */         Folder.this.g.registerDropZones(list);
/*     */         
/* 235 */         Rectangle r = Folder.this.folderWidget.getSelection().getBounds();
/* 236 */         Folder.this.g.setRectangle(event.display.map(Folder.this.folderWidget, Folder.this.g.getTopLevelContainer(), r));
/* 237 */         Folder.this.g.setPositionDelta(new Point(event.x - r.x, event.y - r.y));
/*     */       }
/* 239 */     });
/* 240 */     this.folderWidget.addListener(5, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 243 */         if (Folder.this.g != null) {
/* 244 */           Point p = event.display.map(Folder.this.folderWidget, Folder.this.g.getTopLevelContainer(), event.x, event.y);
/* 245 */           Folder.this.g.updatePosition(p);
/*     */         }
/*     */       }
/* 248 */     });
/* 249 */     this.folderWidget.addListener(4, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 252 */         if (Folder.this.g != null)
/*     */         {
/*     */           try
/*     */           {
/* 256 */             DropZone dropzone = Folder.this.g.getActiveDropZone();
/* 257 */             Dock dock = Folder.this.getDock();
/* 258 */             Folder srcFolder = Folder.tabToFolder(Folder.this.draggedTab);
/* 259 */             Folder dstFolder = null;
/*     */             
/* 261 */             if (dropzone != null) {
/* 262 */               dstFolder = (Folder)dropzone.ctl;
/* 263 */               Dock dstDock = dstFolder.getDock();
/*     */               
/*     */ 
/* 266 */               if (dropzone.index >= 0) {
/* 267 */                 Folder.this.moveTab(Folder.this.draggedTab, dstFolder.folderWidget, dropzone.index, true);
/*     */               }
/*     */               else
/*     */               {
/* 271 */                 Folder folder2 = dstDock.splitFolder(dstFolder, dropzone.index);
/* 272 */                 Folder.this.moveTab(Folder.this.draggedTab, folder2.folderWidget, 0, true);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 277 */             else if ((dock != null) && (dock.allowForeignDocking))
/*     */             {
/* 279 */               Point p = event.display.map(Folder.this.folderWidget, null, event.x, event.y);
/* 280 */               if (!Folder.this.g.inCandidateArea(p)) {
/* 281 */                 Dock dstDock = dock.createAdditionalDock();
/* 282 */                 dstFolder = dstDock.getInitialFolder();
/* 283 */                 Folder.this.moveTab(Folder.this.draggedTab, dstFolder.folderWidget, 0, true);
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 288 */             if ((dock != null) && (dstFolder != null)) {
/* 289 */               Folder.this.updateFolder(srcFolder);
/*     */ 
/*     */ 
/*     */             }
/* 293 */             else if ((Folder.this.previouslySelectedTab != null) && (!Folder.this.previouslySelectedTab.isDisposed())) {
/* 294 */               Folder.this.focusPart(Folder.this.getPartByTab(Folder.this.previouslySelectedTab));
/* 295 */               Folder.this.selectedTab = Folder.this.previouslySelectedTab;
/*     */             }
/*     */           }
/*     */           finally
/*     */           {
/* 300 */             Folder.this.g.dispose();
/* 301 */             Folder.this.g = null;
/* 302 */             Folder.this.draggedTab = null;
/*     */           }
/*     */           
/*     */         }
/* 306 */         else if (event.button == 2)
/*     */         {
/* 308 */           CTabItem item = Folder.this.folderWidget.getItem(new Point(event.x, event.y));
/* 309 */           if (item == null) {
/* 310 */             return;
/*     */           }
/* 312 */           Part part = Folder.this.getPartByTab(item);
/* 313 */           if ((!part.isHidden()) && (part.isHideable())) {
/* 314 */             if (part.isCloseOnHide()) {
/* 315 */               Folder.this.removePart(part, true);
/*     */             }
/*     */             else {
/* 318 */               part.hide();
/* 319 */               Folder.this.notifyPartHidden(part);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/* 325 */     });
/* 326 */     this.folderWidget.addListener(16, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 329 */         if (Folder.this.g != null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 336 */           Folder.this.g.dispose();
/*     */         }
/*     */         
/*     */       }
/* 340 */     });
/* 341 */     this.folderWidget.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e) {
/* 344 */         Folder.logger.i("KeyPressed: %s", new Object[] { e });
/* 345 */         if ((Folder.this.g != null) && (e.keyCode == 27)) {
/* 346 */           Folder.this.g.dispose();
/* 347 */           Folder.this.g = null;
/* 348 */           Folder.this.draggedTab = null;
/*     */         }
/*     */         
/*     */       }
/* 352 */     });
/* 353 */     this.folderWidget.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/* 356 */         Folder.this.dispose();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInsideDock()
/*     */   {
/* 367 */     return this.insideDock;
/*     */   }
/*     */   
/*     */   public Dock getDock() {
/* 371 */     if (!this.insideDock) {
/* 372 */       return null;
/*     */     }
/*     */     
/* 375 */     Control ctl = this;
/* 376 */     while (!(ctl instanceof Dock)) {
/* 377 */       ctl = ctl.getParent();
/* 378 */       if (ctl == null) {
/* 379 */         throw new RuntimeException("This folder should be inside a dock");
/*     */       }
/*     */     }
/* 382 */     return (Dock)ctl;
/*     */   }
/*     */   
/*     */   public boolean isCloseOnEmpty()
/*     */   {
/* 387 */     return this.closeOnEmpty;
/*     */   }
/*     */   
/*     */   public void setCloseOnEmpty(boolean closeOnEmpty)
/*     */   {
/* 392 */     this.closeOnEmpty = closeOnEmpty;
/*     */   }
/*     */   
/*     */   CTabFolder getFolderWidget() {
/* 396 */     return this.folderWidget;
/*     */   }
/*     */   
/*     */   public Panel getParentPanel() {
/* 400 */     if (!(getParent() instanceof SashForm)) {
/* 401 */       throw new IllegalStateException("Folder in unexpected location");
/*     */     }
/* 403 */     Control ctl = getParent().getParent();
/* 404 */     if (!(ctl instanceof Panel)) {
/* 405 */       throw new IllegalStateException("Folder not in a panel");
/*     */     }
/* 407 */     return (Panel)ctl;
/*     */   }
/*     */   
/*     */   private Part getPartByTab(CTabItem tab) {
/* 411 */     for (Part part : this.parts) {
/* 412 */       if (part.tab == tab) {
/* 413 */         return part;
/*     */       }
/*     */     }
/* 416 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */   public Part getPartByControl(Control control) {
/* 420 */     for (Part part : this.parts) {
/* 421 */       if (part.getControl() == control) {
/* 422 */         return part;
/*     */       }
/*     */     }
/* 425 */     return null;
/*     */   }
/*     */   
/*     */   static Folder widgetToFolder(CTabFolder folderWidget) {
/* 429 */     return (Folder)folderWidget.getParent();
/*     */   }
/*     */   
/*     */   static Folder tabToFolder(CTabItem tab) {
/* 433 */     return (Folder)tab.getParent().getParent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void moveTab(CTabItem srcTab, CTabFolder dstFolderWidget, int dstIndex, boolean notify)
/*     */   {
/* 445 */     Part part = getPartByTab(srcTab);
/* 446 */     CTabFolder srcFolderWidget = srcTab.getParent();
/* 447 */     int srcIndex = Arrays.asList(srcFolderWidget.getItems()).indexOf(srcTab);
/* 448 */     Folder srcFolder = (Folder)srcFolderWidget.getParent();
/* 449 */     Folder dstFolder = (Folder)dstFolderWidget.getParent();
/*     */     
/*     */ 
/* 452 */     if ((srcFolderWidget == dstFolderWidget) && (dstIndex > srcIndex)) {
/* 453 */       dstIndex--;
/*     */     }
/*     */     
/* 456 */     part.hide();
/* 457 */     this.parts.remove(part);
/*     */     
/* 459 */     CTabItem newTab = new CTabItem(dstFolderWidget, this.defaultTabStyle, dstIndex);
/* 460 */     dstFolder.parts.add(dstIndex, part);
/* 461 */     part.restoreInto(newTab);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 472 */     dstFolderWidget.showItem(newTab);
/* 473 */     dstFolderWidget.setSelection(newTab);
/*     */     
/*     */ 
/*     */ 
/* 477 */     if (notify) {
/* 478 */       notifyPartMoved(srcFolder, part);
/*     */     }
/*     */   }
/*     */   
/*     */   void restoreTab(Part part, CTabFolder dstFolderWidget) {
/* 483 */     Folder dstFolder = (Folder)dstFolderWidget.getParent();
/*     */     
/* 485 */     part.hide();
/* 486 */     this.parts.remove(part);
/*     */     
/*     */ 
/* 489 */     CTabItem newTab = new CTabItem(dstFolderWidget, this.defaultTabStyle);
/* 490 */     dstFolder.parts.add(part);
/* 491 */     part.restoreInto(newTab);
/*     */     
/* 493 */     dstFolderWidget.showItem(newTab);
/* 494 */     dstFolderWidget.setSelection(newTab);
/*     */   }
/*     */   
/*     */ 
/*     */   private void updateFolder(Folder srcFolder)
/*     */   {
/* 500 */     Dock dock = srcFolder.getDock();
/* 501 */     if ((dock != null) && (srcFolder.closeOnEmpty) && (srcFolder.getPartsCount() == 0)) {
/* 502 */       dock.notifyFolderRemoving(srcFolder);
/* 503 */       Panel panel = srcFolder.getParentPanel();
/* 504 */       srcFolder.dispose();
/*     */       
/* 506 */       if (panel.isEmpty()) {
/* 507 */         if ((panel.getParent() instanceof Dock)) {
/* 508 */           Shell sh = (Shell)panel.getParent().getParent();
/* 509 */           sh.dispose();
/* 510 */           return;
/*     */         }
/*     */         
/* 513 */         Panel panelParent = (Panel)panel.getParent().getParent();
/* 514 */         panel.dispose();
/* 515 */         panel = panelParent;
/*     */       }
/*     */       
/* 518 */       panel.layout(true, true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addFolderListener(IFolderListener listener) {
/* 523 */     this.folderListeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeFolderListener(IFolderListener listener) {
/* 527 */     this.folderListeners.remove(listener);
/*     */   }
/*     */   
/*     */   void notifyPartSelected(Part part) {
/* 531 */     for (IFolderListener listener : this.folderListeners) {
/* 532 */       listener.partSelected(part);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyPartAdded(Part part) {
/* 537 */     for (IFolderListener listener : this.folderListeners) {
/* 538 */       listener.partAdded(part);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyPartRemoved(Part part) {
/* 543 */     for (IFolderListener listener : this.folderListeners) {
/* 544 */       listener.partRemoved(part);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyPartMoved(Folder src, Part part) {
/* 549 */     for (IFolderListener listener : this.folderListeners) {
/* 550 */       listener.partMoved(src, part);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyPartHidden(Part part) {
/* 555 */     for (IFolderListener listener : this.folderListeners) {
/* 556 */       listener.partHidden(part);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyPartVisible(Part part) {
/* 561 */     for (IFolderListener listener : this.folderListeners) {
/* 562 */       listener.partVisible(part);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Part addPart()
/*     */   {
/* 589 */     return addPart(true);
/*     */   }
/*     */   
/*     */   Part addPart(boolean notify) {
/* 593 */     return addPart(this.folderWidget.getItemCount(), notify);
/*     */   }
/*     */   
/*     */   public Part addPart(int index)
/*     */   {
/* 598 */     return addPart(index, true);
/*     */   }
/*     */   
/*     */   Part addPart(int index, boolean notify) {
/* 602 */     if ((index < 0) || (index > this.parts.size())) {
/* 603 */       index = this.parts.size();
/*     */     }
/* 605 */     Part part = new Part(this);
/* 606 */     this.parts.add(part);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 616 */     if (notify) {
/* 617 */       notifyPartAdded(part);
/*     */     }
/* 619 */     return part;
/*     */   }
/*     */   
/*     */   public void hidePart(Part part) {
/* 623 */     setPartVisibility(part, 0);
/*     */   }
/*     */   
/*     */   public void unhidePart(Part part) {
/* 627 */     setPartVisibility(part, 1);
/*     */   }
/*     */   
/*     */   public void showPart(Part part) {
/* 631 */     setPartVisibility(part, 2);
/*     */   }
/*     */   
/*     */   public void focusPart(Part part) {
/* 635 */     setPartVisibility(part, 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPartVisibility(Part part, int action)
/*     */   {
/* 644 */     setPartVisibility(part, action, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPartVisibility(Part part, int action, boolean notify)
/*     */   {
/* 654 */     if ((action < 0) || (action > 3)) {
/* 655 */       throw new IllegalArgumentException();
/*     */     }
/* 657 */     int index = this.parts.indexOf(part);
/* 658 */     if ((index < 0) || (index > this.folderWidget.getItemCount())) {
/* 659 */       index = this.folderWidget.getItemCount();
/*     */     }
/* 661 */     if (action == 0) {
/* 662 */       if (!part.isHidden()) {
/* 663 */         if (part.isCloseOnHide()) {
/* 664 */           removePart(part, notify);
/*     */         }
/*     */         else {
/* 667 */           part.hide();
/* 668 */           if (notify) {
/* 669 */             notifyPartHidden(part);
/*     */           }
/*     */         }
/*     */       }
/* 673 */       return;
/*     */     }
/* 675 */     if ((action >= 1) && 
/* 676 */       (part.isHidden())) {
/* 677 */       CTabItem tab = new CTabItem(this.folderWidget, this.defaultTabStyle, index);
/* 678 */       part.restoreInto(tab);
/* 679 */       if (notify) {
/* 680 */         notifyPartVisible(part);
/*     */       }
/*     */     }
/*     */     
/* 684 */     if (action >= 2) {
/* 685 */       IMPartManager partManager = part.getManager();
/* 686 */       if ((part.state == 0) && (partManager != null)) {
/* 687 */         Composite container = part.getContainerWidget();
/* 688 */         partManager.createView(container, part);
/* 689 */         container.layout();
/* 690 */         part.state = 1;
/*     */       }
/* 692 */       this.folderWidget.setSelection(part.tab);
/*     */     }
/* 694 */     if (action >= 3) {
/* 695 */       this.folderWidget.setSelection(part.tab);
/* 696 */       part.tab.getControl().setFocus();
/* 697 */       if (part.getManager() != null) {
/* 698 */         part.getManager().setFocus();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getPartVisibility(Part part) {
/* 704 */     int index = this.parts.indexOf(part);
/* 705 */     if ((index < 0) || (index > this.folderWidget.getItemCount())) {
/* 706 */       index = this.folderWidget.getItemCount();
/*     */     }
/* 708 */     if (part.isHidden()) {
/* 709 */       return 0;
/*     */     }
/* 711 */     if (this.folderWidget.getSelection() != part.tab) {
/* 712 */       return 1;
/*     */     }
/* 714 */     if (!hasFocus(part.getContainerWidget(), false)) {
/* 715 */       return 2;
/*     */     }
/* 717 */     return 3;
/*     */   }
/*     */   
/*     */   public static boolean hasFocus(Control ctl, boolean direct)
/*     */   {
/* 722 */     if (ctl == null) {
/* 723 */       return false;
/*     */     }
/* 725 */     Control c = ctl.getDisplay().getFocusControl();
/* 726 */     if (c == ctl) {
/* 727 */       return true;
/*     */     }
/* 729 */     if (direct) {
/* 730 */       return false;
/*     */     }
/* 732 */     while (c != null) {
/* 733 */       c = c.getParent();
/* 734 */       if (c == ctl) {
/* 735 */         return true;
/*     */       }
/* 737 */       if (c == null) {
/* 738 */         return false;
/*     */       }
/*     */     }
/* 741 */     return false;
/*     */   }
/*     */   
/*     */   public void clearPart(Part part) {
/* 745 */     if (part.state == 0) {
/* 746 */       return;
/*     */     }
/*     */     
/* 749 */     if (part.getManager() != null) {
/* 750 */       part.getManager().deleteView();
/*     */     }
/*     */     
/* 753 */     for (Control child : part.getContainerWidget().getChildren()) {
/* 754 */       if (!child.isDisposed()) {
/* 755 */         child.dispose();
/*     */       }
/*     */     }
/* 758 */     part.getContainerWidget().layout(true, true);
/*     */     
/* 760 */     part.state = 0;
/*     */   }
/*     */   
/*     */   public void removePart(Part part) {
/* 764 */     removePart(part, true);
/*     */   }
/*     */   
/*     */   void removePart(Part part, boolean notify) {
/* 768 */     if (!part.isCloseOnHide()) {
/* 769 */       throw new IllegalArgumentException("Cannot close part");
/*     */     }
/* 771 */     if (this.parts.indexOf(part) == -1) {
/* 772 */       throw new IllegalArgumentException("Invalid part");
/*     */     }
/* 774 */     part.hide();
/* 775 */     this.parts.remove(part);
/* 776 */     clearPart(part);
/* 777 */     if (notify) {
/* 778 */       notifyPartRemoved(part);
/*     */     }
/* 780 */     Folder folder = (Folder)part.getParentElement();
/* 781 */     if (folder != null) {
/* 782 */       updateFolder(folder);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 788 */     return String.format("Folder@%d", new Object[] { Integer.valueOf(this.internalFolderId) });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setElementId(String elementId)
/*     */   {
/* 795 */     this.elementId = elementId;
/*     */   }
/*     */   
/*     */   public String getElementId()
/*     */   {
/* 800 */     return this.elementId;
/*     */   }
/*     */   
/*     */   public IMElement getParentElement()
/*     */   {
/* 805 */     return getParentPanel();
/*     */   }
/*     */   
/*     */   public List<? extends IMElement> getChildrenElements()
/*     */   {
/* 810 */     return this.parts;
/*     */   }
/*     */   
/*     */   public List<Part> getParts()
/*     */   {
/* 815 */     return Collections.unmodifiableList(this.parts);
/*     */   }
/*     */   
/*     */   public int getPartsCount()
/*     */   {
/* 820 */     return this.parts.size();
/*     */   }
/*     */   
/*     */   public int getVisiblePartsCount() {
/* 824 */     int cnt = 0;
/* 825 */     for (Part part : this.parts) {
/* 826 */       if (!part.isHidden()) {
/* 827 */         cnt++;
/*     */       }
/*     */     }
/* 830 */     if (cnt != this.folderWidget.getItemCount())
/*     */     {
/* 832 */       throw new IllegalStateException(String.format("Unexpected count of visible parts: %d, %d", new Object[] {Integer.valueOf(cnt), Integer.valueOf(this.folderWidget.getItemCount()) }));
/*     */     }
/* 834 */     return cnt;
/*     */   }
/*     */   
/*     */   public int getPanelShare() {
/* 838 */     Panel panel = getParentPanel();
/* 839 */     int ratio = panel.getSplitRatio();
/* 840 */     if (ratio == 100) {
/* 841 */       return 100;
/*     */     }
/* 843 */     int i = panel.getChildrenElements().indexOf(this);
/* 844 */     if (i == 0) {
/* 845 */       return ratio;
/*     */     }
/* 847 */     return 100 - ratio;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initPreset(int start, int cnt, final int autoRefreshPeriodMs)
/*     */   {
/* 859 */     for (int i = start; i < start + cnt; i++) {
/* 860 */       Part part = addPart(false);
/* 861 */       part.setLabel("Item " + i);
/*     */       
/* 863 */       final StyledText text = new StyledText(part.getContainerWidget(), 0);
/* 864 */       text.setText("Content for Item " + i);
/*     */       
/* 866 */       showPart(part);
/*     */       
/* 868 */       if (autoRefreshPeriodMs > 0) {
/* 869 */         ThreadUtil.start(new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/*     */               for (;;) {
/* 874 */                 Folder.this.getDisplay().asyncExec(new Runnable()
/*     */                 {
/*     */                   public void run() {
/* 877 */                     Folder.10.this.val$text.setText("Nanotime: " + System.nanoTime());
/*     */                   }
/* 879 */                 });
/* 880 */                 Thread.sleep(autoRefreshPeriodMs);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 890 */               return;
/*     */             }
/*     */             catch (InterruptedException e) {}catch (SWTException e) {}
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\Folder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */