/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.base.Throwables;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.jface.action.MenuManager;
/*     */ import org.eclipse.jface.action.StatusLineManager;
/*     */ import org.eclipse.jface.action.ToolBarManager;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.ShellAdapter;
/*     */ import org.eclipse.swt.events.ShellEvent;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.FormAttachment;
/*     */ import org.eclipse.swt.layout.FormData;
/*     */ import org.eclipse.swt.layout.FormLayout;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Menu;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.ToolBar;
/*     */ import org.eclipse.swt.widgets.ToolItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class App
/*     */ {
/*  49 */   private static final ILogger logger = GlobalLog.getLogger(App.class);
/*     */   
/*     */   Display display;
/*     */   
/*     */   String appname;
/*     */   
/*     */   Shell shell;
/*     */   
/*     */   boolean hasToolbar;
/*     */   
/*     */   MenuManager menuManager;
/*     */   
/*     */   Composite toolbarContainer;
/*     */   ToolBarManager toolbarManager;
/*     */   Dock dock;
/*     */   StatusLineManager statusManager;
/*     */   
/*     */   public App(String name, int style)
/*     */   {
/*  68 */     onPreDisplayCreation(name, "");
/*     */     
/*  70 */     this.display = Display.getDefault();
/*  71 */     this.appname = name;
/*     */     
/*  73 */     this.hasToolbar = ((style & 0x4) != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onPreDisplayCreation(String name, String version)
/*     */   {
/*  85 */     Display.setAppName(name);
/*  86 */     Display.setAppVersion(version);
/*     */   }
/*     */   
/*     */   public void build() {
/*  90 */     this.shell = new Shell(this.display);
/*  91 */     this.shell.setText(Strings.safe(this.appname));
/*  92 */     this.shell.setLayout(new FormLayout());
/*  93 */     customizeShell(this.shell);
/*     */     
/*  95 */     this.menuManager = new MenuManager();
/*  96 */     Menu menu = this.menuManager.createMenuBar(this.shell);
/*  97 */     this.shell.setMenuBar(menu);
/*     */     
/*  99 */     this.toolbarContainer = new Composite(this.shell, 0);
/* 100 */     FormData formData = new FormData();
/* 101 */     formData.top = new FormAttachment(0, 0);
/* 102 */     formData.left = new FormAttachment(0, 0);
/* 103 */     formData.right = new FormAttachment(100, 0);
/* 104 */     this.toolbarContainer.setLayoutData(formData);
/* 105 */     if (this.hasToolbar) {
/* 106 */       GridLayout toolbarContainerLayout = new GridLayout();
/* 107 */       toolbarContainerLayout.marginTop = 2;
/* 108 */       toolbarContainerLayout.marginBottom = 3;
/* 109 */       this.toolbarContainer.setLayout(toolbarContainerLayout);
/* 110 */       this.toolbarManager = new ToolBarManager(8388928);
/* 111 */       ToolBar toolbar = this.toolbarManager.createControl(this.toolbarContainer);
/* 112 */       ToolItem item = new ToolItem(toolbar, 8);
/* 113 */       item.setText(" ");
/* 114 */       toolbar.pack();
/*     */     }
/*     */     
/* 117 */     this.statusManager = new StatusLineManager();
/* 118 */     Control statusLine = this.statusManager.createControl(this.shell);
/* 119 */     this.statusManager.setMessage("");
/* 120 */     formData = new FormData();
/* 121 */     formData.left = new FormAttachment(0, 0);
/* 122 */     formData.right = new FormAttachment(100, 0);
/* 123 */     formData.bottom = new FormAttachment(100, 0);
/* 124 */     statusLine.pack();
/* 125 */     statusLine.setLayoutData(formData);
/*     */     
/* 127 */     this.dock = new Dock(this.shell, true);
/* 128 */     formData = new FormData();
/* 129 */     formData.top = new FormAttachment(this.toolbarContainer);
/* 130 */     formData.bottom = new FormAttachment(statusLine);
/* 131 */     formData.left = new FormAttachment(0, 0);
/* 132 */     formData.right = new FormAttachment(100, 0);
/* 133 */     this.dock.setLayoutData(formData);
/*     */     
/* 135 */     this.shell.addShellListener(new ShellAdapter()
/*     */     {
/*     */       public void shellClosed(ShellEvent e) {
/* 138 */         App.logger.i("Primary shell is about to close", new Object[0]);
/* 139 */         if (!App.this.onApplicationCloseAttempt()) {
/* 140 */           e.doit = false;
/*     */         }
/*     */         
/*     */       }
/* 144 */     });
/* 145 */     this.shell.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/* 148 */         App.logger.i("Primary shell is being disposed", new Object[0]);
/*     */       }
/*     */       
/* 151 */     });
/* 152 */     buildShell(this.shell);
/* 153 */     buildDock(this.dock);
/* 154 */     buildMenu(this.menuManager);
/* 155 */     if (this.toolbarManager != null) {
/* 156 */       buildToolbar(this.toolbarManager);
/*     */     }
/*     */     
/* 159 */     onApplicationBuilt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeShell(Shell shell) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getArguments()
/*     */   {
/* 171 */     return new String[0];
/*     */   }
/*     */   
/*     */   public void run() {
/* 175 */     this.shell.open();
/*     */     try
/*     */     {
/* 178 */       onApplicationReady();
/*     */     }
/*     */     catch (Exception e) {
/* 181 */       logger.catching(e);
/* 182 */       System.exit(-1);
/*     */     }
/*     */     
/*     */ 
/* 186 */     while (!this.shell.isDisposed()) {
/* 187 */       boolean canSleep = false;
/*     */       try {
/* 189 */         canSleep = !this.display.readAndDispatch();
/*     */       }
/*     */       catch (Exception e) {
/* 192 */         if (!onApplicationException(e)) {
/*     */           try {
/* 194 */             this.shell.dispose();
/*     */           }
/*     */           catch (Exception localException1) {}
/*     */           
/* 198 */           break;
/*     */         }
/*     */       }
/*     */       
/* 202 */       if (canSleep) {
/* 203 */         this.display.sleep();
/*     */       }
/*     */     }
/*     */     
/* 207 */     onApplicationClose();
/*     */     
/*     */     try
/*     */     {
/* 211 */       this.display.dispose();
/*     */     }
/*     */     catch (Exception localException2) {}
/*     */     
/* 215 */     System.exit(0);
/*     */   }
/*     */   
/*     */   public void close() {
/* 219 */     if (this.shell == null) {
/* 220 */       throw new IllegalStateException();
/*     */     }
/* 222 */     this.shell.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void buildShell(Shell shell) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void buildMenu(MenuManager menuManager) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void buildToolbar(ToolBarManager toolbarManager) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void buildDock(Dock dock) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Display getDisplay()
/*     */   {
/* 254 */     return this.display;
/*     */   }
/*     */   
/*     */   public Shell getPrimaryShell() {
/* 258 */     return this.shell;
/*     */   }
/*     */   
/*     */   public MenuManager getMenuManager() {
/* 262 */     return this.menuManager;
/*     */   }
/*     */   
/*     */   public ToolBarManager getToolbarManager() {
/* 266 */     return this.toolbarManager;
/*     */   }
/*     */   
/*     */   public Dock getDock() {
/* 270 */     return this.dock;
/*     */   }
/*     */   
/*     */   public StatusLineManager getStatusManager() {
/* 274 */     return this.statusManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onApplicationException(Exception e)
/*     */   {
/* 285 */     String msg = String.format("The following error was reported on the UI thread:\n\n%s", new Object[] {
/* 286 */       Throwables.formatStacktraceShort(e) });
/* 287 */     MessageDialog.openError(null, "Error", msg);
/* 288 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onApplicationBuilt() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onApplicationReady() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onApplicationCloseAttempt()
/*     */   {
/* 312 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onApplicationClose() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isToolbarVisible()
/*     */   {
/* 325 */     return this.toolbarContainer.isVisible();
/*     */   }
/*     */   
/*     */   public void setToolbarVisibility(boolean visible) {
/* 329 */     setBarVisibility(this.toolbarContainer, visible);
/*     */   }
/*     */   
/*     */   public boolean isStatusVisible() {
/* 333 */     return this.statusManager.getControl().isVisible();
/*     */   }
/*     */   
/*     */   public void setStatusVisibility(boolean visible) {
/* 337 */     setBarVisibility(this.statusManager.getControl(), visible);
/*     */   }
/*     */   
/*     */   private void setBarVisibility(Control bar, boolean visible) {
/* 341 */     if (bar.isVisible() == visible) {
/* 342 */       return;
/*     */     }
/* 344 */     bar.setVisible(visible);
/* 345 */     if (!visible) {
/* 346 */       ((FormData)bar.getLayoutData()).height = 0;
/*     */     }
/*     */     else {
/* 349 */       int height = bar.computeSize(-1, -1, true).y;
/* 350 */       ((FormData)bar.getLayoutData()).height = height;
/*     */     }
/* 352 */     this.shell.layout();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\App.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */