package com.pnfsoftware.jeb.rcpclient.extensions.app.model;

public abstract interface IMPanelElement
  extends IMElement
{}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\model\IMPanelElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */