/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMDock;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMElement;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPanel;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dock
/*     */   extends Composite
/*     */   implements IMDock
/*     */ {
/*  44 */   private static final ILogger logger = GlobalLog.getLogger(Dock.class);
/*     */   
/*  46 */   private static int internalDockCreationCount = 0;
/*     */   
/*     */   public static final int TOP = -1;
/*     */   
/*     */   public static final int BOTTOM = -2;
/*     */   
/*     */   public static final int LEFT = -3;
/*     */   
/*     */   public static final int RIGHT = -4;
/*     */   int internalDockId;
/*     */   String elementId;
/*     */   boolean allowTabClose;
/*     */   boolean onEmptyCloseFolder;
/*     */   boolean allowForeignDocking;
/*     */   Dock masterDock;
/*     */   private Panel mainPanel;
/*     */   private Folder initialFolder;
/*  63 */   private List<IDockListener> dockListeners = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dock(Shell parentShell, boolean onEmptyCloseFolder)
/*     */   {
/*  74 */     this(parentShell, onEmptyCloseFolder, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Dock(Shell parentShell, boolean onEmptyCloseFolder, Dock masterDock)
/*     */   {
/*  85 */     super(parentShell, 0);
/*  86 */     this.internalDockId = (internalDockCreationCount++);
/*     */     
/*     */ 
/*  89 */     boolean ok = false;
/*  90 */     for (Control child : parentShell.getChildren()) {
/*  91 */       if ((child instanceof Dock)) {
/*  92 */         if (child == this) {
/*  93 */           ok = true;
/*     */         }
/*     */         else {
/*  96 */           ok = false;
/*  97 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 101 */     if (!ok) {
/* 102 */       throw new IllegalStateException("One Dock per Shell at most");
/*     */     }
/*     */     
/* 105 */     setLayout(new FillLayout());
/*     */     
/* 107 */     this.onEmptyCloseFolder = onEmptyCloseFolder;
/* 108 */     this.allowForeignDocking = true;
/* 109 */     this.masterDock = masterDock;
/*     */     
/* 111 */     build();
/*     */   }
/*     */   
/*     */   private void build() {
/* 115 */     this.mainPanel = new Panel(this, 0);
/* 116 */     this.initialFolder = createFolder(this.mainPanel, true);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 120 */     this.mainPanel.dispose();
/* 121 */     build();
/* 122 */     layout();
/*     */   }
/*     */   
/*     */   public Dock getMasterDock() {
/* 126 */     return this.masterDock;
/*     */   }
/*     */   
/*     */   public Panel getMainPanel() {
/* 130 */     return this.mainPanel;
/*     */   }
/*     */   
/*     */   public Folder getInitialFolder()
/*     */   {
/* 135 */     return this.initialFolder;
/*     */   }
/*     */   
/*     */   Folder createFolder(Panel panel, boolean notify) {
/* 139 */     int style = 2048;
/* 140 */     if (this.allowTabClose) {
/* 141 */       style |= 0x40;
/*     */     }
/* 143 */     int tabStyle = 0;
/* 144 */     Folder folder = panel.createFolder(style, tabStyle, this.onEmptyCloseFolder);
/* 145 */     if (notify) {
/* 146 */       notifyFolderAdded(folder);
/*     */     }
/* 148 */     return folder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Folder> getFolders()
/*     */   {
/* 158 */     List<Folder> folders = new ArrayList();
/* 159 */     collectFolders(getMainPanel(), folders);
/* 160 */     return folders;
/*     */   }
/*     */   
/*     */   private void collectFolders(Widget w, List<Folder> folders) {
/* 164 */     if ((w instanceof Panel)) {
/* 165 */       Panel panel = (Panel)w;
/* 166 */       for (Control elt : panel.getElements()) {
/* 167 */         collectFolders(elt, folders);
/*     */       }
/*     */     }
/* 170 */     else if ((w instanceof Folder)) {
/* 171 */       folders.add((Folder)w);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Folder splitFolder(Folder folder, int split)
/*     */   {
/* 183 */     return splitFolder(folder, split, 50);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Folder splitFolder(Folder folder, int split, int ratio)
/*     */   {
/* 195 */     if (folder.getDock() != this) {
/* 196 */       throw new IllegalArgumentException("Folder does not belong to this dock!");
/*     */     }
/* 198 */     if ((ratio < 0) || (ratio > 100)) {
/* 199 */       throw new IllegalArgumentException("Illegal ratio: " + ratio);
/*     */     }
/*     */     
/*     */     int orientation;
/* 203 */     if ((split == -1) || (split == -2)) {
/* 204 */       orientation = 512;
/*     */     } else { int orientation;
/* 206 */       if ((split == -3) || (split == -4)) {
/* 207 */         orientation = 256;
/*     */       }
/*     */       else
/* 210 */         throw new RuntimeException("Invalid orientation: " + split); }
/*     */     int orientation;
/* 212 */     boolean first = (split == -1) || (split == -3);
/*     */     
/* 214 */     Panel panel0 = folder.getParentPanel();
/*     */     
/*     */ 
/*     */ 
/* 218 */     int[] weights0 = panel0.getWeights();
/* 219 */     int cnt = weights0.length;
/*     */     
/* 221 */     if (cnt == 1) {
/* 222 */       panel0.setOrientation(orientation);
/* 223 */       Folder folder2 = createFolder(panel0, false);
/* 224 */       if (first) {
/* 225 */         folder2.moveAbove(null);
/*     */       }
/* 227 */       panel0.setWeights(new int[] { 100 - ratio, first ? new int[] { ratio, 100 - ratio } : ratio });
/*     */     }
/* 229 */     else if (cnt == 2) {
/* 230 */       int index = panel0.getElementIndex(folder);
/* 231 */       Panel panel1 = panel0.createPanel(orientation);
/* 232 */       if (index == 0) {
/* 233 */         panel1.moveAbove(null);
/*     */       }
/* 235 */       folder.setParent(panel1.getSashFormWidget());
/* 236 */       Folder folder2 = createFolder(panel1, false);
/* 237 */       if (first) {
/* 238 */         folder2.moveAbove(null);
/*     */       }
/* 240 */       panel1.setWeights(new int[] { 100 - ratio, first ? new int[] { ratio, 100 - ratio } : ratio });
/* 241 */       panel1.layout();
/*     */       
/* 243 */       panel0.setWeights(weights0);
/*     */     }
/*     */     else {
/* 246 */       throw new RuntimeException(String.format("Illegal sashform (%d parts)", new Object[] { Integer.valueOf(cnt) }));
/*     */     }
/*     */     Folder folder2;
/* 249 */     panel0.layout();
/*     */     
/* 251 */     notifyFolderAdded(folder2);
/* 252 */     return folder2;
/*     */   }
/*     */   
/*     */   public void addDockListener(IDockListener listener) {
/* 256 */     this.dockListeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeDockListener(IDockListener listener) {
/* 260 */     this.dockListeners.remove(listener);
/*     */   }
/*     */   
/*     */   void notifyFolderAdded(Folder folder) {
/* 264 */     for (IDockListener listener : this.dockListeners) {
/* 265 */       listener.folderAdded(folder);
/*     */     }
/*     */   }
/*     */   
/*     */   void notifyFolderRemoving(Folder folder) {
/* 270 */     for (IDockListener listener : this.dockListeners) {
/* 271 */       listener.folderRemoving(folder);
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<Dock> findDocks(Display display) {
/* 276 */     List<Dock> docks = new ArrayList();
/* 277 */     for (Shell shell : display.getShells()) {
/* 278 */       for (Control ctl : shell.getChildren())
/*     */       {
/* 280 */         if ((ctl instanceof Dock)) {
/* 281 */           docks.add((Dock)ctl);
/*     */         }
/*     */       }
/*     */     }
/* 285 */     return docks;
/*     */   }
/*     */   
/*     */   public Dock createAdditionalDock() {
/* 289 */     return createAdditionalDock(false, 1264, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dock createAdditionalDock(boolean onTop, int shellStyle, Rectangle shellBounds)
/*     */   {
/* 301 */     Shell shell2 = onTop ? new Shell((Shell)getParent(), shellStyle) : new Shell(getDisplay(), shellStyle);
/* 302 */     if (shellBounds != null) {
/* 303 */       shell2.setBounds(shellBounds);
/*     */     }
/*     */     else {
/* 306 */       shell2.setSize(500, 400);
/*     */     }
/* 308 */     shell2.setLayout(new FillLayout());
/* 309 */     final Dock dock2 = new Dock(shell2, this.onEmptyCloseFolder, this.masterDock == null ? this : this.masterDock);
/*     */     
/* 311 */     shell2.addListener(21, new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/* 314 */         Panel p = dock2.getMainPanel();
/* 315 */         List<Part> parts = p.getParts();
/* 316 */         if (!parts.isEmpty()) {
/* 317 */           for (Part pa : parts) {
/* 318 */             if (!pa.isHideable())
/*     */             {
/* 320 */               Folder folder = (Folder)pa.getParentElement();
/* 321 */               folder.restoreTab(pa, pa.defaultOwner.getFolderWidget());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 326 */     });
/* 327 */     shell2.layout();
/* 328 */     shell2.open();
/*     */     
/* 330 */     return dock2;
/*     */   }
/*     */   
/*     */   public String formatStructure() {
/* 334 */     StringBuilder sb = new StringBuilder();
/* 335 */     formatStructure(null, this, 0, sb);
/* 336 */     return Strings.rtrim(sb.toString());
/*     */   }
/*     */   
/*     */   private void formatStructure(IMElement parent, IMElement elt, int depth, StringBuilder sb) {
/* 340 */     if ((parent != null) && (elt.getParentElement() != parent))
/*     */     {
/* 342 */       throw new RuntimeException(String.format("Unexpected parent for element %s: %s != %s", new Object[] { elt, parent, elt.getParentElement() })); }
/*     */     Part part;
/* 344 */     if ((elt instanceof Dock)) {
/* 345 */       Dock dock = (Dock)elt;
/* 346 */       sb.append(String.format("%sDock(#%d)\n", new Object[] { Strings.generate(' ', depth * 2), Integer.valueOf(dock.internalDockId) }));
/*     */     }
/* 348 */     else if ((elt instanceof Panel)) {
/* 349 */       Panel panel = (Panel)elt;
/* 350 */       sb.append(String.format("%sPanel(%s %s)\n", new Object[] { Strings.generate(' ', depth * 2), 
/* 351 */         Arrays.toString(panel.getWeights()), panel.isVertical() ? "vertical" : "horizontal" }));
/*     */     }
/* 353 */     else if ((elt instanceof Folder)) {
/* 354 */       Folder folder = (Folder)elt;
/* 355 */       sb.append(String.format("%sFolder(%d)\n", new Object[] { Strings.generate(' ', depth * 2), Integer.valueOf(folder.getPartsCount()) }));
/*     */     }
/* 357 */     else if ((elt instanceof Part)) {
/* 358 */       part = (Part)elt;
/* 359 */       sb.append(String.format("%sPart(%s)\n", new Object[] { Strings.generate(' ', depth * 2), part.getLabel() }));
/*     */     }
/*     */     else {
/* 362 */       throw new RuntimeException(String.format("Element not supported in this dock: %s", new Object[] { elt == null ? null : elt
/* 363 */         .getClass().getSimpleName() }));
/*     */     }
/* 365 */     for (IMElement child : elt.getChildrenElements()) {
/* 366 */       formatStructure(elt, child, depth + 1, sb);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 372 */     return String.format("Dock@%d", new Object[] { Integer.valueOf(this.internalDockId) });
/*     */   }
/*     */   
/*     */   public void setElementId(String elementId)
/*     */   {
/* 377 */     this.elementId = elementId;
/*     */   }
/*     */   
/*     */   public String getElementId()
/*     */   {
/* 382 */     return this.elementId;
/*     */   }
/*     */   
/*     */ 
/*     */   public IMElement getParentElement()
/*     */   {
/* 388 */     return null;
/*     */   }
/*     */   
/*     */   public List<? extends IMElement> getChildrenElements()
/*     */   {
/* 393 */     return Arrays.asList(new IMPanel[] { getPanelElement() });
/*     */   }
/*     */   
/*     */   public IMPanel getPanelElement()
/*     */   {
/* 398 */     return this.mainPanel;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\Dock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */