/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMElement;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMFolder;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPart;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.app.model.IMPartManager;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.custom.CTabItem;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Part
/*     */   implements IMPart
/*     */ {
/*  38 */   private static final ILogger logger = GlobalLog.getLogger(Part.class);
/*     */   
/*  40 */   private static int internalPartCreationCount = 0;
/*     */   
/*     */   int internalPartId;
/*     */   
/*     */   String elementId;
/*     */   
/*     */   Folder defaultOwner;
/*     */   
/*     */   Folder owner;
/*     */   CTabItem tab;
/*     */   private IMPartManager manager;
/*     */   int state;
/*     */   private Map<String, Object> data;
/*     */   private boolean closeOnHide;
/*     */   private Composite cControl;
/*     */   private String cLabel;
/*     */   private String cTooltip;
/*     */   private Image cIcon;
/*     */   private Font cFont;
/*     */   private boolean cCloseable;
/*     */   
/*     */   public Part(Folder owner)
/*     */   {
/*  63 */     this.internalPartId = (internalPartCreationCount++);
/*  64 */     this.owner = owner;
/*  65 */     this.defaultOwner = owner;
/*  66 */     createContainerWidget();
/*     */   }
/*     */   
/*     */   public Part(CTabItem tab) {
/*  70 */     this.internalPartId = (internalPartCreationCount++);
/*  71 */     setTab(tab);
/*  72 */     this.defaultOwner = this.owner;
/*  73 */     createContainerWidget();
/*     */   }
/*     */   
/*     */   private void setTab(CTabItem tab) {
/*  77 */     this.owner = Folder.tabToFolder(tab);
/*  78 */     this.tab = tab;
/*     */   }
/*     */   
/*     */   private void createContainerWidget() {
/*  82 */     Composite container = new Composite(this.owner.getFolderWidget(), 2048);
/*  83 */     container.setLayout(new FillLayout());
/*  84 */     this.cControl = container;
/*     */   }
/*     */   
/*     */   public Composite getContainerWidget() {
/*  88 */     return this.tab == null ? this.cControl : (Composite)this.tab.getControl();
/*     */   }
/*     */   
/*     */   public boolean isHidden()
/*     */   {
/*  93 */     return this.tab == null;
/*     */   }
/*     */   
/*     */   void hide() {
/*  97 */     if (isHidden()) {
/*  98 */       throw new IllegalStateException();
/*     */     }
/* 100 */     this.cControl = ((Composite)this.tab.getControl());
/* 101 */     this.cLabel = this.tab.getText();
/* 102 */     this.cTooltip = this.tab.getToolTipText();
/* 103 */     this.cIcon = this.tab.getImage();
/* 104 */     this.cFont = this.tab.getFont();
/* 105 */     this.cCloseable = this.tab.getShowClose();
/* 106 */     this.tab.dispose();
/* 107 */     this.tab = null;
/*     */   }
/*     */   
/*     */   void restoreInto(CTabItem tab)
/*     */   {
/* 112 */     if (!isHidden()) {
/* 113 */       throw new IllegalStateException();
/*     */     }
/* 115 */     if (this.cControl != null) {
/* 116 */       CTabFolder folder = tab.getParent();
/* 117 */       this.cControl.setParent(folder);
/* 118 */       tab.setControl(this.cControl);
/*     */     }
/* 120 */     if (this.cLabel != null) {
/* 121 */       tab.setText(this.cLabel);
/*     */     }
/* 123 */     if (this.cTooltip != null) {
/* 124 */       tab.setToolTipText(this.cTooltip);
/*     */     }
/* 126 */     if (this.cIcon != null) {
/* 127 */       tab.setImage(this.cIcon);
/*     */     }
/* 129 */     if (this.cFont != null) {
/* 130 */       tab.setFont(this.cFont);
/*     */     }
/* 132 */     tab.setShowClose(this.cCloseable);
/* 133 */     setTab(tab);
/*     */   }
/*     */   
/*     */   public Control getControl() {
/* 137 */     return this.tab == null ? this.cControl : this.tab.getControl();
/*     */   }
/*     */   
/*     */   public boolean isCloseOnHide()
/*     */   {
/* 142 */     return this.closeOnHide;
/*     */   }
/*     */   
/*     */   public void setCloseOnHide(boolean closeOnHide)
/*     */   {
/* 147 */     this.closeOnHide = closeOnHide;
/*     */   }
/*     */   
/*     */   public String getLabel()
/*     */   {
/* 152 */     return this.tab == null ? this.cLabel : this.tab.getText();
/*     */   }
/*     */   
/*     */   public void setLabel(String label)
/*     */   {
/* 157 */     if (this.tab == null) {
/* 158 */       this.cLabel = label;
/*     */     }
/*     */     else {
/* 161 */       this.tab.setText(label);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getTooltip()
/*     */   {
/* 167 */     return this.tab == null ? this.cTooltip : this.tab.getToolTipText();
/*     */   }
/*     */   
/*     */   public void setTooltip(String tooltip)
/*     */   {
/* 172 */     if (this.tab == null) {
/* 173 */       this.cTooltip = tooltip;
/*     */     }
/*     */     else {
/* 176 */       this.tab.setToolTipText(tooltip);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isHideable()
/*     */   {
/* 182 */     return this.tab == null ? this.cCloseable : this.tab.getShowClose();
/*     */   }
/*     */   
/*     */   public void setHideable(boolean closeable)
/*     */   {
/* 187 */     if (this.tab == null) {
/* 188 */       this.cCloseable = closeable;
/*     */     }
/*     */     else {
/* 191 */       this.tab.setShowClose(closeable);
/*     */     }
/*     */   }
/*     */   
/*     */   public Image getIcon()
/*     */   {
/* 197 */     return this.tab == null ? this.cIcon : this.tab.getImage();
/*     */   }
/*     */   
/*     */   public void setIcon(Image icon)
/*     */   {
/* 202 */     if (this.tab == null) {
/* 203 */       this.cIcon = icon;
/*     */     }
/*     */     else {
/* 206 */       this.tab.setImage(icon);
/*     */     }
/*     */   }
/*     */   
/*     */   public Font getFont() {
/* 211 */     return this.tab == null ? this.cFont : this.tab.getFont();
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/* 215 */     if (this.tab == null) {
/* 216 */       this.cFont = font;
/*     */     }
/*     */     else {
/* 219 */       this.tab.setFont(font);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setElementId(String elementId)
/*     */   {
/* 225 */     this.elementId = elementId;
/*     */   }
/*     */   
/*     */   public String getElementId()
/*     */   {
/* 230 */     return this.elementId;
/*     */   }
/*     */   
/*     */   public List<? extends IMElement> getChildrenElements()
/*     */   {
/* 235 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public IMFolder getParentElement()
/*     */   {
/* 240 */     return this.owner;
/*     */   }
/*     */   
/*     */   public void setManager(IMPartManager manager)
/*     */   {
/* 245 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   public IMPartManager getManager()
/*     */   {
/* 250 */     return this.manager;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getData()
/*     */   {
/* 255 */     if (this.data == null) {
/* 256 */       this.data = new HashMap();
/*     */     }
/* 258 */     return this.data;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 263 */     return String.format("Part@%d[%s]", new Object[] { Integer.valueOf(this.internalPartId), getLabel() });
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\Part.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */