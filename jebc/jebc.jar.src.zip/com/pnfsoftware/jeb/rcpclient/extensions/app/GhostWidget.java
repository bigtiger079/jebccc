/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.base.Couple;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.events.PaintEvent;
/*     */ import org.eclipse.swt.events.PaintListener;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GhostWidget
/*     */ {
/*  36 */   private static final ILogger logger = GlobalLog.getLogger(GhostWidget.class);
/*     */   
/*  38 */   GhostStyleData styleData = GhostStyleData.buildDefault();
/*     */   Display display;
/*     */   Control topLevelContainer;
/*     */   Rectangle topRectangle;
/*  42 */   List<Couple<Control, PaintListener>> paintListeners = new ArrayList();
/*     */   int posDeltaX;
/*     */   int posDeltaY;
/*  45 */   List<DropZone> dropzones = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GhostWidget(Control topLevelContainer, Display display)
/*     */   {
/*  54 */     if ((topLevelContainer != null) && (display != null) && (topLevelContainer.getDisplay() != display)) {
/*  55 */       throw new IllegalArgumentException();
/*     */     }
/*  57 */     this.topLevelContainer = topLevelContainer;
/*  58 */     this.display = display;
/*     */     
/*  60 */     if (topLevelContainer != null) {
/*  61 */       prepare(topLevelContainer);
/*     */     }
/*     */     else {
/*  64 */       for (Shell shell : display.getShells()) {
/*  65 */         prepare(shell);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStyleData(GhostStyleData styleData) {
/*  71 */     this.styleData = styleData;
/*     */   }
/*     */   
/*     */   public GhostStyleData getStyleData() {
/*  75 */     return this.styleData;
/*     */   }
/*     */   
/*     */   public Display getDisplay() {
/*  79 */     return this.display;
/*     */   }
/*     */   
/*     */   public Control getTopLevelContainer() {
/*  83 */     return this.topLevelContainer;
/*     */   }
/*     */   
/*     */   public void setRectangle(Rectangle r) {
/*  87 */     this.topRectangle = r;
/*     */   }
/*     */   
/*     */   public Rectangle getRectangle() {
/*  91 */     return this.topRectangle;
/*     */   }
/*     */   
/*     */   public void setPositionDelta(Point posDelta) {
/*  95 */     this.posDeltaX = posDelta.x;
/*  96 */     this.posDeltaY = posDelta.y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updatePosition(Point p)
/*     */   {
/* 105 */     this.topRectangle.x = (p.x - this.posDeltaX);
/* 106 */     this.topRectangle.y = (p.y - this.posDeltaY);
/*     */     
/*     */ 
/* 109 */     for (DropZone dropzone : this.dropzones) {
/* 110 */       dropzone.activated = UIUtil.isContained(p, dropzone.rectangle);
/*     */     }
/*     */     
/* 113 */     redrawAll();
/*     */   }
/*     */   
/* 116 */   final PaintListener paintListener = new PaintListener()
/*     */   {
/*     */     public void paintControl(PaintEvent e) {
/* 119 */       if (!(e.widget instanceof Control)) {
/* 120 */         return;
/*     */       }
/* 122 */       Control ctl = (Control)e.widget;
/*     */       
/*     */ 
/*     */ 
/* 126 */       GC gc = e.gc;
/* 127 */       gc.setLineWidth(2);
/*     */       
/*     */ 
/* 130 */       Rectangle r = e.display.map(GhostWidget.this.topLevelContainer, ctl, GhostWidget.this.topRectangle);
/* 131 */       gc.setForeground(GhostWidget.this.styleData.cGhostForeground);
/* 132 */       gc.setLineStyle(3);
/* 133 */       gc.drawRectangle(r);
/*     */       
/*     */ 
/* 136 */       for (DropZone dropzone : GhostWidget.this.dropzones) {
/* 137 */         r = e.display.map(GhostWidget.this.topLevelContainer, ctl, dropzone.rectangle);
/*     */         
/* 139 */         gc.setForeground(GhostWidget.this.styleData.cDropzoneForeground);
/* 140 */         gc.setLineStyle(3);
/* 141 */         gc.drawRoundRectangle(r.x, r.y, r.width, r.height, 5, 5);
/*     */         
/* 143 */         if (dropzone.activated) {
/* 144 */           gc.setBackground(GhostWidget.this.styleData.cDropzoneActiveBackground);
/* 145 */           gc.fillRoundRectangle(r.x, r.y, r.width, r.height, 5, 5);
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   private void prepare(Control ctl) {
/* 152 */     ctl.addPaintListener(this.paintListener);
/* 153 */     this.paintListeners.add(new Couple(ctl, this.paintListener));
/*     */     
/* 155 */     if ((ctl instanceof Composite)) {
/* 156 */       for (Control c : ((Composite)ctl).getChildren()) {
/* 157 */         prepare(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void redrawAll() {
/* 163 */     if (this.topLevelContainer != null) {
/* 164 */       redraw(this.topLevelContainer);
/*     */     }
/*     */     else {
/* 167 */       for (Shell shell : this.display.getShells()) {
/* 168 */         redraw(shell);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void redraw(Control ctl) {
/* 174 */     Point size = ctl.getSize();
/* 175 */     ctl.redraw(0, 0, size.x, size.y, true);
/* 176 */     ctl.update();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 189 */     for (Couple<Control, PaintListener> e : this.paintListeners) {
/* 190 */       Control ctl = (Control)e.getFirst();
/* 191 */       PaintListener listener = (PaintListener)e.getSecond();
/* 192 */       if (!ctl.isDisposed()) {
/* 193 */         ctl.removePaintListener(listener);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 198 */     redrawAll();
/*     */   }
/*     */   
/*     */   public void registerDropZones(List<DropZone> dropzones) {
/* 202 */     for (DropZone dropzone : dropzones)
/*     */     {
/* 204 */       if (dropzone.refctl != this.topLevelContainer) {
/* 205 */         if (this.topLevelContainer == null) {
/* 206 */           dropzone.rectangle = this.display.map(dropzone.refctl, null, dropzone.rectangle);
/*     */         }
/*     */         else {
/* 209 */           dropzone.rectangle = this.display.map(dropzone.refctl, this.topLevelContainer, dropzone.rectangle);
/*     */         }
/*     */       }
/*     */     }
/* 213 */     this.dropzones.addAll(dropzones);
/*     */   }
/*     */   
/*     */   public DropZone getActiveDropZone() {
/* 217 */     for (DropZone dropzone : this.dropzones) {
/* 218 */       if (dropzone.activated) {
/* 219 */         return dropzone;
/*     */       }
/*     */     }
/* 222 */     return null;
/*     */   }
/*     */   
/*     */   public boolean inCandidateArea(Point p) {
/* 226 */     if (this.topLevelContainer != null) {
/* 227 */       return UIUtil.isContained(p, this.topLevelContainer.getBounds());
/*     */     }
/*     */     
/* 230 */     for (Shell shell : this.display.getShells()) {
/* 231 */       if (UIUtil.isContained(p, shell.getBounds())) {
/* 232 */         return true;
/*     */       }
/*     */     }
/* 235 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\GhostWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */