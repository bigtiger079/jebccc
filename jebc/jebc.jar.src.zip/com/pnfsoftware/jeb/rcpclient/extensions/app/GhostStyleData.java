/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.app;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.SwtRegistry;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.ColorsGradient;
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GhostStyleData
/*    */ {
/*    */   public Color cGhostForeground;
/*    */   public Color cDropzoneActiveBackground;
/*    */   public Color cDropzoneForeground;
/*    */   
/*    */   public static GhostStyleData buildDefault()
/*    */   {
/* 26 */     GhostStyleData r = new GhostStyleData();
/* 27 */     r.cGhostForeground = get("gray 31");
/* 28 */     r.cDropzoneActiveBackground = get("peachpuff 1 (peachpuff)");
/* 29 */     r.cDropzoneForeground = get("orange");
/* 30 */     return r;
/*    */   }
/*    */   
/*    */   private static Color get(String name) {
/* 34 */     return SwtRegistry.getInstance().getColor(ColorsGradient.get(name));
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\GhostStyleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */