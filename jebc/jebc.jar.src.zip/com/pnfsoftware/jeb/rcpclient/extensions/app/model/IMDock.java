package com.pnfsoftware.jeb.rcpclient.extensions.app.model;

public abstract interface IMDock
  extends IMElement
{
  public abstract IMFolder getInitialFolder();
  
  public abstract IMPanel getPanelElement();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\app\model\IMDock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */