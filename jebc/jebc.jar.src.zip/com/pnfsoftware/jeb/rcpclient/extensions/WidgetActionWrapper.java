/*    */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.operations.ContextMenu;
/*    */ import com.pnfsoftware.jeb.rcpclient.operations.IContextMenu;
/*    */ import com.pnfsoftware.jeb.rcpclient.operations.JebAction;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.jface.action.Action;
/*    */ import org.eclipse.jface.action.IMenuManager;
/*    */ import org.eclipse.swt.events.KeyAdapter;
/*    */ import org.eclipse.swt.events.KeyEvent;
/*    */ import org.eclipse.swt.widgets.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WidgetActionWrapper
/*    */   implements IContextMenu
/*    */ {
/*    */   private Control ctl;
/*    */   
/*    */   private static class ViewerKeyAdapter
/*    */     extends KeyAdapter
/*    */   {
/*    */     private int fKeyCode;
/*    */     private Action fAction;
/*    */     private int fStateMask;
/*    */     
/*    */     public ViewerKeyAdapter(int keyCode, int stateMask, Action action)
/*    */     {
/* 37 */       this.fKeyCode = keyCode;
/* 38 */       this.fStateMask = stateMask;
/* 39 */       this.fAction = action;
/*    */     }
/*    */     
/*    */     public void keyPressed(KeyEvent e)
/*    */     {
/* 44 */       if ((((e.stateMask & this.fStateMask) != 0) || (this.fStateMask == 0)) && 
/* 45 */         (e.keyCode == this.fKeyCode) && 
/* 46 */         (this.fAction.isEnabled())) {
/* 47 */         this.fAction.run();
/* 48 */         e.doit = false;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 56 */   private List<Action> menuActions = new ArrayList();
/*    */   
/*    */   public WidgetActionWrapper(Control ctl) {
/* 59 */     this.ctl = ctl;
/*    */     
/* 61 */     new ContextMenu(ctl).addContextMenu(this);
/*    */   }
/*    */   
/*    */   public void registerAction(JebAction action) {
/* 65 */     if (action.isContextual()) {
/* 66 */       this.menuActions.add(action);
/*    */     }
/*    */     
/* 69 */     if (action.getKeyCode() != 0) {
/* 70 */       this.ctl.addKeyListener(new ViewerKeyAdapter(action.getKeyCode(), action.getKeyModifier(), action));
/*    */     }
/*    */   }
/*    */   
/*    */   public void fillContextMenu(IMenuManager menuMgr)
/*    */   {
/* 76 */     for (Action action : this.menuActions) {
/* 77 */       action.setEnabled(action.isEnabled());
/* 78 */       menuMgr.add(action);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\WidgetActionWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */