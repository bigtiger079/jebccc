/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.AdaptivePopupDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ui.UITaskManager;
/*     */ import com.pnfsoftware.jeb.util.base.OSType;
/*     */ import com.pnfsoftware.jeb.util.concurrent.DaemonExecutors;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UI
/*     */ {
/*  39 */   private static final ILogger logger = GlobalLog.getLogger(UI.class);
/*     */   
/*     */   private static Display display;
/*     */   
/*     */   private static ExecutorService execsvc;
/*     */   
/*     */   private static ShellActivationTracker shellTracker;
/*     */   private static UITaskManager taskManager;
/*  47 */   private static boolean[] kbmodstates = new boolean[4];
/*     */   public static final String MOD1;
/*     */   public static final String MOD2;
/*     */   
/*  51 */   static { if (OSType.determine().isMac()) {
/*  52 */       MOD1 = "⌘";
/*  53 */       MOD2 = "⇧";
/*  54 */       MOD3 = "⌥";
/*  55 */       MOD4 = "⌃";
/*     */     }
/*     */     else {
/*  58 */       MOD1 = "⌃";
/*  59 */       MOD2 = "⇧";
/*  60 */       MOD3 = "⌥";
/*  61 */       MOD4 = "";
/*     */     }
/*     */   }
/*     */   
/*     */   public static void initialize() {
/*  66 */     if ((display != null) && 
/*  67 */       (Display.getCurrent() != display)) {
/*  68 */       throw new IllegalStateException("The UI class was already initialized on another UI thread");
/*     */     }
/*     */     
/*  71 */     display = Display.getCurrent();
/*  72 */     if (display == null) {
/*  73 */       throw new RuntimeException("The UI class must be loaded by the UI thread");
/*     */     }
/*  75 */     execsvc = DaemonExecutors.newFixedThreadPool(10);
/*     */     
/*  77 */     shellTracker = new ShellActivationTracker(display);
/*  78 */     taskManager = new UITaskManager(display, execsvc);
/*     */     
/*  80 */     Listener kbfilter = new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/*     */         int i;
/*  84 */         if (event.keyCode == SWT.MOD1) {
/*  85 */           i = 0;
/*     */         } else { int i;
/*  87 */           if (event.keyCode == SWT.MOD2) {
/*  88 */             i = 1;
/*     */           } else { int i;
/*  90 */             if (event.keyCode == SWT.MOD3) {
/*  91 */               i = 2;
/*     */             } else { int i;
/*  93 */               if (event.keyCode == SWT.MOD4)
/*  94 */                 i = 3; else {
/*     */                 return;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         int i;
/* 101 */         if (event.type == 1) {
/* 102 */           UI.kbmodstates[i] = 1;
/*     */         }
/* 104 */         else if (event.type == 2) {
/* 105 */           UI.kbmodstates[i] = 0;
/*     */         }
/*     */       }
/* 108 */     };
/* 109 */     display.addFilter(1, kbfilter);
/* 110 */     display.addFilter(2, kbfilter);
/*     */   }
/*     */   
/*     */   private static void safeInit() {
/* 114 */     if (display == null) {
/* 115 */       initialize();
/*     */     }
/*     */   }
/*     */   
/*     */   public static Display getDisplay() {
/* 120 */     safeInit();
/* 121 */     return display;
/*     */   }
/*     */   
/*     */   public static ShellActivationTracker getShellTracker() {
/* 125 */     safeInit();
/* 126 */     return shellTracker;
/*     */   }
/*     */   
/*     */   public static UITaskManager getTaskManager() {
/* 130 */     safeInit();
/* 131 */     return taskManager;
/*     */   }
/*     */   
/*     */   public static int getKeyboardModifiersState() {
/* 135 */     int v = 0;
/* 136 */     if (kbmodstates[0] != 0) {
/* 137 */       v |= SWT.MOD1;
/*     */     }
/* 139 */     if (kbmodstates[1] != 0) {
/* 140 */       v |= SWT.MOD2;
/*     */     }
/* 142 */     if (kbmodstates[2] != 0) {
/* 143 */       v |= SWT.MOD3;
/*     */     }
/* 145 */     if (kbmodstates[3] != 0) {
/* 146 */       v |= SWT.MOD4;
/*     */     }
/* 148 */     return v;
/*     */   }
/*     */   
/*     */   public static void log(final int level, Shell shell, final String caption, final String message)
/*     */   {
/* 153 */     safeInit();
/* 154 */     final AtomicBoolean displayed = new AtomicBoolean();
/* 155 */     UIRunnable r = new UIRunnable()
/*     */     {
/*     */       public void runi() {
/* 158 */         Shell shell0 = this.val$shell != null ? this.val$shell : UI.shellTracker.get();
/* 159 */         if (shell0 != null) {
/* 160 */           displayed.set(true);
/* 161 */           if (level == 50) {
/* 162 */             MessageDialog.openError(shell0, caption, message);
/*     */           }
/* 164 */           else if (level == 40) {
/* 165 */             MessageDialog.openWarning(shell0, caption, message);
/*     */           }
/*     */           else {
/* 168 */             MessageDialog.openInformation(shell0, caption, message);
/*     */           }
/*     */         }
/*     */       }
/* 172 */     };
/* 173 */     Display display = Display.getDefault();
/* 174 */     if (Thread.currentThread() == display.getThread()) {
/* 175 */       r.run();
/*     */     }
/*     */     else {
/* 178 */       UIExecutor.sync(display, r);
/*     */     }
/* 180 */     if (!displayed.get()) {
/* 181 */       logger.log(level, false, "%s: %s", new Object[] { caption, message });
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean confirm(Shell shell, final String caption, final String message)
/*     */   {
/* 187 */     safeInit();
/* 188 */     final AtomicBoolean success = new AtomicBoolean();
/* 189 */     UIRunnable r = new UIRunnable()
/*     */     {
/*     */       public void runi() {
/* 192 */         Shell shell0 = this.val$shell != null ? this.val$shell : UI.shellTracker.get();
/* 193 */         if (shell0 != null) {
/* 194 */           success.set(MessageDialog.openConfirm(shell0, caption, message));
/*     */         }
/*     */       }
/*     */     };
/* 198 */     if (Thread.currentThread() == display.getThread()) {
/* 199 */       r.run();
/*     */     }
/*     */     else {
/* 202 */       UIExecutor.sync(display, r);
/*     */     }
/* 204 */     return success.get();
/*     */   }
/*     */   
/*     */   public static void warn(Shell shell, String caption, String message)
/*     */   {
/* 209 */     log(40, shell, caption, message);
/*     */   }
/*     */   
/*     */   public static void info(Shell shell, String caption, String message)
/*     */   {
/* 214 */     log(30, shell, caption, message);
/*     */   }
/*     */   
/*     */   public static void info(String message)
/*     */   {
/* 219 */     log(30, null, S.s(384), message);
/*     */   }
/*     */   
/*     */   public static void warn(String message)
/*     */   {
/* 224 */     log(40, null, S.s(821), message);
/*     */   }
/*     */   
/*     */   public static void error(Shell shell, String caption, String message)
/*     */   {
/* 229 */     log(50, shell, caption, message);
/*     */   }
/*     */   
/*     */   public static void error(String message)
/*     */   {
/* 234 */     log(50, null, S.s(304), message);
/*     */   }
/*     */   
/*     */   public static boolean question(Shell shell, final String caption, final String message)
/*     */   {
/* 239 */     safeInit();
/* 240 */     final AtomicBoolean success = new AtomicBoolean();
/* 241 */     UIRunnable r = new UIRunnable()
/*     */     {
/*     */       public void runi() {
/* 244 */         Shell shell0 = this.val$shell != null ? this.val$shell : UI.shellTracker.get();
/* 245 */         if (shell0 != null) {
/* 246 */           success.set(MessageDialog.openQuestion(shell0, caption, message));
/*     */         }
/*     */       }
/*     */     };
/* 250 */     if (Thread.currentThread() == display.getThread()) {
/* 251 */       r.run();
/*     */     }
/*     */     else {
/* 254 */       UIExecutor.sync(display, r);
/*     */     }
/* 256 */     return success.get();
/*     */   }
/*     */   
/*     */   public static boolean infoOptional(Shell shell, String caption, String message, String widgetName) {
/* 260 */     return popupOptional(shell, 2, caption, message, widgetName);
/*     */   }
/*     */   
/*     */   public static boolean warnOptional(Shell shell, String caption, String message, String widgetName) {
/* 264 */     return popupOptional(shell, 8, caption, message, widgetName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String MOD3;
/*     */   
/*     */ 
/*     */   public static final String MOD4;
/*     */   
/*     */   public static boolean popupOptional(Shell shell, int style, String caption, String message, String widgetName)
/*     */   {
/* 276 */     if (widgetName == null) {
/* 277 */       throw new IllegalArgumentException();
/*     */     }
/* 279 */     if (message == null) {
/* 280 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 284 */     if ((style & 0x2) != 0) {
/* 285 */       logger.info(message, new Object[0]);
/*     */     }
/* 287 */     else if ((style & 0x8) != 0) {
/* 288 */       logger.warn(message, new Object[0]);
/*     */     }
/*     */     
/*     */ 
/* 292 */     IWidgetManager widgetManager = JebDialog.getStandardWidgetManager();
/* 293 */     if ((widgetManager == null) || (!widgetManager.getShouldShowDialog(widgetName))) {
/* 294 */       return false;
/*     */     }
/*     */     String title;
/*     */     String title;
/* 298 */     if (caption != null) {
/* 299 */       title = caption;
/*     */     }
/*     */     else {
/* 302 */       title = style == 2 ? "Warning" : style == 1 ? "Info" : "";
/*     */     }
/* 304 */     new AdaptivePopupDialog(shell, 1, title, message, widgetName).open();
/* 305 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\UI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */