/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.themes;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Theme
/*    */ {
/*    */   String id;
/*    */   String name;
/*    */   Color cBackground;
/*    */   Color cForeground;
/*    */   Color cBackgroundSelectedTab;
/*    */   Color cForegroundSelectedTab;
/*    */   Color cBackgroundTableHeader;
/*    */   Color cForegroundTableHeader;
/*    */   Color cBackgroundFilter;
/*    */   Color cForegroundFilter;
/*    */   Color cBackgroundReadOnlyText;
/*    */   Color cForegroundReadOnlyText;
/*    */   
/*    */   public Theme(String id, String name)
/*    */   {
/* 32 */     if (id == null) {
/* 33 */       throw new NullPointerException();
/*    */     }
/* 35 */     this.id = id;
/* 36 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 40 */     return this.id;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 45 */     return String.format("Theme{%s}", new Object[] { this.id });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\themes\Theme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */