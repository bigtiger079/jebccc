package com.pnfsoftware.jeb.rcpclient.extensions.themes;

public abstract interface IThemeChangeListener
{
  public abstract void onThemeChange(String paramString);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\themes\IThemeChangeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */