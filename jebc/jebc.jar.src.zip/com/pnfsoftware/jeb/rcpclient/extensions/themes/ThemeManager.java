/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.themes;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilterText;
/*     */ import com.pnfsoftware.jeb.util.collect.WeakIdentityHashMap;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThemeManager
/*     */ {
/*  43 */   private static final ILogger logger = GlobalLog.getLogger(ThemeManager.class);
/*     */   
/*     */ 
/*     */   public static final String ID_THEME_STANDARD = "theme.standard";
/*     */   
/*     */   public static final String ID_THEME_DARK = "theme.dark";
/*     */   
/*  50 */   private static ThemeManager instance = new ThemeManager();
/*     */   
/*     */   Display display;
/*     */   Listener filter;
/*  54 */   LinkedHashMap<String, Theme> themes = new LinkedHashMap();
/*     */   Theme activeTheme;
/*  56 */   List<IThemeChangeListener> listeners = new ArrayList();
/*     */   
/*  58 */   WeakIdentityHashMap<Widget, Integer> seen = new WeakIdentityHashMap();
/*     */   boolean firstSet;
/*     */   
/*  61 */   public static ThemeManager getInstance() { return instance; }
/*     */   
/*     */   private ThemeManager()
/*     */   {
/*  65 */     this.display = Display.getCurrent();
/*  66 */     if (this.display == null) {
/*  67 */       throw new RuntimeException("The display must be initialized");
/*     */     }
/*     */     
/*  70 */     this.themes.put("theme.standard", null);
/*  71 */     registerTheme(new DarkTheme());
/*     */     
/*     */ 
/*  74 */     this.filter = new Listener()
/*     */     {
/*     */       public void handleEvent(Event event)
/*     */       {
/*  78 */         ThemeManager.this.processControls(event.widget);
/*     */       }
/*  80 */     };
/*  81 */     this.display.addFilter(26, this.filter);
/*  82 */     this.display.addFilter(15, this.filter);
/*  83 */     this.display.addFilter(22, this.filter);
/*     */   }
/*     */   
/*     */   private void registerTheme(Theme theme) {
/*  87 */     if (this.themes.put(theme.getId(), theme) != null) {
/*  88 */       throw new RuntimeException("Attempt to overwrite a theme");
/*     */     }
/*     */   }
/*     */   
/*     */   public Collection<String> getThemes() {
/*  93 */     return Collections.unmodifiableCollection(this.themes.keySet());
/*     */   }
/*     */   
/*     */   public String getActiveTheme() {
/*  97 */     if (this.activeTheme == null) {
/*  98 */       return "theme.standard";
/*     */     }
/* 100 */     return this.activeTheme.getId();
/*     */   }
/*     */   
/*     */   public boolean isDarkTheme() {
/* 104 */     return (this.activeTheme != null) && ("theme.dark".equals(this.activeTheme.getId()));
/*     */   }
/*     */   
/*     */   public boolean setNextTheme() {
/* 108 */     List<String> ids = new ArrayList(this.themes.keySet());
/* 109 */     if (ids.size() <= 1) {
/* 110 */       return false;
/*     */     }
/*     */     
/* 113 */     if (this.activeTheme == null) {
/* 114 */       return setActiveTheme((String)ids.get(1));
/*     */     }
/*     */     
/* 117 */     for (int i = 1; i < ids.size(); i++) {
/* 118 */       String id = (String)ids.get(i);
/* 119 */       if (id.equals(this.activeTheme.getId())) {
/* 120 */         String nextId = (String)ids.get((i + 1) % ids.size());
/* 121 */         return setActiveTheme(nextId);
/*     */       }
/*     */     }
/*     */     
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public boolean setActiveTheme(String themeId) { Theme wantedTheme;
/*     */     Theme wantedTheme;
/* 130 */     if ((themeId == null) || (themeId.equals("theme.standard"))) {
/* 131 */       wantedTheme = null;
/*     */     }
/*     */     else {
/* 134 */       wantedTheme = (Theme)this.themes.get(themeId);
/* 135 */       if (wantedTheme == null) {
/* 136 */         return false;
/*     */       }
/*     */     }
/* 139 */     setThemeInternal(wantedTheme, true);
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   private void setThemeInternal(Theme theme, boolean notify) {
/* 144 */     if (theme == this.activeTheme) {
/* 145 */       return;
/*     */     }
/* 147 */     this.activeTheme = theme;
/*     */     
/*     */ 
/* 150 */     this.seen = new WeakIdentityHashMap();
/* 151 */     for (Shell shell : this.display.getShells()) {
/* 152 */       processControls(shell);
/*     */     }
/*     */     
/*     */ 
/* 156 */     if (notify) {
/* 157 */       notifyThemeChangeListeners(theme == null ? null : theme.getId());
/*     */     }
/*     */   }
/*     */   
/*     */   void processControls(Widget w) {
/* 162 */     if (w == null) {
/* 163 */       return;
/*     */     }
/*     */     
/*     */ 
/* 167 */     if (this.seen.get(w) != null) {
/* 168 */       return;
/*     */     }
/* 170 */     this.seen.put(w, Integer.valueOf(0));
/*     */     
/*     */ 
/* 173 */     if (!(w instanceof Control)) {
/* 174 */       return;
/*     */     }
/* 176 */     Control ctl = (Control)w;
/*     */     
/* 178 */     int r = processSpecificControl(ctl);
/*     */     
/*     */ 
/* 181 */     if ((r & 0x1) == 0) {
/* 182 */       if (ctl.getData("storedOriginalColors") == null) {
/* 183 */         ctl.setData("cBackground", ctl.getBackground());
/* 184 */         ctl.setData("cForeground", ctl.getForeground());
/* 185 */         ctl.setData("storedOriginalColors", Boolean.valueOf(true));
/*     */       }
/* 187 */       if (this.activeTheme == null) {
/* 188 */         ctl.setBackground((Color)ctl.getData("cBackground"));
/* 189 */         ctl.setForeground((Color)ctl.getData("cForeground"));
/*     */       }
/*     */       else {
/* 192 */         ctl.setBackground(this.activeTheme.cBackground);
/* 193 */         ctl.setForeground(this.activeTheme.cForeground);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 198 */     if (((r & 0x2) == 0) && 
/* 199 */       ((ctl instanceof Composite))) {
/* 200 */       for (Control c : ((Composite)ctl).getChildren()) {
/* 201 */         processControls(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static final int FLAG_PROCEED = 0;
/*     */   
/*     */   public static final int FLAG_SKIP_GENERIC = 1;
/*     */   
/*     */   public static final int FLAG_SKIP_RECURSION = 2;
/*     */   public static final int FLAG_SKIP_ALL = 3;
/*     */   private int processSpecificControl(Control ctl)
/*     */   {
/* 215 */     if ((ctl instanceof CTabFolder)) {
/* 216 */       CTabFolder c = (CTabFolder)ctl;
/* 217 */       if (ctl.getData("storedOriginalColors") == null) {
/* 218 */         ctl.setData("cBackgroundSelectedTab", c.getSelectionBackground());
/* 219 */         ctl.setData("cForegroundSelectedTab", c.getSelectionForeground());
/* 220 */         ctl.setData("storedOriginalColors", Boolean.valueOf(true));
/*     */       }
/* 222 */       if (this.activeTheme == null) {
/* 223 */         c.setSelectionBackground((Color)ctl.getData("cBackgroundSelectedTab"));
/* 224 */         c.setSelectionForeground((Color)ctl.getData("cForegroundSelectedTab"));
/*     */       }
/*     */       else {
/* 227 */         c.setSelectionBackground(this.activeTheme.cBackgroundSelectedTab);
/* 228 */         c.setSelectionForeground(this.activeTheme.cForegroundSelectedTab);
/*     */       }
/* 230 */       return 0;
/*     */     }
/*     */     
/* 233 */     if ((ctl instanceof Table)) {
/* 234 */       Table c = (Table)ctl;
/* 235 */       if (ctl.getData("storedOriginalColors") == null) {
/* 236 */         ctl.setData("cBackgroundTableHeader", c.getHeaderBackground());
/* 237 */         ctl.setData("cForegroundTableHeader", c.getHeaderForeground());
/* 238 */         ctl.setData("storedOriginalColors", Boolean.valueOf(true));
/*     */       }
/* 240 */       if (this.activeTheme == null) {
/* 241 */         c.setHeaderBackground((Color)ctl.getData("cBackgroundTableHeader"));
/* 242 */         c.setHeaderForeground((Color)ctl.getData("cForegroundTableHeader"));
/*     */       }
/*     */       else {
/* 245 */         c.setHeaderBackground(this.activeTheme.cBackgroundTableHeader);
/* 246 */         c.setHeaderForeground(this.activeTheme.cForegroundTableHeader);
/*     */       }
/* 248 */       return 0;
/*     */     }
/*     */     
/* 251 */     if ((ctl instanceof Tree)) {
/* 252 */       Tree c = (Tree)ctl;
/* 253 */       if (ctl.getData("storedOriginalColors") == null) {
/* 254 */         ctl.setData("cBackgroundTableHeader", c.getHeaderBackground());
/* 255 */         ctl.setData("cForegroundTableHeader", c.getHeaderForeground());
/* 256 */         ctl.setData("storedOriginalColors", Boolean.valueOf(true));
/*     */       }
/* 258 */       if (this.activeTheme == null) {
/* 259 */         c.setHeaderBackground((Color)ctl.getData("cBackgroundTableHeader"));
/* 260 */         c.setHeaderForeground((Color)ctl.getData("cForegroundTableHeader"));
/*     */       }
/*     */       else {
/* 263 */         c.setHeaderBackground(this.activeTheme.cBackgroundTableHeader);
/* 264 */         c.setHeaderForeground(this.activeTheme.cForegroundTableHeader);
/*     */       }
/* 266 */       return 0;
/*     */     }
/*     */     
/* 269 */     if ((ctl instanceof FilterText)) {
/* 270 */       if (ctl.getData("storedOriginalColors") == null) {
/* 271 */         ctl.setData("cBackgroundFilter", ctl.getBackground());
/* 272 */         ctl.setData("cForegroundFilter", ctl.getForeground());
/* 273 */         ctl.setData("storedOriginalColors", Boolean.valueOf(true));
/*     */       }
/* 275 */       if (this.activeTheme == null) {
/* 276 */         ctl.setBackground((Color)ctl.getData("cBackgroundFilter"));
/* 277 */         ctl.setForeground((Color)ctl.getData("cForegroundFilter"));
/*     */       }
/*     */       else {
/* 280 */         ctl.setBackground(this.activeTheme.cBackgroundFilter);
/* 281 */         ctl.setForeground(this.activeTheme.cForegroundFilter);
/*     */       }
/* 283 */       return 3;
/*     */     }
/*     */     
/*     */ 
/* 287 */     return 0;
/*     */   }
/*     */   
/*     */   public void addThemeChangeListener(IThemeChangeListener listener) {
/* 291 */     this.listeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeThemeChangeListener(IThemeChangeListener listener) {
/* 295 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   private void notifyThemeChangeListeners(String themeId) {
/* 299 */     for (IThemeChangeListener listener : this.listeners) {
/* 300 */       listener.onThemeChange(themeId);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\themes\ThemeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */