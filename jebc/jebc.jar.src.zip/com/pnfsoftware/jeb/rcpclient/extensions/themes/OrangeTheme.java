/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.themes;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.UIAssetManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrangeTheme
/*    */   extends Theme
/*    */ {
/* 17 */   private static final UIAssetManager ui = ;
/*    */   
/* 19 */   int normal = 12531212;
/* 20 */   int light = 16345146;
/* 21 */   int dark = 8847360;
/* 22 */   int text = 16119285;
/*    */   
/* 24 */   int normal2 = 16088064;
/* 25 */   int light2 = 16756034;
/* 26 */   int dark2 = 12274944;
/* 27 */   int text2 = 16119285;
/*    */   
/*    */   public OrangeTheme() {
/* 30 */     super("theme.orange", "Orange Theme");
/*    */     
/* 32 */     this.cBackground = ui.getColor(this.normal);
/* 33 */     this.cForeground = ui.getColor(this.text);
/*    */     
/* 35 */     this.cBackgroundSelectedTab = ui.getColor(this.light);
/* 36 */     this.cForegroundSelectedTab = ui.getColor(this.text);
/*    */     
/* 38 */     this.cBackgroundTableHeader = ui.getColor(this.normal2);
/* 39 */     this.cForegroundTableHeader = ui.getColor(this.text2);
/*    */     
/* 41 */     this.cBackgroundFilter = ui.getColor(this.light);
/* 42 */     this.cForegroundFilter = ui.getColor(this.text);
/*    */     
/* 44 */     this.cBackgroundReadOnlyText = ui.getColor(this.light);
/* 45 */     this.cForegroundReadOnlyText = ui.getColor(this.text);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\themes\OrangeTheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */