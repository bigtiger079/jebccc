/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.themes;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.UIAssetManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DarkTheme
/*    */   extends Theme
/*    */ {
/* 17 */   private static final UIAssetManager ui = ;
/*    */   
/* 19 */   int normal = 3622479;
/* 20 */   int light = 6451579;
/* 21 */   int dark = 1056551;
/* 22 */   int text = 14737632;
/*    */   
/* 24 */   int normal2 = 2503224;
/* 25 */   int light2 = 5200738;
/* 26 */   int dark2 = 2578;
/* 27 */   int text2 = 16119285;
/*    */   
/*    */   public DarkTheme() {
/* 30 */     super("theme.dark", "Dark Theme");
/*    */     
/* 32 */     this.cBackground = ui.getColor(this.normal);
/* 33 */     this.cForeground = ui.getColor(this.text);
/*    */     
/* 35 */     this.cBackgroundSelectedTab = ui.getColor(this.light);
/* 36 */     this.cForegroundSelectedTab = ui.getColor(this.text);
/*    */     
/* 38 */     this.cBackgroundTableHeader = ui.getColor(this.normal2);
/* 39 */     this.cForegroundTableHeader = ui.getColor(this.text2);
/*    */     
/* 41 */     this.cBackgroundFilter = ui.getColor(this.light);
/* 42 */     this.cForegroundFilter = ui.getColor(this.text);
/*    */     
/* 44 */     this.cBackgroundReadOnlyText = ui.getColor(this.light);
/* 45 */     this.cForegroundReadOnlyText = ui.getColor(this.text);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\themes\DarkTheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */