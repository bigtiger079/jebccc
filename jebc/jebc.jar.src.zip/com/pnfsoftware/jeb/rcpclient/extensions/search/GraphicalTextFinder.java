/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.search;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.IGraphicalTaskExecutor;
/*    */ import com.pnfsoftware.jeb.util.concurrent.MonitorInfoAdapter;
/*    */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphicalTextFinder<FindTextResult extends IFindTextResult>
/*    */ {
/*    */   private IFindTextImpl<FindTextResult> target;
/*    */   private IGraphicalTaskExecutor taskExecutor;
/*    */   private FindTextResult lastResult;
/*    */   private boolean searchInterrupted;
/*    */   
/*    */   public GraphicalTextFinder(IFindTextImpl<FindTextResult> target, IGraphicalTaskExecutor taskExecutor)
/*    */   {
/* 28 */     if (target == null) {
/* 29 */       throw new NullPointerException();
/*    */     }
/* 31 */     this.target = target;
/*    */     
/* 33 */     this.taskExecutor = taskExecutor;
/*    */   }
/*    */   
/*    */   public IFindTextImpl<?> getFindTextImpl() {
/* 37 */     return this.target;
/*    */   }
/*    */   
/*    */   public boolean isReady() {
/* 41 */     return this.target.getFindTextOptions(false).getSearchString().length() > 0;
/*    */   }
/*    */   
/*    */   public synchronized void search(final FindTextOptions opt)
/*    */   {
/* 46 */     this.target.getFindTextOptions(true);
/*    */     
/* 48 */     this.lastResult = null;
/* 49 */     this.searchInterrupted = false;
/*    */     
/*    */ 
/* 52 */     if (this.taskExecutor == null) {
/* 53 */       this.lastResult = this.target.findText(opt);
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/* 58 */       MonitorInfoAdapter monitor = new MonitorInfoAdapter(3000L, 300L)
/*    */       {
/*    */         public void onInterrupt() {
/* 61 */           GraphicalTextFinder.this.searchInterrupted = true;
/*    */         }
/* 63 */       };
/* 64 */       ThreadUtil.monitor(ThreadUtil.start(new Runnable()
/*    */       {
/*    */ 
/* 67 */         public void run() { GraphicalTextFinder.this.lastResult = GraphicalTextFinder.this.target.findText(opt); } }), monitor);
/*    */       
/*    */ 
/*    */ 
/* 71 */       if (this.lastResult == null)
/*    */       {
/* 73 */         if (!this.searchInterrupted) {
/* 74 */           return;
/*    */         }
/*    */         
/*    */ 
/*    */ 
/* 79 */         this.taskExecutor.executeTask(S.s(714) + "...", new Runnable()
/*    */         {
/*    */           public void run() {
/* 82 */             GraphicalTextFinder.this.lastResult = GraphicalTextFinder.this.target.findText(opt);
/*    */           }
/*    */         });
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 89 */     if (this.lastResult != null) {
/* 90 */       this.target.processFindResult(this.lastResult);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\search\GraphicalTextFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */