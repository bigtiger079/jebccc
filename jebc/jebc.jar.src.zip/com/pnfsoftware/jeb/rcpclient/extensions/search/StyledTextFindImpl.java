/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.search;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.custom.StyledText;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyledTextFindImpl
/*     */   implements IFindTextImpl<SimpleTextFindResults>
/*     */ {
/*  23 */   private static final ILogger logger = GlobalLog.getLogger(StyledTextFindImpl.class);
/*     */   
/*     */   StyledText widget;
/*     */   FindTextOptions findOptions;
/*     */   String text;
/*     */   int position;
/*     */   
/*     */   public StyledTextFindImpl(StyledText widget)
/*     */   {
/*  32 */     if (widget == null) {
/*  33 */       throw new NullPointerException();
/*     */     }
/*  35 */     this.widget = widget;
/*     */   }
/*     */   
/*     */   public boolean supportReverseSearch()
/*     */   {
/*  40 */     return true;
/*     */   }
/*     */   
/*     */   public void resetFindTextOptions()
/*     */   {
/*  45 */     this.findOptions = null;
/*     */   }
/*     */   
/*     */   public void setFindTextOptions(FindTextOptions options)
/*     */   {
/*  50 */     this.findOptions = options;
/*     */   }
/*     */   
/*     */   public FindTextOptions getFindTextOptions(boolean update)
/*     */   {
/*  55 */     if (this.findOptions == null) {
/*  56 */       this.findOptions = new FindTextOptions(this.widget.getSelectionText());
/*     */     }
/*  58 */     if (update) {
/*  59 */       this.text = this.widget.getText();
/*  60 */       this.position = this.widget.getCaretOffset();
/*     */     }
/*  62 */     return this.findOptions;
/*     */   }
/*     */   
/*     */   public SimpleTextFindResults findText(FindTextOptions optionsOverride)
/*     */   {
/*  67 */     if (this.text == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     FindTextOptions options = optionsOverride != null ? optionsOverride : this.findOptions;
/*  71 */     if ((options == null) || (options.getSearchString() == null) || (options.getSearchString().isEmpty())) {
/*  72 */       return null;
/*     */     }
/*     */     
/*  75 */     boolean wrappedAround = false;
/*     */     for (;;) {
/*  77 */       int index = Strings.search(this.text, this.position, options.getSearchString(), options.isRegularExpression(), options
/*  78 */         .isCaseSensitive(), options.isReverseSearch());
/*  79 */       if (index >= 0) {
/*  80 */         return new SimpleTextFindResults(index, index + options.getSearchString().length(), wrappedAround);
/*     */       }
/*     */       
/*  83 */       if (!options.isWrapAround()) {
/*     */         break;
/*     */       }
/*     */       
/*  87 */       if (!options.isReverseSearch()) {
/*  88 */         if (this.position == 0) {
/*     */           break;
/*     */         }
/*  91 */         this.position = 0;
/*     */       }
/*     */       else {
/*  94 */         if (this.position == this.text.length()) {
/*     */           break;
/*     */         }
/*  97 */         this.position = this.text.length();
/*     */       }
/*  99 */       wrappedAround = true;
/*     */     }
/*     */     
/* 102 */     return SimpleTextFindResults.EOS;
/*     */   }
/*     */   
/*     */   public void processFindResult(SimpleTextFindResults r)
/*     */   {
/* 107 */     if (r == null) {
/* 108 */       return;
/*     */     }
/* 110 */     if (r.isEndOfSearch()) {
/* 111 */       Display.getCurrent().beep();
/* 112 */       logger.warn("End of search", new Object[0]);
/* 113 */       return;
/*     */     }
/* 115 */     if (r.isWrappedAround()) {
/* 116 */       Display.getCurrent().beep();
/* 117 */       logger.warn("Search wrapped around", new Object[0]);
/*     */     }
/* 119 */     if (!this.findOptions.isReverseSearch()) {
/* 120 */       this.widget.setSelection(r.getIndexBegin(), r.getIndexEnd());
/*     */     }
/*     */     else {
/* 123 */       this.widget.setSelection(r.getIndexEnd(), r.getIndexBegin());
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearFindResult()
/*     */   {
/* 129 */     int offset = this.widget.getCaretOffset();
/* 130 */     this.widget.setSelection(offset);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\search\StyledTextFindImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */