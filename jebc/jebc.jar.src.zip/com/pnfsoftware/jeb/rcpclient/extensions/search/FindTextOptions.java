/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.search;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FindTextOptions
/*    */ {
/*    */   private String searchString;
/*    */   private boolean caseSensitive;
/*    */   private boolean regex;
/*    */   private boolean reverseSearch;
/*    */   private boolean wrapAround;
/*    */   
/*    */   public FindTextOptions()
/*    */   {
/* 25 */     this.searchString = "";
/*    */   }
/*    */   
/*    */   public FindTextOptions(String initialSearchString) {
/* 29 */     this.searchString = Strings.safe(initialSearchString);
/*    */   }
/*    */   
/*    */   public FindTextOptions clone()
/*    */   {
/* 34 */     FindTextOptions dst = new FindTextOptions(this.searchString);
/* 35 */     dst.caseSensitive = this.caseSensitive;
/* 36 */     dst.regex = this.regex;
/* 37 */     dst.reverseSearch = this.reverseSearch;
/* 38 */     dst.wrapAround = this.wrapAround;
/* 39 */     return dst;
/*    */   }
/*    */   
/*    */   public String getSearchString() {
/* 43 */     return this.searchString;
/*    */   }
/*    */   
/*    */   public void setSearchString(String searchString) {
/* 47 */     this.searchString = searchString;
/*    */   }
/*    */   
/*    */   public boolean isCaseSensitive() {
/* 51 */     return this.caseSensitive;
/*    */   }
/*    */   
/*    */   public void setCaseSensitive(boolean caseSensitive) {
/* 55 */     this.caseSensitive = caseSensitive;
/*    */   }
/*    */   
/*    */   public boolean isRegularExpression() {
/* 59 */     return this.regex;
/*    */   }
/*    */   
/*    */   public void setRegularExpression(boolean regex) {
/* 63 */     this.regex = regex;
/*    */   }
/*    */   
/*    */   public boolean isReverseSearch() {
/* 67 */     return this.reverseSearch;
/*    */   }
/*    */   
/*    */   public void setReverseSearch(boolean reverseSearch) {
/* 71 */     this.reverseSearch = reverseSearch;
/*    */   }
/*    */   
/*    */   public boolean isWrapAround() {
/* 75 */     return this.wrapAround;
/*    */   }
/*    */   
/*    */   public void setWrapAround(boolean wrapAround) {
/* 79 */     this.wrapAround = wrapAround;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 84 */     return String.format("\"%s\"", new Object[] { this.searchString });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\search\FindTextOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */