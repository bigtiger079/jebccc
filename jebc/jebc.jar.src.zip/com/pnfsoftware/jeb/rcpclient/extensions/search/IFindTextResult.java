package com.pnfsoftware.jeb.rcpclient.extensions.search;

public abstract interface IFindTextResult
{
  public abstract boolean isEndOfSearch();
  
  public abstract boolean isWrappedAround();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\search\IFindTextResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */