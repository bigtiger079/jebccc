/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.search;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTextFindResults
/*    */   implements IFindTextResult
/*    */ {
/* 16 */   public static SimpleTextFindResults EOS = new SimpleTextFindResults(-1);
/*    */   private int indexBegin;
/*    */   private int indexEnd;
/*    */   private int flag;
/*    */   
/*    */   public SimpleTextFindResults(int flag)
/*    */   {
/* 23 */     this.flag = flag;
/*    */   }
/*    */   
/*    */   public SimpleTextFindResults(int indexBegin, int indexEnd, boolean wrappedAround) {
/* 27 */     this.indexBegin = indexBegin;
/* 28 */     this.indexEnd = indexEnd;
/* 29 */     this.flag = (wrappedAround ? 1 : 0);
/*    */   }
/*    */   
/*    */   public boolean isEndOfSearch()
/*    */   {
/* 34 */     return this.flag == -1;
/*    */   }
/*    */   
/*    */   public boolean isWrappedAround()
/*    */   {
/* 39 */     return this.flag == 1;
/*    */   }
/*    */   
/*    */   public int getIndexBegin() {
/* 43 */     return this.indexBegin;
/*    */   }
/*    */   
/*    */   public int getIndexEnd() {
/* 47 */     return this.indexEnd;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return String.format("%d-%d", new Object[] { Integer.valueOf(this.indexBegin), Integer.valueOf(this.indexEnd) });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\search\SimpleTextFindResults.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */