/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.resource.FontDescriptor;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwtRegistry
/*     */ {
/*  30 */   private static final ILogger logger = GlobalLog.getLogger(SwtRegistry.class);
/*     */   
/*  32 */   private static SwtRegistry manager = null;
/*     */   
/*     */   protected Display display;
/*     */   
/*     */   public static SwtRegistry getInstance()
/*     */   {
/*  38 */     if (manager == null) {
/*  39 */       manager = new SwtRegistry();
/*     */     }
/*  41 */     return manager;
/*     */   }
/*     */   
/*     */ 
/*  45 */   protected Map<RGB, Color> colors = new HashMap();
/*  46 */   protected Map<FontDescriptor, Font> fonts = new HashMap();
/*     */   
/*     */   protected SwtRegistry() {
/*  49 */     this(Display.getCurrent());
/*     */   }
/*     */   
/*     */   protected SwtRegistry(Display display) {
/*  53 */     if (display == null) {
/*  54 */       throw new IllegalArgumentException("Needs a display");
/*     */     }
/*  56 */     this.display = display;
/*     */   }
/*     */   
/*     */   public Display getDisplay() {
/*  60 */     return this.display;
/*     */   }
/*     */   
/*     */   public Color getColor(RGB rgb) {
/*  64 */     Color color = (Color)this.colors.get(rgb);
/*  65 */     if (color == null) {
/*  66 */       color = new Color(this.display, rgb);
/*  67 */       this.colors.put(rgb, color);
/*     */     }
/*  69 */     return color;
/*     */   }
/*     */   
/*     */   public Color getColor(int rgb) {
/*  73 */     return getColor(new RGB(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF));
/*     */   }
/*     */   
/*     */   public Color getColor(int r, int g, int b) {
/*  77 */     return getColor(new RGB(r, g, b));
/*     */   }
/*     */   
/*     */   public Color getSystemColor(int id) {
/*  81 */     return this.display.getSystemColor(id);
/*     */   }
/*     */   
/*     */   public Font getFont(FontDescriptor desc) {
/*  85 */     Font font = (Font)this.fonts.get(desc);
/*  86 */     if (font == null) {
/*  87 */       font = desc.createFont(this.display);
/*  88 */       this.fonts.put(desc, font);
/*     */     }
/*  90 */     return font;
/*     */   }
/*     */   
/*     */   public Font getFont(FontData data) {
/*  94 */     FontDescriptor desc = FontDescriptor.createFrom(data);
/*  95 */     return getFont(desc);
/*     */   }
/*     */   
/*     */   public Font getFont(FontData[] data) {
/*  99 */     FontDescriptor desc = FontDescriptor.createFrom(data);
/* 100 */     return getFont(desc);
/*     */   }
/*     */   
/*     */   public Font getFont(String name, int height, int style) {
/* 104 */     return getFont(new FontData(name, height, style));
/*     */   }
/*     */   
/*     */   public Font getFont(Font basefont, Integer height, Integer style) {
/* 108 */     FontDescriptor desc = FontDescriptor.createFrom(basefont);
/* 109 */     if (height != null) {
/* 110 */       desc = desc.setHeight(height.intValue());
/*     */     }
/* 112 */     if (style != null) {
/* 113 */       desc = desc.setStyle(style.intValue());
/*     */     }
/* 115 */     return getFont(desc);
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 119 */     for (Color color : this.colors.values()) {
/* 120 */       color.dispose();
/*     */     }
/* 122 */     for (Font font : this.fonts.values()) {
/* 123 */       font.dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\SwtRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */