package com.pnfsoftware.jeb.rcpclient.extensions.viewers;

public abstract interface IInfiniTableSectionProvider
  extends IFilteredTableContentProvider
{
  public abstract Object[] get(Object paramObject, long paramLong, int paramInt);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\IInfiniTableSectionProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */