/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredViewerComparator
/*     */   extends ViewerComparator
/*     */ {
/*     */   AbstractFilteredViewer<?, ?> v;
/*     */   int propertyIndex;
/*     */   int direction;
/*     */   
/*     */   public FilteredViewerComparator(Comparator<? super String> comp, AbstractFilteredViewer<?, ?> v)
/*     */   {
/*  27 */     super(comp);
/*  28 */     this.v = v;
/*     */     
/*  30 */     this.propertyIndex = -1;
/*  31 */     this.direction = 0;
/*     */   }
/*     */   
/*     */   public FilteredViewerComparator(AbstractFilteredViewer<?, ?> v) {
/*  35 */     this(null, v);
/*     */   }
/*     */   
/*     */   public int getDirection() {
/*  39 */     return this.direction;
/*     */   }
/*     */   
/*     */   public void setColumn(int column) {
/*  43 */     if (column == this.propertyIndex) {
/*  44 */       if (this.direction == 0) {
/*  45 */         this.direction = 128;
/*     */       }
/*  47 */       else if (this.direction == 128) {
/*  48 */         this.direction = 1024;
/*     */       }
/*  50 */       else if (this.direction == 1024) {
/*  51 */         this.direction = 0;
/*     */       }
/*     */     }
/*     */     else {
/*  55 */       this.propertyIndex = column;
/*  56 */       this.direction = 128;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int compare(Viewer viewer, Object e1, Object e2)
/*     */   {
/*  63 */     if (this.propertyIndex < 0) {
/*  64 */       return 0;
/*     */     }
/*  66 */     if (this.direction == 0) {
/*  67 */       return 0;
/*     */     }
/*     */     
/*  70 */     Object[] l1 = this.v.getContentProvider().getRowElements(e1);
/*  71 */     Object[] l2 = this.v.getContentProvider().getRowElements(e2);
/*     */     
/*  73 */     Object o1 = this.propertyIndex < l1.length ? l1[this.propertyIndex] : null;
/*  74 */     Object o2 = this.propertyIndex < l2.length ? l2[this.propertyIndex] : null;
/*     */     
/*     */ 
/*  77 */     int i = 0;
/*  78 */     while ((i < 5) && ((o1 instanceof Object[])) && ((o2 instanceof Object[]))) {
/*  79 */       if ((((Object[])o1).length > 0) && (((Object[])o2).length > 0)) {
/*  80 */         o1 = ((Object[])(Object[])o1)[0];
/*  81 */         o2 = ((Object[])(Object[])o2)[0];
/*     */       }
/*  83 */       i++;
/*     */     }
/*     */     
/*  86 */     int rc = 0;
/*  87 */     if (((o1 instanceof String)) && ((o2 instanceof String))) {
/*  88 */       rc = getComparator().compare((String)o1, (String)o2);
/*     */     }
/*  90 */     else if (((o1 instanceof Comparable)) && ((o2 instanceof Comparable)) && (o1.getClass() == o2.getClass())) {
/*  91 */       rc = ((Comparable)o1).compareTo(o2);
/*     */     }
/*     */     else {
/*  94 */       if (o1 == null) {
/*  95 */         o1 = "";
/*     */       }
/*  97 */       if (o2 == null) {
/*  98 */         o2 = "";
/*     */       }
/* 100 */       rc = getComparator().compare(o1.toString(), o2.toString());
/*     */     }
/* 102 */     return this.direction == 128 ? rc : -rc;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\FilteredViewerComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */