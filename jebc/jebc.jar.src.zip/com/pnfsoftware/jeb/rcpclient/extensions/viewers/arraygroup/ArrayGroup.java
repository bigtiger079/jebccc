/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayGroup
/*    */   implements IArrayGroup
/*    */ {
/*    */   int firstIndex;
/* 24 */   List<Object> children = new ArrayList();
/*    */   
/*    */   public ArrayGroup(int firstIndex) {
/* 27 */     this.firstIndex = firstIndex;
/*    */   }
/*    */   
/*    */   public void add(Object child) {
/* 31 */     this.children.add(child);
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 36 */     Object lastElement = this.children.get(this.children.size() - 1);
/* 37 */     if ((lastElement instanceof ArrayGroup)) {
/* 38 */       return ((ArrayGroup)lastElement).getLastElementIndex();
/*    */     }
/* 40 */     return getFirstElementIndex() + this.children.size() - 1;
/*    */   }
/*    */   
/*    */   public int getFirstElementIndex()
/*    */   {
/* 45 */     return this.firstIndex;
/*    */   }
/*    */   
/*    */   public Object getFirstElement()
/*    */   {
/* 50 */     Object first = this.children.get(0);
/* 51 */     if ((first instanceof IArrayGroup)) {
/* 52 */       return ((IArrayGroup)first).getFirstElement();
/*    */     }
/* 54 */     return first;
/*    */   }
/*    */   
/*    */   public Object getLastElement()
/*    */   {
/* 59 */     Object last = this.children.get(this.children.size() - 1);
/* 60 */     if ((last instanceof IArrayGroup)) {
/* 61 */       return ((IArrayGroup)last).getLastElement();
/*    */     }
/* 63 */     return last;
/*    */   }
/*    */   
/*    */   public boolean isSingle()
/*    */   {
/* 68 */     return this.children.size() == 1;
/*    */   }
/*    */   
/*    */   public List<Object> getChildren()
/*    */   {
/* 73 */     return this.children;
/*    */   }
/*    */   
/*    */   public int size()
/*    */   {
/* 78 */     return this.children.size();
/*    */   }
/*    */   
/*    */   public String getGroupName()
/*    */   {
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\arraygroup\ArrayGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */