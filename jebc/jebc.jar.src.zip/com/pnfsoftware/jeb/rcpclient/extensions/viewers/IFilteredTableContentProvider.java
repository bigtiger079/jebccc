package com.pnfsoftware.jeb.rcpclient.extensions.viewers;

public abstract interface IFilteredTableContentProvider
  extends IFilteredContentProvider
{
  public abstract boolean isChecked(Object paramObject);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\IFilteredTableContentProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */