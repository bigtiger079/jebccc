/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IOutOfRangeHelper;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.InfiniTableView;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.jface.viewers.IBaseLabelProvider;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.IStructuredContentProvider;
/*     */ import org.eclipse.jface.viewers.TableViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.events.ControlAdapter;
/*     */ import org.eclipse.swt.events.ControlEvent;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfiniTableViewer
/*     */   extends Viewer
/*     */ {
/*  33 */   private static final ILogger logger = GlobalLog.getLogger(InfiniTableViewer.class);
/*     */   
/*     */   private InfiniTableView ctl;
/*     */   
/*     */   private Table table;
/*     */   private TableViewer wrappedViewer;
/*     */   private IInfiniTableSectionProvider clientContentProvider;
/*  40 */   private long minAllowedId = Long.MIN_VALUE;
/*     */   
/*     */   private long sectionBase;
/*     */   private int sectionSize;
/*     */   
/*     */   public InfiniTableViewer(final InfiniTableView ctl)
/*     */   {
/*  47 */     this.ctl = ctl;
/*  48 */     this.table = ctl.getTable();
/*     */     
/*  50 */     ctl.setRequestOutOfRangeHandler(new IOutOfRangeHelper()
/*     */     {
/*     */       public void onResetRange(int delta)
/*     */       {
/*  54 */         InfiniTableViewer.this.sectionBase = (InfiniTableViewer.this.sectionBase + delta);
/*  55 */         InfiniTableViewer.this.sectionSize = 0;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  60 */         Object input = InfiniTableViewer.this.wrappedViewer.getInput();
/*  61 */         InfiniTableViewer.this.wrappedViewer.setInput(null);
/*  62 */         InfiniTableViewer.this.wrappedViewer.setInput(input);
/*     */         
/*  64 */         InfiniTableViewer.this.table.setTopIndex(0);
/*     */       }
/*     */       
/*     */ 
/*     */       public void onRequestOutOfRange(int selDelta, int topDelta)
/*     */       {
/*  70 */         int selIndex = InfiniTableViewer.this.table.getSelectionIndex();
/*  71 */         int topIndex = InfiniTableViewer.this.table.getTopIndex();
/*  72 */         int newSelIndex = selIndex + selDelta;
/*  73 */         int newTopIndex = topIndex + topDelta;
/*     */         
/*  75 */         if ((selDelta != 0) && (topDelta == 0)) {
/*  76 */           if (newSelIndex < 0) {
/*  77 */             if (InfiniTableViewer.this.sectionBase + selDelta < InfiniTableViewer.this.minAllowedId) {
/*  78 */               return;
/*     */             }
/*  80 */             InfiniTableViewer.this.sectionBase = (InfiniTableViewer.this.sectionBase + selDelta);
/*  81 */             InfiniTableViewer.this.wrappedViewer.refresh();
/*     */           }
/*  83 */           else if (newSelIndex >= InfiniTableViewer.this.table.getItemCount()) {
/*  84 */             int gap = InfiniTableViewer.this.table.getItemCount() - selIndex - 1;
/*  85 */             InfiniTableViewer.this.sectionBase = (InfiniTableViewer.this.sectionBase + (selDelta - gap));
/*  86 */             InfiniTableViewer.this.wrappedViewer.refresh();
/*     */           }
/*  88 */           InfiniTableViewer.this.table.setSelection(selIndex);
/*     */           
/*  90 */           selIndex = newSelIndex;
/*  91 */           selDelta = 0;
/*     */         }
/*  93 */         else if ((selDelta == 0) && (topDelta != 0)) {
/*  94 */           if (newTopIndex > topIndex) {
/*  95 */             InfiniTableViewer.this.sectionSize = (InfiniTableViewer.this.sectionSize + topDelta);
/*  96 */             InfiniTableViewer.this.wrappedViewer.refresh();
/*  97 */             InfiniTableViewer.this.table.setSelection(newSelIndex);
/*  98 */             InfiniTableViewer.this.table.setTopIndex(newTopIndex);
/*     */           }
/* 100 */           else if (newTopIndex < topIndex) {
/* 101 */             if (InfiniTableViewer.this.sectionBase + topDelta < InfiniTableViewer.this.minAllowedId) {
/* 102 */               return;
/*     */             }
/* 104 */             InfiniTableViewer.this.sectionBase = (InfiniTableViewer.this.sectionBase + topDelta);
/* 105 */             InfiniTableViewer.this.sectionSize = (InfiniTableViewer.this.sectionSize - topDelta);
/* 106 */             InfiniTableViewer.this.wrappedViewer.refresh();
/* 107 */             InfiniTableViewer.this.table.setSelection(selIndex - topDelta);
/* 108 */             InfiniTableViewer.this.table.setTopIndex(topIndex);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 113 */     });
/* 114 */     ctl.addControlListener(new ControlAdapter()
/*     */     {
/*     */       public void controlResized(ControlEvent e) {
/* 117 */         InfiniTableViewer.this.wrappedViewer.refresh();
/*     */       }
/*     */       
/* 120 */     });
/* 121 */     this.wrappedViewer = new TableViewer(this.table);
/*     */     
/* 123 */     this.wrappedViewer.setContentProvider(new IStructuredContentProvider()
/*     */     {
/*     */       public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
/* 126 */         InfiniTableViewer.this.clientContentProvider.inputChanged(viewer, oldInput, newInput);
/*     */       }
/*     */       
/*     */ 
/*     */       public void dispose()
/*     */       {
/* 132 */         InfiniTableViewer.this.clientContentProvider.dispose();
/*     */       }
/*     */       
/*     */       public Object[] getElements(Object inputElement)
/*     */       {
/* 137 */         int visicount = ctl.getMaximumVisibleRowCount(true);
/*     */         
/* 139 */         Object[] data = InfiniTableViewer.this.clientContentProvider.get(inputElement, InfiniTableViewer.this.sectionBase, InfiniTableViewer.this.sectionSize + visicount);
/*     */         
/* 141 */         return data;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void setTopId(long startId, boolean doRefresh) {
/* 147 */     this.sectionBase = startId;
/* 148 */     if (doRefresh) {
/* 149 */       refresh();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMinimumAllowedId(long minAllowedId) {
/* 154 */     this.minAllowedId = minAllowedId;
/*     */   }
/*     */   
/*     */   public long getMinimumAllowedId() {
/* 158 */     return this.minAllowedId;
/*     */   }
/*     */   
/*     */   public void setContentProvider(IInfiniTableSectionProvider provider)
/*     */   {
/* 163 */     this.clientContentProvider = provider;
/*     */   }
/*     */   
/*     */   public void setLabelProvider(IBaseLabelProvider provider) {
/* 167 */     this.wrappedViewer.setLabelProvider(provider);
/*     */   }
/*     */   
/*     */   public Control getControl()
/*     */   {
/* 172 */     return this.ctl;
/*     */   }
/*     */   
/*     */   public void setInput(Object input)
/*     */   {
/* 177 */     this.wrappedViewer.setInput(input);
/*     */   }
/*     */   
/*     */   public Object getInput()
/*     */   {
/* 182 */     return this.wrappedViewer.getInput();
/*     */   }
/*     */   
/*     */   public void refresh()
/*     */   {
/* 187 */     this.wrappedViewer.refresh();
/*     */   }
/*     */   
/*     */   public ISelection getSelection()
/*     */   {
/* 192 */     return this.wrappedViewer.getSelection();
/*     */   }
/*     */   
/*     */   public void setSelection(ISelection selection, boolean reveal)
/*     */   {
/* 197 */     throw new RuntimeException("TBI");
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\InfiniTableViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */