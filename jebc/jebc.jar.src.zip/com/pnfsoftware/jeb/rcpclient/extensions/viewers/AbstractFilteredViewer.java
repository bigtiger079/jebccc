/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.AbstractFilteredView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.IFilterText;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.filter.AbstractFilteredFilter;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.IPattern;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.SimplePattern;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.eclipse.jface.viewers.ColumnViewer;
/*     */ import org.eclipse.jface.viewers.IBaseLabelProvider;
/*     */ import org.eclipse.jface.viewers.IDoubleClickListener;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.ISelectionChangedListener;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFilteredViewer<T extends Composite, V extends ColumnViewer>
/*     */   extends Viewer
/*     */ {
/*     */   private AbstractFilteredView<T> widget;
/*     */   private V viewer;
/*     */   AbstractFilteredFilter filter;
/*     */   protected IFilteredContentProvider provider;
/*     */   protected FilteredViewerComparator comparator;
/*     */   private boolean displayFilteredRowCount;
/*  47 */   private IPattern filterPatternFactory = new SimplePattern("");
/*     */   private IFilterText filterText;
/*  49 */   private List<Listener> filterDoneListeners = new ArrayList();
/*     */   
/*     */   public AbstractFilteredViewer(AbstractFilteredView<T> widget) {
/*  52 */     this.widget = widget;
/*     */     
/*  54 */     this.viewer = buildViewer(widget);
/*     */     
/*  56 */     this.filter = buildFilter(this.viewer);
/*  57 */     this.viewer.addFilter(this.filter);
/*     */     
/*  59 */     this.filterText = widget.getFilterText();
/*  60 */     this.filterText.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e) {
/*  63 */         if (e.character != '\r')
/*     */         {
/*  65 */           AbstractFilteredViewer.this.filterText.setStatus(null);
/*  66 */           return;
/*     */         }
/*  68 */         Object result = AbstractFilteredViewer.this.applyFilterText();
/*     */         
/*  70 */         Event event = new Event();
/*  71 */         event.widget = AbstractFilteredViewer.this.widget;
/*  72 */         event.data = result;
/*  73 */         for (Listener l : AbstractFilteredViewer.this.filterDoneListeners) {
/*  74 */           l.handleEvent(event);
/*     */         }
/*     */         
/*     */       }
/*  78 */     });
/*  79 */     refreshItemCountLabel();
/*     */   }
/*     */   
/*     */   public Object applyFilterText() {
/*  83 */     IFilterText filterText = this.widget.getFilterText();
/*  84 */     String filterString = filterText.getText();
/*  85 */     Object result = null;
/*     */     
/*  87 */     if ((filterString == null) || (filterString.length() == 0)) {
/*  88 */       this.filter.setFilterText(null, true);
/*  89 */       filterText.setStatus(null);
/*     */       
/*  91 */       result = doAfterEmptyFilter();
/*     */     }
/*     */     else {
/*  94 */       doBeforeNotNullFilter();
/*     */       try {
/*  96 */         this.filter.setFilterPattern(this.filterPatternFactory.createInstance(filterString), true);
/*  97 */         filterText.setStatus(Boolean.TRUE);
/*     */       }
/*     */       catch (PatternSyntaxException ex) {
/* 100 */         String text = filterString.toLowerCase();
/* 101 */         this.filter.setFilterText(text, true);
/* 102 */         filterText.setStatus(Boolean.FALSE);
/*     */       }
/* 104 */       result = doAfterNotNullFilter();
/*     */     }
/*     */     
/* 107 */     refreshItemCountLabel();
/* 108 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isFiltered() {
/* 112 */     return this.filter.isFiltered();
/*     */   }
/*     */   
/*     */   protected abstract V buildViewer(AbstractFilteredView<T> paramAbstractFilteredView);
/*     */   
/*     */   protected abstract AbstractFilteredFilter buildFilter(V paramV);
/*     */   
/*     */   protected Object doAfterEmptyFilter() {
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   protected void doBeforeNotNullFilter() {}
/*     */   
/*     */   protected Object doAfterNotNullFilter()
/*     */   {
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   public AbstractFilteredView<T> getControl()
/*     */   {
/* 132 */     return this.widget;
/*     */   }
/*     */   
/*     */   public void setInput(Object input)
/*     */   {
/* 137 */     this.viewer.setInput(input);
/*     */   }
/*     */   
/*     */   public Object getInput()
/*     */   {
/* 142 */     return this.viewer.getInput();
/*     */   }
/*     */   
/*     */   public void setSelection(ISelection selection, boolean reveal)
/*     */   {
/* 147 */     this.viewer.setSelection(selection, reveal);
/*     */   }
/*     */   
/*     */   public ISelection getSelection()
/*     */   {
/* 152 */     return this.viewer.getSelection();
/*     */   }
/*     */   
/*     */   public void refresh()
/*     */   {
/* 157 */     UIUtil.safeRefreshViewer(this.viewer);
/*     */   }
/*     */   
/*     */   public void setLabelProvider(IBaseLabelProvider provider) {
/* 161 */     this.viewer.setLabelProvider(provider);
/*     */   }
/*     */   
/*     */   protected void setContentProvider(IFilteredContentProvider provider) {
/* 165 */     this.provider = provider;
/* 166 */     this.viewer.setContentProvider(provider);
/*     */   }
/*     */   
/*     */   public IFilteredContentProvider getContentProvider() {
/* 170 */     return this.provider;
/*     */   }
/*     */   
/*     */   public void setDisplayFilteredRowCount(boolean enabled) {
/* 174 */     if (this.displayFilteredRowCount != enabled) {
/* 175 */       this.displayFilteredRowCount = enabled;
/* 176 */       refreshItemCountLabel();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void refreshItemCountLabel() {
/* 181 */     if (this.displayFilteredRowCount) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterPatternFactory(IPattern pattern)
/*     */   {
/* 191 */     this.filterPatternFactory = pattern;
/*     */   }
/*     */   
/*     */   protected AbstractFilteredView<T> getWidget() {
/* 195 */     return this.widget;
/*     */   }
/*     */   
/*     */   public V getViewer() {
/* 199 */     return this.viewer;
/*     */   }
/*     */   
/*     */   public void addDoubleClickListener(IDoubleClickListener listener) {
/* 203 */     this.viewer.addDoubleClickListener(listener);
/*     */   }
/*     */   
/*     */   public void removeDoubleClickListener(IDoubleClickListener listener) {
/* 207 */     this.viewer.removeDoubleClickListener(listener);
/*     */   }
/*     */   
/*     */   public void addSelectionChangedListener(ISelectionChangedListener listener)
/*     */   {
/* 212 */     this.viewer.addSelectionChangedListener(listener);
/*     */   }
/*     */   
/*     */   public void removeSelectionChangedListener(ISelectionChangedListener listener)
/*     */   {
/* 217 */     this.viewer.removeSelectionChangedListener(listener);
/*     */   }
/*     */   
/*     */   public void addFilteredTextListener(Listener listener) {
/* 221 */     this.filterDoneListeners.add(listener);
/*     */   }
/*     */   
/*     */   public FilteredViewerComparator getComparator() {
/* 225 */     return this.comparator;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\AbstractFilteredViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */