/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.dnd.DragSourceEvent;
/*    */ import org.eclipse.swt.dnd.DragSourceListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DndDragSource
/*    */   implements DragSourceListener
/*    */ {
/* 22 */   private static final ILogger logger = GlobalLog.getLogger(DndDragSource.class);
/*    */   
/*    */   private IDndProvider dndProvider;
/* 25 */   String dragData = null;
/*    */   
/*    */   public DndDragSource(IDndProvider dndProvider) {
/* 28 */     this.dndProvider = dndProvider;
/*    */   }
/*    */   
/*    */   public void dragStart(DragSourceEvent event)
/*    */   {
/* 33 */     Object data = this.dndProvider.getSelectedElements();
/* 34 */     event.doit = this.dndProvider.canDrag(data);
/* 35 */     if (event.doit) {
/* 36 */       this.dragData = this.dndProvider.getDragData();
/* 37 */       if (this.dragData == null) {
/* 38 */         logger.i("Invalid Drag %s", new Object[] { data });
/* 39 */         event.doit = false;
/*    */       }
/*    */     }
/* 42 */     logger.i("can Drag %b %s", new Object[] { Boolean.valueOf(event.doit), data });
/*    */   }
/*    */   
/*    */   public void dragSetData(DragSourceEvent event)
/*    */   {
/* 47 */     event.data = this.dndProvider.getDragData();
/* 48 */     logger.i("dragSetData %s", new Object[] { event.data });
/*    */   }
/*    */   
/*    */   public void dragFinished(DragSourceEvent event)
/*    */   {
/* 53 */     logger.i("dragFinished", new Object[0]);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\DndDragSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */