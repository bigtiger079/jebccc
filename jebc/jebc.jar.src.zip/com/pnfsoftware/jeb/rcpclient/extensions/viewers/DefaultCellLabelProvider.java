/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.util.regex.ILabelValueProvider;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import org.eclipse.jface.viewers.CellLabelProvider;
/*    */ import org.eclipse.jface.viewers.ViewerCell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultCellLabelProvider
/*    */   extends CellLabelProvider
/*    */   implements ILabelValueProvider
/*    */ {
/*    */   private IFilteredTableContentProvider provider;
/*    */   
/*    */   public DefaultCellLabelProvider(IFilteredTableContentProvider provider)
/*    */   {
/* 26 */     this.provider = provider;
/*    */   }
/*    */   
/*    */   public void update(ViewerCell cell)
/*    */   {
/* 31 */     String s = getStringAt(cell.getElement(), cell.getColumnIndex());
/* 32 */     cell.setText(Strings.safe(s));
/*    */   }
/*    */   
/*    */   public String getStringAt(Object element, int key)
/*    */   {
/* 37 */     if (element == null) {
/* 38 */       return null;
/*    */     }
/*    */     
/* 41 */     Object[] elts = this.provider.getRowElements(element);
/*    */     
/* 43 */     Object o = null;
/*    */     
/* 45 */     if ((elts != null) && (key >= 0) && (key < elts.length)) {
/* 46 */       o = elts[key];
/*    */     }
/*    */     
/* 49 */     return o == null ? null : o.toString();
/*    */   }
/*    */   
/*    */   public String getString(Object element)
/*    */   {
/* 54 */     StringBuilder sb = new StringBuilder();
/*    */     
/*    */ 
/*    */ 
/* 58 */     int maxSafe = 40;
/*    */     
/* 60 */     int key = 0;
/* 61 */     while (key < 40) {
/* 62 */       if (key >= 1) {
/* 63 */         sb.append(",");
/*    */       }
/*    */       
/*    */ 
/* 67 */       String value = getStringAt(element, key);
/* 68 */       if (value == null) {
/*    */         break;
/*    */       }
/*    */       
/* 72 */       sb.append(value);
/* 73 */       key++;
/*    */     }
/*    */     
/* 76 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\DefaultCellLabelProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */