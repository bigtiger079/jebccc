/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerDropAdapter;
/*     */ import org.eclipse.swt.dnd.DropTargetEvent;
/*     */ import org.eclipse.swt.dnd.TransferData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DndDropTarget
/*     */   extends ViewerDropAdapter
/*     */ {
/*  27 */   private static final ILogger logger = GlobalLog.getLogger(DndDropTarget.class);
/*     */   private IDndProvider dndProvider;
/*     */   private DndDragSource dragSource;
/*  30 */   boolean allowInsertBeforeOrAfter = false;
/*     */   
/*     */   public DndDropTarget(Viewer viewer, IDndProvider dndProvider, DndDragSource dragSource) {
/*  33 */     super(viewer);
/*  34 */     this.dndProvider = dndProvider;
/*  35 */     this.dragSource = dragSource;
/*     */     
/*  37 */     setFeedbackEnabled(false);
/*     */     
/*  39 */     setExpandEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int determineLocation(DropTargetEvent event)
/*     */   {
/*  46 */     int location = super.determineLocation(event);
/*  47 */     if ((!this.allowInsertBeforeOrAfter) && ((location == 1) || (location == 2))) {
/*  48 */       return 3;
/*     */     }
/*  50 */     return location;
/*     */   }
/*     */   
/*     */   public void drop(DropTargetEvent event)
/*     */   {
/*  55 */     int location = determineLocation(event);
/*  56 */     Object target = determineTarget(event);
/*  57 */     if (this.dndProvider.performDrop((String)event.data, target, location)) {
/*  58 */       logger.i("drop from %s to %s (%d)", new Object[] { event.data, target, Integer.valueOf(location) });
/*  59 */       super.drop(event);
/*     */     }
/*     */     else {
/*  62 */       logger.i("cannotDrop from %s to %s (%d)", new Object[] { event.data, target, Integer.valueOf(location) });
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean performDrop(Object data)
/*     */   {
/*  68 */     return true;
/*     */   }
/*     */   
/*     */   public boolean validateDrop(Object target, int operation, TransferData transferType)
/*     */   {
/*  73 */     boolean canDrop = false;
/*  74 */     if ((this.dragSource.dragData != null) && (target != null)) {
/*  75 */       canDrop = this.dndProvider.canDrop(this.dragSource.dragData, target, 3);
/*     */     }
/*  77 */     logger.i("validate drop %s %d %s %b", new Object[] { target, Integer.valueOf(operation), transferType, Boolean.valueOf(canDrop) });
/*  78 */     return canDrop;
/*     */   }
/*     */   
/*     */   public void dragOver(DropTargetEvent event)
/*     */   {
/*  83 */     event.feedback = 0;
/*  84 */     super.dragOver(event);
/*  85 */     Object target = getCurrentTarget();
/*  86 */     boolean canDrop = false;
/*  87 */     if ((this.dragSource.dragData != null) && (target != null)) {
/*  88 */       canDrop = this.dndProvider.canDrop(this.dragSource.dragData, target, 3);
/*     */     }
/*  90 */     setFeedbackSelect(event, canDrop ? 3 : 4);
/*     */   }
/*     */   
/*     */   private void setFeedbackSelect(DropTargetEvent event, int location) {
/*  94 */     switch (location) {
/*     */     case 1: 
/*  96 */       event.feedback |= 0x2;
/*  97 */       break;
/*     */     case 2: 
/*  99 */       event.feedback |= 0x4;
/* 100 */       break;
/*     */     case 3: 
/* 102 */       event.feedback |= 0x1;
/* 103 */       if (this.dndProvider.shouldExpand(this.dragSource.dragData, getCurrentTarget())) {
/* 104 */         event.feedback |= 0x10;
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\DndDropTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */