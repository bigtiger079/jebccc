/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayLogicalGroup
/*    */   extends ArrayGroup
/*    */ {
/*    */   private String groupName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 17 */   boolean packaged = false;
/*    */   
/*    */   public ArrayLogicalGroup(int firstIndex, String groupName) {
/* 20 */     super(firstIndex);
/* 21 */     this.groupName = groupName;
/*    */   }
/*    */   
/*    */   public ArrayLogicalGroup(int firstIndex, String groupName, boolean packaged) {
/* 25 */     super(firstIndex);
/* 26 */     this.groupName = groupName;
/* 27 */     this.packaged = packaged;
/*    */   }
/*    */   
/*    */   public String getGroupName()
/*    */   {
/* 32 */     return this.groupName;
/*    */   }
/*    */   
/*    */   public void setGroupName(String groupName) {
/* 36 */     this.groupName = groupName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 49 */     if (this.packaged) {
/* 50 */       int size = 0;
/* 51 */       for (Object child : this.children) {
/* 52 */         if ((child instanceof ArrayLogicalGroup)) {
/* 53 */           size += ((ArrayLogicalGroup)child).size();
/*    */         }
/*    */         else {
/* 56 */           size++;
/*    */         }
/*    */       }
/* 59 */       return size;
/*    */     }
/* 61 */     return super.size();
/*    */   }
/*    */   
/*    */   public boolean isPackaged()
/*    */   {
/* 66 */     return this.packaged;
/*    */   }
/*    */   
/*    */   public boolean isSingle()
/*    */   {
/* 71 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\arraygroup\ArrayLogicalGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */