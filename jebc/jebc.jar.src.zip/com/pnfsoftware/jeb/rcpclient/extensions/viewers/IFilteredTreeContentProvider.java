package com.pnfsoftware.jeb.rcpclient.extensions.viewers;

import org.eclipse.jface.viewers.ITreeContentProvider;

public abstract interface IFilteredTreeContentProvider
  extends IFilteredContentProvider, ITreeContentProvider
{}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\IFilteredTreeContentProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */