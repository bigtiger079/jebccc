/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VirtualArrayGroup
/*    */   implements IArrayGroup
/*    */ {
/*    */   int firstIndex;
/*    */   Object element;
/*    */   String label;
/*    */   
/*    */   public VirtualArrayGroup(int firstIndex, Object element)
/*    */   {
/* 28 */     this(firstIndex, element, null);
/*    */   }
/*    */   
/*    */   public VirtualArrayGroup(int firstIndex, Object element, String label)
/*    */   {
/* 33 */     this.firstIndex = firstIndex;
/* 34 */     this.element = element;
/* 35 */     this.label = label;
/*    */   }
/*    */   
/*    */   public int getFirstElementIndex()
/*    */   {
/* 40 */     return this.firstIndex;
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 45 */     return this.firstIndex;
/*    */   }
/*    */   
/*    */   public Object getFirstElement()
/*    */   {
/* 50 */     return this.element;
/*    */   }
/*    */   
/*    */   public Object getLastElement()
/*    */   {
/* 55 */     return this.element;
/*    */   }
/*    */   
/*    */   public boolean isSingle()
/*    */   {
/* 60 */     return true;
/*    */   }
/*    */   
/*    */   public List<Object> getChildren()
/*    */   {
/* 65 */     List<Object> list = new ArrayList();
/* 66 */     list.add(this.element);
/* 67 */     return list;
/*    */   }
/*    */   
/*    */   public int size()
/*    */   {
/* 72 */     return 1;
/*    */   }
/*    */   
/*    */   public String getGroupName()
/*    */   {
/* 77 */     return this.label;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\arraygroup\VirtualArrayGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */