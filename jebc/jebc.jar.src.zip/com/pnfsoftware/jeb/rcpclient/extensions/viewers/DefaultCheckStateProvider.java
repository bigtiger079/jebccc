/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*    */ 
/*    */ import org.eclipse.jface.viewers.ICheckStateProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultCheckStateProvider
/*    */   implements ICheckStateProvider
/*    */ {
/*    */   private IFilteredTableContentProvider provider;
/*    */   
/*    */   public DefaultCheckStateProvider(IFilteredTableContentProvider provider)
/*    */   {
/* 22 */     this.provider = provider;
/*    */   }
/*    */   
/*    */   public boolean isChecked(Object element)
/*    */   {
/* 27 */     return this.provider.isChecked(element);
/*    */   }
/*    */   
/*    */   public boolean isGrayed(Object element)
/*    */   {
/* 32 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\DefaultCheckStateProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */