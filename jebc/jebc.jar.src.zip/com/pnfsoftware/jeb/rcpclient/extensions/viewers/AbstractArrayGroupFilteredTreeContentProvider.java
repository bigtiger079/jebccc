/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup.ArrayGroup;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup.ArrayLogicalGroup;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup.IArrayGroup;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.arraygroup.VirtualArrayGroup;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractArrayGroupFilteredTreeContentProvider
/*     */   implements IFilteredTreeContentProvider
/*     */ {
/*     */   public static final int DEFAULT_LIMIT = 1000;
/*     */   public static final int DEFAULT__GROUP_LIMIT = 100;
/*     */   public static final int DEFAULT_PERFORMANCE_LIMIT = 20;
/*     */   private static final int MIN_GROUP_SIZE_ALLOWED = 10;
/*     */   private int limit;
/*     */   private int groupLimit;
/*     */   private int performanceLimit;
/*  43 */   private boolean performanceOptimizer = false;
/*     */   
/*     */ 
/*     */ 
/*  47 */   private Map<Integer, Map<Integer, Map<Object, ArrayGroup>>> arrayGroups = new HashMap();
/*  48 */   private Map<Integer, Map<Integer, Map<Object, ArrayLogicalGroup>>> arrayLogicalGroups = new HashMap();
/*  49 */   private Map<Integer, Map<Object, VirtualArrayGroup>> virtualElements = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractArrayGroupFilteredTreeContentProvider(int limit, int groupLimit, int performanceLimit)
/*     */   {
/*  63 */     this.limit = limit;
/*  64 */     this.groupLimit = groupLimit;
/*  65 */     this.performanceLimit = performanceLimit;
/*     */   }
/*     */   
/*     */   public AbstractArrayGroupFilteredTreeContentProvider() {
/*  69 */     this(1000, 100, 20);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ArrayGroup getArrayGroup(Object parentElement, int firstIndex, int toplevel)
/*     */   {
/*  82 */     Map<Integer, Map<Object, ArrayGroup>> lev = (Map)this.arrayGroups.get(Integer.valueOf(toplevel));
/*  83 */     if (lev == null) {
/*  84 */       lev = new HashMap();
/*  85 */       this.arrayGroups.put(Integer.valueOf(toplevel), lev);
/*     */     }
/*  87 */     Map<Object, ArrayGroup> gr = (Map)lev.get(Integer.valueOf(firstIndex));
/*  88 */     if (gr == null) {
/*  89 */       gr = new HashMap();
/*  90 */       lev.put(Integer.valueOf(firstIndex), gr);
/*     */     }
/*  92 */     ArrayGroup g = (ArrayGroup)gr.get(parentElement);
/*  93 */     if (g == null) {
/*  94 */       g = new ArrayGroup(firstIndex);
/*  95 */       gr.put(parentElement, g);
/*     */     }
/*     */     
/*  98 */     g.getChildren().clear();
/*  99 */     return g;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ArrayLogicalGroup getArrayLogicalGroup(Object parentElement, int firstIndex, String groupName, boolean packaged, int toplevel)
/*     */   {
/* 115 */     Map<Integer, Map<Object, ArrayLogicalGroup>> lev = (Map)this.arrayLogicalGroups.get(Integer.valueOf(toplevel));
/* 116 */     if (lev == null) {
/* 117 */       lev = new HashMap();
/* 118 */       this.arrayLogicalGroups.put(Integer.valueOf(toplevel), lev);
/*     */     }
/* 120 */     Map<Object, ArrayLogicalGroup> gr = (Map)lev.get(Integer.valueOf(firstIndex));
/* 121 */     if (gr == null) {
/* 122 */       gr = new HashMap();
/* 123 */       lev.put(Integer.valueOf(firstIndex), gr);
/*     */     }
/* 125 */     ArrayLogicalGroup g = (ArrayLogicalGroup)gr.get(parentElement);
/* 126 */     if ((g == null) || (!Strings.equals(g.getGroupName(), groupName)) || (g.isPackaged() != packaged))
/*     */     {
/* 128 */       g = new ArrayLogicalGroup(firstIndex, groupName, packaged);
/* 129 */       gr.put(parentElement, g);
/*     */     }
/*     */     
/* 132 */     g.getChildren().clear();
/* 133 */     return g;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected VirtualArrayGroup getVirtualElement(Object elt, int firstIndex, String label)
/*     */   {
/* 146 */     Map<Object, VirtualArrayGroup> gr = (Map)this.virtualElements.get(Integer.valueOf(firstIndex));
/* 147 */     if (gr == null) {
/* 148 */       gr = new HashMap();
/* 149 */       this.virtualElements.put(Integer.valueOf(firstIndex), gr);
/*     */     }
/* 151 */     VirtualArrayGroup g = (VirtualArrayGroup)gr.get(elt);
/* 152 */     if ((g == null) || (!Strings.equals(g.getGroupName(), label)))
/*     */     {
/* 154 */       g = new VirtualArrayGroup(firstIndex, elt, label);
/* 155 */       gr.put(elt, g);
/*     */     }
/*     */     
/* 158 */     g.getChildren().clear();
/* 159 */     return g;
/*     */   }
/*     */   
/*     */   public final boolean hasChildren(Object element)
/*     */   {
/* 164 */     if ((element instanceof IArrayGroup)) {
/* 165 */       if (((IArrayGroup)element).isSingle()) {
/* 166 */         return hasChildren(((IArrayGroup)element).getFirstElement());
/*     */       }
/* 168 */       return true;
/*     */     }
/* 170 */     return hasChildren2(element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean hasChildren2(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object[] getChildren(Object parentElement)
/*     */   {
/* 183 */     if ((parentElement instanceof IArrayGroup)) {
/* 184 */       if (((IArrayGroup)parentElement).isSingle()) {
/* 185 */         parentElement = ((IArrayGroup)parentElement).getFirstElement();
/*     */       }
/*     */       else {
/* 188 */         return ((ArrayGroup)parentElement).getChildren().toArray();
/*     */       }
/*     */     }
/* 191 */     List<?> children = getChildren2(parentElement);
/* 192 */     if (children == null) {
/* 193 */       return null;
/*     */     }
/* 195 */     if (this.limit < 10) {
/* 196 */       return children.toArray();
/*     */     }
/*     */     
/* 199 */     Object[] elts = children.toArray();
/* 200 */     sort(elts);
/* 201 */     children = Arrays.asList(elts);
/* 202 */     return noMoreThanNChildren(children, parentElement);
/*     */   }
/*     */   
/*     */   private Object[] noMoreThanNChildren(List<?> r, Object parentElement) {
/* 206 */     if (((this.performanceOptimizer) && (r.size() >= this.performanceLimit)) || (r.size() > this.limit)) {
/* 207 */       if (!this.performanceOptimizer) {
/* 208 */         this.performanceOptimizer = true;
/* 209 */         onFirstOptimization(r);
/*     */       }
/*     */       
/* 212 */       List<IArrayGroup> groups = new ArrayList();
/* 213 */       Map<Integer, ArrayLogicalGroup> logicalGroups = getLogicalGroups(r, parentElement);
/* 214 */       int logicalGroupSize = getLogicalGroupSize(logicalGroups);
/* 215 */       if (r.size() <= this.limit) {
/* 216 */         if (logicalGroups.size() == 0)
/*     */         {
/* 218 */           return r.toArray();
/*     */         }
/* 220 */         if ((logicalGroups.size() == 1) && (r.size() - logicalGroupSize < this.performanceLimit))
/*     */         {
/* 222 */           return r.toArray();
/*     */         }
/*     */       }
/* 225 */       ArrayGroup currentGroup = null;
/* 226 */       boolean shouldCreateIntermediateGroups = r.size() - logicalGroupSize > this.limit;
/* 227 */       for (int i = 0; i < r.size(); i++) {
/* 228 */         if (!logicalGroups.isEmpty()) {
/* 229 */           ArrayLogicalGroup logicalGroup = (ArrayLogicalGroup)logicalGroups.get(Integer.valueOf(i));
/* 230 */           if (logicalGroup != null) {
/* 231 */             currentGroup = null;
/* 232 */             groups.add(logicalGroup);
/* 233 */             i += logicalGroup.size() - 1;
/* 234 */             continue;
/*     */           }
/*     */         }
/* 237 */         if ((shouldCreateIntermediateGroups) && ((currentGroup == null) || (currentGroup.size() >= getGroupLimit()))) {
/* 238 */           currentGroup = getArrayGroup(parentElement, i, 0);
/* 239 */           groups.add(currentGroup);
/*     */         }
/* 241 */         if (currentGroup != null) {
/* 242 */           currentGroup.add(r.get(i));
/*     */         } else {
/* 244 */           groups.add(getVirtualElement(r.get(i), i, null));
/*     */         }
/*     */       }
/*     */       
/* 248 */       if ((shouldCreateIntermediateGroups) && (logicalGroupSize > 0))
/*     */       {
/* 250 */         int flattenedElements = this.limit - groups.size() % this.limit;
/* 251 */         while ((flattenedElements != this.limit) && (flattenedElements > 0)) {
/* 252 */           List<Integer> groupsBySize = getSmallestGroups(groups);
/* 253 */           if (groupsBySize.isEmpty()) {
/*     */             break;
/*     */           }
/* 256 */           for (int j = groupsBySize.size() - 1; j >= 0; j--) {
/* 257 */             int index = ((Integer)groupsBySize.get(j)).intValue();
/* 258 */             flattenedElements -= ((IArrayGroup)groups.get(index)).size();
/* 259 */             if (flattenedElements < 0) break;
/* 260 */             IArrayGroup g = (IArrayGroup)groups.remove(index);
/* 261 */             for (int k = 0; k < g.size(); k++) {
/* 262 */               groups.add(index + k, new VirtualArrayGroup(g
/* 263 */                 .getFirstElementIndex() + k, g.getChildren().get(k)));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 272 */       return noMoreThanNChildrenGroup(groups, parentElement, 1);
/*     */     }
/* 274 */     return r.toArray();
/*     */   }
/*     */   
/*     */   private List<Integer> getSmallestGroups(List<IArrayGroup> groups) {
/* 278 */     int minSize = -1;
/* 279 */     List<Integer> subGroups = new ArrayList();
/* 280 */     for (int i = 1; i < groups.size(); i++) {
/* 281 */       IArrayGroup g = (IArrayGroup)groups.get(i);
/* 282 */       if (!(g instanceof ArrayLogicalGroup))
/*     */       {
/*     */ 
/* 285 */         int size = g.size();
/* 286 */         if (size != 1)
/*     */         {
/*     */ 
/* 289 */           if ((size < minSize) || (minSize == -1)) {
/* 290 */             minSize = size;
/* 291 */             subGroups.clear();
/* 292 */             subGroups.add(Integer.valueOf(i));
/* 293 */           } else if (size == minSize) {
/* 294 */             subGroups.add(Integer.valueOf(i));
/*     */           } }
/*     */       } }
/* 297 */     return subGroups;
/*     */   }
/*     */   
/*     */   private int getLogicalGroupSize(Map<Integer, ArrayLogicalGroup> logicalGroups) {
/* 301 */     int size = 0;
/* 302 */     if ((logicalGroups == null) || (logicalGroups.size() == 0)) {
/* 303 */       return size;
/*     */     }
/* 305 */     for (ArrayLogicalGroup g : logicalGroups.values()) {
/* 306 */       size += g.size();
/*     */     }
/* 308 */     return size;
/*     */   }
/*     */   
/*     */   private Object[] noMoreThanNChildrenGroup(List<IArrayGroup> r, Object parentElement, int toplevel) {
/* 312 */     if (this.groupLimit < 10)
/*     */     {
/* 314 */       return r.toArray();
/*     */     }
/* 316 */     if (r.size() > this.limit)
/*     */     {
/* 318 */       List<IArrayGroup> groups = new ArrayList();
/* 319 */       ArrayGroup currentGroup = null;
/* 320 */       for (int i = 0; i < r.size(); i++) {
/* 321 */         if ((currentGroup == null) || (currentGroup.size() >= this.groupLimit)) {
/* 322 */           currentGroup = getArrayGroup(parentElement, ((IArrayGroup)r.get(i)).getFirstElementIndex(), toplevel);
/* 323 */           groups.add(currentGroup);
/*     */         }
/* 325 */         currentGroup.add(r.get(i));
/*     */       }
/* 327 */       return noMoreThanNChildrenGroup(groups, parentElement, toplevel + 1);
/*     */     }
/* 329 */     return r.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Integer, ArrayLogicalGroup> getLogicalGroups(List<?> r, Object parentElement)
/*     */   {
/* 346 */     return new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract List<?> getChildren2(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void sort(Object[] paramArrayOfObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onFirstOptimization(List<?> r) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getStringAt(Object element, int index)
/*     */   {
/* 378 */     if ((element instanceof IArrayGroup)) {
/* 379 */       IArrayGroup v = (IArrayGroup)element;
/* 380 */       if (index == 0) {
/* 381 */         return String.format("[%d..%d]", new Object[] { Integer.valueOf(v.getFirstElementIndex()), Integer.valueOf(v.getLastElementIndex()) });
/*     */       }
/*     */     }
/* 384 */     return null;
/*     */   }
/*     */   
/*     */   public int getLimit() {
/* 388 */     return this.limit;
/*     */   }
/*     */   
/*     */   public int getGroupLimit() {
/* 392 */     return this.groupLimit < 10 ? this.limit : this.groupLimit;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\AbstractArrayGroupFilteredTreeContentProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */