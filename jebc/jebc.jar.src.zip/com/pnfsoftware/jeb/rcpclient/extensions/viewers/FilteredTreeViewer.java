/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.AbstractFilteredView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilteredTreeView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.filter.AbstractFilteredFilter;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.tree.TreeUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.jface.viewers.StructuredViewer;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.dnd.TextTransfer;
/*     */ import org.eclipse.swt.dnd.Transfer;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredTreeViewer
/*     */   extends AbstractFilteredViewer<Tree, TreeViewer>
/*     */ {
/*     */   Object[] expandedElements;
/*     */   private boolean expandAfterFilter;
/*     */   private static final int EXPAND_LIMIT = 2000;
/*     */   public static final int EXPAND_ERROR = -1;
/*     */   
/*     */   public FilteredTreeViewer(FilteredTreeView widget, boolean expandAfterFilter)
/*     */   {
/*  56 */     super(widget);
/*  57 */     this.expandAfterFilter = expandAfterFilter;
/*     */     
/*  59 */     this.comparator = new FilteredViewerComparator(Strings.getDefaultComparator(), this);
/*  60 */     ((TreeViewer)getViewer()).setComparator(this.comparator);
/*     */     
/*  62 */     int colIndex = 0;
/*  63 */     for (TreeColumn col : widget.getTree().getColumns())
/*     */     {
/*  65 */       col.addSelectionListener(new ColumnSelectionListener(colIndex, col));
/*  66 */       colIndex++;
/*     */     }
/*     */   }
/*     */   
/*     */   protected TreeViewer buildViewer(AbstractFilteredView<Tree> widget)
/*     */   {
/*  72 */     return new TreeViewer((Tree)widget.getElement());
/*     */   }
/*     */   
/*     */   protected AbstractFilteredFilter buildFilter(TreeViewer viewer)
/*     */   {
/*  77 */     return new RegexViewerFilter(viewer);
/*     */   }
/*     */   
/*     */   class ColumnSelectionListener extends SelectionAdapter {
/*     */     int columnIndex;
/*     */     TreeColumn column;
/*     */     
/*     */     public ColumnSelectionListener(int columnIndex, TreeColumn column) {
/*  85 */       this.columnIndex = columnIndex;
/*  86 */       this.column = column;
/*     */     }
/*     */     
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/*  91 */       if (FilteredTreeViewer.this.comparator != null) {
/*  92 */         FilteredTreeViewer.this.comparator.setColumn(this.columnIndex);
/*  93 */         int dir = FilteredTreeViewer.this.comparator.getDirection();
/*  94 */         ((Tree)FilteredTreeViewer.this.getWidget().getElement()).setSortDirection(dir);
/*  95 */         ((Tree)FilteredTreeViewer.this.getWidget().getElement()).setSortColumn(this.column);
/*  96 */         FilteredTreeViewer.this.refresh();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object doAfterEmptyFilter()
/*     */   {
/* 103 */     if (this.expandedElements != null) {
/* 104 */       ((TreeViewer)getViewer()).collapseAll();
/* 105 */       ((TreeViewer)getViewer()).setExpandedElements(this.expandedElements);
/* 106 */       this.expandedElements = null;
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   protected void doBeforeNotNullFilter()
/*     */   {
/* 113 */     if (this.expandedElements == null) {
/* 114 */       this.expandedElements = ((TreeViewer)getViewer()).getExpandedElements();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object doAfterNotNullFilter()
/*     */   {
/* 120 */     if (this.expandAfterFilter) {
/*     */       try {
/* 122 */         ((TreeViewer)getViewer()).getTree().setRedraw(false);
/*     */         
/* 124 */         TreeItem[] items = ((TreeViewer)getViewer()).getTree().getItems();
/* 125 */         return Integer.valueOf(expandFiltered(items, items.length));
/*     */       }
/*     */       finally {
/* 128 */         ((TreeViewer)getViewer()).getTree().setRedraw(true);
/*     */       }
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   private int expandFiltered(TreeItem[] items, int opened) {
/* 135 */     if ((items == null) || (items.length == 0)) {
/* 136 */       return opened;
/*     */     }
/* 138 */     List<TreeItem> toExpand = new ArrayList();
/* 139 */     for (TreeItem item : items)
/*     */     {
/*     */ 
/* 142 */       if (getProvider().hasChildren(item.getData())) {
/* 143 */         boolean childMatch = isOneChildMatchFilter(item.getData());
/*     */         
/* 145 */         if (childMatch)
/*     */         {
/* 147 */           toExpand.add(item);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 153 */     for (??? = toExpand.iterator(); ((Iterator)???).hasNext();) { TreeItem item = (TreeItem)((Iterator)???).next();
/* 154 */       ((TreeViewer)getViewer()).setExpandedState(item.getData(), true);
/* 155 */       opened += item.getItems().length;
/* 156 */       if (opened > 2000) {
/* 157 */         return -1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 162 */     for (int i = 0; i < toExpand.size(); i++) {
/* 163 */       opened = expandFiltered(((TreeItem)toExpand.get(i)).getItems(), opened);
/* 164 */       if (opened > 2000) {
/* 165 */         return -1;
/*     */       }
/* 167 */       if (opened == -1) {
/* 168 */         return -1;
/*     */       }
/*     */     }
/* 171 */     return opened;
/*     */   }
/*     */   
/*     */   private boolean isOneChildMatchFilter(Object root) {
/* 175 */     if ((root == null) || (!getProvider().hasChildren(root))) {
/* 176 */       return false;
/*     */     }
/* 178 */     Object[] children = getProvider().getChildren(root);
/*     */     
/* 180 */     for (Object child : children) {
/* 181 */       if (this.filter.isElementMatch(child)) {
/* 182 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 187 */     for (Object child : children) {
/* 188 */       boolean childMatch = isOneChildMatchFilter(child);
/* 189 */       if (childMatch) {
/* 190 */         return true;
/*     */       }
/*     */     }
/* 193 */     return false;
/*     */   }
/*     */   
/*     */   public void addDragnDropSupport(IDndProvider dndProvider) {
/* 197 */     Transfer[] types = { TextTransfer.getInstance() };
/* 198 */     int operations = 10;
/* 199 */     DndDragSource dragSource = new DndDragSource(dndProvider);
/* 200 */     ((TreeViewer)getViewer()).addDragSupport(operations, types, dragSource);
/* 201 */     ((TreeViewer)getViewer()).addDropSupport(operations, types, new DndDropTarget(getViewer(), dndProvider, dragSource));
/*     */   }
/*     */   
/*     */   public void setContentProvider(IFilteredTreeContentProvider provider) {
/* 205 */     super.setContentProvider(provider);
/*     */   }
/*     */   
/*     */   public IFilteredTreeContentProvider getProvider() {
/* 209 */     return (IFilteredTreeContentProvider)this.provider;
/*     */   }
/*     */   
/*     */   public void expandAll() {
/* 213 */     ((TreeViewer)getViewer()).expandAll();
/*     */   }
/*     */   
/*     */   public void expandToLevel(int level) {
/* 217 */     ((TreeViewer)getViewer()).expandToLevel(level);
/*     */   }
/*     */   
/*     */   public void expandToLevel(Object elementOrTreePath, int level) {
/* 221 */     ((TreeViewer)getViewer()).expandToLevel(elementOrTreePath, level);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public class RegexViewerFilter
/*     */     extends AbstractFilteredFilter
/*     */   {
/* 236 */     private Set<Object> parentMatches = Collections.newSetFromMap(new WeakHashMap());
/*     */     
/*     */     public RegexViewerFilter(StructuredViewer viewer) {
/* 239 */       super();
/*     */     }
/*     */     
/*     */     public boolean select(Viewer viewer, Object parentElement, Object element)
/*     */     {
/* 244 */       if (this.patternChanged) {
/* 245 */         this.patternChanged = false;
/* 246 */         this.parentMatches.clear();
/*     */       }
/*     */       
/* 249 */       if (this.parentMatches.contains(element))
/*     */       {
/* 251 */         return true;
/*     */       }
/*     */       
/* 254 */       if (isParentMatches(parentElement))
/*     */       {
/* 256 */         this.parentMatches.add(element);
/* 257 */         return true;
/*     */       }
/*     */       
/* 260 */       boolean elementMatch = isElementMatch(element);
/* 261 */       if (elementMatch)
/*     */       {
/* 263 */         this.parentMatches.add(element);
/* 264 */         return true;
/*     */       }
/*     */       
/* 267 */       Object[] children = getProvider().getChildren(element);
/* 268 */       if (children != null) {
/* 269 */         for (Object child : children) {
/* 270 */           boolean r = select(viewer, element, child);
/* 271 */           if (r)
/*     */           {
/* 273 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 278 */       return elementMatch;
/*     */     }
/*     */     
/*     */     public IFilteredTreeContentProvider getProvider()
/*     */     {
/* 283 */       return FilteredTreeViewer.this.getProvider();
/*     */     }
/*     */     
/*     */     private boolean isParentMatches(Object parentElement) {
/* 287 */       return this.parentMatches.contains(parentElement);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void onRefreshDone() {}
/*     */   }
/*     */   
/*     */ 
/*     */   public String exportToString()
/*     */   {
/* 298 */     return TreeUtil.buildXml(((TreeViewer)getViewer()).getTree(), 2);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\FilteredTreeViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */