/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.viewers;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.AbstractFilteredView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.FilteredTableView;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.filter.AbstractFilteredFilter;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import org.eclipse.jface.viewers.CheckboxTableViewer;
/*     */ import org.eclipse.jface.viewers.ICheckStateProvider;
/*     */ import org.eclipse.jface.viewers.StructuredViewer;
/*     */ import org.eclipse.jface.viewers.TableViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredTableViewer
/*     */   extends AbstractFilteredViewer<Table, TableViewer>
/*     */ {
/*     */   public FilteredTableViewer(FilteredTableView widget)
/*     */   {
/*  45 */     super(widget);
/*     */     
/*  47 */     this.comparator = new FilteredViewerComparator(Strings.getDefaultComparator(), this);
/*  48 */     ((TableViewer)getViewer()).setComparator(this.comparator);
/*     */     
/*  50 */     int colIndex = 0;
/*  51 */     for (TableColumn col : widget.getTable().getColumns()) {
/*  52 */       col.addSelectionListener(new ColumnSelectionListener(colIndex, col));
/*  53 */       colIndex++;
/*     */     }
/*     */   }
/*     */   
/*     */   protected TableViewer buildViewer(AbstractFilteredView<Table> widget)
/*     */   {
/*  59 */     if ((((Table)widget.getElement()).getStyle() & 0x20) == 0) {
/*  60 */       return new TableViewer((Table)widget.getElement());
/*     */     }
/*     */     
/*  63 */     return new CheckboxTableViewer((Table)widget.getElement());
/*     */   }
/*     */   
/*     */ 
/*     */   protected AbstractFilteredFilter buildFilter(TableViewer viewer)
/*     */   {
/*  69 */     return new Filter(viewer);
/*     */   }
/*     */   
/*     */   class ColumnSelectionListener extends SelectionAdapter {
/*     */     int columnIndex;
/*     */     TableColumn column;
/*     */     
/*     */     public ColumnSelectionListener(int columnIndex, TableColumn column) {
/*  77 */       this.columnIndex = columnIndex;
/*  78 */       this.column = column;
/*     */     }
/*     */     
/*     */     public void widgetSelected(SelectionEvent e)
/*     */     {
/*  83 */       if (FilteredTableViewer.this.comparator != null) {
/*  84 */         FilteredTableViewer.this.comparator.setColumn(this.columnIndex);
/*  85 */         int dir = FilteredTableViewer.this.comparator.getDirection();
/*  86 */         ((Table)FilteredTableViewer.this.getWidget().getElement()).setSortDirection(dir);
/*  87 */         ((Table)FilteredTableViewer.this.getWidget().getElement()).setSortColumn(this.column);
/*  88 */         FilteredTableViewer.this.refresh();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setInput(Object input, boolean pack) {
/*  94 */     super.setInput(input);
/*  95 */     if (pack) {
/*  96 */       getWidget().pack(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setContentProvider(IFilteredTableContentProvider provider) {
/* 101 */     super.setContentProvider(provider);
/*     */   }
/*     */   
/*     */   public IFilteredTableContentProvider getProvider() {
/* 105 */     return (IFilteredTableContentProvider)this.provider;
/*     */   }
/*     */   
/*     */   public void setCheckStateProvider(ICheckStateProvider provider) {
/* 109 */     if (!(getViewer() instanceof CheckboxTableViewer)) {
/* 110 */       throw new RuntimeException();
/*     */     }
/* 112 */     ((CheckboxTableViewer)getViewer()).setCheckStateProvider(provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class Filter
/*     */     extends AbstractFilteredFilter
/*     */   {
/*     */     public Filter(StructuredViewer viewer)
/*     */     {
/* 173 */       super();
/*     */     }
/*     */     
/*     */     public boolean select(Viewer viewer, Object parent, Object element)
/*     */     {
/* 178 */       return isElementMatch(element);
/*     */     }
/*     */     
/*     */     public IFilteredContentProvider getProvider()
/*     */     {
/* 183 */       return FilteredTableViewer.this.getProvider();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\viewers\FilteredTableViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */