/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UIExecutor
/*     */ {
/*  32 */   private static UIExecutor instance = new UIExecutor();
/*     */   
/*  34 */   private static AtomicInteger synccnt = new AtomicInteger();
/*  35 */   private static AtomicInteger executingSyncCnt = new AtomicInteger();
/*     */   
/*  37 */   private static Object alock = new Object();
/*  38 */   private static AtomicInteger asynccnt = new AtomicInteger();
/*     */   private static int asynccntExec;
/*  40 */   private static Map<String, Integer> asyncCallers = Collections.synchronizedMap(new HashMap());
/*  41 */   private static long asyncBestWaitTime = Long.MAX_VALUE;
/*  42 */   private static long asyncWorstWaitTime = 0L;
/*     */   
/*     */   private static long asyncAvgWaitTime;
/*     */   
/*     */ 
/*     */   public static UIExecutor getInstance()
/*     */   {
/*  49 */     return instance;
/*     */   }
/*     */   
/*     */   public static void async(Widget w, UIRunnable runnable) {
/*  53 */     asyncInternal(w.getDisplay(), runnable);
/*     */   }
/*     */   
/*     */   public static void async(Display d, UIRunnable runnable) {
/*  57 */     asyncInternal(d, runnable);
/*     */   }
/*     */   
/*     */   public static void asyncIfNotOnUIThread(Display d, UIRunnable runnable) {
/*  61 */     asyncInternal(d, runnable, true);
/*     */   }
/*     */   
/*     */   public static void sync(Widget w, Runnable runnable) {
/*  65 */     sync(w.getDisplay(), runnable);
/*     */   }
/*     */   
/*     */   public static void sync(Display d, Runnable runnable) {
/*  69 */     if (d.isDisposed()) {
/*  70 */       return;
/*     */     }
/*     */     
/*     */ 
/*  74 */     if (d.getThread() == Thread.currentThread()) {
/*  75 */       runnable.run();
/*  76 */       return;
/*     */     }
/*     */     
/*  79 */     executingSyncCnt.incrementAndGet();
/*     */     
/*  81 */     synccnt.incrementAndGet();
/*  82 */     d.syncExec(runnable);
/*     */     
/*  84 */     executingSyncCnt.decrementAndGet();
/*     */   }
/*     */   
/*     */   private static void asyncInternal(Display d, UIRunnable runnable) {
/*  88 */     asyncInternal(d, runnable, false);
/*     */   }
/*     */   
/*     */   private static void asyncInternal(Display d, UIRunnable runnable, boolean bypassQueue) {
/*  92 */     if (d.isDisposed()) {
/*  93 */       return;
/*     */     }
/*     */     
/*     */ 
/*  97 */     if ((bypassQueue) && (d.getThread() == Thread.currentThread())) {
/*  98 */       runnable.run();
/*  99 */       return;
/*     */     }
/*     */     
/* 102 */     boolean debug = Licensing.isDebugBuild();
/* 103 */     if (debug) {
/* 104 */       StackTraceElement[] elts = Thread.currentThread().getStackTrace();
/* 105 */       String caller = "unknown";
/* 106 */       if (elts.length >= 4) {
/* 107 */         caller = elts[3].toString();
/*     */       }
/* 109 */       synchronized (asyncCallers) {
/* 110 */         Integer cnt = (Integer)asyncCallers.get(caller);
/* 111 */         if (cnt == null) {
/* 112 */           asyncCallers.put(caller, Integer.valueOf(1));
/*     */         }
/*     */         else {
/* 115 */           asyncCallers.put(caller, Integer.valueOf(cnt.intValue() + 1));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 120 */     asynccnt.incrementAndGet();
/* 121 */     d.asyncExec(runnable);
/*     */     
/* 123 */     if (debug) {
/* 124 */       monitorUITask(runnable);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void monitorUITask(UIRunnable task)
/*     */   {
/* 130 */     String threadName = "monitorUITask: " + getCaller();
/* 131 */     ThreadUtil.start(threadName, new Runnable()
/*     */     {
/*     */       public void run() {
/* 134 */         while (!this.val$task.isDone()) {
/*     */           try {
/* 136 */             Thread.sleep(500L);
/*     */           }
/*     */           catch (InterruptedException e) {
/* 139 */             return;
/*     */           }
/*     */         }
/* 142 */         synchronized (UIExecutor.alock) {
/* 143 */           UIExecutor.access$108();
/* 144 */           long waitTime = this.val$task.getExecStartTs() - this.val$task.getCreatedTs();
/* 145 */           if (waitTime < UIExecutor.asyncBestWaitTime) {
/* 146 */             UIExecutor.access$202(waitTime);
/*     */           }
/* 148 */           if (waitTime > UIExecutor.asyncWorstWaitTime) {
/* 149 */             UIExecutor.access$302(waitTime);
/*     */           }
/* 151 */           if (UIExecutor.asynccntExec == 1) {
/* 152 */             UIExecutor.access$402(waitTime);
/*     */           }
/*     */           else {
/* 155 */             long n = UIExecutor.asynccntExec - 1L;
/* 156 */             UIExecutor.access$402((n * UIExecutor.asyncAvgWaitTime + waitTime) / UIExecutor.asynccntExec);
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private static String getCaller()
/*     */   {
/* 165 */     StackTraceElement[] stack = Thread.currentThread().getStackTrace();
/* 166 */     for (int i = 1; i < stack.length; i++) {
/* 167 */       if ((!stack[i].getClassName().startsWith(UIExecutor.class.getName())) && 
/* 168 */         (!stack[i].getClassName().contains(".Abstract"))) {
/* 169 */         return stack[i].getClassName();
/*     */       }
/*     */     }
/* 172 */     return "";
/*     */   }
/*     */   
/*     */   public static String format() {
/* 176 */     StringBuilder sb = new StringBuilder();
/*     */     
/*     */     List<Map.Entry<String, Integer>> list;
/* 179 */     synchronized (asyncCallers) {
/* 180 */       list = new ArrayList(asyncCallers.entrySet()); }
/*     */     List<Map.Entry<String, Integer>> list;
/* 182 */     Collections.sort(list, new Comparator()
/*     */     {
/*     */       public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
/* 185 */         return -Integer.compare(((Integer)o1.getValue()).intValue(), ((Integer)o2.getValue()).intValue());
/*     */       }
/*     */       
/* 188 */     });
/* 189 */     sb.append(String.format("=> %d sync executed (currently executing: %d)\n", new Object[] { Integer.valueOf(synccnt.get()), 
/* 190 */       Integer.valueOf(executingSyncCnt.get()) }));
/* 191 */     sb.append(String.format("=> %d/%d async executed (wait times: avg=%dms best=%dms worst=%dms)\n", new Object[] { Integer.valueOf(asynccntExec), 
/* 192 */       Integer.valueOf(asynccnt.get()), Long.valueOf(asyncAvgWaitTime), Long.valueOf(asyncBestWaitTime), Long.valueOf(asyncWorstWaitTime) }));
/*     */     
/* 194 */     sb.append("Top callers:\n");
/* 195 */     int i = 0;
/* 196 */     for (Map.Entry<String, Integer> e : list) {
/* 197 */       if (i >= 10) {
/*     */         break;
/*     */       }
/* 200 */       sb.append(String.format("- %4d %s\n", new Object[] { e.getValue(), e.getKey() }));
/* 201 */       i++;
/*     */     }
/*     */     
/* 204 */     return sb.toString().trim();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 209 */     return format();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\UIExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */