/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.IWidgetManager;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShellWrapper
/*     */ {
/*     */   private Shell shell;
/*     */   private IWidgetManager widgetManager;
/*     */   private int widgetId;
/*     */   private Listener closeListener;
/*     */   private Rectangle recordedBounds;
/*     */   
/*     */   public static enum BoundsRestorationType
/*     */   {
/*  28 */     NONE, 
/*  29 */     POSITION, 
/*  30 */     SIZE, 
/*  31 */     SIZE_AND_POSITION;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private BoundsRestorationType() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ShellWrapper wrap(Shell shell, IWidgetManager widgetManager)
/*     */   {
/*  48 */     int widgetId = UIUtil.getWidgetId(shell);
/*  49 */     if (widgetId == 0) {
/*  50 */       return null;
/*     */     }
/*     */     
/*  53 */     return new ShellWrapper(shell, widgetManager, widgetId);
/*     */   }
/*     */   
/*     */   private ShellWrapper(Shell shell, IWidgetManager widgetManager, int widgetId) {
/*  57 */     this.shell = shell;
/*  58 */     this.widgetManager = widgetManager;
/*  59 */     this.widgetId = widgetId;
/*  60 */     setup();
/*     */   }
/*     */   
/*     */   public boolean hasRecordedBounds() {
/*  64 */     return this.recordedBounds != null;
/*     */   }
/*     */   
/*     */   public Rectangle getRecordedBounds() {
/*  68 */     return this.recordedBounds;
/*     */   }
/*     */   
/*     */   public Point getRecordedSize() {
/*  72 */     if (this.recordedBounds == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     return new Point(this.recordedBounds.width, this.recordedBounds.height);
/*     */   }
/*     */   
/*     */   public Point getRecordedPosition() {
/*  79 */     if (this.recordedBounds == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     return new Point(this.recordedBounds.x, this.recordedBounds.y);
/*     */   }
/*     */   
/*     */   private void setup() {
/*  86 */     if ((this.widgetId != 0) && (this.widgetManager != null)) {
/*  87 */       this.recordedBounds = this.widgetManager.getRecordedBounds(this.widgetId);
/*     */       
/*  89 */       this.shell.addListener(21, this. = new Listener()
/*     */       {
/*     */         public void handleEvent(Event event) {
/*  92 */           ShellWrapper.this.widgetManager.setRecordedBounds(ShellWrapper.this.widgetId, ShellWrapper.this.shell.getBounds());
/*     */         }
/*     */         
/*  95 */       });
/*  96 */       this.shell.addDisposeListener(new DisposeListener()
/*     */       {
/*     */         public void widgetDisposed(DisposeEvent e) {
/*  99 */           if (ShellWrapper.this.closeListener != null) {
/* 100 */             ShellWrapper.this.shell.removeListener(21, ShellWrapper.this.closeListener);
/*     */           }
/*     */         }
/*     */       });
/*     */       
/* 105 */       if (this.recordedBounds != null) {
/* 106 */         this.shell.setBounds(this.recordedBounds);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\ShellWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */