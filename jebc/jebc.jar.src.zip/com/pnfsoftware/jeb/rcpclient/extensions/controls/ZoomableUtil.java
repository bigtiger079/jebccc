/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ZoomableUtil
/*    */ {
/*    */   public static int updateZoom(int previous, int update)
/*    */   {
/* 18 */     if (update > 0) {
/* 19 */       return previous + 1;
/*    */     }
/* 21 */     if (update < 0) {
/* 22 */       return previous - 1;
/*    */     }
/* 24 */     return 0;
/*    */   }
/*    */   
/*    */   public static int sanitizeZoom(int zoom) {
/* 28 */     if (zoom < 0) {
/* 29 */       return -1;
/*    */     }
/* 31 */     if (zoom > 0) {
/* 32 */       return 1;
/*    */     }
/* 34 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\ZoomableUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */