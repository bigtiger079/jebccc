/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import java.io.File;
/*    */ import org.eclipse.swt.events.SelectionAdapter;
/*    */ import org.eclipse.swt.events.SelectionEvent;
/*    */ import org.eclipse.swt.widgets.FileDialog;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileSelectionListener
/*    */   extends SelectionAdapter
/*    */ {
/*    */   Shell parent;
/*    */   Text text;
/*    */   private String[] extensions;
/*    */   
/*    */   public FileSelectionListener(Shell parent, Text text, String[] extensions)
/*    */   {
/* 34 */     this.parent = parent;
/* 35 */     this.text = text;
/* 36 */     this.extensions = extensions;
/*    */   }
/*    */   
/*    */   public void widgetSelected(SelectionEvent e)
/*    */   {
/* 41 */     FileDialog dirdlg = new FileDialog(this.parent, 4096);
/* 42 */     dirdlg.setText(S.s(341));
/* 43 */     dirdlg.setFilterExtensions(this.extensions);
/*    */     
/* 45 */     String dirname = getDefaultText();
/* 46 */     if (dirname != null) {
/* 47 */       File dir = new File(dirname);
/* 48 */       if (dir.isAbsolute()) {}
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 57 */     if (dirname != null) {
/* 58 */       dirdlg.setFilterPath(dirname);
/*    */     }
/*    */     
/* 61 */     dirname = dirdlg.open();
/* 62 */     if (dirname != null) {
/* 63 */       setText(dirname);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getDefaultText() {
/* 68 */     return this.text.getText();
/*    */   }
/*    */   
/*    */   public void setText(String dirname) {
/* 72 */     this.text.setText(dirname);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\FileSelectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */