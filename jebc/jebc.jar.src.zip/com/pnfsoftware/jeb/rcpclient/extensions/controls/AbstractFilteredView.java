/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFilteredView<T extends Composite>
/*     */   extends Composite
/*     */ {
/*     */   private Composite container;
/*     */   private FilterText filterText;
/*     */   private String previousFilterText;
/*     */   private T mainElement;
/*     */   
/*     */   public AbstractFilteredView(Composite parent, int style, String[] columnNames)
/*     */   {
/*  40 */     this(parent, style, columnNames, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFilteredView(Composite parent, int style, String[] columnNames, int[] columnWidths, boolean displayIndex)
/*     */   {
/*  52 */     super(parent, 0);
/*  53 */     setLayout(new FillLayout());
/*     */     
/*  55 */     this.container = new Composite(this, 0);
/*  56 */     GridLayout layout = new GridLayout(1, false);
/*     */     
/*  58 */     this.container.setLayout(layout);
/*     */     
/*  60 */     final boolean filterOnTop = (style & 0x80) != 0;
/*  61 */     if (filterOnTop) {
/*  62 */       style &= 0xFF7F;
/*  63 */       this.filterText = new FilterText(this.container);
/*     */     }
/*     */     
/*  66 */     this.mainElement = buildElement(this.container, style);
/*     */     
/*  68 */     if (!filterOnTop) {
/*  69 */       this.filterText = new FilterText(this.container);
/*     */     }
/*  71 */     this.filterText.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     
/*  73 */     boolean singleColumn = (!displayIndex) && (columnNames != null) && (columnNames.length == 1);
/*  74 */     if (displayIndex) {
/*  75 */       buildColumn(this.mainElement, "Index", singleColumn ? 0 : 50);
/*     */     }
/*  77 */     if (columnNames != null) {
/*  78 */       int i = 0;
/*  79 */       for (String name : columnNames) {
/*  80 */         buildColumn(this.mainElement, name, columnWidths != null ? columnWidths[i] : singleColumn ? 0 : 100);
/*  81 */         i++;
/*     */       }
/*     */     }
/*     */     
/*  85 */     this.filterText.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/*  89 */         if ((e.keyCode == 16777218) && (filterOnTop) && (AbstractFilteredView.this.getItemCount() > 0)) {
/*  90 */           AbstractFilteredView.this.setSelection(0);
/*  91 */           AbstractFilteredView.this.mainElement.setFocus();
/*  92 */           e.doit = false;
/*     */         }
/*  94 */         else if ((e.keyCode == 16777217) && (!filterOnTop) && (AbstractFilteredView.this.getItemCount() > 0)) {
/*  95 */           AbstractFilteredView.this.setSelection(AbstractFilteredView.this.getItemCount() - 1);
/*  96 */           AbstractFilteredView.this.mainElement.setFocus();
/*  97 */           e.doit = false;
/*     */ 
/*     */         }
/* 100 */         else if (((e.stateMask & SWT.MOD1) == SWT.MOD1) && (e.keyCode == 8)) {
/* 101 */           AbstractFilteredView.this.filterText.setText("");
/* 102 */           e.doit = false;
/*     */ 
/*     */         }
/* 105 */         else if (e.keyCode == 27) {
/* 106 */           AbstractFilteredView.this.setFilterVisibility(false, false);
/* 107 */           AbstractFilteredView.this.mainElement.setFocus();
/* 108 */           e.doit = false;
/*     */         }
/*     */         
/*     */       }
/* 112 */     });
/* 113 */     this.mainElement.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/* 117 */         if (((e.keyCode == 16777217) && (filterOnTop) && (AbstractFilteredView.this.getSelectionIndex() == 0)) || ((e.keyCode == 16777218) && (!filterOnTop) && 
/* 118 */           (AbstractFilteredView.this.getSelectionIndex() == AbstractFilteredView.this.getItemCount() - 1))) {
/* 119 */           if (AbstractFilteredView.this.filterText.isVisible()) {
/* 120 */             AbstractFilteredView.this.filterText.setFocus();
/* 121 */             e.doit = false;
/*     */           }
/*     */           
/*     */         }
/* 125 */         else if (((e.stateMask & SWT.MOD1) == SWT.MOD1) && (e.keyCode == 102)) {
/* 126 */           AbstractFilteredView.this.setFilterVisibility(true, true);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public IFilterText getFilterText()
/*     */   {
/* 134 */     return this.filterText;
/*     */   }
/*     */   
/*     */   public T getElement() {
/* 138 */     return this.mainElement;
/*     */   }
/*     */   
/*     */   public boolean setFocus()
/*     */   {
/* 143 */     return this.mainElement.setFocus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterVisibility(boolean visible, boolean focus)
/*     */   {
/* 153 */     if (this.filterText.isVisible() != visible) {
/* 154 */       Object layoutData = this.filterText.getLayoutData();
/* 155 */       if ((layoutData instanceof GridData)) {
/* 156 */         ((GridData)layoutData).exclude = (!visible);
/*     */       }
/* 158 */       this.filterText.setVisible(visible);
/* 159 */       this.filterText.getParent().layout();
/*     */       
/* 161 */       if (!visible) {
/* 162 */         this.previousFilterText = this.filterText.getText();
/* 163 */         this.filterText.setText("");
/*     */       }
/* 165 */       else if (this.previousFilterText != null) {
/* 166 */         this.filterText.setText(this.previousFilterText);
/* 167 */         this.previousFilterText = null;
/*     */       }
/*     */     }
/* 170 */     if (focus) {
/* 171 */       this.filterText.setFocus();
/* 172 */       this.filterText.selectAll();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFilterVisibility(boolean visible) {
/* 177 */     setFilterVisibility(visible, visible);
/*     */   }
/*     */   
/*     */   protected abstract T buildElement(Composite paramComposite, int paramInt);
/*     */   
/*     */   protected abstract void buildColumn(T paramT, String paramString, int paramInt);
/*     */   
/*     */   public abstract int getSelectionIndex();
/*     */   
/*     */   public abstract void setSelection(int paramInt);
/*     */   
/*     */   public abstract int getItemCount();
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\AbstractFilteredView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */