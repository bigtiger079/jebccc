/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import org.eclipse.swt.graphics.FontMetrics;
/*    */ import org.eclipse.swt.graphics.GC;
/*    */ import org.eclipse.swt.layout.GridData;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputField
/*    */   extends Composite
/*    */   implements ITextControl
/*    */ {
/*    */   private Text textbox;
/*    */   
/*    */   public InputField(Composite parent, String name, String initialValue, int wantedLength)
/*    */   {
/* 31 */     super(parent, 0);
/* 32 */     setLayout(new GridLayout(2, false));
/*    */     
/* 34 */     this.textbox = new Text(this, 2052);
/* 35 */     if (initialValue != null) {
/* 36 */       this.textbox.setText(initialValue);
/*    */     }
/*    */     
/* 39 */     if (wantedLength >= 1) {
/* 40 */       GC gc = new GC(this.textbox);
/*    */       try {
/* 42 */         gc.setFont(this.textbox.getFont());
/* 43 */         FontMetrics fm = gc.getFontMetrics();
/* 44 */         GridData data = new GridData(wantedLength * fm.getAverageCharWidth(), 1 * fm.getHeight());
/* 45 */         this.textbox.setLayoutData(data);
/*    */       }
/*    */       finally {
/* 48 */         gc.dispose();
/*    */       }
/*    */     }
/*    */     
/* 52 */     Label l = new Label(this, 0);
/* 53 */     if (name != null) {
/* 54 */       l.setText(name);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getText()
/*    */   {
/* 60 */     return this.textbox.getText();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\InputField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */