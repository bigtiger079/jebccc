/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.events.ControlListener;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseWheelListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfiniTableView
/*     */   extends Composite
/*     */ {
/*  36 */   private static final ILogger logger = GlobalLog.getLogger(InfiniTableView.class);
/*     */   
/*     */   private Table table;
/*     */   private IOutOfRangeHelper oorHandler;
/*  40 */   private int currentSelection = -1;
/*     */   
/*     */   public InfiniTableView(Composite parent, int style, String[] columnNames) {
/*  43 */     super(parent, style);
/*     */     
/*     */ 
/*  46 */     setLayout(new GridLayout());
/*     */     
/*  48 */     this.table = new Table(this, 0x10010 | style);
/*  49 */     this.table.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*  50 */     this.table.setHeaderVisible(true);
/*  51 */     this.table.setLinesVisible(true);
/*     */     
/*  53 */     for (String name : columnNames) {
/*  54 */       buildColumn(this.table, name, 100);
/*     */     }
/*     */     
/*  57 */     this.table.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  60 */         if (InfiniTableView.this.currentSelection == -1) {
/*  61 */           InfiniTableView.this.currentSelection = InfiniTableView.this.table.getSelectionIndex();
/*  62 */           return;
/*     */         }
/*     */         
/*  65 */         boolean syncChange = true;
/*     */         
/*  67 */         int prevSel = InfiniTableView.this.currentSelection;
/*  68 */         int sel = InfiniTableView.this.table.getSelectionIndex();
/*  69 */         int topIndex = InfiniTableView.this.table.getTopIndex();
/*     */         
/*     */ 
/*  72 */         int visi = InfiniTableView.this.getMaximumVisibleRowCount(true);
/*  73 */         if ((prevSel < topIndex) || (prevSel > topIndex + visi)) {
/*  74 */           InfiniTableView.this.oorHandler.onResetRange(topIndex);
/*  75 */           sel -= topIndex;
/*  76 */           InfiniTableView.this.table.setSelection(sel);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  81 */         InfiniTableView.this.currentSelection = sel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     });
/* 102 */     this.table.addKeyListener(new KeyAdapter()
/*     */     {
/*     */       public void keyPressed(KeyEvent e) {
/* 105 */         int selIndex = InfiniTableView.this.table.getSelectionIndex();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 110 */         if (e.keyCode == 16777217) {
/* 111 */           if (selIndex == -1) {
/* 112 */             InfiniTableView.this.table.setSelection(0);
/* 113 */             selIndex = 0;
/*     */           }
/*     */           
/* 116 */           if (selIndex == 0) {
/* 117 */             InfiniTableView.this.oorHandler.onRequestOutOfRange(-1, 0);
/* 118 */             e.doit = false;
/*     */           }
/*     */         }
/* 121 */         else if (e.keyCode == 16777218) {
/* 122 */           if (selIndex == InfiniTableView.this.table.getItemCount() - 1)
/*     */           {
/* 124 */             InfiniTableView.this.oorHandler.onRequestOutOfRange(1, 0);
/* 125 */             e.doit = false;
/*     */           }
/*     */         }
/* 128 */         else if (e.keyCode == 16777221)
/*     */         {
/*     */ 
/*     */ 
/* 132 */           e.doit = false;
/*     */         }
/* 134 */         else if (e.keyCode == 16777222)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 139 */           e.doit = false;
/*     */         }
/* 141 */         else if (e.keyCode == 16777223) {
/* 142 */           e.doit = false;
/*     */         }
/* 144 */         else if (e.keyCode == 16777224) {
/* 145 */           e.doit = false;
/*     */         }
/*     */         
/*     */       }
/* 149 */     });
/* 150 */     this.table.addMouseWheelListener(new MouseWheelListener()
/*     */     {
/*     */       public void mouseScrolled(MouseEvent e) {
/* 153 */         int topIndex = InfiniTableView.this.table.getTopIndex();
/* 154 */         int rowCount = InfiniTableView.this.table.getItemCount();
/* 155 */         int visi = InfiniTableView.this.getMaximumVisibleRowCount(true);
/* 156 */         int newTopIndex = topIndex - e.count;
/* 157 */         if ((newTopIndex < 0) || (newTopIndex >= rowCount - visi)) {
/* 158 */           InfiniTableView.this.oorHandler.onRequestOutOfRange(0, newTopIndex - topIndex);
/*     */         }
/*     */         else {
/* 161 */           InfiniTableView.this.table.setTopIndex(newTopIndex);
/*     */         }
/* 163 */         InfiniTableView.this.currentSelection = InfiniTableView.this.table.getSelectionIndex();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void addControlListener(ControlListener listener)
/*     */   {
/* 170 */     this.table.addControlListener(listener);
/*     */   }
/*     */   
/*     */   public void removeControlListener(ControlListener listener)
/*     */   {
/* 175 */     this.table.removeControlListener(listener);
/*     */   }
/*     */   
/*     */   public int getMaximumVisibleRowCount(boolean includePartialRow) {
/* 179 */     int height = this.table.getClientArea().height;
/* 180 */     if (height == 0)
/*     */     {
/* 182 */       return 0;
/*     */     }
/* 184 */     int H = height - this.table.getHeaderHeight();
/* 185 */     int h = this.table.getItemHeight();
/* 186 */     int cnt = H / h;
/* 187 */     if ((includePartialRow) && (H % h != 0)) {
/* 188 */       cnt++;
/*     */     }
/* 190 */     return cnt;
/*     */   }
/*     */   
/*     */   public void setRequestOutOfRangeHandler(IOutOfRangeHelper oorHandler) {
/* 194 */     this.oorHandler = oorHandler;
/*     */   }
/*     */   
/*     */   public Table getTable() {
/* 198 */     return this.table;
/*     */   }
/*     */   
/*     */   protected void buildColumn(Table parent, String name, int initialWidth) {
/* 202 */     TableColumn tc = new TableColumn(parent, 16384);
/* 203 */     tc.setText(name);
/* 204 */     tc.setResizable(true);
/* 205 */     tc.setMoveable(true);
/* 206 */     if (initialWidth > 0) {
/* 207 */       tc.setWidth(initialWidth);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\InfiniTableView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */