package com.pnfsoftware.jeb.rcpclient.extensions.controls;

public abstract interface IOutOfRangeHelper
{
  public abstract void onResetRange(int paramInt);
  
  public abstract void onRequestOutOfRange(int paramInt1, int paramInt2);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\IOutOfRangeHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */