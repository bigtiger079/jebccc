/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectorySelectorView
/*    */   extends Composite
/*    */   implements ITextControl
/*    */ {
/*    */   private Label l;
/*    */   private Text textbox;
/*    */   private Button browse;
/*    */   
/*    */   public DirectorySelectorView(Composite parent, String name, String value)
/*    */   {
/* 32 */     super(parent, 0);
/* 33 */     setLayout(new GridLayout(3, false));
/*    */     
/* 35 */     this.l = new Label(this, 0);
/* 36 */     if (name != null) {
/* 37 */       this.l.setText(name);
/*    */     }
/*    */     
/* 40 */     this.textbox = new Text(this, 2052);
/* 41 */     if (value != null) {
/* 42 */       this.textbox.setText(value);
/*    */     }
/* 44 */     this.textbox.setLayoutData(UIUtil.createGridDataForText(this.textbox, 50));
/*    */     
/* 46 */     this.browse = UIUtil.createPushbox(this, S.s(102), new DirectorySelectionListener(getShell(), this.textbox));
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled)
/*    */   {
/* 51 */     super.setEnabled(enabled);
/* 52 */     if (this.l != null) {
/* 53 */       this.l.setEnabled(enabled);
/*    */     }
/* 55 */     this.textbox.setEnabled(enabled);
/* 56 */     this.browse.setEnabled(enabled);
/*    */   }
/*    */   
/*    */   public Text getTextbox() {
/* 60 */     return this.textbox;
/*    */   }
/*    */   
/*    */   public String getText()
/*    */   {
/* 65 */     return this.textbox.getText();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\DirectorySelectorView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */