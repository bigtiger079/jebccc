/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.table.TableUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredTableView
/*     */   extends AbstractFilteredView<Table>
/*     */ {
/*  34 */   private List<ITableEventListener> listeners = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilteredTableView(Composite parent, int style, String[] columnNames)
/*     */   {
/*  45 */     this(parent, style, columnNames, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilteredTableView(Composite parent, int style, String[] columnNames, int[] columnWidths, boolean displayIndex)
/*     */   {
/*  58 */     super(parent, style, columnNames, columnWidths, displayIndex);
/*     */     
/*  60 */     getTable().addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  63 */         if (!(e.item instanceof TableItem)) {
/*  64 */           return;
/*     */         }
/*     */         
/*  67 */         Object object = e.item.getData();
/*  68 */         boolean selected = FilteredTableView.this.getTable().getSelectionCount() > 0;
/*  69 */         boolean checked = ((TableItem)e.item).getChecked();
/*     */         
/*  71 */         for (ITableEventListener listener : FilteredTableView.this.listeners) {
/*  72 */           listener.onTableEvent(object, selected, checked);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected Table buildElement(Composite parent, int style)
/*     */   {
/*  80 */     Table table = new Table(parent, 0x10000 | style | 0x2);
/*  81 */     table.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*  82 */     table.setHeaderVisible(true);
/*  83 */     table.setLinesVisible(true);
/*  84 */     return table;
/*     */   }
/*     */   
/*     */   protected void buildColumn(Table parent, String name, int initialWidth)
/*     */   {
/*  89 */     TableColumn tc = new TableColumn(parent, 16384);
/*  90 */     tc.setText(name);
/*  91 */     tc.setResizable(true);
/*  92 */     tc.setMoveable(true);
/*  93 */     if (initialWidth > 0) {
/*  94 */       tc.setWidth(initialWidth);
/*     */     }
/*     */   }
/*     */   
/*     */   public Table getTable() {
/*  99 */     return (Table)getElement();
/*     */   }
/*     */   
/*     */   public int getSelectionIndex()
/*     */   {
/* 104 */     return ((Table)getElement()).getSelectionIndex();
/*     */   }
/*     */   
/*     */   public void setSelection(int index)
/*     */   {
/* 109 */     ((Table)getElement()).setSelection(index);
/* 110 */     ((Table)getElement()).showSelection();
/*     */   }
/*     */   
/*     */   public int getItemCount()
/*     */   {
/* 115 */     return ((Table)getElement()).getItemCount();
/*     */   }
/*     */   
/*     */   public void addTableEventListener(ITableEventListener listener) {
/* 119 */     if (!this.listeners.contains(listener)) {
/* 120 */       this.listeners.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeTableEventListener(ITableEventListener listener) {
/* 125 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void addSelectionListener(SelectionListener listener) {
/* 129 */     ((Table)getElement()).addSelectionListener(listener);
/*     */   }
/*     */   
/*     */   public void removeSelectionListener(SelectionListener listener) {
/* 133 */     ((Table)getElement()).removeSelectionListener(listener);
/*     */   }
/*     */   
/*     */   public void pack(boolean changed)
/*     */   {
/* 138 */     super.pack(changed);
/*     */     
/* 140 */     int cnt = ((Table)getElement()).getColumns().length;
/* 141 */     int cx = ((Table)getElement()).getSize().x;
/* 142 */     if (cnt <= 1) {
/* 143 */       if (cnt == 1) {
/* 144 */         ((Table)getElement()).getColumns()[0].setWidth(cx);
/*     */       }
/* 146 */       return;
/*     */     }
/*     */     
/* 149 */     int maxWidthColumn = cx / cnt;
/* 150 */     for (TableColumn tc : ((Table)getElement()).getColumns()) {
/* 151 */       tc.pack();
/* 152 */       if (tc.getWidth() > maxWidthColumn) {
/* 153 */         tc.setWidth(maxWidthColumn);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String exportToString() {
/* 159 */     return TableUtil.buildCsv(getTable());
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\FilteredTableView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */