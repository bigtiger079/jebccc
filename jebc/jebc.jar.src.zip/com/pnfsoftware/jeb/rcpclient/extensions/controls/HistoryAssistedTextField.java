/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.TextHistory;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.bindings.keys.KeyStroke;
/*     */ import org.eclipse.jface.fieldassist.ContentProposal;
/*     */ import org.eclipse.jface.fieldassist.ContentProposalAdapter;
/*     */ import org.eclipse.jface.fieldassist.ControlDecoration;
/*     */ import org.eclipse.jface.fieldassist.FieldDecoration;
/*     */ import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
/*     */ import org.eclipse.jface.fieldassist.IContentProposal;
/*     */ import org.eclipse.jface.fieldassist.IContentProposalProvider;
/*     */ import org.eclipse.jface.fieldassist.TextContentAdapter;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.events.TraverseEvent;
/*     */ import org.eclipse.swt.events.TraverseListener;
/*     */ import org.eclipse.swt.events.VerifyEvent;
/*     */ import org.eclipse.swt.events.VerifyListener;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HistoryAssistedTextField
/*     */   extends Composite
/*     */ {
/*  49 */   private static final ILogger logger = GlobalLog.getLogger(HistoryAssistedTextField.class);
/*     */   
/*     */   private Text text;
/*     */   
/*     */   private ContentProposalAdapter cpa;
/*     */   
/*     */   private TextHistory history;
/*     */   
/*     */   public HistoryAssistedTextField(Composite parent, String labelText, final TextHistory history, boolean displayHelpDecorator)
/*     */   {
/*  59 */     super(parent, 0);
/*  60 */     setLayout(new FillLayout());
/*  61 */     this.history = history;
/*     */     
/*  63 */     Composite ph = new Composite(this, 0);
/*  64 */     ph.setLayout(new GridLayout(2, false));
/*     */     
/*  66 */     Label label = new Label(ph, 0);
/*  67 */     label.setText(labelText);
/*     */     
/*     */ 
/*  70 */     this.text = UIUtil.createTextboxInGrid(ph, 2052, 30, 1);
/*  71 */     ((GridData)this.text.getLayoutData()).horizontalIndent = 8;
/*  72 */     ((GridData)this.text.getLayoutData()).grabExcessHorizontalSpace = true;
/*  73 */     ((GridData)this.text.getLayoutData()).horizontalAlignment = 4;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     if (history != null) {
/*  80 */       Label hint2 = new Label(ph, 64);
/*  81 */       hint2.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  82 */       hint2.setText("(Hit Control+Space to browse your input history)");
/*     */       
/*  84 */       if (displayHelpDecorator) {
/*  85 */         ControlDecoration deco = new ControlDecoration(this.text, 16512);
/*     */         
/*  87 */         Image image = FieldDecorationRegistry.getDefault().getFieldDecoration("DEC_INFORMATION").getImage();
/*  88 */         deco.setDescriptionText("Hit Control+Space to browse your input history");
/*  89 */         deco.setImage(image);
/*  90 */         deco.setShowOnlyOnFocus(true);
/*     */       }
/*     */       
/*  93 */       char[] autoActivationCharacters = new char[0];
/*  94 */       KeyStroke keyStroke = KeyStroke.getInstance(262144, 32);
/*     */       
/*  96 */       this.cpa = new ContentProposalAdapter(this.text, new TextContentAdapter(), new HistoryProposalProvider(history), keyStroke, autoActivationCharacters);
/*     */       
/*  98 */       this.cpa.setPopupSize(new Point(300, 200));
/*  99 */       this.cpa.setProposalAcceptanceStyle(2);
/*     */       
/* 101 */       this.text.addTraverseListener(new TraverseListener()
/*     */       {
/*     */         public void keyTraversed(TraverseEvent e)
/*     */         {
/* 105 */           if (e.character == '\r')
/*     */           {
/*     */ 
/* 108 */             if (!HistoryAssistedTextField.this.cpa.isProposalPopupOpen())
/*     */             {
/*     */ 
/* 111 */               history.record(HistoryAssistedTextField.this.text.getText());
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 118 */     this.text.addVerifyListener(new VerifyListener()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void verifyText(VerifyEvent e) {}
/*     */ 
/*     */ 
/* 125 */     });
/* 126 */     this.text.addKeyListener(new KeyListener()
/*     */     {
/*     */       public void keyReleased(KeyEvent e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void keyPressed(KeyEvent e)
/*     */       {
/* 136 */         if ((e.stateMask == SWT.MOD1) && (e.character == '\b')) {
/* 137 */           HistoryAssistedTextField.this.text.setText("");
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   class HistoryProposalProvider implements IContentProposalProvider {
/*     */     TextHistory hist;
/*     */     
/*     */     public HistoryProposalProvider(TextHistory history) {
/* 147 */       this.hist = history;
/*     */     }
/*     */     
/*     */     public IContentProposal[] getProposals(String contents, int position)
/*     */     {
/* 152 */       String template = "";
/* 153 */       if (HistoryAssistedTextField.this.text.getSelectionCount() != contents.length())
/*     */       {
/* 155 */         template = contents;
/*     */       }
/*     */       
/* 158 */       List<IContentProposal> r = new ArrayList();
/* 159 */       for (String s : this.hist.getAll()) {
/* 160 */         if (s.contains(template)) {
/* 161 */           ContentProposal proposal = new ContentProposal(s, s, null, s.length());
/* 162 */           r.add(0, proposal);
/*     */         }
/*     */       }
/* 165 */       return (IContentProposal[])r.toArray(new IContentProposal[r.size()]);
/*     */     }
/*     */   }
/*     */   
/*     */   static class OverwriteContentAdapter extends TextContentAdapter
/*     */   {
/*     */     public void insertControlContents(Control control, String contents, int cursorPosition)
/*     */     {
/* 173 */       ((Text)control).setText(contents);
/* 174 */       ((Text)control).setSelection(contents.length());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void confirm()
/*     */   {
/* 184 */     if (this.history != null)
/*     */     {
/*     */ 
/* 187 */       if (!this.cpa.isProposalPopupOpen())
/*     */       {
/*     */ 
/* 190 */         String str = this.text.getText();
/* 191 */         if (!str.isEmpty()) {
/* 192 */           this.history.record(this.text.getText());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Text getWidget() {
/* 199 */     return this.text;
/*     */   }
/*     */   
/*     */   public String getText() {
/* 203 */     return this.text.getText();
/*     */   }
/*     */   
/*     */   public void setText(String content) {
/* 207 */     this.text.setText(content);
/*     */   }
/*     */   
/*     */   public void selectAll() {
/* 211 */     this.text.selectAll();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\HistoryAssistedTextField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */