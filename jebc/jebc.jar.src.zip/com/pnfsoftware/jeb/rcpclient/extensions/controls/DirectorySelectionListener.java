/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import com.pnfsoftware.jeb.client.S;
/*    */ import org.eclipse.swt.events.SelectionAdapter;
/*    */ import org.eclipse.swt.events.SelectionEvent;
/*    */ import org.eclipse.swt.widgets.DirectoryDialog;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectorySelectionListener
/*    */   extends SelectionAdapter
/*    */ {
/*    */   Shell parent;
/*    */   Text text;
/*    */   
/*    */   public DirectorySelectionListener(Shell parent, Text text)
/*    */   {
/* 31 */     this.parent = parent;
/* 32 */     this.text = text;
/*    */   }
/*    */   
/*    */   public void widgetSelected(SelectionEvent e)
/*    */   {
/* 37 */     DirectoryDialog dirdlg = new DirectoryDialog(this.parent, 4096);
/* 38 */     dirdlg.setMessage(S.s(277));
/*    */     
/* 40 */     String dirname = getDefaultText();
/* 41 */     if (dirname != null) {
/* 42 */       dirdlg.setFilterPath(dirname);
/*    */     }
/*    */     
/* 45 */     dirname = dirdlg.open();
/* 46 */     if (dirname != null) {
/* 47 */       setText(dirname);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getDefaultText() {
/* 52 */     return this.text.getText();
/*    */   }
/*    */   
/*    */   public void setText(String dirname) {
/* 56 */     this.text.setText(dirname);
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\DirectorySelectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */