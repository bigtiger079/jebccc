/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ import org.eclipse.swt.widgets.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongInputField
/*    */   extends Composite
/*    */   implements ITextControl
/*    */ {
/*    */   private Text textbox;
/*    */   
/*    */   public LongInputField(Composite parent, String name, String value)
/*    */   {
/* 28 */     super(parent, 0);
/* 29 */     setLayout(new GridLayout(1, false));
/*    */     
/* 31 */     this.textbox = create(this, name, value, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Text create(Composite parent, String name, String value, boolean fillLabel)
/*    */   {
/* 39 */     Label l = new Label(parent, 0);
/* 40 */     if (name != null) {
/* 41 */       l.setText(name);
/*    */     }
/* 43 */     l.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, fillLabel, false));
/*    */     
/* 45 */     Text textbox = new Text(parent, 2052);
/* 46 */     if (value != null) {
/* 47 */       textbox.setText(value);
/*    */     }
/* 49 */     textbox.setLayoutData(UIUtil.createGridDataFillHorizontally());
/* 50 */     return textbox;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getText()
/*    */   {
/* 56 */     return this.textbox.getText();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\LongInputField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */