/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditableList
/*     */   extends Composite
/*     */ {
/*     */   private Label l;
/*     */   private Table table;
/*     */   private Composite buttons;
/*     */   
/*     */   public EditableList(Composite parent, int style, String label, String[] values)
/*     */   {
/*  44 */     super(parent, 0);
/*  45 */     setLayout(new FillLayout());
/*     */     
/*  47 */     Composite ph = new Composite(this, 0);
/*  48 */     ph.setLayout(new GridLayout(2, false));
/*     */     
/*  50 */     this.l = UIUtil.createLabel(ph, label);
/*  51 */     this.l.setLayoutData(UIUtil.createGridDataSpanHorizontally(2, true, false));
/*  52 */     this.table = new Table(ph, 0x800 | style);
/*  53 */     GridData d = new GridData(-1, 100);
/*  54 */     d.horizontalAlignment = 4;
/*  55 */     d.grabExcessHorizontalSpace = true;
/*  56 */     this.table.setLayoutData(d);
/*  57 */     resetItems(values);
/*  58 */     this.buttons = new Composite(ph, 0);
/*     */     
/*  60 */     this.buttons.setLayout(new GridLayout(1, true));
/*  61 */     this.table.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {
/*  64 */         boolean enabled = (EditableList.this.getSelectionIndices() != null) && (EditableList.this.getSelectionIndices().length != 0);
/*  65 */         for (Control c : EditableList.this.compositeEnabledOnSelection.keySet()) {
/*  66 */           c.setEnabled(enabled);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*  73 */   Map<Control, Boolean> compositeEnabledOnSelection = new WeakHashMap();
/*     */   
/*     */   public void addButton(String label, SelectionListener listener, boolean enableOnSelection) {
/*  76 */     Button b = UIUtil.createPushbox(this.buttons, label, listener);
/*  77 */     GridData data = new GridData();
/*  78 */     data.horizontalAlignment = 4;
/*  79 */     b.setLayoutData(data);
/*  80 */     if (enableOnSelection) {
/*  81 */       this.compositeEnabledOnSelection.put(b, Boolean.TRUE);
/*  82 */       b.setEnabled(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/*  88 */     super.setEnabled(enabled);
/*  89 */     this.l.setEnabled(enabled);
/*  90 */     this.table.setEnabled(enabled);
/*  91 */     for (Control button : this.buttons.getChildren()) {
/*  92 */       button.setEnabled(enabled);
/*     */     }
/*     */   }
/*     */   
/*     */   public Table getTable() {
/*  97 */     return this.table;
/*     */   }
/*     */   
/*     */   public int[] getSelectionIndices() {
/* 101 */     return this.table.getSelectionIndices();
/*     */   }
/*     */   
/*     */   public TableItem[] getSelection() {
/* 105 */     return this.table.getSelection();
/*     */   }
/*     */   
/*     */   public void resetItems(String[] values) {
/* 109 */     int selected = this.table.getSelectionIndex();
/* 110 */     this.table.removeAll();
/* 111 */     for (String e : values) {
/* 112 */       TableItem item = new TableItem(this.table, 0);
/* 113 */       item.setText(e);
/*     */     }
/* 115 */     this.table.setSelection(selected);
/*     */   }
/*     */   
/*     */   public void resetItems(List<ICheckable> values) {
/* 119 */     int selected = this.table.getSelectionIndex();
/* 120 */     this.table.removeAll();
/* 121 */     for (ICheckable e : values) {
/* 122 */       TableItem item = new TableItem(this.table, 0);
/* 123 */       item.setText(e.getText());
/* 124 */       item.setChecked(e.isChecked());
/*     */     }
/* 126 */     this.table.setSelection(selected);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class SimpleCheckable
/*     */     implements EditableList.ICheckable
/*     */   {
/*     */     private String text;
/*     */     
/*     */     private boolean checked;
/*     */     
/*     */ 
/*     */     public SimpleCheckable(String text, boolean checked)
/*     */     {
/* 140 */       this.text = text;
/* 141 */       this.checked = checked;
/*     */     }
/*     */     
/*     */     public String getText()
/*     */     {
/* 146 */       return this.text;
/*     */     }
/*     */     
/*     */     public boolean isChecked()
/*     */     {
/* 151 */       return this.checked;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface ICheckable
/*     */   {
/*     */     public abstract String getText();
/*     */     
/*     */     public abstract boolean isChecked();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\EditableList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */