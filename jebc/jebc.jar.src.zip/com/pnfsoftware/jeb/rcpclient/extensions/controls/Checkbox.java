/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Button;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Checkbox
/*    */   extends Composite
/*    */   implements ITextControl
/*    */ {
/*    */   private Button btn;
/*    */   
/*    */   public Checkbox(Composite parent, String name, boolean selected)
/*    */   {
/* 24 */     super(parent, 0);
/* 25 */     GridLayout layout = new GridLayout(1, false);
/* 26 */     layout.marginHeight = 0;
/* 27 */     layout.verticalSpacing = 0;
/* 28 */     layout.marginWidth = 0;
/* 29 */     layout.horizontalSpacing = 0;
/* 30 */     setLayout(layout);
/*    */     
/* 32 */     this.btn = new Button(parent, 32);
/* 33 */     if (name != null) {
/* 34 */       this.btn.setText(name);
/*    */     }
/* 36 */     this.btn.setSelection(selected);
/*    */   }
/*    */   
/*    */   public String getText()
/*    */   {
/* 41 */     return Boolean.toString(this.btn.getSelection());
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\Checkbox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */