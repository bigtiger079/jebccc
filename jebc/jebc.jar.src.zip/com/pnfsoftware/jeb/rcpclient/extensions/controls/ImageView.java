/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import org.eclipse.swt.graphics.GC;
/*    */ import org.eclipse.swt.graphics.Image;
/*    */ import org.eclipse.swt.graphics.Point;
/*    */ import org.eclipse.swt.graphics.Rectangle;
/*    */ import org.eclipse.swt.layout.FillLayout;
/*    */ import org.eclipse.swt.widgets.Canvas;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.Listener;
/*    */ import org.eclipse.swt.widgets.ScrollBar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageView
/*    */   extends Composite
/*    */ {
/*    */   private Canvas canvas;
/*    */   private Point origin;
/*    */   
/*    */   public ImageView(Composite parent, byte[] data)
/*    */   {
/* 33 */     this(parent, new Image(parent.getDisplay(), new ByteArrayInputStream(data)));
/*    */   }
/*    */   
/*    */   public ImageView(Composite parent, final Image image) {
/* 37 */     super(parent, 0);
/* 38 */     setLayout(new FillLayout());
/*    */     
/* 40 */     this.canvas = new Canvas(this, 1049344);
/* 41 */     this.origin = new Point(0, 0);
/*    */     
/* 43 */     final ScrollBar hBar = this.canvas.getHorizontalBar();
/* 44 */     hBar.addListener(13, new Listener()
/*    */     {
/*    */       public void handleEvent(Event e) {
/* 47 */         int hSelection = hBar.getSelection();
/* 48 */         int destX = -hSelection - ImageView.this.origin.x;
/* 49 */         Rectangle rect = image.getBounds();
/* 50 */         ImageView.this.canvas.scroll(destX, 0, 0, 0, rect.width, rect.height, false);
/* 51 */         ImageView.this.origin.x = (-hSelection);
/*    */       }
/*    */       
/* 54 */     });
/* 55 */     final ScrollBar vBar = this.canvas.getVerticalBar();
/* 56 */     vBar.addListener(13, new Listener()
/*    */     {
/*    */       public void handleEvent(Event e) {
/* 59 */         int vSelection = vBar.getSelection();
/* 60 */         int destY = -vSelection - ImageView.this.origin.y;
/* 61 */         Rectangle rect = image.getBounds();
/* 62 */         ImageView.this.canvas.scroll(0, destY, 0, 0, rect.width, rect.height, false);
/* 63 */         ImageView.this.origin.y = (-vSelection);
/*    */       }
/*    */       
/* 66 */     });
/* 67 */     this.canvas.addListener(11, new Listener()
/*    */     {
/*    */       public void handleEvent(Event e) {
/* 70 */         Rectangle rect = image.getBounds();
/* 71 */         Rectangle client = ImageView.this.canvas.getClientArea();
/* 72 */         hBar.setMaximum(rect.width);
/* 73 */         vBar.setMaximum(rect.height);
/* 74 */         hBar.setThumb(Math.min(rect.width, client.width));
/* 75 */         vBar.setThumb(Math.min(rect.height, client.height));
/* 76 */         int hPage = rect.width - client.width;
/* 77 */         int vPage = rect.height - client.height;
/* 78 */         int hSelection = hBar.getSelection();
/* 79 */         int vSelection = vBar.getSelection();
/* 80 */         if (hSelection >= hPage) {
/* 81 */           if (hPage <= 0) {
/* 82 */             hSelection = 0;
/*    */           }
/* 84 */           ImageView.this.origin.x = (-hSelection);
/*    */         }
/* 86 */         if (vSelection >= vPage) {
/* 87 */           if (vPage <= 0) {
/* 88 */             vSelection = 0;
/*    */           }
/* 90 */           ImageView.this.origin.y = (-vSelection);
/*    */         }
/* 92 */         ImageView.this.canvas.redraw();
/*    */       }
/*    */       
/* 95 */     });
/* 96 */     this.canvas.addListener(9, new Listener()
/*    */     {
/*    */       public void handleEvent(Event e) {
/* 99 */         GC gc = e.gc;
/* :0 */         gc.drawImage(image, ImageView.this.origin.x, ImageView.this.origin.y);
/* :1 */         Rectangle rect = image.getBounds();
/* :2 */         Rectangle client = ImageView.this.canvas.getClientArea();
/* :3 */         int marginWidth = client.width - rect.width;
/* :4 */         if (marginWidth > 0) {
/* :5 */           gc.fillRectangle(rect.width, 0, marginWidth, client.height);
/*    */         }
/* :7 */         int marginHeight = client.height - rect.height;
/* :8 */         if (marginHeight > 0) {
/* :9 */           gc.fillRectangle(0, rect.height, client.width, marginHeight);
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\ImageView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */