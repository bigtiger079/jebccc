package com.pnfsoftware.jeb.rcpclient.extensions.controls;

public abstract interface ITextControl
{
  public abstract String getText();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\ITextControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */