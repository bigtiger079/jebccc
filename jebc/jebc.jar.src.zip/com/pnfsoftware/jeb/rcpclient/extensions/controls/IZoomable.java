package com.pnfsoftware.jeb.rcpclient.extensions.controls;

public abstract interface IZoomable
{
  public abstract int getZoomLevel();
  
  public abstract boolean applyZoom(int paramInt, boolean paramBoolean);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\IZoomable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */