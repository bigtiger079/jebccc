package com.pnfsoftware.jeb.rcpclient.extensions.controls;

public abstract interface ITableEventListener
{
  public abstract void onTableEvent(Object paramObject, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\ITableEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */