/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonGroup
/*     */   extends Composite
/*     */ {
/*     */   private Composite buttons;
/*  32 */   private List<Button> buttonList = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ButtonGroup(Composite parent, int style, GridData gridData)
/*     */   {
/*  41 */     super(parent, style);
/*     */     
/*  43 */     if (gridData != null)
/*     */     {
/*  45 */       setLayoutData(gridData);
/*  46 */       this.buttons = new Composite(this, 0);
/*  47 */       UIUtil.setStandardLayout(this, 1, 0);
/*     */     }
/*     */     else
/*     */     {
/*  51 */       this.buttons = this;
/*     */     }
/*  53 */     RowLayout rl = new RowLayout(256);
/*     */     
/*  55 */     rl.spacing = 6;
/*  56 */     this.buttons.setLayout(rl);
/*     */   }
/*     */   
/*     */   public void setBackground(Color color)
/*     */   {
/*  61 */     super.setBackground(color);
/*  62 */     this.buttons.setBackground(color);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button add(String name, SelectionListener listener)
/*     */   {
/*  74 */     Button b = UIUtil.createPushbox(this.buttons, name, listener);
/*  75 */     this.buttonList.add(b);
/*  76 */     return b;
/*     */   }
/*     */   
/*     */   public List<Button> getButtonList() {
/*  80 */     return this.buttonList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ButtonGroup buildBottomButtons(Composite parent, int style)
/*     */   {
/*  87 */     return buildBottomButtons(parent, style, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ButtonGroup buildBottomButtons(Composite parent, int style, int horizontalSpan)
/*     */   {
/*  94 */     GridData gd = new GridData(4, 1024, true, true, horizontalSpan, 1);
/*  95 */     return new ButtonGroup(parent, style, gd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ButtonGroup buildButtons(Composite parent, int style)
/*     */   {
/* 102 */     return new ButtonGroup(parent, style, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ButtonGroup buildButtons(Composite parent, int style, int horizontalSpan)
/*     */   {
/* 109 */     GridData gd = UIUtil.createGridDataSpanHorizontally(horizontalSpan);
/* 110 */     return new ButtonGroup(parent, style, gd);
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\ButtonGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */