/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimitiveDisplayView
/*     */   extends Composite
/*     */ {
/*  26 */   private static final ILogger logger = GlobalLog.getLogger(PrimitiveDisplayView.class);
/*     */   private DataFrame df;
/*     */   private DataFrameView dfv;
/*     */   
/*     */   public PrimitiveDisplayView(Composite parent, int style)
/*     */   {
/*  32 */     super(parent, style);
/*  33 */     setLayout(new FillLayout());
/*     */     
/*  35 */     this.df = new DataFrame(new String[] { "Type", "Value", "Hex value" });
/*  36 */     this.dfv = new DataFrameView(this, this.df, false);
/*  37 */     this.dfv.addExtraEntriesToContextMenu();
/*     */   }
/*     */   
/*     */   public void setBytes(byte[] data) {
/*  41 */     setBytes(data, 0, data != null ? data.length : -1);
/*     */   }
/*     */   
/*     */   public void setBytes(byte[] data, int offset, int length)
/*     */   {
/*  46 */     this.df.clear();
/*  47 */     if ((data != null) && (offset >= 0) && (length > 0) && (offset + length <= data.length)) {
/*  48 */       ByteBuffer b = ByteBuffer.wrap(data, offset, length);
/*     */       
/*     */ 
/*  51 */       if (b.limit() >= 2) {
/*  52 */         b.order(ByteOrder.LITTLE_ENDIAN);
/*  53 */         short v = b.getShort(0);
/*  54 */         this.df.addRow(new Object[] { "i16 LE", Short.toString(v), Integer.toHexString(v & 0xFFFF) });
/*  55 */         int u = v & 0xFFFF;
/*  56 */         this.df.addRow(new Object[] { "u16 LE", Integer.toString(u), Integer.toHexString(u & 0xFFFF) });
/*     */         
/*  58 */         b.order(ByteOrder.BIG_ENDIAN);
/*  59 */         v = b.getShort(0);
/*  60 */         this.df.addRow(new Object[] { "i16 BE", Short.toString(v), Integer.toHexString(v & 0xFFFF) });
/*  61 */         u = v & 0xFFFF;
/*  62 */         this.df.addRow(new Object[] { "i16 BE", Integer.toString(u), Integer.toHexString(u & 0xFFFF) });
/*     */       }
/*     */       
/*     */ 
/*  66 */       if (b.limit() >= 4) {
/*  67 */         b.order(ByteOrder.LITTLE_ENDIAN);
/*  68 */         int v = b.getInt(0);
/*  69 */         this.df.addRow(new Object[] { "i32 LE", Integer.toString(v), Integer.toHexString(v) });
/*  70 */         b.order(ByteOrder.BIG_ENDIAN);
/*  71 */         v = b.getInt(0);
/*  72 */         this.df.addRow(new Object[] { "i32 BE", Integer.toString(v), Integer.toHexString(v) });
/*     */       }
/*     */       
/*     */ 
/*  76 */       if (b.limit() >= 8) {
/*  77 */         b.order(ByteOrder.LITTLE_ENDIAN);
/*  78 */         long v = b.getLong(0);
/*  79 */         this.df.addRow(new Object[] { "i64 LE", Long.toString(v), Long.toHexString(v) });
/*  80 */         b.order(ByteOrder.BIG_ENDIAN);
/*  81 */         v = b.getLong(0);
/*  82 */         this.df.addRow(new Object[] { "i64 BE", Long.toString(v), Long.toHexString(v) });
/*     */       }
/*     */       
/*     */ 
/*  86 */       if (b.limit() >= 4) {
/*  87 */         b.order(ByteOrder.LITTLE_ENDIAN);
/*  88 */         float v = b.getFloat(0);
/*  89 */         this.df.addRow(new Object[] { "f32 LE", Float.toString(v), Float.toHexString(v) });
/*     */         
/*  91 */         b.order(ByteOrder.BIG_ENDIAN);
/*  92 */         v = b.getFloat(0);
/*  93 */         this.df.addRow(new Object[] { "f32 BE", Float.toString(v), Float.toHexString(v) });
/*     */       }
/*     */       
/*     */ 
/*  97 */       if (b.limit() >= 8) {
/*  98 */         b.order(ByteOrder.LITTLE_ENDIAN);
/*  99 */         double v = b.getDouble(0);
/* 100 */         this.df.addRow(new Object[] { "f64 LE", Double.toString(v), Double.toHexString(v) });
/*     */         
/* 102 */         b.order(ByteOrder.BIG_ENDIAN);
/* 103 */         v = b.getDouble(0);
/* 104 */         this.df.addRow(new Object[] { "f64 BE", Double.toString(v), Double.toHexString(v) });
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 109 */         String s = new String(data, offset, length, "UTF-8");
/* 110 */         this.df.addRow(new Object[] { "UTF-8", s });
/*     */       }
/*     */       catch (Exception e) {
/* 113 */         logger.catching(e);
/*     */       }
/*     */     }
/* 116 */     this.dfv.refresh();
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\PrimitiveDisplayView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */