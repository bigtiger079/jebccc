/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.api.IOperable;
/*     */ import com.pnfsoftware.jeb.client.api.OperationRequest;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ContextMenuFilter;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.export.ExportUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.export.IExportableData;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.DefaultCellLabelProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.FilteredTableViewer;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.IFilteredTableContentProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.viewers.TablePatternMatcher;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.table.TableUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.operations.ContextMenu;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.DataFrame.Row;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.ILabelValueProvider;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.IPatternMatcher;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.regex.PatternFilter;
/*     */ import com.pnfsoftware.jeb.util.base.Assert;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.viewers.ColumnViewer;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFrameView
/*     */   extends FilteredTableView
/*     */ {
/*     */   private boolean displayIndex;
/*     */   private DataFrame df;
/*     */   private FilteredTableViewer filteredViewer;
/*     */   private ColumnViewer viewer;
/*     */   private ContextMenu ctxMenu;
/*     */   private IFilteredTableContentProvider provider;
/*     */   private DataFrameLabelProvider labelProvider;
/*     */   
/*     */   public DataFrameView(Composite parent, DataFrame df, boolean displayIndex)
/*     */   {
/*  55 */     super(parent, 898, 
/*  56 */       (String[])df.getColumnLabels().toArray(new String[df.getColumnLabels().size()]), null, displayIndex);
/*     */     
/*  58 */     this.df = df;
/*  59 */     this.displayIndex = displayIndex;
/*     */     
/*  61 */     String[] titleColumns = (String[])df.getColumnLabels().toArray(new String[df.getColumnLabels().size()]);
/*  62 */     this.provider = new DataFrameContentProvider();
/*  63 */     this.labelProvider = new DataFrameLabelProvider(this.provider);
/*  64 */     IPatternMatcher patternMatcher = new TablePatternMatcher(this.provider, this.labelProvider);
/*     */     
/*  66 */     this.filteredViewer = new FilteredTableViewer(this);
/*  67 */     this.filteredViewer.setContentProvider(this.provider);
/*  68 */     this.filteredViewer.setLabelProvider(this.labelProvider);
/*  69 */     String[] titleColumnsWithIndex; if (displayIndex) {
/*  70 */       titleColumnsWithIndex = new String[titleColumns.length + 1];
/*  71 */       System.arraycopy(titleColumns, 0, titleColumnsWithIndex, 1, titleColumns.length);
/*  72 */       titleColumns = titleColumnsWithIndex;
/*     */     }
/*  74 */     this.filteredViewer.setFilterPatternFactory(new PatternFilter(patternMatcher, "", titleColumns));
/*  75 */     this.viewer = this.filteredViewer.getViewer();
/*     */     
/*  77 */     this.ctxMenu = ContextMenuFilter.addContextMenu(this.viewer, getFilterText(), this.labelProvider, titleColumns, null);
/*     */     
/*  79 */     this.filteredViewer.setInput(df, true);
/*     */     
/*  81 */     for (TableColumn tc : getTable().getColumns()) {
/*  82 */       tc.pack();
/*     */     }
/*     */   }
/*     */   
/*     */   public void refresh() {
/*  87 */     this.viewer.refresh();
/*     */   }
/*     */   
/*     */   public FilteredTableViewer getViewer() {
/*  91 */     return this.filteredViewer;
/*     */   }
/*     */   
/*     */   public ColumnViewer getTableViewer() {
/*  95 */     return this.viewer;
/*     */   }
/*     */   
/*     */   public int getSelectedRow() {
/*  99 */     ISelection selection = this.viewer.getSelection();
/* 100 */     if ((selection instanceof IStructuredSelection)) {
/* 101 */       IStructuredSelection sel = (IStructuredSelection)selection;
/* 102 */       Object element = sel.getFirstElement();
/* 103 */       if ((element instanceof DataFrame.Row)) {
/* 104 */         DataFrame.Row row = (DataFrame.Row)element;
/* 105 */         return row.index;
/*     */       }
/*     */     }
/* 108 */     return -1;
/*     */   }
/*     */   
/*     */   public ContextMenu getContextMenu() {
/* 112 */     return this.ctxMenu;
/*     */   }
/*     */   
/*     */   public void forceFilter(String filter) {
/* 116 */     getFilterText().setText(filter);
/* 117 */     this.filteredViewer.applyFilterText();
/*     */   }
/*     */   
/*     */ 
/*     */   class DataFrameLabelProvider
/*     */     extends DefaultCellLabelProvider
/*     */     implements IExportableData
/*     */   {
/*     */     DataFrameLabelProvider(IFilteredTableContentProvider contentProvider)
/*     */     {
/* 127 */       super();
/*     */     }
/*     */     
/*     */     public String getStringAt(Object element, int key)
/*     */     {
/* 132 */       int index = key;
/* 133 */       if (DataFrameView.this.displayIndex) {
/* 134 */         index--;
/*     */       }
/*     */       
/* 137 */       String label = null;
/* 138 */       if (index >= 0) {
/* 139 */         label = DataFrameView.this.df.getLabelFor((DataFrame.Row)element, index);
/*     */       }
/* 141 */       if (label == null) {
/* 142 */         label = super.getStringAt(element, key);
/*     */       }
/* 144 */       return label;
/*     */     }
/*     */     
/*     */     public String exportElementToString(Object obj)
/*     */     {
/* 149 */       if ((obj instanceof DataFrame.Row)) {
/* 150 */         Object[] row = ((DataFrame.Row)obj).elements.toArray();
/* 151 */         return ExportUtil.buildCsvLine(this, obj, DataFrameView.this.displayIndex ? row.length + 1 : row.length);
/*     */       }
/* 153 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   class DataFrameContentProvider implements IFilteredTableContentProvider {
/*     */     DataFrameContentProvider() {}
/*     */     
/*     */     public void inputChanged(Viewer v, Object oldInput, Object newInput) {
/* 161 */       if (newInput != null) {
/* 162 */         Assert.a(newInput == DataFrameView.this.df);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void dispose() {}
/*     */     
/*     */ 
/*     */     public Object[] getElements(Object inputElement)
/*     */     {
/* 173 */       return DataFrameView.this.df.getRows().toArray();
/*     */     }
/*     */     
/*     */     public Object[] getRowElements(Object row)
/*     */     {
/* 178 */       DataFrame.Row r = (DataFrame.Row)row;
/* 179 */       Object[] rowElements = r.elements.toArray();
/* 180 */       if (DataFrameView.this.displayIndex) {
/* 181 */         Object[] rowElementsWithIndex = new Object[rowElements.length + 1];
/* 182 */         rowElementsWithIndex[0] = Integer.valueOf(r.index);
/* 183 */         System.arraycopy(rowElements, 0, rowElementsWithIndex, 1, rowElements.length);
/* 184 */         return rowElementsWithIndex;
/*     */       }
/* 186 */       return rowElements;
/*     */     }
/*     */     
/*     */     public boolean isChecked(Object row)
/*     */     {
/* 191 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public IFilteredTableContentProvider getProvider() {
/* 196 */     return this.provider;
/*     */   }
/*     */   
/*     */   public ILabelValueProvider getLabelProvider() {
/* 200 */     return this.labelProvider;
/*     */   }
/*     */   
/*     */   public String exportToString()
/*     */   {
/* 205 */     return TableUtil.buildCsv(getTable());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addExtraEntriesToContextMenu()
/*     */   {
/* 212 */     ContextMenuFilter.addCopyEntry(this.ctxMenu, getTable(), new CopyAction());
/*     */   }
/*     */   
/*     */   private class CopyAction implements IOperable
/*     */   {
/*     */     public CopyAction() {}
/*     */     
/*     */     public boolean verifyOperation(OperationRequest req)
/*     */     {
/* 221 */       switch (DataFrameView.1.$SwitchMap$com$pnfsoftware$jeb$client$api$Operation[req.getOperation().ordinal()]) {
/*     */       case 1: 
/* 223 */         return DataFrameView.this.getSelectedRow() >= 0;
/*     */       }
/* 225 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean doOperation(OperationRequest req)
/*     */     {
/* 231 */       switch (DataFrameView.1.$SwitchMap$com$pnfsoftware$jeb$client$api$Operation[req.getOperation().ordinal()]) {
/*     */       case 1: 
/* 233 */         IStructuredSelection selection = (IStructuredSelection)DataFrameView.this.viewer.getSelection();
/* 234 */         if ((DataFrameView.this.viewer.getLabelProvider() instanceof IExportableData)) {
/* 235 */           ExportUtil.copyLinesToClipboard((IExportableData)DataFrameView.this.viewer.getLabelProvider(), selection.toList());
/* 236 */           return true;
/*     */         }
/* 238 */         return false;
/*     */       }
/* 240 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\DataFrameView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */