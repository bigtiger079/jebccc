/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.core.output.ItemClassIdentifiers;
/*     */ import com.pnfsoftware.jeb.rcpclient.RcpClientContext;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.Style;
/*     */ import com.pnfsoftware.jeb.rcpclient.iviewers.StyleManager;
/*     */ import org.eclipse.swt.events.FocusAdapter;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterText
/*     */   extends Composite
/*     */   implements IFilterText
/*     */ {
/*     */   private Boolean status;
/*     */   private Text filterText;
/*     */   private Color fgColor;
/*     */   private Color bgColor;
/*     */   
/*     */   public FilterText(Composite parent)
/*     */   {
/*  45 */     super(parent, 0);
/*  46 */     setLayout(new FillLayout());
/*     */     
/*     */ 
/*  49 */     this.filterText = new Text(this, 2948);
/*  50 */     this.filterText.setMessage(S.s(344));
/*     */     
/*  52 */     this.filterText.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusGained(FocusEvent e) {
/*  55 */         FilterText.this.setStatus(FilterText.this.status);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public Control getTextWidget()
/*     */   {
/*  62 */     return this.filterText;
/*     */   }
/*     */   
/*     */   public void setText(String s)
/*     */   {
/*  67 */     this.filterText.setText(s);
/*     */   }
/*     */   
/*     */   public void submitText(String s)
/*     */   {
/*  72 */     setText(s);
/*  73 */     Event e = new Event();
/*  74 */     e.character = '\r';
/*  75 */     this.filterText.notifyListeners(1, e);
/*     */   }
/*     */   
/*     */   public String getText()
/*     */   {
/*  80 */     return this.filterText.getText();
/*     */   }
/*     */   
/*     */   public void selectAll() {
/*  84 */     this.filterText.selectAll();
/*     */   }
/*     */   
/*     */   public void addFocusListener(FocusListener listener)
/*     */   {
/*  89 */     this.filterText.addFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void removeFocusListener(FocusListener listener)
/*     */   {
/*  94 */     this.filterText.removeFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void addKeyListener(KeyListener listener)
/*     */   {
/*  99 */     this.filterText.addKeyListener(listener);
/*     */   }
/*     */   
/*     */   public void removeKeyListener(KeyListener listener)
/*     */   {
/* 104 */     this.filterText.removeKeyListener(listener);
/*     */   }
/*     */   
/*     */   public void setStatus(Boolean status)
/*     */   {
/* 109 */     this.status = status;
/* 110 */     if (status == null) {
/* 111 */       this.filterText.setBackground(this.bgColor);
/* 112 */       this.filterText.setForeground(this.fgColor);
/*     */     }
/*     */     else {
/* 115 */       StyleManager styleman = RcpClientContext.getInstance().getStyleManager();
/* 116 */       ItemClassIdentifiers styleid = status.booleanValue() ? ItemClassIdentifiers.RESULT_SUCCESS : ItemClassIdentifiers.RESULT_ERROR;
/* 117 */       Style style = styleman.getNormalStyle(styleid);
/* 118 */       this.filterText.setBackground(style.getBackgroungColor() == null ? this.bgColor : style.getBackgroungColor());
/* 119 */       this.filterText.setForeground(style.getColor() == null ? this.fgColor : style.getColor());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBackground(Color color)
/*     */   {
/* 125 */     this.filterText.setBackground(color);
/* 126 */     this.bgColor = color;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setForeground(Color color)
/*     */   {
/* 132 */     this.filterText.setForeground(color);
/* 133 */     this.fgColor = color;
/*     */   }
/*     */   
/*     */ 
/*     */   public Color getBackground()
/*     */   {
/* 139 */     return this.filterText.getBackground();
/*     */   }
/*     */   
/*     */   public boolean setFocus()
/*     */   {
/* 144 */     return this.filterText.setFocus();
/*     */   }
/*     */   
/*     */   public static boolean isSelected() {
/* 148 */     Control c = Display.getCurrent().getFocusControl();
/* 149 */     if ((c != null) && ((c.getParent() instanceof FilterText))) {
/* 150 */       return true;
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\FilterText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */