/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import org.apache.commons.lang3.mutable.MutableInt;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredTreeView
/*     */   extends AbstractFilteredView<Tree>
/*     */ {
/*     */   public FilteredTreeView(Composite parent, int style, String[] columnNames)
/*     */   {
/*  30 */     this(parent, style, columnNames, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilteredTreeView(Composite parent, int style, String[] columnNames, int[] columnWidths)
/*     */   {
/*  42 */     super(parent, style, columnNames, columnWidths, false);
/*     */   }
/*     */   
/*     */   public Tree getTree() {
/*  46 */     return (Tree)getElement();
/*     */   }
/*     */   
/*     */   protected Tree buildElement(Composite parent, int style)
/*     */   {
/*  51 */     Tree tree = new Tree(parent, style);
/*  52 */     tree.setLayoutData(UIUtil.createGridDataSpanHorizontally(1, true, true));
/*  53 */     return tree;
/*     */   }
/*     */   
/*     */   protected void buildColumn(Tree parent, String name, int initialWidth)
/*     */   {
/*  58 */     TreeColumn col = new TreeColumn(parent, 16384);
/*  59 */     col.setText(name);
/*  60 */     col.setResizable(true);
/*  61 */     if (initialWidth > 0) {
/*  62 */       col.setWidth(initialWidth);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSelectionIndex()
/*     */   {
/*  68 */     if (((Tree)getElement()).getSelectionCount() == 0)
/*     */     {
/*  70 */       return -1;
/*     */     }
/*     */     
/*  73 */     MutableInt counter = new MutableInt(0);
/*  74 */     boolean found = getIndexOfItem(((Tree)getElement()).getItems(), ((Tree)getElement()).getSelection()[0], counter);
/*  75 */     if (found) {
/*  76 */       return counter.intValue();
/*     */     }
/*     */     
/*  79 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean getIndexOfItem(TreeItem[] fullTree, TreeItem toFind, MutableInt currentIndex)
/*     */   {
/*  84 */     for (TreeItem item : fullTree) {
/*  85 */       if (!isBlankItem(item))
/*     */       {
/*     */ 
/*  88 */         if (item.equals(toFind)) {
/*  89 */           return true;
/*     */         }
/*  91 */         currentIndex.increment();
/*  92 */         boolean found = getIndexOfItem(item.getItems(), toFind, currentIndex);
/*  93 */         if (found)
/*  94 */           return found;
/*     */       }
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSelection(int index) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 108 */     return getItemCount(((Tree)getElement()).getItems());
/*     */   }
/*     */   
/*     */   private int getItemCount(TreeItem[] items) {
/* 112 */     int childrenCount = 0;
/* 113 */     if ((items == null) || (items.length == 0)) {
/* 114 */       return childrenCount;
/*     */     }
/*     */     
/* 117 */     for (TreeItem item : items) {
/* 118 */       if (!isBlankItem(item))
/*     */       {
/*     */ 
/*     */ 
/* 122 */         childrenCount += 1 + getItemCount(item.getItems()); }
/*     */     }
/* 124 */     return childrenCount;
/*     */   }
/*     */   
/*     */   private static boolean isBlankItem(TreeItem item) {
/* 128 */     return ((item.getItems() == null) || (item.getItems().length == 0)) && (item.getData() == null) && 
/* 129 */       (item.getText().isEmpty());
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\FilteredTreeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */