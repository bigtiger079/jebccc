/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.controls;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import org.eclipse.swt.layout.GridLayout;
/*    */ import org.eclipse.swt.widgets.Combo;
/*    */ import org.eclipse.swt.widgets.Composite;
/*    */ import org.eclipse.swt.widgets.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TriStateField
/*    */   extends Composite
/*    */ {
/*    */   private Combo wlist;
/*    */   
/*    */   public TriStateField(Composite parent, String name, Boolean initialState, String thirdStateLabel)
/*    */   {
/* 35 */     super(parent, 0);
/* 36 */     setLayout(new GridLayout(2, false));
/*    */     
/* 38 */     this.wlist = new Combo(this, 8);
/* 39 */     this.wlist.setItems(new String[] { Strings.safe(thirdStateLabel, "Unknown"), "Yes", "No" });
/* 40 */     this.wlist.setLayoutData(UIUtil.createGridDataFillHorizontally());
/*    */     
/* 42 */     setState(initialState);
/*    */     
/* 44 */     Label label = new Label(this, 0);
/* 45 */     label.setText(name);
/*    */   }
/*    */   
/*    */   public void setState(Boolean state) {
/* 49 */     int index = state.booleanValue() ? 1 : state == null ? 0 : 2;
/* 50 */     this.wlist.select(index);
/*    */   }
/*    */   
/*    */   public Boolean getState() {
/* 54 */     int index = Math.max(0, this.wlist.getSelectionIndex());
/* 55 */     return index == 1 ? Boolean.TRUE : index == 0 ? null : Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\controls\TriStateField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */