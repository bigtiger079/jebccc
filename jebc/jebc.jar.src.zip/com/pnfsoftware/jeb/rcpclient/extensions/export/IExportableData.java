package com.pnfsoftware.jeb.rcpclient.extensions.export;

public abstract interface IExportableData
{
  public abstract String exportElementToString(Object paramObject);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\export\IExportableData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */