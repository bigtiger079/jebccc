/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.export;
/*    */ 
/*    */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*    */ import com.pnfsoftware.jeb.rcpclient.util.regex.IValueProvider;
/*    */ import java.util.List;
/*    */ import org.apache.commons.text.StringEscapeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportUtil
/*    */ {
/*    */   public static boolean copyLinesToClipboard(IExportableData exportTable, List<?> list)
/*    */   {
/* 30 */     String export = exportLines(exportTable, list);
/* 31 */     if (export == null) {
/* 32 */       return false;
/*    */     }
/* 34 */     UIUtil.copyTextToClipboard(export);
/* 35 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String exportLines(IExportableData exportTable, List<?> list)
/*    */   {
/* 48 */     if (list != null) {
/* 49 */       StringBuilder stb = new StringBuilder();
/* 50 */       for (Object o : list) {
/* 51 */         String s = exportTable.exportElementToString(o);
/* 52 */         if (s != null) {
/* 53 */           stb.append(s).append('\n');
/*    */         }
/*    */       }
/* 56 */       if (stb.length() > 0) {
/* 57 */         stb.deleteCharAt(stb.length() - 1);
/* 58 */         return stb.toString();
/*    */       }
/*    */     }
/* 61 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String buildCsvLine(IValueProvider labelProvider, Object obj, int length)
/*    */   {
/* 74 */     StringBuilder stb = new StringBuilder();
/* 75 */     for (int i = 0; i < length; i++) {
/* 76 */       String cell = StringEscapeUtils.escapeCsv(labelProvider.getStringAt(obj, i));
/* 77 */       stb.append(cell == null ? "" : cell).append(",");
/*    */     }
/* 79 */     if (stb.length() > 0) {
/* 80 */       stb.deleteCharAt(stb.length() - 1);
/*    */     }
/* 82 */     return stb.toString();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\export\ExportUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */