/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRefresher
/*     */ {
/*  26 */   private static final ILogger logger = GlobalLog.getLogger(AbstractRefresher.class);
/*     */   private Display display;
/*     */   private String name;
/*     */   private AtomicInteger state;
/*     */   
/*     */   public AbstractRefresher(Display display, String name)
/*     */   {
/*  33 */     this.display = display;
/*  34 */     this.name = name;
/*  35 */     this.state = new AtomicInteger(0);
/*     */   }
/*     */   
/*     */   public AbstractRefresher(Display display) {
/*  39 */     this(display, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Display getDisplay()
/*     */   {
/*  48 */     return this.display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  57 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getState()
/*     */   {
/*  70 */     return this.state.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void request()
/*     */   {
/*  78 */     boolean waitRefreshFinished = false;
/*  79 */     synchronized (this.state) {
/*  80 */       int v = getState();
/*  81 */       if (v == 0)
/*     */       {
/*  83 */         this.state.set(1);
/*     */       }
/*  85 */       else if (v == 1)
/*     */       {
/*  87 */         this.state.set(2);
/*  88 */         waitRefreshFinished = true;
/*     */       }
/*     */       else
/*     */       {
/*  92 */         return;
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (waitRefreshFinished)
/*     */     {
/*  98 */       ThreadUtil.start(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           do {
/*     */             try {
/* 104 */               Thread.sleep(200L);
/*     */             }
/*     */             catch (InterruptedException e)
/*     */             {
/* 108 */               if (!AbstractRefresher.this.state.compareAndSet(2, 1))
/*     */               {
/* 110 */                 AbstractRefresher.this.state.set(0);
/*     */               }
/* 112 */               return;
/*     */             }
/*     */             
/* 115 */           } while (AbstractRefresher.this.getState() != 3);
/*     */           
/*     */ 
/*     */ 
/* 119 */           AbstractRefresher.this.state.set(1);
/* 120 */           AbstractRefresher.this.launchRefresh();
/*     */         }
/*     */         
/*     */       });
/*     */     } else {
/* 125 */       launchRefresh();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void launchRefresh()
/*     */   {
/* 132 */     UIExecutor.async(this.display, new UIRunnable(String.format("Refresher(%s)", new Object[] { this.name }))
/*     */     {
/*     */       public void runi()
/*     */       {
/* 136 */         synchronized (AbstractRefresher.this) {
/* 137 */           if (AbstractRefresher.this.shouldPerformRefresh()) {
/* 138 */             AbstractRefresher.this.performRefresh();
/* 139 */             synchronized (AbstractRefresher.this.state)
/*     */             {
/* 141 */               if (!AbstractRefresher.this.state.compareAndSet(2, 3))
/*     */               {
/* 143 */                 AbstractRefresher.this.state.set(0);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean shouldPerformRefresh()
/*     */   {
/* 156 */     return true;
/*     */   }
/*     */   
/*     */   protected abstract void performRefresh();
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\AbstractRefresher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */