/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.controls.ImageView;
/*     */ import com.pnfsoftware.jeb.util.events.IEvent;
/*     */ import com.pnfsoftware.jeb.util.events.IEventListener;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageViewer
/*     */   extends Viewer
/*     */ {
/*  27 */   private static final ILogger logger = GlobalLog.getLogger(ImageViewer.class);
/*     */   
/*     */   private IImageDocument input;
/*     */   
/*     */   private IEventListener inputListener;
/*     */   
/*     */   private Composite container;
/*     */   
/*     */   private ImageView widget;
/*     */   
/*  37 */   private ViewerRefresher refresher = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageViewer(Composite parent)
/*     */   {
/*  44 */     this.container = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageView getControl()
/*     */   {
/*  53 */     return this.widget;
/*     */   }
/*     */   
/*     */   public IImageDocument getInput()
/*     */   {
/*  58 */     return this.input;
/*     */   }
/*     */   
/*     */   public void refresh()
/*     */   {
/*  63 */     if (this.widget != null) {
/*  64 */       this.widget.dispose();
/*  65 */       this.widget = null;
/*     */     }
/*  67 */     if (this.input != null) {
/*  68 */       this.widget = new ImageView(this.container, this.input.getImage());
/*  69 */       this.container.layout();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setInput(Object input)
/*     */   {
/*  75 */     if (this.inputListener != null) {
/*  76 */       this.input.removeListener(this.inputListener);
/*  77 */       this.inputListener = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     if (this.refresher == null) {
/*  95 */       this.refresher = new ViewerRefresher(this.container.getDisplay(), this);
/*     */     }
/*     */     
/*  98 */     this.input = ((IImageDocument)input);
/*  99 */     this.input.addListener(this. = new IEventListener()
/*     */     {
/*     */       public void onEvent(IEvent e) {
/* 102 */         ImageViewer.logger.i("Event received: %s", new Object[] { e });
/* 103 */         ImageViewer.this.refresher.request();
/*     */       }
/* 105 */     });
/* 106 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSelection(ISelection selection, boolean reveal) {}
/*     */   
/*     */ 
/*     */   public ISelection getSelection()
/*     */   {
/* 115 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\ImageViewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */