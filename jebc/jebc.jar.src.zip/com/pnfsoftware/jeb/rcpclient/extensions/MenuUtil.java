/*    */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*    */ 
/*    */ import org.eclipse.jface.action.IContributionItem;
/*    */ import org.eclipse.jface.action.IMenuListener;
/*    */ import org.eclipse.jface.action.IMenuManager;
/*    */ import org.eclipse.jface.action.MenuManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuUtil
/*    */ {
/*    */   public static MenuManager createAutoRefreshMenu(String name)
/*    */   {
/* 23 */     MenuManager menu = new MenuManager(name, null);
/* 24 */     menu.addMenuListener(new IMenuListener()
/*    */     {
/*    */       public void menuAboutToShow(IMenuManager manager) {
/* 27 */         for (IContributionItem item : manager.getItems()) {
/* 28 */           item.update();
/*    */         }
/*    */       }
/* 31 */     });
/* 32 */     return menu;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\MenuUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */