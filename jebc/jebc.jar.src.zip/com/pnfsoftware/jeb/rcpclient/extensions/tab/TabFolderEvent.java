/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.tab;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TabFolderEvent
/*    */ {
/*    */   public TabFolderView manager;
/*    */   
/*    */ 
/*    */ 
/*    */   public String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TabFolderEvent(TabFolderView manager, String name)
/*    */   {
/* 20 */     this.manager = manager;
/* 21 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\tab\TabFolderEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */