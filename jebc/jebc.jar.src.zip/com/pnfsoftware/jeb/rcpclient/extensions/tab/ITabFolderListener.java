package com.pnfsoftware.jeb.rcpclient.extensions.tab;

public abstract interface ITabFolderListener
{
  public abstract void tabAdded(TabFolderEvent paramTabFolderEvent);
  
  public abstract void tabRemoved(TabFolderEvent paramTabFolderEvent);
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\tab\ITabFolderListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */