/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.tab;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.parts.ILazyView;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.CTabFolderUtils;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.custom.CTabFolder;
/*     */ import org.eclipse.swt.custom.CTabFolder2Listener;
/*     */ import org.eclipse.swt.custom.CTabFolderEvent;
/*     */ import org.eclipse.swt.custom.CTabItem;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.layout.FillLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabFolderView
/*     */   extends Composite
/*     */   implements CTabFolder2Listener
/*     */ {
/*  51 */   private static final ILogger logger = GlobalLog.getLogger(TabFolderView.class);
/*     */   private static final String LAZY_INITIALIZED = "initialized";
/*     */   private CTabFolder folder;
/*     */   private SelectionListener selectionListener;
/*     */   
/*     */   public static class Entry {
/*     */     String name;
/*     */     Control control;
/*     */     CTabItem tab;
/*     */     
/*  61 */     Entry(String name, Control control, CTabItem tab) { this.name = name;
/*  62 */       this.control = control;
/*  63 */       this.tab = tab;
/*     */     }
/*     */     
/*     */     public String getName() {
/*  67 */       return this.name;
/*     */     }
/*     */     
/*     */     public Control getControl() {
/*  71 */       return this.control;
/*     */     }
/*     */     
/*     */     public boolean hasTab() {
/*  75 */       return this.tab != null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  81 */   private List<ITabFolderListener> listeners = new ArrayList();
/*  82 */   private List<Entry> entries = new ArrayList();
/*     */   
/*     */ 
/*     */   private boolean addSpaces;
/*     */   
/*     */ 
/*     */   private final boolean lazyInit;
/*     */   
/*  90 */   private List<Entry> entriesByFocusOrder = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean clearing;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabFolderView(Composite parent, int flags, boolean addSpaces, boolean lazyInit)
/*     */   {
/* 102 */     super(parent, 0);
/* 103 */     setLayout(new FillLayout());
/*     */     
/* 105 */     this.addSpaces = addSpaces;
/*     */     
/* 107 */     this.folder = new CTabFolder(this, flags);
/*     */     
/* 109 */     CTabFolderUtils.setCTabFolderHeight(this.folder, -1);
/*     */     
/* 111 */     this.folder.addCTabFolder2Listener(this);
/*     */     
/* 113 */     this.folder.addSelectionListener(this. = new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent event) {
/* 116 */         if (TabFolderView.this.clearing) {
/* 117 */           return;
/*     */         }
/* 119 */         CTabItem selectedTab = TabFolderView.this.folder.getSelection();
/* 120 */         for (TabFolderView.Entry e : TabFolderView.this.entries) {
/* 121 */           if (e.tab == selectedTab) {
/* 122 */             Control control = selectedTab.getControl();
/* 123 */             if (TabFolderView.this.isLazyInitializationToPerform(control)) {
/* 124 */               ((ILazyView)control).lazyInitialization();
/* 125 */               control.setData("initialized", Boolean.TRUE);
/*     */             }
/* 127 */             e.control.setFocus();
/*     */             
/*     */ 
/* 130 */             if (TabFolderView.this.entriesByFocusOrder.contains(e)) {
/* 131 */               TabFolderView.this.entriesByFocusOrder.remove(e);
/*     */             }
/* 133 */             TabFolderView.this.entriesByFocusOrder.add(0, e);
/* 134 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 138 */     });
/* 139 */     this.folder.addFocusListener(new FocusListener()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void focusGained(FocusEvent e) {}
/* 146 */     });
/* 147 */     this.lazyInit = lazyInit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanUp()
/*     */   {
/* 166 */     this.folder.removeSelectionListener(this.selectionListener);
/* 167 */     this.entries.clear();
/* 168 */     this.listeners.clear();
/*     */   }
/*     */   
/*     */   public void addListener(ITabFolderListener l) {
/* 172 */     this.listeners.add(l);
/*     */   }
/*     */   
/*     */   public void removeListener(ITabFolderListener l) {
/* 176 */     this.listeners.remove(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CTabFolder getContainer()
/*     */   {
/* 185 */     return this.folder;
/*     */   }
/*     */   
/*     */   public List<Control> getControls() {
/* 189 */     List<Control> r = new ArrayList();
/* 190 */     for (Entry entry : this.entries) {
/* 191 */       r.add(entry.control);
/*     */     }
/* 193 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEntryCount()
/*     */   {
/* 200 */     return this.entries.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEntryVisibleCount()
/*     */   {
/* 207 */     int i = 0;
/* 208 */     for (Entry entry : this.entries) {
/* 209 */       if (entry.tab != null) {
/* 210 */         i++;
/*     */       }
/*     */     }
/* 213 */     return i;
/*     */   }
/*     */   
/*     */   private boolean isImmediateLazyInitialization(Control control) {
/* 217 */     return ((control instanceof ILazyView)) && (!this.lazyInit);
/*     */   }
/*     */   
/*     */   private boolean isLazyInitializationToPerform(Control control) {
/* 221 */     return ((control instanceof ILazyView)) && (this.lazyInit) && (control.getData("initialized") == null);
/*     */   }
/*     */   
/*     */   public boolean addEntry(String name, Control control) {
/* 225 */     return addEntry(name, control, null, true);
/*     */   }
/*     */   
/*     */   public boolean addEntry(String name, Control control, Integer index) {
/* 229 */     return addEntry(name, control, index, true);
/*     */   }
/*     */   
/*     */   public boolean addEntry(String name, Control control, boolean showTab) {
/* 233 */     return addEntry(name, control, null, showTab);
/*     */   }
/*     */   
/*     */   public boolean addEntry(String name, Control control, Integer index, boolean showTab) {
/* 237 */     if (control == null) {
/* 238 */       return false;
/*     */     }
/*     */     
/* 241 */     if (isImmediateLazyInitialization(control)) {
/* 242 */       ((ILazyView)control).lazyInitialization();
/* 243 */       control.setData("initialized", Boolean.TRUE);
/*     */     }
/*     */     
/*     */ 
/* 247 */     CTabItem item = null;
/* 248 */     if (showTab) {
/* 249 */       item = createCTabItem(name, control, index);
/*     */     }
/*     */     
/*     */ 
/* 253 */     Entry entry = new Entry(name, control, item);
/* 254 */     this.entries.add(entry);
/*     */     
/*     */ 
/* 257 */     for (ITabFolderListener l : this.listeners) {
/* 258 */       l.tabAdded(new TabFolderEvent(this, name));
/*     */     }
/* 260 */     return true;
/*     */   }
/*     */   
/*     */   public boolean hideEntry(String name) {
/* 264 */     Entry entry = getEntry(name);
/* 265 */     if (entry == null) {
/* 266 */       return false;
/*     */     }
/* 268 */     if (entry.tab != null) {
/* 269 */       entry.tab.dispose();
/* 270 */       entry.tab = null;
/*     */     }
/* 272 */     return true;
/*     */   }
/*     */   
/*     */   public boolean removeEntry(String name) {
/* 276 */     Entry entry = getEntry(name);
/* 277 */     if (entry == null) {
/* 278 */       return false;
/*     */     }
/*     */     
/* 281 */     return removeEntry(entry);
/*     */   }
/*     */   
/*     */   public boolean removeEntry(Control ctl) {
/* 285 */     Entry entry = getEntry(ctl);
/* 286 */     if (entry == null) {
/* 287 */       return false;
/*     */     }
/*     */     
/* 290 */     return removeEntry(entry);
/*     */   }
/*     */   
/*     */   private boolean removeEntry(Entry entry)
/*     */   {
/* 295 */     if (entry.tab != null) {
/* 296 */       entry.tab.dispose();
/* 297 */       entry.tab = null;
/*     */       
/* 299 */       entry.control.dispose();
/* 300 */       entry.control = null;
/*     */     }
/*     */     
/*     */ 
/* 304 */     this.entries.remove(entry);
/*     */     
/* 306 */     this.entriesByFocusOrder.remove(entry);
/*     */     
/*     */ 
/* 309 */     for (ITabFolderListener l : this.listeners) {
/* 310 */       l.tabRemoved(new TabFolderEvent(this, entry.name));
/*     */     }
/* 312 */     return true;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void removeAllEntries()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iconst_1
/*     */     //   2: putfield 32	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:clearing	Z
/*     */     //   5: aload_0
/*     */     //   6: getfield 33	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:entries	Ljava/util/List;
/*     */     //   9: invokeinterface 102 1 0
/*     */     //   14: ifne +27 -> 41
/*     */     //   17: aload_0
/*     */     //   18: aload_0
/*     */     //   19: getfield 33	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:entries	Ljava/util/List;
/*     */     //   22: iconst_0
/*     */     //   23: invokeinterface 101 2 0
/*     */     //   28: checkcast 9	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView$Entry
/*     */     //   31: getfield 41	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView$Entry:name	Ljava/lang/String;
/*     */     //   34: invokevirtual 53	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:removeEntry	(Ljava/lang/String;)Z
/*     */     //   37: pop
/*     */     //   38: goto -33 -> 5
/*     */     //   41: aload_0
/*     */     //   42: iconst_0
/*     */     //   43: putfield 32	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:clearing	Z
/*     */     //   46: goto +11 -> 57
/*     */     //   49: astore_1
/*     */     //   50: aload_0
/*     */     //   51: iconst_0
/*     */     //   52: putfield 32	com/pnfsoftware/jeb/rcpclient/extensions/tab/TabFolderView:clearing	Z
/*     */     //   55: aload_1
/*     */     //   56: athrow
/*     */     //   57: return
/*     */     // Line number table:
/*     */     //   Java source line #316	-> byte code offset #0
/*     */     //   Java source line #318	-> byte code offset #5
/*     */     //   Java source line #319	-> byte code offset #17
/*     */     //   Java source line #323	-> byte code offset #41
/*     */     //   Java source line #324	-> byte code offset #46
/*     */     //   Java source line #323	-> byte code offset #49
/*     */     //   Java source line #324	-> byte code offset #55
/*     */     //   Java source line #325	-> byte code offset #57
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	58	0	this	TabFolderView
/*     */     //   49	7	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   5	41	49	finally
/*     */   }
/*     */   
/*     */   public boolean showEntry(int index, boolean setFocus)
/*     */   {
/* 328 */     if ((index < 0) || (index >= this.entries.size())) {
/* 329 */       return false;
/*     */     }
/*     */     
/* 332 */     Entry entry = (Entry)this.entries.get(index);
/*     */     
/* 334 */     showEntry(entry, setFocus);
/* 335 */     return true;
/*     */   }
/*     */   
/*     */   public boolean showEntry(Control control, boolean setFocus) {
/* 339 */     Entry entry = getEntry(control);
/* 340 */     if (entry == null) {
/* 341 */       return false;
/*     */     }
/*     */     
/* 344 */     showEntry(entry, setFocus);
/* 345 */     return true;
/*     */   }
/*     */   
/*     */   public boolean showEntry(String name, boolean setFocus) {
/* 349 */     Entry entry = getEntry(name);
/* 350 */     if (entry == null) {
/* 351 */       return false;
/*     */     }
/*     */     
/* 354 */     showEntry(entry, setFocus);
/* 355 */     return true;
/*     */   }
/*     */   
/*     */   public void showEntry(Entry entry, boolean setFocus)
/*     */   {
/* 360 */     if (entry.tab == null) {
/* 361 */       CTabItem item = createCTabItem(entry.name, entry.control, null);
/* 362 */       entry.tab = item;
/*     */     }
/*     */     
/* 365 */     if (setFocus)
/*     */     {
/* 367 */       this.folder.setSelection(entry.tab);
/* 368 */       this.folder.notifyListeners(13, new Event());
/*     */       
/* 370 */       entry.tab.getControl().setFocus();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CTabItem createCTabItem(String name, Control control, Integer index)
/*     */   {
/* 382 */     if (control.getParent() != this.folder) {
/* 383 */       control.setParent(this.folder);
/*     */     }
/*     */     
/* 386 */     if (index == null) {
/* 387 */       index = Integer.valueOf(this.folder.getItemCount());
/*     */     }
/* 389 */     if (index.intValue() < 0) {
/* 390 */       index = Integer.valueOf(index.intValue() + this.folder.getItemCount());
/*     */     }
/*     */     
/* 393 */     CTabItem item = new CTabItem(this.folder, 0, index.intValue());
/* 394 */     String displayName = name;
/* 395 */     if (this.addSpaces) {
/* 396 */       displayName = "   " + name + "   ";
/*     */     }
/*     */     
/* 399 */     item.setText(displayName);
/* 400 */     item.setControl(control);
/* 401 */     return item;
/*     */   }
/*     */   
/*     */   public Control getCurrentEntryControl() {
/* 405 */     for (Entry entry : this.entries) {
/* 406 */       if (this.folder.getSelection() == entry.tab) {
/* 407 */         return entry.control;
/*     */       }
/*     */     }
/* 410 */     return null;
/*     */   }
/*     */   
/*     */   public String getCurrentEntryName() {
/* 414 */     for (Entry entry : this.entries) {
/* 415 */       if (this.folder.getSelection() == entry.tab) {
/* 416 */         return entry.name;
/*     */       }
/*     */     }
/* 419 */     return null;
/*     */   }
/*     */   
/*     */   public Control getEntryControl(int index) {
/* 423 */     return ((Entry)this.entries.get(index)).control;
/*     */   }
/*     */   
/*     */   public String getEntryName(int index) {
/* 427 */     return ((Entry)this.entries.get(index)).name;
/*     */   }
/*     */   
/*     */   public List<Entry> getEntries() {
/* 431 */     return Collections.unmodifiableList(this.entries);
/*     */   }
/*     */   
/*     */   private Entry getEntry(String name) {
/* 435 */     for (Entry entry : this.entries) {
/* 436 */       if (entry.name.equals(name)) {
/* 437 */         return entry;
/*     */       }
/*     */     }
/* 440 */     return null;
/*     */   }
/*     */   
/*     */   private Entry getEntry(Control control) {
/* 444 */     for (Entry entry : this.entries) {
/* 445 */       if (entry.control == control) {
/* 446 */         return entry;
/*     */       }
/*     */     }
/* 449 */     return null;
/*     */   }
/*     */   
/*     */   public CTabItem getTab(Control control) {
/* 453 */     for (CTabItem item : this.folder.getItems()) {
/* 454 */       if (item.getControl() == control) {
/* 455 */         return item;
/*     */       }
/*     */     }
/* 458 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CTabItem getMostRecentlyFocusedTab()
/*     */   {
/* 468 */     return this.entriesByFocusOrder.isEmpty() ? null : ((Entry)this.entriesByFocusOrder.get(0)).tab;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<CTabItem> getPreviouslyFocusedTabs()
/*     */   {
/* 479 */     List<CTabItem> li = new ArrayList(this.entriesByFocusOrder.size());
/* 480 */     for (Entry e : this.entriesByFocusOrder) {
/* 481 */       li.add(e.tab);
/*     */     }
/* 483 */     return li;
/*     */   }
/*     */   
/*     */   public void close(CTabFolderEvent e)
/*     */   {
/* 488 */     CTabItem tab = (CTabItem)e.item;
/* 489 */     for (Entry entry : this.entries) {
/* 490 */       if (entry.tab == tab) {
/* 491 */         entry.tab = null;
/* 492 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void maximize(CTabFolderEvent e) {}
/*     */   
/*     */   public void minimize(CTabFolderEvent e) {}
/*     */   
/*     */   public void restore(CTabFolderEvent e) {}
/*     */   
/*     */   public void showList(CTabFolderEvent e) {}
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\tab\TabFolderView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */