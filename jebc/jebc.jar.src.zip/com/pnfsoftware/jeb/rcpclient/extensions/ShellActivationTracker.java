/*    */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.Listener;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShellActivationTracker
/*    */   implements Listener
/*    */ {
/* 26 */   private static final ILogger logger = GlobalLog.getLogger(ShellActivationTracker.class);
/*    */   private Display display;
/*    */   private Shell shell;
/*    */   private Shell mainShell;
/*    */   
/*    */   public ShellActivationTracker(Display display)
/*    */   {
/* 33 */     this.display = display;
/* 34 */     set(display.getActiveShell());
/* 35 */     display.addFilter(26, this);
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 39 */     this.display.removeFilter(26, this);
/*    */   }
/*    */   
/*    */   public void handleEvent(Event event)
/*    */   {
/* 44 */     if ((event.widget instanceof Shell)) {
/* 45 */       set((Shell)event.widget);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setMainShell(Shell mainShell) {
/* 50 */     this.mainShell = mainShell;
/*    */   }
/*    */   
/*    */   public Shell getMainShell() {
/* 54 */     return this.mainShell;
/*    */   }
/*    */   
/*    */   private void set(Shell shell) {
/* 58 */     if (shell == null) {
/* 59 */       logger.i("Shell is null", new Object[0]);
/*    */     }
/* 61 */     else if (this.shell == null) {
/* 62 */       logger.i("Shell was null, now: %s", new Object[] { shell });
/*    */     }
/* 64 */     this.shell = shell;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Shell get()
/*    */   {
/* 73 */     if (!UIUtil.isUIThread(this.display)) {
/* 74 */       return null;
/*    */     }
/*    */     
/* 77 */     Shell r = this.display.getActiveShell();
/* 78 */     if (r == null) {
/* 79 */       r = this.shell;
/*    */     }
/* 81 */     if ((r == null) || (r.isDisposed()))
/*    */     {
/* 83 */       r = this.mainShell;
/*    */     }
/* 85 */     return r;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\ShellActivationTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */