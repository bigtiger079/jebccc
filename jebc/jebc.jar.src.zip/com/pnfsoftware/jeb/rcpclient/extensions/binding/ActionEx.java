/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.binding;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.bindings.keys.KeyStroke;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ActionEx
/*     */   extends Action
/*     */   implements Runnable
/*     */ {
/*     */   private static KeyShortcutsManager ksm;
/*     */   boolean hasCustomShortcut;
/*     */   
/*     */   public static void setKeyboardShortcuts(KeyShortcutsManager manager)
/*     */   {
/*  29 */     ksm = manager;
/*     */   }
/*     */   
/*     */   public static KeyShortcutsManager getKeyShortcutManager() {
/*  33 */     return ksm;
/*     */   }
/*     */   
/*     */ 
/*  37 */   List<Integer> acclist = new ArrayList();
/*     */   String text;
/*     */   String text0;
/*     */   
/*     */   public ActionEx(String id, String text) {
/*  42 */     this(id, text, 0);
/*     */   }
/*     */   
/*     */   public ActionEx(String id, String text, int style) {
/*  46 */     this(id, text, style, new int[0]);
/*     */   }
/*     */   
/*     */   public ActionEx(String id, String text, int style, int... accelerators) {
/*  50 */     super(text, style);
/*  51 */     this.text0 = text;
/*  52 */     setText(text);
/*     */     
/*  54 */     if (!Strings.isBlank(id)) {
/*  55 */       setId(id);
/*     */     }
/*     */     int keycode;
/*  58 */     if (ksm != null) {
/*  59 */       keycode = ksm.getShortcutKeycode(getId());
/*  60 */       if ((keycode != 0) && 
/*  61 */         (addExtraAccelerator(keycode))) {
/*  62 */         this.hasCustomShortcut = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  67 */     for (int accelerator : accelerators) {
/*  68 */       setAccelerator(accelerator);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setText(String text)
/*     */   {
/*  74 */     this.text = text;
/*     */   }
/*     */   
/*     */   public String getText()
/*     */   {
/*  79 */     return this.text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccelerator(int keycode)
/*     */   {
/*  91 */     if (!this.hasCustomShortcut) {
/*  92 */       addExtraAccelerator(keycode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getAccelerator()
/*     */   {
/*  99 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean addExtraAccelerator(int keycode) {
/* 103 */     if ((ksm != null) && (ksm.isReserved(keycode)) && (!Strings.equals(getId(), ksm.getActionIdForKeycode(keycode)))) {
/* 104 */       return false;
/*     */     }
/*     */     
/* 107 */     int mod = keycode & SWT.MODIFIER_MASK;
/* 108 */     int key = keycode & (SWT.MODIFIER_MASK ^ 0xFFFFFFFF);
/* 109 */     keycode = mod | Character.toLowerCase(key);
/* 110 */     if (this.acclist.contains(Integer.valueOf(keycode))) {
/* 111 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 115 */     if (this.acclist.isEmpty()) {
/* 116 */       String s = KeyStroke.getInstance(mod, Character.toUpperCase(key)).toString();
/* 117 */       setText(this.text0 + "\t" + refineAcceleratorString(s));
/*     */     }
/* 119 */     this.acclist.add(Integer.valueOf(keycode));
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   private String refineAcceleratorString(String s) {
/* 124 */     s = s.replace("CR", "ENTER");
/* 125 */     StringBuilder sb = new StringBuilder();
/* 126 */     boolean upper = true;
/* 127 */     for (int i = 0; i < s.length(); i++) {
/* 128 */       Character c = Character.valueOf(s.charAt(i));
/* 129 */       if (c.charValue() == '_') {
/* 130 */         c = Character.valueOf(' ');
/* 131 */         upper = true;
/*     */       }
/* 133 */       else if (c.charValue() == '+') {
/* 134 */         c = null;
/* 135 */         upper = true;
/*     */       }
/* 137 */       else if (upper) {
/* 138 */         c = Character.valueOf(Character.toUpperCase(c.charValue()));
/* 139 */         upper = false;
/*     */       }
/*     */       else {
/* 142 */         c = Character.valueOf(Character.toLowerCase(c.charValue()));
/*     */       }
/* 144 */       if (c != null) {
/* 145 */         sb.append(c);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     s = sb.toString().replace("Enter", "↩").replace("Tab", "↹").replace("Space", "␣").replace("Del", "⌫").replace("Command", "⌘").replace("Ctrl", "⌃").replace("Control", "⌃").replace("Alt", "⌥").replace("Shift", "⇧").replace("Arrow Left", "←").replace("Arrow Up", "↑").replace("Arrow Right", "→").replace("Arrow Down", "↓");
/*     */     
/* 163 */     return s;
/*     */   }
/*     */   
/*     */   public List<Integer> getExtraAccelerators() {
/* 167 */     return this.acclist;
/*     */   }
/*     */   
/*     */   public boolean canExecute() {
/* 171 */     return isEnabled();
/*     */   }
/*     */   
/*     */   public void execute() {
/* 175 */     run();
/*     */   }
/*     */   
/*     */   public boolean checkExecutionContext(Control ctl) {
/* 179 */     return (isAllowedForControl(ctl)) && (!isForbiddenForControl(ctl));
/*     */   }
/*     */   
/*     */   protected boolean isAllowedForControl(Control ctl) {
/* 183 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean isForbiddenForControl(Control ctl) {
/* 187 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\binding\ActionEx.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */