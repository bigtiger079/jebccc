/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.binding;
/*    */ 
/*    */ import com.pnfsoftware.jeb.core.properties.IConfiguration;
/*    */ import com.pnfsoftware.jeb.core.properties.impl.SimplePropertyManager;
/*    */ import com.pnfsoftware.jeb.util.format.Strings;
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.jface.bindings.keys.KeyStroke;
/*    */ import org.eclipse.jface.bindings.keys.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyShortcutsManager
/*    */ {
/* 27 */   private static final ILogger logger = GlobalLog.getLogger(KeyShortcutsManager.class);
/*    */   
/*    */   SimplePropertyManager pm;
/*    */   
/* 31 */   Map<String, Integer> map = new HashMap();
/* 32 */   Map<Integer, String> rmap = new HashMap();
/*    */   
/*    */   public KeyShortcutsManager(SimplePropertyManager pm) {
/* 35 */     this.pm = pm;
/*    */     
/* 37 */     for (String actionId : pm.getConfiguration().getAllPropertyKeys()) {
/* 38 */       if (Strings.isBlank(actionId)) {
/* 39 */         logger.error("Action id is blank \"%s\"", new Object[] { actionId });
/*    */       }
/*    */       
/* 42 */       int keycode = processEntry(actionId);
/* 43 */       if (keycode == 0) {
/* 44 */         logger.error("Illegal action definition \"%s=%s\"", new Object[] { actionId, pm.getString(actionId) });
/*    */       }
/*    */       
/* 47 */       if (this.map.containsKey(actionId)) {
/* 48 */         logger.error("Action \"%s\" is already defined", new Object[] { actionId });
/*    */       }
/* 50 */       if (this.rmap.containsKey(Integer.valueOf(keycode))) {
/* 51 */         logger.error("Action \"%s\" is attempting to use a key reserved by action \"%s\"", new Object[] { actionId, this.rmap
/* 52 */           .get(Integer.valueOf(keycode)) });
/*    */       }
/*    */       
/* 55 */       this.map.put(actionId, Integer.valueOf(keycode));
/* 56 */       this.rmap.put(Integer.valueOf(keycode), actionId);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isReserved(int keycode) {
/* 61 */     return getActionIdForKeycode(keycode) != null;
/*    */   }
/*    */   
/*    */   public String getActionIdForKeycode(int keycode) {
/* 65 */     return (String)this.rmap.get(Integer.valueOf(keycode));
/*    */   }
/*    */   
/*    */   public int getShortcutKeycode(String actionId) {
/* 69 */     Integer r = (Integer)this.map.get(actionId);
/* 70 */     return r == null ? 0 : r.intValue();
/*    */   }
/*    */   
/*    */   private int processEntry(String actionId) {
/* 74 */     if (Strings.isBlank(actionId)) {
/* 75 */       return 0;
/*    */     }
/*    */     
/* 78 */     String s = this.pm.getString(actionId);
/* 79 */     if (Strings.isBlank(s)) {
/* 80 */       return 0;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 85 */       ks = KeyStroke.getInstance(s.trim());
/*    */     } catch (ParseException e) {
/*    */       KeyStroke ks;
/* 88 */       return 0;
/*    */     }
/*    */     KeyStroke ks;
/* 91 */     int keycode = ks.getModifierKeys() | ks.getNaturalKey();
/* 92 */     return keycode;
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\binding\KeyShortcutsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */