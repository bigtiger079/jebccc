/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.binding;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.Licensing;
/*     */ import com.pnfsoftware.jeb.rcpclient.AllHandlers;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.handlers.JebBaseHandler;
/*     */ import com.pnfsoftware.jeb.util.collect.WeakIdentityHashMap;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.eclipse.jface.bindings.keys.KeyStroke;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Listener;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyAcceleratorManager
/*     */ {
/*  39 */   private static final ILogger logger = GlobalLog.getLogger(KeyAcceleratorManager.class);
/*     */   
/*     */   private Display display;
/*  42 */   private WeakIdentityHashMap<Shell, Integer> shellmap = new WeakIdentityHashMap();
/*     */   private Listener filter;
/*     */   private boolean disregardIncomingTraversalKeyDown;
/*  45 */   private Map<Integer, ActionEx> keyToHandlers = new HashMap();
/*     */   
/*     */   public KeyAcceleratorManager(Display display) {
/*  48 */     this.display = display;
/*     */     
/*     */ 
/*  51 */     for (Shell shell : display.getShells()) {
/*  52 */       processShell(shell);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.filter = new Listener()
/*     */     {
/*     */       public void handleEvent(Event event) {
/*  61 */         if (event.type == 1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*  66 */           if (KeyAcceleratorManager.this.disregardIncomingTraversalKeyDown) {
/*  67 */             KeyAcceleratorManager.this.disregardIncomingTraversalKeyDown = false;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*  72 */             if ((event.keyCode == 27) || (event.keyCode == 9))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*  77 */               return;
/*     */             }
/*     */           }
/*     */           
/*  81 */           if (KeyAcceleratorManager.this.processKey(event)) {
/*  82 */             event.type = 0;
/*  83 */             event.doit = false;
/*     */           }
/*     */         }
/*  86 */         else if (event.type == 31) {
/*  87 */           if (KeyAcceleratorManager.this.processKey(event))
/*     */           {
/*     */ 
/*     */ 
/*  91 */             event.type = 0;
/*  92 */             event.doit = false;
/*  93 */             KeyAcceleratorManager.this.disregardIncomingTraversalKeyDown = true;
/*     */           }
/*     */         }
/*  96 */         else if (event.type == 26)
/*     */         {
/*  98 */           if ((event.widget instanceof Shell)) {
/*  99 */             Shell shell = (Shell)event.widget;
/* 100 */             KeyAcceleratorManager.this.processShell(shell);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 105 */     };
/* 106 */     display.addFilter(1, this.filter);
/* 107 */     display.addFilter(31, this.filter);
/* 108 */     display.addFilter(26, this.filter);
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 112 */     this.display.removeFilter(1, this.filter);
/* 113 */     this.display.removeFilter(31, this.filter);
/* 114 */     this.display.removeFilter(26, this.filter);
/*     */   }
/*     */   
/*     */   private void processShell(Shell shell) {
/* 118 */     if (this.shellmap.get(shell) != null) {
/* 119 */       return;
/*     */     }
/*     */     
/* 122 */     this.shellmap.put(shell, Integer.valueOf(0));
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean processKey(Event event)
/*     */   {
/* 128 */     if ((event.widget instanceof Control))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */       if ((event.keyCode & SWT.MODIFIER_MASK) == 0) {
/* 135 */         ActionEx h = (ActionEx)this.keyToHandlers.get(Integer.valueOf(event.stateMask | event.keyCode));
/* 136 */         if (h == null) {
/* 137 */           h = (ActionEx)this.keyToHandlers.get(Integer.valueOf(event.character));
/*     */         }
/* 139 */         if (h != null)
/*     */         {
/* 141 */           if ((h instanceof JebBaseHandler)) {
/* 142 */             JebBaseHandler h2 = AllHandlers.getInstance().create(((JebBaseHandler)h).getClass());
/* 143 */             if (h2 != null) {
/* 144 */               h = h2;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 149 */           Control ctl = (Control)event.widget;
/* 150 */           if ((h.checkExecutionContext(ctl)) && 
/* 151 */             (h.canExecute())) {
/* 152 */             UIExecutor.sync(this.display, h);
/* 153 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 159 */     return false;
/*     */   }
/*     */   
/*     */   public void registerHandlers(Collection<? extends ActionEx> handlers) {
/* 163 */     for (ActionEx handler : handlers) {
/* 164 */       registerHandler(handler);
/*     */     }
/*     */   }
/*     */   
/*     */   public void registerHandler(ActionEx handler) {
/* 169 */     for (Iterator localIterator = handler.getExtraAccelerators().iterator(); localIterator.hasNext();) { int keycode = ((Integer)localIterator.next()).intValue();
/* 170 */       ActionEx h0 = (ActionEx)this.keyToHandlers.get(Integer.valueOf(keycode));
/* 171 */       if (h0 != null) {
/* 172 */         if (h0 != handler) {
/* 173 */           logger.error("The accelerator %s is already used by handler %s (handler %s cannot steal it)", new Object[] {
/* 174 */             KeyStroke.getInstance(keycode & 0xFEFF0000, keycode & 0x100FFFF).toString(), h0
/* 175 */             .getClass().getSimpleName(), handler.getClass().getSimpleName() });
/* 176 */           if (Licensing.isDebugBuild()) {
/* 177 */             throw new RuntimeException("Keyboard shortcut conflict must be resolved in debug mode");
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/* 182 */         this.keyToHandlers.put(Integer.valueOf(keycode), handler);
/*     */     }
/*     */   }
/*     */   
/*     */   public void unregisterHandler(ActionEx handler) {
/* 187 */     List<Integer> tbd = new ArrayList();
/* 188 */     for (Map.Entry<Integer, ActionEx> e : this.keyToHandlers.entrySet()) {
/* 189 */       if (e.getValue() == handler) {
/* 190 */         tbd.add(e.getKey());
/*     */       }
/*     */     }
/* 193 */     for (??? = tbd.iterator(); ???.hasNext();) { int keycode = ((Integer)???.next()).intValue();
/* 194 */       this.keyToHandlers.remove(Integer.valueOf(keycode));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\binding\KeyAcceleratorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */