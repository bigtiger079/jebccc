/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.ui;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.ShellWrapper.BoundsRestorationType;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIExecutor;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIRunnable;
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.util.base.Throwables;
/*     */ import com.pnfsoftware.jeb.util.concurrent.ThreadUtil;
/*     */ import com.pnfsoftware.jeb.util.format.Strings;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskMonitorDialog
/*     */   extends JebDialog
/*     */ {
/*  32 */   private static final ILogger logger = GlobalLog.getLogger(TaskMonitorDialog.class);
/*     */   
/*  34 */   private String[] labels = { "Please wait...", "" };
/*  35 */   private Label[] wLabels = new Label[this.labels.length];
/*     */   private Thread t;
/*     */   private Exception ex;
/*     */   private long popupTimeout;
/*     */   private volatile boolean canceled;
/*     */   
/*     */   public TaskMonitorDialog(Shell parent)
/*     */   {
/*  43 */     this(parent, 0L);
/*     */   }
/*     */   
/*     */   public TaskMonitorDialog(Shell parent, long popupTimeout) {
/*  47 */     super(parent, 67616, "Task", null);
/*  48 */     this.boundsRestorationType = ShellWrapper.BoundsRestorationType.NONE;
/*  49 */     this.doNotOpenShell = true;
/*  50 */     this.doNotDispatchEvents = true;
/*  51 */     this.popupTimeout = popupTimeout;
/*     */   }
/*     */   
/*     */   protected void createContents(Composite parent)
/*     */   {
/*  56 */     UIUtil.setStandardLayout(parent, 1);
/*     */     
/*  58 */     Composite c = new Composite(parent, 0);
/*  59 */     GridData data = new GridData();
/*  60 */     data.grabExcessHorizontalSpace = true;
/*  61 */     data.minimumWidth = 680;
/*  62 */     data.grabExcessVerticalSpace = true;
/*  63 */     data.minimumHeight = 140;
/*  64 */     c.setLayoutData(data);
/*     */     
/*  66 */     UIUtil.setStandardLayout(c, 1);
/*     */     
/*  68 */     for (int i = 0; i < this.wLabels.length; i++) {
/*  69 */       this.wLabels[i] = new Label(c, 0);
/*  70 */       this.wLabels[i].setText(Strings.safe(this.labels[i]));
/*  71 */       this.wLabels[i].setLayoutData(UIUtil.createGridDataFillHorizontally());
/*     */     }
/*     */     
/*  74 */     createButtons(parent, 256, 256);
/*     */   }
/*     */   
/*     */   protected void onButtonClick(int style)
/*     */   {
/*  79 */     if (style == 256) {
/*  80 */       this.monitor.setCanceled(true);
/*  81 */       getButtonByStyle(256).setEnabled(false);
/*     */     }
/*     */     else {
/*  84 */       super.onButtonClick(style);
/*     */     }
/*     */   }
/*     */   
/*  88 */   ITaskProgressMonitor monitor = new ITaskProgressMonitor()
/*     */   {
/*     */     public void setTaskName(String name) {
/*  91 */       updateLabel(0, name);
/*     */     }
/*     */     
/*     */     public void setSubtaskName(String name)
/*     */     {
/*  96 */       updateLabel(1, name);
/*     */     }
/*     */     
/*     */     public void progress(long current, long total)
/*     */     {
/* 101 */       if ((total > 0L) && (current >= 0L) && (current <= total)) {
/* 102 */         String text = String.format("[Progress: %.1f%%]", new Object[] { Double.valueOf(current * 100.0D / total) });
/* 103 */         updateLabel(1, text);
/*     */       }
/*     */     }
/*     */     
/*     */     public void setCanceled(boolean value)
/*     */     {
/* 109 */       TaskMonitorDialog.this.canceled = true;
/* 110 */       updateLabel(0, "Cancelling... please wait");
/*     */     }
/*     */     
/*     */     public boolean isCanceled()
/*     */     {
/* 115 */       return TaskMonitorDialog.this.canceled;
/*     */     }
/*     */     
/*     */ 
/*     */     public void done() {}
/*     */     
/*     */ 
/*     */     private void updateLabel(final int index, final String text)
/*     */     {
/* 124 */       UIExecutor.sync(TaskMonitorDialog.this.getParent().getDisplay(), new UIRunnable()
/*     */       {
/*     */         public void runi() {
/* 127 */           TaskMonitorDialog.this.labels[index] = text;
/* 128 */           Label wLabel = TaskMonitorDialog.this.wLabels[index];
/* 129 */           if ((wLabel != null) && (!wLabel.isDisposed())) {
/* 130 */             wLabel.setText(Strings.safe(text));
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   };
/*     */   
/*     */   public void run(final UITask<?> task) throws InvocationTargetException, InterruptedException {
/* 138 */     if (Display.getCurrent() == null) {
/* 139 */       throw new RuntimeException("TaskMonitorDialog.run() must be called from the UI thread");
/*     */     }
/*     */     
/*     */ 
/* 143 */     this.t = ThreadUtil.start(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 147 */           task.run(TaskMonitorDialog.this.monitor);
/*     */         }
/*     */         catch (Exception e) {
/* 150 */           TaskMonitorDialog.this.ex = e;
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 155 */     });
/* 156 */     super.open();
/*     */     
/* 158 */     long t0 = System.currentTimeMillis();
/* 159 */     boolean hiddenShell = false;
/* 160 */     Rectangle bounds0 = null;
/*     */     
/*     */ 
/* 163 */     bounds0 = this.shell.getBounds();
/* 164 */     this.shell.setBounds(0, -50, 1, 1);
/* 165 */     hiddenShell = true;
/*     */     
/*     */ 
/* 168 */     this.shell.open();
/*     */     
/* 170 */     Display display = this.shell.getDisplay();
/* 171 */     while (!this.shell.isDisposed()) {
/* 172 */       if (!display.readAndDispatch())
/*     */       {
/* 174 */         this.t.join(20L);
/* 175 */         if (!this.t.isAlive()) {
/* 176 */           this.shell.close();
/* 177 */           break;
/*     */         }
/* 179 */         if ((hiddenShell) && (System.currentTimeMillis() - t0 >= this.popupTimeout))
/*     */         {
/* 181 */           Rectangle displaybounds = this.shell.getDisplay().getClientArea();
/* 182 */           int offx = 0;
/* 183 */           int offy = 0;
/* 184 */           Composite parent = this.shell.getParent();
/* 185 */           if (parent != null) {
/* 186 */             Rectangle r = parent.getBounds();
/* 187 */             offx = r.x + r.width / 2 - (displaybounds.x + displaybounds.width / 2);
/* 188 */             offy = r.y + r.height / 2 - (displaybounds.y + displaybounds.height / 2);
/*     */           }
/* 190 */           this.shell.setBounds(displaybounds.x + (displaybounds.width - bounds0.width) / 2 + offx, displaybounds.y + (displaybounds.height - bounds0.height) / 2 + offy, bounds0.width, bounds0.height);
/*     */           
/*     */ 
/* 193 */           hiddenShell = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 198 */     if ((this.ex instanceof InvocationTargetException)) {
/* 199 */       throw ((InvocationTargetException)this.ex);
/*     */     }
/* 201 */     if ((this.ex instanceof InterruptedException)) {
/* 202 */       throw ((InterruptedException)this.ex);
/*     */     }
/* 204 */     if (this.ex != null)
/*     */     {
/* 206 */       Throwables.rethrowUnchecked(this.ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extension\\ui\TaskMonitorDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */