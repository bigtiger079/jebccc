/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.ui;
/*     */ 
/*     */ import com.pnfsoftware.jeb.util.base.CallableWithProgressCallback;
/*     */ import com.pnfsoftware.jeb.util.base.IProgressCallback;
/*     */ import com.pnfsoftware.jeb.util.base.RunnableWithProgressCallback;
/*     */ import com.pnfsoftware.jeb.util.concurrent.ThreadEx;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UITask<T>
/*     */ {
/*  35 */   private static final ILogger logger = GlobalLog.getLogger(UITask.class);
/*     */   
/*     */   private String taskName;
/*  38 */   private long checkTimeoutMs = 200L;
/*     */   
/*     */   private Runnable runnable;
/*     */   
/*     */   private Callable<T> callable;
/*     */   private T result;
/*     */   
/*     */   public UITask(ExecutorService execsvc, String taskName, Runnable runnable)
/*     */   {
/*  47 */     this.taskName = taskName;
/*  48 */     this.runnable = runnable;
/*     */   }
/*     */   
/*     */   public UITask(ExecutorService execsvc, String taskName, Callable<T> callable) {
/*  52 */     this.taskName = taskName;
/*  53 */     this.callable = callable;
/*     */   }
/*     */   
/*     */   public void setCheckTimeout(long millis) {
/*  57 */     this.checkTimeoutMs = millis;
/*     */   }
/*     */   
/*     */   public long setCheckTimeout() {
/*  61 */     return this.checkTimeoutMs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T getResult()
/*     */   {
/*  72 */     return (T)this.result;
/*     */   }
/*     */   
/*     */   public void run(final ITaskProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
/*  76 */     if (this.taskName != null) {
/*  77 */       monitor.setTaskName(this.taskName);
/*     */     }
/*     */     
/*  80 */     IProgressCallback callback = new IProgressCallback()
/*     */     {
/*     */       public void progress(long current, long total) {
/*  83 */         monitor.progress(current, total);
/*     */       }
/*     */     };
/*  86 */     if ((this.callable instanceof CallableWithProgressCallback)) {
/*  87 */       ((CallableWithProgressCallback)this.callable).setCallback(callback);
/*     */     }
/*  89 */     if ((this.runnable instanceof RunnableWithProgressCallback)) {
/*  90 */       ((RunnableWithProgressCallback)this.runnable).setCallback(callback);
/*     */     }
/*     */     ThreadEx<T> t;
/*     */     ThreadEx<T> t;
/*  94 */     if (this.runnable != null) {
/*  95 */       t = new ThreadEx(this.runnable);
/*     */     }
/*     */     else {
/*  98 */       t = new ThreadEx(this.callable);
/*     */     }
/* 100 */     t.start();
/*     */     
/*     */     for (;;)
/*     */     {
/*     */       try
/*     */       {
/* 106 */         if (this.runnable != null) {
/* 107 */           t.get(this.checkTimeoutMs);
/*     */         }
/*     */         else {
/* 110 */           this.result = t.get(this.checkTimeoutMs);
/*     */         }
/*     */       }
/*     */       catch (InterruptedException e) {
/* 114 */         throw e;
/*     */       }
/*     */       catch (ExecutionException e) {
/* 117 */         throw new InvocationTargetException(e.getCause());
/*     */       }
/*     */       catch (TimeoutException localTimeoutException) {}
/*     */       
/*     */ 
/*     */ 
/* 123 */       if (!t.isAlive()) {
/*     */         break;
/*     */       }
/*     */       
/* 127 */       if ((monitor.isCanceled()) && (!t.isInterrupted())) {
/* 128 */         t.interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extension\\ui\UITask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */