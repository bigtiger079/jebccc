/*    */ package com.pnfsoftware.jeb.rcpclient.extensions.ui;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UITaskManager
/*    */ {
/*    */   Display display;
/*    */   ExecutorService execsvc;
/*    */   
/*    */   public UITaskManager(Display display, ExecutorService execsvc)
/*    */   {
/* 21 */     this.display = display;
/* 22 */     this.execsvc = execsvc;
/*    */   }
/*    */   
/*    */   public void create(Shell shell, String caption, Runnable runnable, long popupDelayMs) throws InvocationTargetException, InterruptedException
/*    */   {
/* 27 */     TaskMonitorDialog dlg = new TaskMonitorDialog(shell, popupDelayMs);
/* 28 */     UITask<?> job = new UITask(this.execsvc, caption, runnable);
/* 29 */     dlg.run(job);
/*    */   }
/*    */   
/*    */   public <T> T create(Shell shell, String caption, Callable<T> callable, long popupDelayMs) throws InvocationTargetException, InterruptedException
/*    */   {
/* 34 */     TaskMonitorDialog dlg = new TaskMonitorDialog(shell, popupDelayMs);
/* 35 */     UITask<T> job = new UITask(this.execsvc, caption, callable);
/* 36 */     dlg.run(job);
/* 37 */     return (T)job.getResult();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extension\\ui\UITaskManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */