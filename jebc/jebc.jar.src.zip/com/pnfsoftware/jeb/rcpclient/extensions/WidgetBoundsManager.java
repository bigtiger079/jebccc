/*    */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.eclipse.swt.graphics.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WidgetBoundsManager
/*    */ {
/* 24 */   private static final ILogger logger = GlobalLog.getLogger(WidgetBoundsManager.class);
/*    */   
/* 26 */   private Map<Integer, Rectangle> map = new HashMap();
/*    */   
/*    */   public WidgetBoundsManager() {}
/*    */   
/*    */   public WidgetBoundsManager(String encodedData)
/*    */   {
/* 32 */     loadFromString(encodedData);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean loadFromString(String s)
/*    */   {
/* 45 */     String[] elts = s.split("\\|");
/* 46 */     int errcnt = 0;
/* 47 */     for (String elt : elts) {
/* 48 */       String[] kv = elt.split("=");
/*    */       try {
/* 50 */         int id = Integer.parseInt(kv[0]);
/* 51 */         String[] v = kv[1].split(",");
/* 52 */         int x = Integer.parseInt(v[0]);
/* 53 */         int y = Integer.parseInt(v[1]);
/* 54 */         int w = Integer.parseInt(v[2]);
/* 55 */         int h = Integer.parseInt(v[3]);
/* 56 */         Rectangle r = new Rectangle(x, y, w, h);
/* 57 */         this.map.put(Integer.valueOf(id), r);
/*    */       }
/*    */       catch (Exception e) {
/* 60 */         logger.debug("Invalid shell bounds entry: \"%s\"", new Object[] { elt });
/* 61 */         errcnt++;
/*    */       }
/*    */     }
/* 64 */     return errcnt == 0;
/*    */   }
/*    */   
/*    */   public String encode() {
/* 68 */     StringBuilder sb = new StringBuilder();
/* 69 */     int i = 0;
/* 70 */     for (Iterator localIterator = this.map.keySet().iterator(); localIterator.hasNext();) { int widgetId = ((Integer)localIterator.next()).intValue();
/* 71 */       if (i >= 1) {
/* 72 */         sb.append("|");
/*    */       }
/* 74 */       Rectangle r = (Rectangle)this.map.get(Integer.valueOf(widgetId));
/* 75 */       sb.append(String.format("%d=%d,%d,%d,%d", new Object[] { Integer.valueOf(widgetId), Integer.valueOf(r.x), Integer.valueOf(r.y), Integer.valueOf(r.width), Integer.valueOf(r.height) }));
/* 76 */       i++;
/*    */     }
/* 78 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public Rectangle getRecordedBounds(int widgetId) {
/* 82 */     return (Rectangle)this.map.get(Integer.valueOf(widgetId));
/*    */   }
/*    */   
/*    */   public void setRecordedBounds(int widgetId, Rectangle bounds) {
/* 86 */     if (bounds == null) {
/* 87 */       this.map.remove(Integer.valueOf(widgetId));
/*    */     }
/*    */     else {
/* 90 */       this.map.put(Integer.valueOf(widgetId), bounds);
/*    */     }
/*    */   }
/*    */   
/*    */   public void clearBounds() {
/* 95 */     this.map.clear();
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\WidgetBoundsManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */