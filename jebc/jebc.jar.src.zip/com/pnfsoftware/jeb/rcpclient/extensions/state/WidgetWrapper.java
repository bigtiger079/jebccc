/*     */ package com.pnfsoftware.jeb.rcpclient.extensions.state;
/*     */ 
/*     */ import com.pnfsoftware.jeb.rcpclient.extensions.UIUtil;
/*     */ import com.pnfsoftware.jeb.rcpclient.util.IPersistenceProvider;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableColumn;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WidgetWrapper
/*     */ {
/*  34 */   private static final ILogger logger = GlobalLog.getLogger(WidgetWrapper.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private IPersistenceProvider pp;
/*     */   
/*     */ 
/*     */ 
/*     */   public WidgetWrapper(IPersistenceProvider pp)
/*     */   {
/*  44 */     if (pp == null) {
/*  45 */       throw new IllegalArgumentException("The persistence provider is null");
/*     */     }
/*  47 */     this.pp = pp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean wrap(Control ctl)
/*     */   {
/*  58 */     int id = UIUtil.getWidgetId(ctl);
/*  59 */     if (id == 0) {
/*  60 */       logger.debug("The widget '%s' has a null id and cannot be wrapped", new Object[] { ctl });
/*  61 */       return false;
/*     */     }
/*     */     
/*  64 */     wrapInternal("" + id, ctl);
/*  65 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void wrapInternal(String fqn, Control ctl)
/*     */   {
/*  76 */     if ((ctl instanceof Table)) {
/*  77 */       monitorTable(fqn, (Table)ctl);
/*     */     }
/*  79 */     if ((ctl instanceof Tree)) {
/*  80 */       monitorTree(fqn, (Tree)ctl);
/*     */     }
/*  82 */     if ((ctl instanceof Composite)) {
/*  83 */       int i = 0;
/*  84 */       for (Control ctl1 : ((Composite)ctl).getChildren()) {
/*  85 */         wrapInternal(fqn + "/@" + i, ctl1);
/*  86 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void monitorTable(final String fqn, Table table) {
/*  92 */     final IColumnWidgetManager t = new TableColumnManager(table);
/*     */     
/*  94 */     restore(fqn, t);
/*     */     
/*  96 */     table.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/*  99 */         WidgetWrapper.this.record(fqn, t);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   void monitorTree(final String fqn, Tree tree) {
/* 105 */     final IColumnWidgetManager t = new TreeColumnManager(tree);
/*     */     
/* 107 */     restore(fqn, t);
/*     */     
/* 109 */     tree.addDisposeListener(new DisposeListener()
/*     */     {
/*     */       public void widgetDisposed(DisposeEvent e) {
/* 112 */         WidgetWrapper.this.record(fqn, t);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   void restore(String fqn, IColumnWidgetManager t) {
/* 118 */     logger.i("Restoring state for widget %s", new Object[] { fqn });
/* 119 */     String encodedData = this.pp.load(fqn);
/* 120 */     if (encodedData != null) {
/*     */       try {
/* 122 */         String[] elts = encodedData.split(",");
/* 123 */         if (elts.length == t.getCount()) {
/* 124 */           int[] order = new int[elts.length];
/* 125 */           int[] widths = new int[elts.length];
/* 126 */           for (int i = 0; i < elts.length; i++) {
/* 127 */             String[] v = elts[i].split(":");
/* 128 */             if (v.length != 2) {
/*     */               break;
/*     */             }
/* 131 */             order[i] = Integer.parseInt(v[0]);
/* 132 */             widths[i] = Integer.parseInt(v[1]);
/*     */           }
/* 134 */           t.setOrder(order);
/* 135 */           for (int i = 0; i < widths.length; i++) {
/* 136 */             t.setWidth(i, widths[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException e) {
/* 141 */         logger.trace("Invalid widget persistence data: %s", new Object[] { e });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void record(String fqn, IColumnWidgetManager t) {
/* 147 */     logger.i("Recording state for widget %s", new Object[] { fqn });
/* 148 */     int count = t.getCount();
/* 149 */     if (count >= 1) {
/* 150 */       StringBuilder sb = new StringBuilder();
/* 151 */       int[] order = t.getOrder();
/*     */       
/* 153 */       for (int i = 0; i < count; i++) {
/* 154 */         if (i >= 1) {
/* 155 */           sb.append(',');
/*     */         }
/* 157 */         int index = order[i];
/* 158 */         int w = t.getWidth(index);
/* 159 */         sb.append(String.format("%d:%d", new Object[] { Integer.valueOf(index), Integer.valueOf(w) }));
/*     */       }
/*     */       
/* 162 */       String encodedState = sb.toString();
/* 163 */       this.pp.save(fqn, encodedState);
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract interface IColumnWidgetManager {
/*     */     public abstract int getCount();
/*     */     
/*     */     public abstract int[] getOrder();
/*     */     
/*     */     public abstract void setOrder(int[] paramArrayOfInt);
/*     */     
/*     */     public abstract int getWidth(int paramInt);
/*     */     
/*     */     public abstract void setWidth(int paramInt1, int paramInt2);
/*     */   }
/*     */   
/*     */   static class TableColumnManager implements WidgetWrapper.IColumnWidgetManager {
/*     */     private Table t;
/*     */     
/*     */     public TableColumnManager(Table t) {
/* 183 */       this.t = t;
/*     */     }
/*     */     
/*     */     public int getCount()
/*     */     {
/* 188 */       return this.t.getColumnCount();
/*     */     }
/*     */     
/*     */     public int[] getOrder()
/*     */     {
/* 193 */       return this.t.getColumnOrder();
/*     */     }
/*     */     
/*     */     public void setOrder(int[] order)
/*     */     {
/* 198 */       this.t.setColumnOrder(order);
/*     */     }
/*     */     
/*     */     public int getWidth(int index)
/*     */     {
/* 203 */       return this.t.getColumn(index).getWidth();
/*     */     }
/*     */     
/*     */     public void setWidth(int index, int width)
/*     */     {
/* 208 */       this.t.getColumn(index).setWidth(width);
/*     */     }
/*     */   }
/*     */   
/*     */   static class TreeColumnManager implements WidgetWrapper.IColumnWidgetManager {
/*     */     private Tree t;
/*     */     
/*     */     public TreeColumnManager(Tree t) {
/* 216 */       this.t = t;
/*     */     }
/*     */     
/*     */     public int getCount()
/*     */     {
/* 221 */       return this.t.getColumnCount();
/*     */     }
/*     */     
/*     */     public int[] getOrder()
/*     */     {
/* 226 */       return this.t.getColumnOrder();
/*     */     }
/*     */     
/*     */     public void setOrder(int[] order)
/*     */     {
/* 231 */       this.t.setColumnOrder(order);
/*     */     }
/*     */     
/*     */     public int getWidth(int index)
/*     */     {
/* 236 */       return this.t.getColumn(index).getWidth();
/*     */     }
/*     */     
/*     */     public void setWidth(int index, int width)
/*     */     {
/* 241 */       this.t.getColumn(index).setWidth(width);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\state\WidgetWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */