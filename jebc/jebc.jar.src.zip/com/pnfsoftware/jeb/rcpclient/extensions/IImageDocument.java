package com.pnfsoftware.jeb.rcpclient.extensions;

import com.pnfsoftware.jeb.util.events.IEventSource;
import org.eclipse.swt.graphics.Image;

public abstract interface IImageDocument
  extends IEventSource
{
  public abstract Image getImage();
}


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\IImageDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */