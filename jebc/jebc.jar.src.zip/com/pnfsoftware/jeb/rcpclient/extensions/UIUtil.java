/*     */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*     */ 
/*     */ import com.pnfsoftware.jeb.client.S;
/*     */ import com.pnfsoftware.jeb.rcpclient.dialogs.JebDialog;
/*     */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*     */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.swt.dnd.Clipboard;
/*     */ import org.eclipse.swt.dnd.TextTransfer;
/*     */ import org.eclipse.swt.dnd.Transfer;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.events.TraverseEvent;
/*     */ import org.eclipse.swt.events.TraverseListener;
/*     */ import org.eclipse.swt.graphics.FontMetrics;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.FormAttachment;
/*     */ import org.eclipse.swt.layout.FormData;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.layout.RowData;
/*     */ import org.eclipse.swt.layout.RowLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Group;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.MessageBox;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UIUtil
/*     */ {
/*  51 */   private static final ILogger logger = GlobalLog.getLogger(UIUtil.class);
/*     */   private static boolean warnedArraySort;
/*     */   
/*     */   public static boolean isUIThread(Display display)
/*     */   {
/*  56 */     return Thread.currentThread() == display.getThread();
/*     */   }
/*     */   
/*     */   public static Button createPushbox(Composite parent, String name, SelectionListener listener) {
/*  60 */     Button btn = new Button(parent, 8);
/*  61 */     btn.setText("     " + name + "     ");
/*  62 */     if (listener != null) {
/*  63 */       btn.addSelectionListener(listener);
/*     */     }
/*  65 */     return btn;
/*     */   }
/*     */   
/*     */   public static Button createTightPushbox(Composite parent, String name, SelectionListener listener) {
/*  69 */     Button btn = new Button(parent, 8);
/*  70 */     btn.setText(name);
/*  71 */     if (listener != null) {
/*  72 */       btn.addSelectionListener(listener);
/*     */     }
/*  74 */     return btn;
/*     */   }
/*     */   
/*     */   public static Button createCheckbox(Composite parent, String name, SelectionListener listener) {
/*  78 */     Button btn = new Button(parent, 32);
/*  79 */     btn.setText(name);
/*  80 */     if (listener != null) {
/*  81 */       btn.addSelectionListener(listener);
/*     */     }
/*     */     
/*  84 */     return btn;
/*     */   }
/*     */   
/*     */   public static Label createLabel(Composite parent, String text) {
/*  88 */     Label label = new Label(parent, 16896);
/*  89 */     label.setText(text);
/*  90 */     return label;
/*     */   }
/*     */   
/*     */   public static Label createWrappedLabelInGridLayout(Composite parent, int addStyle, String text, int columns) {
/*  94 */     Label label = new Label(parent, addStyle | 0x4000 | 0x200 | 0x40);
/*  95 */     label.setLayoutData(createGridDataFillHorizontally());
/*  96 */     label.setText(text);
/*  97 */     return label;
/*     */   }
/*     */   
/*     */   public static Text createTextbox(Composite parent, int length, String init, SelectionListener listener) {
/* 101 */     Text text = new Text(parent, 2052);
/*     */     
/* 103 */     if ((parent.getLayout() instanceof RowLayout)) {
/* 104 */       RowData data = null;
/* 105 */       GC gc = new GC(text);
/*     */       try {
/* 107 */         gc.setFont(text.getFont());
/* 108 */         FontMetrics fm = gc.getFontMetrics();
/* 109 */         data = new RowData(length * fm.getAverageCharWidth(), 1 * fm.getHeight());
/*     */       }
/*     */       finally {
/* 112 */         gc.dispose();
/*     */       }
/* 114 */       text.setLayoutData(data);
/*     */     }
/*     */     
/* 117 */     if (init != null) {
/* 118 */       text.setText(init);
/* 119 */       text.selectAll();
/*     */     }
/*     */     
/* 122 */     text.pack(false);
/*     */     
/* 124 */     if (listener != null) {
/* 125 */       text.addSelectionListener(listener);
/*     */     }
/*     */     
/* 128 */     return text;
/*     */   }
/*     */   
/*     */   public static Text createTextboxInGrid(Composite parent, int flags, int columns, int lines) {
/* 132 */     return createTextboxInGrid(parent, flags, columns, lines, false, false);
/*     */   }
/*     */   
/*     */   public static Text createTextboxInGrid(Composite parent, int flags, int columns, int lines, boolean fillHorizontally, boolean fillVertically) {
/* 136 */     Text text = new Text(parent, flags);
/* 137 */     if ((parent.getLayout() instanceof GridLayout)) {
/* 138 */       GridData data = null;
/* 139 */       GC gc = new GC(text);
/*     */       try {
/* 141 */         gc.setFont(text.getFont());
/* 142 */         FontMetrics fm = gc.getFontMetrics();
/*     */         
/* 144 */         data = new GridData();
/* 145 */         if (columns >= 1) {
/* 146 */           data.widthHint = (columns * fm.getAverageCharWidth());
/*     */         }
/* 148 */         if (lines >= 1) {
/* 149 */           data.heightHint = (lines * fm.getHeight());
/*     */         }
/*     */       }
/*     */       finally {
/* 153 */         gc.dispose();
/*     */       }
/* 155 */       if (fillHorizontally) {
/* 156 */         data.horizontalAlignment = 4;
/* 157 */         data.grabExcessHorizontalSpace = true;
/*     */       }
/* 159 */       if (fillVertically) {
/* 160 */         data.verticalAlignment = 4;
/* 161 */         data.grabExcessVerticalSpace = true;
/*     */       }
/* 163 */       text.setLayoutData(data);
/*     */     }
/* 165 */     text.pack(false);
/* 166 */     return text;
/*     */   }
/*     */   
/*     */   public static void disableTabOutput(Control textControl) {
/* 170 */     disableTabOutput(textControl, null);
/*     */   }
/*     */   
/*     */   public static void disableTabOutput(Control textControl, Control nextFocusControl) {
/* 174 */     textControl.addTraverseListener(new TraverseListener()
/*     */     {
/*     */       public void keyTraversed(TraverseEvent e) {
/* 177 */         if ((e.detail == 16) || (e.detail == 8))
/*     */         {
/* 179 */           e.doit = true;
/*     */           
/* 181 */           if (this.val$nextFocusControl != null) {
/* 182 */             this.val$nextFocusControl.setFocus();
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public static RowLayout createRowLayout(boolean vertical, boolean wrap) {
/* 190 */     RowLayout l = new RowLayout();
/* 191 */     l.type = (vertical ? 512 : 256);
/* 192 */     l.wrap = wrap;
/* 193 */     return l;
/*     */   }
/*     */   
/*     */   public static void setStandardLayout(Composite composite)
/*     */   {
/* 198 */     setStandardLayout(composite, 1);
/*     */   }
/*     */   
/*     */   public static void setStandardLayout(Composite composite, int numColumns)
/*     */   {
/* 203 */     setStandardLayout(composite, numColumns, 5);
/*     */   }
/*     */   
/*     */   public static void setStandardLayout(Composite composite, int numColumns, int marginSize)
/*     */   {
/* 208 */     GridLayout layout = new GridLayout(numColumns, false);
/* 209 */     layout.marginLeft = marginSize;
/* 210 */     layout.marginRight = marginSize;
/* 211 */     layout.marginTop = marginSize;
/* 212 */     layout.marginBottom = marginSize;
/* 213 */     composite.setLayout(layout);
/*     */   }
/*     */   
/*     */   public static GridData createGridDataFillHorizontally() {
/* 217 */     return createGridDataFill(true, false);
/*     */   }
/*     */   
/*     */   public static GridData createGridDataFill(boolean fillHorizontally, boolean fillVertically) {
/* 221 */     GridData data = new GridData();
/* 222 */     if (fillHorizontally) {
/* 223 */       data.horizontalAlignment = 4;
/* 224 */       data.grabExcessHorizontalSpace = true;
/*     */     }
/* 226 */     if (fillVertically) {
/* 227 */       data.verticalAlignment = 4;
/* 228 */       data.grabExcessVerticalSpace = true;
/*     */     }
/* 230 */     return data;
/*     */   }
/*     */   
/*     */   public static GridData createGridDataSpanHorizontally(int span) {
/* 234 */     return createGridDataSpanHorizontally(span, false, false);
/*     */   }
/*     */   
/*     */   public static GridData createGridDataSpanHorizontally(int span, boolean fillHorizontally, boolean fillVertically) {
/* 238 */     GridData data = new GridData();
/* 239 */     data.horizontalSpan = span;
/* 240 */     if (fillHorizontally) {
/* 241 */       data.horizontalAlignment = 4;
/* 242 */       data.grabExcessHorizontalSpace = true;
/*     */     }
/* 244 */     if (fillVertically) {
/* 245 */       data.verticalAlignment = 4;
/* 246 */       data.grabExcessVerticalSpace = true;
/*     */     }
/* 248 */     return data;
/*     */   }
/*     */   
/*     */   public static GridData createGridDataForText(Control ctl, int charCount) {
/* 252 */     return createGridDataForText(ctl, charCount, 1, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static GridData createGridDataForText(Control ctl, int columnCount, int lineCount, boolean fillHorizontally)
/*     */   {
/* 266 */     GridData data = null;
/* 267 */     GC gc = new GC(ctl);
/*     */     try {
/* 269 */       gc.setFont(ctl.getFont());
/* 270 */       FontMetrics fm = gc.getFontMetrics();
/* 271 */       int width = columnCount <= 0 ? -1 : columnCount * fm.getAverageCharWidth();
/* 272 */       int height = lineCount <= 0 ? -1 : lineCount * fm.getHeight();
/* 273 */       data = new GridData(width, height);
/* 274 */       if (fillHorizontally) {
/* 275 */         data.horizontalAlignment = 4;
/* 276 */         data.grabExcessHorizontalSpace = true;
/*     */       }
/*     */     }
/*     */     finally {
/* 280 */       gc.dispose();
/*     */     }
/* 282 */     return data;
/*     */   }
/*     */   
/*     */   public static Group createGroup(Composite parent, String label) {
/* 286 */     Group general = new Group(parent, 0);
/* 287 */     general.setText(label);
/* 288 */     general.setLayoutData(createGridDataFillHorizontally());
/* 289 */     general.setLayout(new GridLayout(2, false));
/* 290 */     return general;
/*     */   }
/*     */   
/*     */   public static Group createGroupGrid(Composite parent, String label, int span, int cols) {
/* 294 */     Group c = new Group(parent, 0);
/* 295 */     c.setText(label);
/* 296 */     c.setLayoutData(createGridDataSpanHorizontally(span, true, false));
/* 297 */     c.setLayout(new GridLayout(cols, false));
/* 298 */     return c;
/*     */   }
/*     */   
/*     */   public static Composite createCompositeGrid(Composite parent, int span, int cols) {
/* 302 */     Composite c = new Composite(parent, 0);
/* 303 */     c.setLayoutData(createGridDataSpanHorizontally(span, true, false));
/* 304 */     c.setLayout(new GridLayout(cols, false));
/* 305 */     return c;
/*     */   }
/*     */   
/*     */   public static int determineTextWidth(Control ctl, int columnCount) {
/* 309 */     int width = 0;
/* 310 */     GC gc = new GC(ctl);
/*     */     try {
/* 312 */       gc.setFont(ctl.getFont());
/* 313 */       FontMetrics fm = gc.getFontMetrics();
/* 314 */       width = columnCount <= 0 ? -1 : columnCount * fm.getAverageCharWidth();
/*     */     }
/*     */     finally {
/* 317 */       gc.dispose();
/*     */     }
/* 319 */     return width;
/*     */   }
/*     */   
/*     */   public static int determineTextHeight(Control ctl, int lineCount) {
/* 323 */     int height = 0;
/* 324 */     GC gc = new GC(ctl);
/*     */     try {
/* 326 */       gc.setFont(ctl.getFont());
/* 327 */       FontMetrics fm = gc.getFontMetrics();
/* 328 */       height = lineCount <= 0 ? -1 : lineCount * fm.getHeight();
/*     */     }
/*     */     finally {
/* 331 */       gc.dispose();
/*     */     }
/* 333 */     return height;
/*     */   }
/*     */   
/*     */   public static FormData createFormData(Object top, Object bottom, Object left, Object right) {
/* 337 */     FormData data = new FormData();
/* 338 */     data.top = createFormAttachment(top);
/* 339 */     data.bottom = createFormAttachment(bottom);
/* 340 */     data.left = createFormAttachment(left);
/* 341 */     data.right = createFormAttachment(right);
/* 342 */     return data;
/*     */   }
/*     */   
/*     */   public static FormAttachment createFormAttachment(Object v) {
/* 346 */     if (v == null) {
/* 347 */       return null;
/*     */     }
/* 349 */     if ((v instanceof Integer)) {
/* 350 */       return new FormAttachment(((Integer)v).intValue());
/*     */     }
/* 352 */     if ((v instanceof Control)) {
/* 353 */       return new FormAttachment((Control)v);
/*     */     }
/* 355 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */   public static RowLayout createVerticalLayout() {
/* 359 */     return createRowLayout(true, false);
/*     */   }
/*     */   
/*     */   public static RowLayout createHorizontalLayout() {
/* 363 */     return createRowLayout(false, false);
/*     */   }
/*     */   
/*     */   public static Rectangle rectangleFromString(String s) {
/* 367 */     String[] elts = s.split(";");
/* 368 */     if (elts.length == 4) {
/*     */       try {
/* 370 */         return new Rectangle(Integer.parseInt(elts[0]), Integer.parseInt(elts[1]), Integer.parseInt(elts[2]), 
/* 371 */           Integer.parseInt(elts[3]));
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/* 376 */     return null;
/*     */   }
/*     */   
/*     */   public static String rectangleToString(Rectangle r) {
/* 380 */     return String.format("%d;%d;%d;%d", new Object[] { Integer.valueOf(r.x), Integer.valueOf(r.y), Integer.valueOf(r.width), Integer.valueOf(r.height) });
/*     */   }
/*     */   
/*     */   public static void showOperationResultDialog(Shell parent, boolean success) {
/* 384 */     int flags = 0x20 | (success ? 2 : 1);
/* 385 */     MessageBox mb = new MessageBox(parent, flags);
/* 386 */     mb.setText(S.s(280));
/* 387 */     if (success) {
/* 388 */       mb.setMessage(S.s(206));
/*     */     }
/*     */     else {
/* 391 */       mb.setMessage(S.s(205));
/*     */     }
/* 393 */     mb.open();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setWidgetName(Widget widget, String name)
/*     */   {
/* 404 */     widget.setData("widgetName", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getWidgetName(Widget widget)
/*     */   {
/* 414 */     Object o = widget.getData("widgetName");
/* 415 */     if ((o != null) && (!(o instanceof String))) {
/* 416 */       throw new IllegalStateException("The widgetName UI property must be a String");
/*     */     }
/*     */     
/* 419 */     return (String)o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getWidgetId(Object object)
/*     */   {
/* 431 */     if ((object instanceof JebDialog)) {
/* 432 */       object = ((JebDialog)object).getShell();
/*     */     }
/*     */     
/* 435 */     if ((object instanceof Control)) {
/* 436 */       String fqname = "";
/* 437 */       Control control = (Control)object;
/*     */       
/* 439 */       if (!(control instanceof Shell)) {
/* 440 */         Object objName = control.getData("widgetName");
/* 441 */         if (!(objName instanceof String)) {
/* 442 */           logger.i("control: widgetName is missing", new Object[0]);
/* 443 */           return 0;
/*     */         }
/* 445 */         fqname = objName + "/" + fqname;
/*     */         
/* 447 */         control = control.getShell();
/* 448 */         if (control == null) {
/* 449 */           logger.i("non-shell control has no parent shell, wth?", new Object[0]);
/* 450 */           return 0;
/*     */         }
/*     */       }
/*     */       
/* 454 */       while (control != null) {
/* 455 */         if (!(control instanceof Shell)) {
/* 456 */           logger.i("was expecting a shell instance, got: %s", new Object[] { control.getClass().getName() });
/* 457 */           return 0;
/*     */         }
/*     */         
/* 460 */         Object objName = control.getData("widgetName");
/* 461 */         if (!(objName instanceof String)) {
/* 462 */           logger.i("shell: widgetName is missing: %s", new Object[] { ((Shell)control).getText() });
/* 463 */           return 0;
/*     */         }
/* 465 */         fqname = objName + "/" + fqname;
/*     */         
/* 467 */         control = control.getParent();
/*     */       }
/*     */       
/*     */ 
/* 471 */       return fqname.hashCode();
/*     */     }
/*     */     
/* 474 */     return 0;
/*     */   }
/*     */   
/*     */   public static Shell getParentShell(Composite ctl) {
/*     */     do {
/* 479 */       ctl = ctl.getParent();
/* 480 */       if (ctl == null) {
/* 481 */         return null;
/*     */       }
/* 483 */     } while (!(ctl instanceof Shell));
/* 484 */     return (Shell)ctl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void copyTextToClipboard(String text)
/*     */   {
/* 495 */     Clipboard clipboard = new Clipboard(Display.getCurrent());
/* 496 */     TextTransfer textTransfer = TextTransfer.getInstance();
/* 497 */     clipboard.setContents(new String[] { text }, new Transfer[] { textTransfer });
/* 498 */     clipboard.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getTextFromClipboard()
/*     */   {
/* 507 */     Clipboard clipboard = new Clipboard(Display.getCurrent());
/* 508 */     TextTransfer textTransfer = TextTransfer.getInstance();
/* 509 */     String s = (String)clipboard.getContents(textTransfer, 1);
/* 510 */     clipboard.dispose();
/* 511 */     return s;
/*     */   }
/*     */   
/*     */   public static boolean isArrowKey(int key) {
/* 515 */     switch (key) {
/*     */     case 16777217: 
/*     */     case 16777218: 
/*     */     case 16777219: 
/*     */     case 16777220: 
/* 520 */       return true;
/*     */     }
/* 522 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void safeRefreshViewer(Viewer viewer)
/*     */   {
/*     */     try
/*     */     {
/* 533 */       viewer.refresh();
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 536 */       if (e.getMessage().contains("Comparison method violates its general contract!"))
/*     */       {
/*     */ 
/* 539 */         if (!Boolean.parseBoolean(System.getProperty("java.util.Arrays.useLegacyMergeSort"))) {
/* 540 */           logger.error("A comparison error occurred, the viewer cannot be sorted!", new Object[0]);
/* 541 */           if (!warnedArraySort) {
/* 542 */             warnedArraySort = true;
/* 543 */             logger.error("It may be a well-known issue in the UI framework: consider editing jeb.ini, and add the following line:\n  -Djava.util.Arrays.useLegacyMergeSort=true\nafter the line (add it if necessary):\n  -vmargs\nRefer to the FAQ for details: https://www.pnfsoftware.com/jeb/manual/faq/", new Object[0]);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 549 */           return;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 555 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isContained(Point p, Rectangle r)
/*     */   {
/* 566 */     return (p.x >= r.x) && (p.x < r.x + r.width) && (p.y >= r.y) && (p.y < r.y + r.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean intersect(Rectangle a, Rectangle b)
/*     */   {
/* 576 */     return intersectOrContain(a, b, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean contains(Rectangle a, Rectangle b)
/*     */   {
/* 586 */     return intersectOrContain(a, b, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean intersectOrContain(Rectangle a, Rectangle b, boolean requestFullInclusion)
/*     */   {
/* 598 */     int left0 = a.x;
/* 599 */     int right0 = a.x + a.width;
/* 600 */     int top0 = a.y;
/* 601 */     int bottom0 = a.y + a.height;
/*     */     
/* 603 */     int left1 = b.x;
/* 604 */     int right1 = b.x + b.width;
/* 605 */     int top1 = b.y;
/* 606 */     int bottom1 = b.y + b.height;
/*     */     
/*     */ 
/* 609 */     if ((left1 >= left0) && (right1 <= right0) && (top1 >= top0) && (bottom1 <= bottom0)) {
/* 610 */       return true;
/*     */     }
/*     */     
/* 613 */     if (requestFullInclusion) {
/* 614 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 618 */     left0 -= b.width;
/* 619 */     right0 += b.width;
/* 620 */     top0 -= b.height;
/* 621 */     bottom0 += b.height;
/* 622 */     if ((left1 > left0) && (right1 < right0) && (top1 > top0) && (bottom1 < bottom0)) {
/* 623 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 627 */     return false;
/*     */   }
/*     */   
/*     */   public static Point getRectangleCenter(Rectangle r) {
/* 631 */     return new Point(r.x + r.width / 2, r.y + r.height / 2);
/*     */   }
/*     */   
/*     */   public static String formatControlHierarchy(Control ctl) {
/* 635 */     String s = "";
/* 636 */     while (ctl != null) {
/* 637 */       s = ctl.getClass().getSimpleName() + " >> " + s;
/* 638 */       ctl = ctl.getParent();
/*     */     }
/* 640 */     return s;
/*     */   }
/*     */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\UIUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */