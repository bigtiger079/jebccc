/*    */ package com.pnfsoftware.jeb.rcpclient.extensions;
/*    */ 
/*    */ import com.pnfsoftware.jeb.util.logging.GlobalLog;
/*    */ import com.pnfsoftware.jeb.util.logging.ILogger;
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogDocument
/*    */   extends Document
/*    */ {
/* 23 */   private static final ILogger logger = GlobalLog.getLogger(LogDocument.class);
/*    */   
/*    */ 
/*    */   private int limit;
/*    */   
/*    */ 
/*    */   private int limitHalf;
/*    */   
/*    */ 
/*    */   public LogDocument(int limit)
/*    */   {
/* 34 */     this.limit = Math.max(0, limit);
/* 35 */     this.limitHalf = (limit / 2);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getLimit()
/*    */   {
/* 43 */     return this.limit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public synchronized void append(String additionString)
/*    */   {
/*    */     try
/*    */     {
/* 52 */       int addLen = additionString.length();
/* 53 */       int curLen = getLength();
/* 54 */       int hypLen = curLen + addLen;
/* 55 */       if ((this.limit > 0) && (hypLen > this.limit)) {
/* 56 */         if (addLen > this.limit) {
/* 57 */           String text = additionString.substring(addLen - this.limit, addLen);
/* 58 */           set(text);
/*    */         }
/* 60 */         else if (addLen > this.limitHalf) {
/* 61 */           set(additionString);
/*    */         }
/*    */         else {
/* 64 */           int r = this.limitHalf - addLen;
/* 65 */           String text = get(curLen - r, r) + additionString;
/* 66 */           set(text);
/*    */         }
/*    */       }
/*    */       else {
/* 70 */         replace(curLen, 0, additionString);
/*    */       }
/*    */     }
/*    */     catch (BadLocationException e) {
/* 74 */       logger.catching(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\tools\jeb32\jebc.jar!\com\pnfsoftware\jeb\rcpclient\extensions\LogDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */